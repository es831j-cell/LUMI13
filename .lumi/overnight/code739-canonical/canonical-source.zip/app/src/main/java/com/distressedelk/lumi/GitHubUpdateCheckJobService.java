package com.distressedelk.lumi;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Code389 R106: persisted discovery of owner-published Lumi update packages in the same
 * private GitHub repository used by the trusted build relay. Discovery/download is passive:
 * a package is never executed here. MainActivity hands the cached ZIP to LumiUpdateManager,
 * which requires Lumi's manifest signature before any remote package can be staged.
 */
public final class GitHubUpdateCheckJobService extends JobService {
    private static final int PERIODIC_JOB_ID=0x4C554D55;
    private static final int ONESHOT_JOB_ID=0x4C554D56;
    private static final long PERIOD_MS=15L*60L*1000L; // Android JobScheduler periodic minimum.
    private static final long FOREGROUND_DELAY_MS=12L*1000L;
    private static final long FOREGROUND_COOLDOWN_MS=2L*60L*1000L;

    static void schedulePeriodic(Context c){
        if(c==null) return;
        try{
            SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
            if(!TrustedBuildRelayClient.publishedUpdateChannelConfigured(p)) return;
            JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE); if(js==null)return;
            JobInfo job=new JobInfo.Builder(PERIODIC_JOB_ID,new ComponentName(c,GitHubUpdateCheckJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPersisted(true)
                    .setPeriodic(PERIOD_MS)
                    .build();
            int result=js.schedule(job);
            p.edit().putLong("code706_update_periodic_scheduled_at",System.currentTimeMillis())
                    .putInt("code706_update_periodic_schedule_result",result).apply();
        }catch(Throwable t){
            try{c.getSharedPreferences("lumi",Context.MODE_PRIVATE).edit()
                    .putString("code706_update_scheduler_error",t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage())).apply();}catch(Throwable ignored){}
        }
    }

    static void cancelOneShot(Context c){
        if(c==null)return;
        try{
            JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if(js!=null)js.cancel(ONESHOT_JOB_ID);
            c.getSharedPreferences("lumi",Context.MODE_PRIVATE).edit()
                    .putLong("code706_update_oneshot_cancelled_at",System.currentTimeMillis()).apply();
        }catch(Throwable ignored){}
    }

    static void scheduleNow(Context c,long delayMs){ scheduleNow(c,delayMs,"unspecified"); }

    static void scheduleForeground(Context c,String reason){
        if(c==null)return;
        try{
            SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
            if(!TrustedBuildRelayClient.publishedUpdateChannelConfigured(p))return;
            long now=System.currentTimeMillis();
            long last=p.getLong("code706_update_foreground_schedule_at",0L);
            if(last>0L && now-last<FOREGROUND_COOLDOWN_MS){
                p.edit().putLong("code706_update_foreground_coalesced_at",now)
                        .putString("code706_update_foreground_reason",reason==null?"foreground":reason).apply();
                return;
            }
            p.edit().putLong("code706_update_foreground_schedule_at",now)
                    .putString("code706_update_foreground_reason",reason==null?"foreground":reason).apply();
            scheduleNow(c,FOREGROUND_DELAY_MS,"foreground:"+(reason==null?"foreground":reason));
        }catch(Throwable ignored){}
    }

    static void scheduleNow(Context c,long delayMs,String reason){
        if(c==null) return;
        try{
            SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
            if(!TrustedBuildRelayClient.publishedUpdateChannelConfigured(p)) return;
            JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE); if(js==null)return;
            JobInfo job=new JobInfo.Builder(ONESHOT_JOB_ID,new ComponentName(c,GitHubUpdateCheckJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setMinimumLatency(Math.max(1000L,delayMs))
                    .setOverrideDeadline(Math.max(30000L,delayMs+60000L))
                    .build();
            int result=js.schedule(job);
            p.edit().putLong("code706_update_oneshot_scheduled_at",System.currentTimeMillis())
                    .putLong("code706_update_oneshot_delay_ms",Math.max(1000L,delayMs))
                    .putString("code706_update_oneshot_reason",reason==null?"unspecified":reason)
                    .putInt("code706_update_oneshot_schedule_result",result).apply();
        }catch(Throwable t){
            try{c.getSharedPreferences("lumi",Context.MODE_PRIVATE).edit()
                    .putString("code706_update_scheduler_error",t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage())).apply();}catch(Throwable ignored){}
        }
    }

    @Override public boolean onStartJob(JobParameters params){
        new Thread(() -> {
            SharedPreferences p=getSharedPreferences("lumi",MODE_PRIVATE);
            long started=System.currentTimeMillis();
            String kind=params!=null&&params.getJobId()==PERIODIC_JOB_ID?"periodic":"oneshot";
            p.edit().putLong("code706_update_job_started_at",started).putString("code706_update_job_kind",kind).apply();
            try{
                org.json.JSONObject r=TrustedBuildRelayClient.checkPublishedUpdate(this,p,true);
                String state=r.optString("state","UNKNOWN");
                long target=p.getLong("github_update_available_version",-1L);
                SharedPreferences.Editor e=p.edit().putLong("code706_update_job_finished_at",System.currentTimeMillis())
                        .putString("code706_update_job_state",state).putLong("code706_update_job_target",target)
                        .remove("code706_update_job_error");
                if("UPDATE_DOWNLOADED".equals(state)){
                    e.putBoolean("github_update_notice_pending",true)
                            .putLong("github_update_notice_target",target)
                            .putLong("code485_background_update_downloaded_at",System.currentTimeMillis())
                            .putLong("code485_background_update_target",target);
                }
                e.apply();
            }
            catch(Throwable t){
                p.edit().putString("github_update_check_state","CHECK_FAILED")
                        .putString("github_update_check_error",SecretStore.redact(t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage())))
                        .putLong("github_update_last_check_at",System.currentTimeMillis())
                        .putLong("code706_update_job_finished_at",System.currentTimeMillis())
                        .putString("code706_update_job_state","CHECK_FAILED")
                        .putString("code706_update_job_error",SecretStore.redact(t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()))).apply();
            }
            jobFinished(params,false);
        },"LumiGitHubUpdateCheck").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params){
        try{getSharedPreferences("lumi",MODE_PRIVATE).edit().putLong("code706_update_job_stopped_at",System.currentTimeMillis()).apply();}catch(Throwable ignored){}
        return true;
    }
}
