package com.distressedelk.lumi;

/**
 * Code624: single authoritative conversation phase + product-turn transaction ledger.
 * MainActivity and delegates may request transitions or finish a turn, but this object owns
 * the active turn id and its terminal outcome. UI/renderer code is observer-only.
 */
final class ConversationRuntimeState {
    enum State { IDLE, LISTENING, THINKING, SPEAKING, INTERRUPTED, STOPPED, RECOVERING }
    enum TurnTerminal { NONE, COMPLETE, FAILED, CANCELLED, TIMEOUT }

    private int generation=1;
    private State state=State.IDLE;
    private long changedAt=System.currentTimeMillis();
    private String reason="init";

    private long activeTurnId=0L;
    private long activeTurnStartedAt=0L;
    private String activeTurnSource="";
    private String activeTurnReason="";
    private long lastTurnId=0L;
    private TurnTerminal lastTurnTerminal=TurnTerminal.NONE;
    private String lastTurnRoute="";
    private String lastTurnReason="";
    private long lastTurnFinishedAt=0L;

    synchronized int newGeneration(State next,String why){
        generation++; if(generation<=0) generation=1;
        state=next==null?State.IDLE:next; changedAt=System.currentTimeMillis(); reason=why==null?"":why; return generation;
    }
    synchronized int transition(State next,String why){
        state=next==null?State.IDLE:next; changedAt=System.currentTimeMillis(); reason=why==null?"":why; return generation;
    }
    synchronized int generation(){return generation;}
    synchronized boolean current(int token){return token==generation;}
    synchronized State state(){return state;}
    synchronized long changedAt(){return changedAt;}
    synchronized String reason(){return reason;}

    synchronized void beginTurn(long id,String source,String why){
        if(id<=0L) return;
        long now=System.currentTimeMillis();
        if(activeTurnId>0L && activeTurnId!=id){
            settle(activeTurnId,TurnTerminal.CANCELLED,"","superseded by turn="+id,now);
        }
        activeTurnId=id; activeTurnStartedAt=now; activeTurnSource=source==null?"":source; activeTurnReason=why==null?"":why;
    }
    synchronized boolean finishTurn(long id,TurnTerminal terminal,String route,String why){
        if(id<=0L || terminal==null || terminal==TurnTerminal.NONE || activeTurnId!=id) return false;
        settle(id,terminal,route,why,System.currentTimeMillis()); return true;
    }
    synchronized boolean cancelActiveTurn(String why){
        if(activeTurnId<=0L) return false;
        settle(activeTurnId,TurnTerminal.CANCELLED,"",why,System.currentTimeMillis()); return true;
    }
    private void settle(long id,TurnTerminal terminal,String route,String why,long now){
        lastTurnId=id; lastTurnTerminal=terminal; lastTurnRoute=route==null?"":route; lastTurnReason=why==null?"":why; lastTurnFinishedAt=now;
        activeTurnId=0L; activeTurnStartedAt=0L; activeTurnSource=""; activeTurnReason="";
    }
    synchronized long activeTurnId(){return activeTurnId;}
    synchronized long activeTurnStartedAt(){return activeTurnStartedAt;}
    synchronized String activeTurnSource(){return activeTurnSource;}
    synchronized long lastTurnId(){return lastTurnId;}
    synchronized TurnTerminal lastTurnTerminal(){return lastTurnTerminal;}
    synchronized String lastTurnRoute(){return lastTurnRoute;}
    synchronized String lastTurnReason(){return lastTurnReason;}
    synchronized long lastTurnFinishedAt(){return lastTurnFinishedAt;}
    synchronized String snapshot(){return "generation="+generation+" state="+state+" ageMs="+Math.max(0L,System.currentTimeMillis()-changedAt)+" reason="+reason+" activeTurn="+activeTurnId+" lastTurn="+lastTurnId+" terminal="+lastTurnTerminal+" route="+lastTurnRoute;}
}
