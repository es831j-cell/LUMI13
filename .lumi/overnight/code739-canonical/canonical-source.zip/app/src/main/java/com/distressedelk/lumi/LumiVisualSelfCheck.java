package com.distressedelk.lumi;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.SurfaceView;
import android.view.View;

/** Code736: final visual gate using live framebuffer visibility plus the locked state-color contract. */
public final class LumiVisualSelfCheck {
    static final String REFERENCE_ID="owner-approved-r422-sha82108daed36f";
    private LumiVisualSelfCheck(){}
    public static String request(android.content.Context c,SharedPreferences p){
        if(c instanceof MainActivity){MainActivity a=(MainActivity)c;if(a.avatarSceneView!=null){schedule(a,a.avatarSceneView,p);return "SCHEDULED_CODE735_VISIBILITY_GATE";}}
        if(p!=null)p.edit().putBoolean("visual_self_check_foreground_required",true).putLong("visual_self_check_request_at",System.currentTimeMillis()).apply();
        return "FOREGROUND_REQUIRED";
    }
    public static void schedule(Activity a,View stage,SharedPreferences p){
        if(a==null||stage==null||p==null)return;
        LumiRendererControl.applyCode735VisibilityBaseline(a);
        p.edit().putString("visual_reference_truth","OWNER_REFERENCE_CONTEXT_ONLY_R445")
                .putString("visual_self_check_reference",REFERENCE_ID).putString("visual_self_check_status","SCHEDULED_CODE735")
                .putInt("visual_self_check_retry_count",0).putString("visual_self_check_step","SCHEDULED_VISIBLE_FRAMEBUFFER").putLong("visual_self_check_scheduled_at",System.currentTimeMillis()).apply();
        arm(stage,p);stage.postDelayed(()->capture(a,stage,p),1800L);
    }
    private static void arm(View stage,SharedPreferences p){p.edit().putBoolean("visual_self_check_calibration_pose",true).putLong("visual_self_check_pose_at",System.currentTimeMillis()).apply();if(stage instanceof LumiAvatarSceneView)((LumiAvatarSceneView)stage).requestModelRender();else stage.invalidate();}
    private static void capture(Activity a,View stage,SharedPreferences p){
        int w=stage.getWidth(),h=stage.getHeight();if(w<32||h<32){retryOrFail(a,stage,p,"STAGE_NOT_READY");return;}
        Bitmap actual=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        SurfaceView surface=stage instanceof LumiAvatarSceneView?((LumiAvatarSceneView)stage).captureSurface():null;
        if(surface!=null&&surface.getWidth()>0&&surface.getHeight()>0){
            try{PixelCopy.request(surface,actual,result->{if(result==PixelCopy.SUCCESS)finishCompare(a,stage,p,actual,"PIXELCOPY_PROCEDURAL_PRIMARY_R445");else{actual.recycle();retryOrFail(a,stage,p,"PIXELCOPY_"+result);}},new Handler(Looper.getMainLooper()));return;}
            catch(Throwable t){actual.recycle();retryOrFail(a,stage,p,"PIXELCOPY_"+t.getClass().getSimpleName());return;}
        }
        try{Canvas c=new Canvas(actual);c.drawColor(Color.BLACK);stage.draw(c);finishCompare(a,stage,p,actual,"FALLBACK_STAGE_DRAW_R445");}
        catch(Throwable t){actual.recycle();fail(p,"DRAW_"+t.getClass().getSimpleName());}
    }
    private static void finishCompare(Activity a,View stage,SharedPreferences p,Bitmap actual,String scope){
        try{
            Bitmap ref=reference(a,actual.getWidth(),actual.getHeight());
            Measure am=measure(actual), rm=ref==null?new Measure():measure(ref);
            if(ref!=null)ref.recycle();actual.recycle();
            float shapeDelta=shapeDelta(am,rm);
            boolean shaderOk=p.getBoolean("pyramid_shader_program_ok",false);
            boolean visible=shaderOk && am.occ>=3.0f && am.occ<=62f && am.luma>=14f && am.widthPct>=16f && am.heightPct>=24f && Math.abs(am.dx)<=18f && Math.abs(am.dy)<=18f;
            boolean paletteOk=statePaletteContractPass(p);
            boolean gatePass=visible&&paletteOk;
            String evidence="gatePass="+gatePass+", visible="+visible+", paletteOk="+paletteOk+", shaderOk="+shaderOk+", occ="+am.occ+", luma="+am.luma+", widthPct="+am.widthPct+", heightPct="+am.heightPct+", dx="+am.dx+", dy="+am.dy+", referenceShapeDelta="+shapeDelta;
            p.edit().putString("visual_self_check_status",gatePass?"PASS_CODE736_VISUAL_FINAL":"FAIL_CODE736_VISUAL_FINAL")
                    .putBoolean("visual_observation_capture_invalid",am.count==0).putFloat("visual_self_check_mismatch_pct",shapeDelta)
                    .putFloat("visual_self_check_actual_occupancy_pct",am.occ).putFloat("visual_self_check_reference_occupancy_pct",rm.occ)
                    .putFloat("visual_self_check_actual_luma",am.luma).putFloat("visual_self_check_reference_luma",rm.luma)
                    .putFloat("visual_self_check_bbox_width_delta_pct",Math.abs(am.widthPct-rm.widthPct)).putFloat("visual_self_check_bbox_height_delta_pct",Math.abs(am.heightPct-rm.heightPct))
                    .putFloat("visual_self_check_centroid_dx_pct",am.dx).putFloat("visual_self_check_centroid_dy_pct",am.dy)
                    .putString("visual_self_check_reference",REFERENCE_ID).putString("visual_self_check_step","VISUAL_FINAL_RESULT_R446")
                    .putString("visual_self_check_scope",scope).putString("visual_gate_r445",visible?"PASS":"FAIL")
                    .putBoolean("visual_state_palette_pass_r446",paletteOk).putString("visual_gate_r446",gatePass?"PASS":"FAIL")
                    .putLong("visual_self_check_at",System.currentTimeMillis()).apply();
            LumiEvidenceLedger.append(p,"VISUAL","VISUAL_FINALIZATION","render",evidence,"LumiVisualSelfCheck");
            LumiCoreSelfStateEngine.verifyVisualFinalization(p,gatePass,visible,paletteOk,am.occ,am.luma,am.widthPct,am.heightPct,am.dx,am.dy,shapeDelta);
            p.edit().putBoolean("visual_self_check_calibration_pose",false).apply();
            if(!gatePass)retryOrFail(a,stage,p,visible?"STATE_PALETTE_GATE_FAILED":"VISIBILITY_GATE_FAILED");
        }catch(Throwable t){fail(p,"COMPARE_"+t.getClass().getSimpleName());}
    }
    private static void retryOrFail(Activity a,View stage,SharedPreferences p,String why){
        int n=p.getInt("visual_self_check_retry_count",0)+1;
        if(n<=2){p.edit().putInt("visual_self_check_retry_count",n).putString("visual_self_check_status","RETRYING_VISIBLE_FRAMEBUFFER_R445").putString("visual_self_check_error",why).apply();if(stage instanceof LumiAvatarSceneView)((LumiAvatarSceneView)stage).requestModelRender();stage.postDelayed(()->capture(a,stage,p),800L*n);}else fail(p,why);
    }
    private static boolean statePaletteContractPass(SharedPreferences p){
        float lr=LumiRendererControl.value(p,"listenR",0f),lg=LumiRendererControl.value(p,"listenG",0f),lb=LumiRendererControl.value(p,"listenB",0f);
        float tr=LumiRendererControl.value(p,"thinkR",0f),tg=LumiRendererControl.value(p,"thinkG",0f),tb=LumiRendererControl.value(p,"thinkB",0f);
        float sr=LumiRendererControl.value(p,"speakR",0f),sg=LumiRendererControl.value(p,"speakG",0f),sb=LumiRendererControl.value(p,"speakB",0f);
        boolean listen=lg>=.24f&&lg>=lr*4f&&lg>=lb*2f;
        boolean think=tr>=.45f&&tr>=tg*5f&&tr>=tb*4f;
        boolean speak=sb>=.45f&&sb>=sg*4f&&sb>=sr*1.35f;
        return listen&&think&&speak&&p.getBoolean("renderer_code736_visual_final_applied",false);
    }
    private static Bitmap reference(Activity a,int w,int h){
        try{Bitmap src=BitmapFactory.decodeResource(a.getResources(),R.drawable.lumi_visual_owner_reference_r422);if(src==null)return null;Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(out);c.drawColor(Color.BLACK);float scale=Math.min(w/(float)src.getWidth(),h/(float)src.getHeight());int dw=Math.max(1,Math.round(src.getWidth()*scale)),dh=Math.max(1,Math.round(src.getHeight()*scale));int left=(w-dw)/2,top=(h-dh)/2;c.drawBitmap(src,null,new Rect(left,top,left+dw,top+dh),null);src.recycle();return out;}catch(Throwable t){return null;}
    }
    private static boolean fg(int c){int r=Color.red(c),g=Color.green(c),b=Color.blue(c),mx=Math.max(r,Math.max(g,b)),mn=Math.min(r,Math.min(g,b));return mx>=42&&(mx-mn>=7||mx>=78);}
    private static float luma(int c){return .2126f*Color.red(c)+.7152f*Color.green(c)+.0722f*Color.blue(c);}
    private static Measure measure(Bitmap b){
        Measure m=new Measure();if(b==null)return m;int w=b.getWidth(),h=b.getHeight(),step=Math.max(2,Math.min(w,h)/320);long samples=0,sx=0,sy=0;double lum=0;int minx=w,miny=h,maxx=-1,maxy=-1;
        for(int y=0;y<h;y+=step)for(int x=0;x<w;x+=step){samples++;int c=b.getPixel(x,y);if(!fg(c))continue;m.count++;sx+=x;sy+=y;lum+=luma(c);minx=Math.min(minx,x);maxx=Math.max(maxx,x);miny=Math.min(miny,y);maxy=Math.max(maxy,y);}
        m.occ=samples==0?0f:100f*m.count/samples;m.luma=m.count==0?0f:(float)(lum/m.count);float bw=maxx>=minx?maxx-minx+1:0,bh=maxy>=miny?maxy-miny+1:0;m.widthPct=100f*bw/Math.max(1,w);m.heightPct=100f*bh/Math.max(1,h);float cx=m.count==0?w/2f:sx/(float)m.count,cy=m.count==0?h/2f:sy/(float)m.count;m.dx=100f*(cx-w/2f)/Math.max(1,w);m.dy=100f*(cy-h/2f)/Math.max(1,h);m.aspect=bh<=0?0f:bw/bh;return m;
    }
    private static float shapeDelta(Measure a,Measure r){if(a.count==0||r.count==0||r.aspect<=0)return 100f;return Math.min(100f,100f*Math.abs(a.aspect-r.aspect)/Math.max(.01f,r.aspect));}
    private static void fail(SharedPreferences p,String why){p.edit().putBoolean("visual_self_check_calibration_pose",false).putString("visual_self_check_status","RAW_CAPTURE_FAILURE_R445").putString("visual_gate_r445","FAIL").putString("visual_gate_r446","FAIL").putString("visual_self_check_error",why).putLong("visual_self_check_at",System.currentTimeMillis()).apply();LumiCoreSelfStateEngine.recordVisualCaptureFailure(p,why);}
    private static final class Measure{long count;float occ,luma,widthPct,heightPct,dx,dy,aspect;}
}
