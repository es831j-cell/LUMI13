package com.distressedelk.lumi;
import android.content.SharedPreferences;
final class LumiSourceCorrectionManifest{
 private LumiSourceCorrectionManifest(){}
 private static final String[] IDS={"CORE-REPAIR-BYPASS","FALSE-PASS-PROXIES","DEPENDENCY-TRACE-SEMANTICS","RENDERER-AUTONOMY-TRAPDOOR","SOURCE-LIFECYCLE-NO-CALLER"};
 static void apply(SharedPreferences p){if(p==null)return;int build=p.getInt("lumi_core_evidence_build",p.getInt("lumi_self_governance_build",0));if(build<=0)build=737;for(String id:IDS)LumiSourceCorrectionRegistry.markFixedInSource(p,id,build);}
}
