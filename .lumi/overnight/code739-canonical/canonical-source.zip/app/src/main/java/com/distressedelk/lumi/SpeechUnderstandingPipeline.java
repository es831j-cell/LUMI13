package com.distressedelk.lumi;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Code403 cheap, on-device transcript repair. It never grants identity or authority.
 * It only rescues high-confidence conversational wording, especially Lumi's wake name. */
final class SpeechUnderstandingPipeline {
    private SpeechUnderstandingPipeline(){}
    static float wakeAffinity(String raw){
        String x=norm(raw);
        if(x.matches("^(hey|hi|hello|good morning|good afternoon|good evening) (lumi|loomi|lumie|loony|looney|larry)( .*)?$")) return 4.5f;
        if(x.matches("^(hey|hi|hello) i love me( .*)?$")) return 4.0f;
        return 0f;
    }
    static String normalize(String winner,List<String> alternatives,String recentContext){
        String w=winner==null?"":winner.trim(); if(w.isEmpty()) return w;
        String repaired=repairWake(w);
        if(!repaired.equals(w)) return repaired;
        if(alternatives!=null){
            for(String a:alternatives){
                if(a==null)continue;
                if(norm(a).contains("lumi") && wakeAffinity(a)>0f) return repairWake(a.trim());
            }
        }
        return w;
    }
    private static String repairWake(String raw){
        String x=norm(raw);
        String[] starters={"hey ","hi ","hello ","good morning ","good afternoon ","good evening "};
        for(String s:starters){
            if(x.startsWith(s)){
                String rest=x.substring(s.length());
                String[] bad={"larry","loomi","lumie","loony","looney","i love me"};
                for(String b:bad){
                    if(rest.equals(b) || rest.startsWith(b+" ")){
                        int cut=s.length()+b.length();
                        String suffix=x.length()>cut?x.substring(cut):"";
                        return (s+"lumi"+suffix).trim();
                    }
                }
            }
        }
        return raw;
    }
    private static String norm(String s){
        return s==null?"":s.toLowerCase(Locale.US).replaceAll("[^a-z0-9' ]"," ").replaceAll("\\s+"," ").trim();
    }
}
