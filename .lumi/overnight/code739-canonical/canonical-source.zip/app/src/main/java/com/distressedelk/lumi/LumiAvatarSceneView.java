package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.SurfaceView;
import android.widget.FrameLayout;

/** Code718: stable procedural visual is primary; corrupt Code717 Filament surface is quarantined. */
public final class LumiAvatarSceneView extends FrameLayout {
    public static final String SCENE_ID=LumiAvatarForge.SCENE_ID;
    public static final String MODEL_ID="lumi_pyramid_r422.glb";
    private final SharedPreferences prefs;
    private final Context hostContext;
    private LumiPyramid3DView proceduralView;
    private boolean code721VisualCheckScheduled=false;

    public LumiAvatarSceneView(Context context){
        super(context);
        hostContext=context;
        prefs=context.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        LumiAvatarForge.ensureBaseline(context);
        LumiRendererControl.applyCode735VisibilityBaseline(context);
        LumiRendererControl.applyCode736VisualFinalBaseline(context);
        setBackgroundColor(Color.TRANSPARENT);
        activateProceduralPrimary(context,"CODE717_PHONE_FRAMEBUFFER_CORRUPTION");
        record("constructed");
    }

    private void activateProceduralPrimary(Context context,String why){
        try{removeAllViews();}catch(Throwable ignored){}
        proceduralView=new LumiPyramid3DView(context);
        addView(proceduralView,new FrameLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT));
        SharedPreferences.Editor e=prefs.edit()
                .putBoolean("avatar_forge_pbr_quarantined",true)
                .putString("avatar_forge_pbr_quarantine_reason",why==null?"CODE718_RENDERER_QUARANTINE":why)
                .putLong("avatar_forge_pbr_quarantined_at",System.currentTimeMillis())
                .putBoolean("avatar_forge_fallback_active",false)
                .putString("visual_model_mounted_class",proceduralView.getClass().getName())
                .putString("avatar_forge_runtime","PROCEDURAL_PRIMARY_CODE718")
                .putString("visual_core_renderer","procedural-pyramid-r338")
                .putString("visual_renderer_authority","CODE718_STABLE_PROCEDURAL_PRIMARY")
                .putBoolean("code718_visual_renderer_recovery_applied",true)
                .putString("visual_renderer_boot_state","CODE736_VISUAL_FINAL_PRIMARY")
                .putLong("visual_renderer_boot_at",System.currentTimeMillis());
        e.apply();
    }

    private void record(String state){
        prefs.edit().putString("visual_scene_id",SCENE_ID).putString("visual_scene_mounted_class",getClass().getName())
                .putString("visual_scene_state",state).putBoolean("visual_legacy_red_contract_blocked",false)
                .putLong("visual_scene_event_at",System.currentTimeMillis()).apply();
    }

    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();record("attached");}
    @Override protected void onDetachedFromWindow(){record("detached");super.onDetachedFromWindow();}
    public void setVisualState(LumiPyramid3DView.VisualState state){if(proceduralView!=null)proceduralView.setVisualState(state);}
    public void onHostForeground(){
        record("foreground");
        if(proceduralView!=null)proceduralView.onHostForeground();
        if(!code721VisualCheckScheduled && hostContext instanceof android.app.Activity){
            code721VisualCheckScheduled=true;
            prefs.edit().putInt("code721_visual_autocheck_release",721).putString("visual_self_check_status","SCHEDULED_CODE721_AUTOCHECK").apply();
            LumiVisualSelfCheck.schedule((android.app.Activity)hostContext,this,prefs);
        }
    }
    public void onHostBackground(){record("background");if(proceduralView!=null)proceduralView.onHostBackground();}
    public void onResume(){record("resumed");if(proceduralView!=null)proceduralView.onResume();}
    public void forceMaintenanceRecovery(){record("maintenance-recovery");if(proceduralView!=null)proceduralView.forceMaintenanceRecovery();}
    public void applyCommittedVisualState(){if(proceduralView!=null)proceduralView.requestRender();}
    public void requestModelRender(){if(proceduralView!=null)proceduralView.requestRender();}
    public void reloadAvatarModel(){if(proceduralView!=null)proceduralView.forceMaintenanceRecovery();}
    public SurfaceView captureSurface(){return proceduralView;}
    public String diagnosticSnapshot(){return "scene="+SCENE_ID+" • authority=CODE718_STABLE_PROCEDURAL_PRIMARY • pbrQuarantined=true • "+(proceduralView==null?"no-model":proceduralView.diagnosticSnapshot());}
}
