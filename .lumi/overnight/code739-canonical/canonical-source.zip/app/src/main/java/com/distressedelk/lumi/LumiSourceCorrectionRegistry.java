package com.distressedelk.lumi;
import android.content.SharedPreferences;import org.json.*;import java.util.*;
final class LumiSourceCorrectionRegistry{
 private static final String KEY="lumi_source_correction_registry_v2";private LumiSourceCorrectionRegistry(){}
 static synchronized void upsert(SharedPreferences p,String id,String capability,String severity,String evidence,String desired,String rootCause,String sourceArea,String whyRuntimeInsufficient,String proposed,String acceptance,String blockedBy){if(p==null||id==null||id.trim().isEmpty())return;try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));JSONObject o=null;int idx=-1;for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);if(id.equals(x.optString("id"))){o=x;idx=i;break;}}if(o==null)o=new JSONObject();o.put("id",id).put("state","OPEN").put("capability",safe(capability)).put("severity",safe(severity)).put("evidence",safe(evidence)).put("desiredStateViolation",safe(desired)).put("rootCause",safe(rootCause)).put("sourceArea",safe(sourceArea)).put("whyRuntimeInsufficient",safe(whyRuntimeInsufficient)).put("proposedCorrection",safe(proposed)).put("acceptanceTest",safe(acceptance)).put("blockedDependencies",safe(blockedBy)).put("buildFound",currentBuild(p)).put("updatedAt",System.currentTimeMillis());if(!o.has("createdAt"))o.put("createdAt",System.currentTimeMillis());JSONArray b=new JSONArray();if(idx<0){for(int i=0;i<a.length();i++)b.put(a.getJSONObject(i));b.put(o);}else for(int i=0;i<a.length();i++)b.put(i==idx?o:a.getJSONObject(i));persist(p,b);}catch(Throwable ignored){}}
 static synchronized void markFixedInSource(SharedPreferences p,String id,int build){
  if(p==null||id==null||id.trim().isEmpty())return;
  try{
    JSONArray a=new JSONArray(p.getString(KEY,"[]"));JSONObject target=null;
    for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(id.equals(o.optString("id"))){target=o;break;}}
    if(target==null){
      target=new JSONObject();target.put("id",id).put("capability",capabilityForManifestId(id)).put("severity","HIGH")
       .put("evidence","Cold audit identified a source-level intent gap")
       .put("desiredStateViolation","Lumi intent contract was not fully satisfied")
       .put("rootCause","Legacy or incomplete authority path required source migration")
       .put("sourceArea","Code735 dependency + visual closure")
       .put("whyRuntimeInsufficient","The correction required source/build changes")
       .put("proposedCorrection","Applied by the current signed source-correction manifest")
       .put("acceptanceTest",acceptanceForManifestId(id)).put("blockedDependencies","")
       .put("buildFound",725).put("createdAt",System.currentTimeMillis());a.put(target);
    }
    if(!"CLOSED_VERIFIED".equals(target.optString("state"))){target.put("state","FIXED_IN_SOURCE").put("fixedInBuild",build).put("updatedAt",System.currentTimeMillis());}
    persist(p,a);
  }catch(Throwable ignored){}
 }
 private static String capabilityForManifestId(String id){
  if("CORE-REPAIR-BYPASS".equals(id))return "MAINTENANCE";
  if("FALSE-PASS-PROXIES".equals(id))return "SELF";
  if("DEPENDENCY-TRACE-SEMANTICS".equals(id))return "DEPENDENCIES";
  if("RENDERER-AUTONOMY-TRAPDOOR".equals(id))return "VISUAL";
  if("SOURCE-LIFECYCLE-NO-CALLER".equals(id))return "SOURCE_CORRECTION";
  return "SELF";
 }
 private static String acceptanceForManifestId(String id){
  if("CORE-REPAIR-BYPASS".equals(id))return "Repair request is Core-planned, actuator rejects unplanned calls, and before/after verification passes";
  if("FALSE-PASS-PROXIES".equals(id))return "Governed domains remain UNKNOWN until named fresh acceptance evidence exists";
  if("DEPENDENCY-TRACE-SEMANTICS".equals(id))return "Dependency validator rejects invalid destinations, orphans and cycles and Core uses verified dependencies";
  if("RENDERER-AUTONOMY-TRAPDOOR".equals(id))return "No renderer path can independently enable autonomous tuning or declare final visual health";
  if("SOURCE-LIFECYCLE-NO-CALLER".equals(id))return "Correction progresses FIXED_IN_SOURCE to INSTALLED_AWAITING_ACCEPTANCE and only then CLOSED_VERIFIED";
  return "Installed build passes its declared acceptance test";
 }
 static synchronized void closeCurrentRuntimeVerified(SharedPreferences p,String id,String evidence){if(p==null||id==null||id.trim().isEmpty())return;try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));int build=currentBuild(p);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(!id.equals(o.optString("id")))continue;String st=o.optString("state","OPEN");if("CLOSED_VERIFIED".equals(st))continue;if("OPEN".equals(st)){o.put("state","FIXED_IN_SOURCE").put("fixedInBuild",build).put("updatedAt",System.currentTimeMillis());st="FIXED_IN_SOURCE";}if("FIXED_IN_SOURCE".equals(st)){o.put("state","INSTALLED_AWAITING_ACCEPTANCE").put("installedAt",System.currentTimeMillis());st="INSTALLED_AWAITING_ACCEPTANCE";}if("INSTALLED_AWAITING_ACCEPTANCE".equals(st))o.put("state","CLOSED_VERIFIED").put("verificationEvidence",safe(evidence)).put("closedAt",System.currentTimeMillis()).put("closedInBuild",build);}persist(p,a);}catch(Throwable ignored){}}
 static synchronized void closeVerified(SharedPreferences p,String id,String evidence){try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(id.equals(o.optString("id"))){String state=o.optString("state","OPEN");if("INSTALLED_AWAITING_ACCEPTANCE".equals(state)){o.put("state","CLOSED_VERIFIED").put("verificationEvidence",safe(evidence)).put("closedAt",System.currentTimeMillis()).put("closedInBuild",currentBuild(p));}else{o.put("acceptanceEvidenceObserved",safe(evidence)).put("acceptanceBlockedReason","must progress FIXED_IN_SOURCE -> INSTALLED_AWAITING_ACCEPTANCE before closure").put("updatedAt",System.currentTimeMillis());}}}persist(p,a);}catch(Throwable ignored){}}
 static synchronized void reconcileInstalledBuild(SharedPreferences p,int installed){try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if("FIXED_IN_SOURCE".equals(o.optString("state"))&&o.optInt("fixedInBuild",Integer.MAX_VALUE)<=installed)o.put("state","INSTALLED_AWAITING_ACCEPTANCE").put("installedAt",System.currentTimeMillis());}persist(p,a);}catch(Throwable ignored){}}
 static int openCount(SharedPreferences p){try{return openCount(new JSONArray(p.getString(KEY,"[]")));}catch(Throwable t){return 0;}}
 static synchronized boolean isClosed(SharedPreferences p,String id){try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(id.equals(o.optString("id")))return "CLOSED_VERIFIED".equals(o.optString("state"));}}catch(Throwable ignored){}return false;}
 static boolean hasOpen(SharedPreferences p){return openCount(p)>0;}
 static int activeDefectCount(SharedPreferences p){try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));int n=0;Set<String> ids=new HashSet<>();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if("OPEN".equals(o.optString("state"))&&ids.add(o.optString("id")))n++;}return n;}catch(Throwable t){return 0;}}
 static int pendingAcceptanceCount(SharedPreferences p){try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));int n=0;Set<String> ids=new HashSet<>();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String st=o.optString("state");if(("FIXED_IN_SOURCE".equals(st)||"INSTALLED_AWAITING_ACCEPTANCE".equals(st))&&ids.add(o.optString("id")))n++;}return n;}catch(Throwable t){return 0;}}
 private static int openCount(JSONArray a)throws Exception{Set<String> ids=new HashSet<>();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(!"CLOSED_VERIFIED".equals(o.optString("state")))ids.add(o.optString("id"));}return ids.size();}
 static String summary(SharedPreferences p,boolean detail){try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));int count=openCount(a),critical=0,high=0,other=0;StringBuilder items=new StringBuilder();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if("CLOSED_VERIFIED".equals(o.optString("state")))continue;String sev=o.optString("severity","MEDIUM").toUpperCase(Locale.US);if("CRITICAL".equals(sev))critical++;else if("HIGH".equals(sev))high++;else other++;if(detail){if(items.length()>0)items.append("; ");items.append(o.optString("id")).append('[').append(o.optString("state")).append("] ").append(o.optString("capability")).append(": ").append(o.optString("proposedCorrection"));}}String s="I have "+count+" open source/core-update corrections: "+critical+" critical, "+high+" high, "+other+" other.";return detail&&items.length()>0?s+" "+items:s;}catch(Throwable t){return "Source-correction count is UNKNOWN.";}}
 private static void mutate(SharedPreferences p,String id,String state,String key,String value){try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(id.equals(o.optString("id")))o.put("state",state).put(key,value).put("updatedAt",System.currentTimeMillis());}persist(p,a);}catch(Throwable ignored){}}
 private static void persist(SharedPreferences p,JSONArray a)throws Exception{p.edit().putString(KEY,a.toString()).putInt("lumi_source_correction_open_count",openCount(a)).putLong("lumi_source_correction_at",System.currentTimeMillis()).apply();}
 private static int currentBuild(SharedPreferences p){int b=p==null?0:p.getInt("lumi_core_evidence_build",p.getInt("lumi_self_governance_build",0));return b>0?b:737;}
 private static String safe(String s){return s==null?"":s;}
}
