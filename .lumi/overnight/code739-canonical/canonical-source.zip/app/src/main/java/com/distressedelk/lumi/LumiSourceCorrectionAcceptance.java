package com.distressedelk.lumi;
import android.content.SharedPreferences;
final class LumiSourceCorrectionAcceptance{
 private LumiSourceCorrectionAcceptance(){}
 static void closeVerifiedFromAcceptance(SharedPreferences p,String id,String evidence){
  if(p==null||id==null||id.trim().isEmpty())return;
  LumiSourceCorrectionRegistry.closeCurrentRuntimeVerified(p,id,evidence);
 }
 private static boolean backed(SharedPreferences p,String d){
  if("self".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"SELF","purposeLoaded=true","coreAuthorityBound=true");
  if("dependencies".equals(d))return p.getInt("lumi_dependency_graph_issue_count",-1)==0&&"GRAPH_VERIFIED".equals(p.getString("lumi_dependency_graph_state",""));
  if("ui".equals(d)){long at=p.getLong("lumi_ui_verify_at",0L);return at>LumiEvidenceLedger.invalidatedAt(p,"UI")&&LumiEvidenceLedger.verificationAfterInvalidation(p,"UI",at,"unresolved=");}
  if("voice".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"VOICE","sttCommit=*","ttsReplyCompleted=true","postTtsRecognizerReady=true");
  if("audio".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"AUDIO","focusGranted=true","routeObserved=*","ttsOutputCompleted=true","focusReleased=true","postTtsInputReady=true");
  if("visual".equals(d)){long at=p.getLong("lumi_visual_core_verify_at",0L);return at>LumiEvidenceLedger.invalidatedAt(p,"VISUAL")&&LumiEvidenceLedger.verificationAfterInvalidation(p,"VISUAL",at,"render=");}
  if("update".equals(d))return LumiDependencyGraph.currentUpdateReady(p);
  if("identity".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"IDENTITY","ownerAuthorityVerified=true","uncertainSpeakerDenied=true");
  if("providers".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"PROVIDERS","delegateSucceeded=true","coreFinalDecision=true");
  if("memory".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"MEMORY","writeVerified=true","recallVerified=true","provenanceVerified=true","currentBuildPrecedence=true");
  if("maintenance".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"MAINTENANCE","corePlanAuthorized=true","actuatorCompleted=true","repairAcceptancePassed=true");
  if("security".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"SECURITY","ownerAuthorityIntact=true","signingContinuityVerified=true","recoveryControlsVerified=true");
  if("truth".equals(d))return LumiEvidenceLedger.correlatedOrderedSinceInvalidation(p,"TRUTH","coreSoleFinalAuthority=true","noEvidenceIsUnknown=true");
  if("source_correction".equals(d))return !LumiSourceCorrectionRegistry.hasOpen(p);return false;}
 static void reconcile(SharedPreferences p){if(p==null)return;
  boolean repair=backed(p,"maintenance");if(repair)LumiSourceCorrectionRegistry.closeVerified(p,"CORE-REPAIR-BYPASS","correlated Core plan -> actuator completion -> Core acceptance observed");
  boolean guarded=p.getBoolean("lumi_truth_guard_r447",false);if(guarded)LumiSourceCorrectionRegistry.closeVerified(p,"FALSE-PASS-PROXIES","R447 truth guard installed: unproven domains remain UNKNOWN/VERIFYING and are never promoted by activity/configuration alone");
  if(backed(p,"dependencies"))LumiSourceCorrectionRegistry.closeVerified(p,"DEPENDENCY-TRACE-SEMANTICS","Dependency topology is GRAPH_VERIFIED with zero structural findings; runtime acceptance coverage is reported separately");
  boolean renderer=!p.getBoolean("renderer_autotune_enabled",false)&&p.getString("renderer_visual_authority","").startsWith("LUMI_CORE_");if(renderer)LumiSourceCorrectionRegistry.closeVerified(p,"RENDERER-AUTONOMY-TRAPDOOR","Renderer autonomy disabled and Core authority active");
  boolean all=LumiSourceCorrectionRegistry.isClosed(p,"CORE-REPAIR-BYPASS")&&LumiSourceCorrectionRegistry.isClosed(p,"FALSE-PASS-PROXIES")&&LumiSourceCorrectionRegistry.isClosed(p,"DEPENDENCY-TRACE-SEMANTICS")&&LumiSourceCorrectionRegistry.isClosed(p,"RENDERER-AUTONOMY-TRAPDOOR");if(all)LumiSourceCorrectionRegistry.closeVerified(p,"SOURCE-LIFECYCLE-NO-CALLER","Runtime acceptance reconciler closed every governed correction");}
}
