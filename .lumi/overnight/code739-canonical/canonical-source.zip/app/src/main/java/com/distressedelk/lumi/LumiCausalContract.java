package com.distressedelk.lumi;

import java.util.HashSet;
import java.util.Set;

/** Pure-Java executable contract for Code651 causal truth. */
final class LumiCausalContract {
    enum Terminal { OPEN, SUCCESS, FAILED, TIMEOUT, CANCELLED, SUPERSEDED }

    private LumiCausalContract(){}

    static boolean isClosed(Terminal t){ return t!=null && t!=Terminal.OPEN; }

    static Terminal terminal(String raw){
        if(raw==null)return Terminal.FAILED;
        String s=raw.trim().toUpperCase(java.util.Locale.US);
        if("COMPLETE".equals(s)||"SUCCESS".equals(s)||"SATISFIED".equals(s)||"ANSWERED".equals(s))return Terminal.SUCCESS;
        if("TIMEOUT".equals(s))return Terminal.TIMEOUT;
        if("CANCELLED".equals(s)||"CANCELED".equals(s))return Terminal.CANCELLED;
        if("SUPERSEDED".equals(s))return Terminal.SUPERSEDED;
        return Terminal.FAILED;
    }

    static String contractFailure(){
        if(terminal("COMPLETE")!=Terminal.SUCCESS)return "COMPLETE must map to SUCCESS";
        if(terminal("FAILED")!=Terminal.FAILED)return "FAILED must remain FAILED";
        if(terminal("TIMEOUT")!=Terminal.TIMEOUT)return "TIMEOUT must remain TIMEOUT";
        if(terminal("CANCELLED")!=Terminal.CANCELLED)return "CANCELLED must remain CANCELLED";
        if(terminal("SUPERSEDED")!=Terminal.SUPERSEDED)return "SUPERSEDED must remain SUPERSEDED";
        if(isClosed(Terminal.OPEN))return "OPEN may never satisfy a trace";
        Set<Terminal> allowed=new HashSet<Terminal>();
        allowed.add(Terminal.SUCCESS);allowed.add(Terminal.FAILED);allowed.add(Terminal.TIMEOUT);
        allowed.add(Terminal.CANCELLED);allowed.add(Terminal.SUPERSEDED);
        if(allowed.size()!=5)return "terminal set incomplete";
        return "";
    }

    static boolean contractSelfTest(){ return contractFailure().isEmpty(); }
}
