package com.distressedelk.lumi;

/** Code403 pre-TTS phrasing pass. Deliberately cheap: no model/network call is introduced. */
final class ConversationalSpeechPlanner {
    private ConversationalSpeechPlanner(){}
    static String prepare(String text){
        if(text==null)return "";
        String s=text.trim();
        s=s.replaceAll("(?m)^[-–—]\\s+"," ");
        s=s.replaceAll("\\s*\\n+\\s*",". ");
        s=s.replaceAll("\\s+"," ").trim();
        s=s.replaceAll("\\.\\s*\\.",".");
        s=s.replaceAll("\\s+([,.;!?])","$1");
        // Give Android TTS clearer thought boundaries without SSML or a network voice service.
        s=s.replace("; ",". ");
        s=s.replace(" -- ",", ");
        return s;
    }
}
