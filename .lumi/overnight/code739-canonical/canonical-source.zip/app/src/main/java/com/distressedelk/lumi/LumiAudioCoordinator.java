package com.distressedelk.lumi;

/**
 * Code466 audit boundary for TTS/audio coordination.
 * Phase 1 is behavior-preserving: it projects the authoritative Core2 runtime into one audio
 * ownership surface so TTS, focus, STOP and post-TTS handoff can migrate here next.
 */
final class LumiAudioCoordinator {
    static final String MARKER = "CORE2_AUDIO_COORDINATOR_BOUNDARY";

    static final class Snapshot {
        final long sequence;
        final boolean speaking;
        final boolean interruptedOrStopped;
        final String reason;
        Snapshot(long sequence, boolean speaking, boolean interruptedOrStopped, String reason){
            this.sequence=sequence;
            this.speaking=speaking;
            this.interruptedOrStopped=interruptedOrStopped;
            this.reason=reason==null?"":reason;
        }
        String compact(){ return "seq="+sequence+" speaking="+speaking+" interruptedOrStopped="+interruptedOrStopped+" reason="+reason; }
    }

    private long sequence=0L;
    private Snapshot latest=new Snapshot(0L,false,false,"init");

    synchronized Snapshot observe(LumiRuntimeController.Snapshot runtime, String reason){
        LumiRuntimeController.State state=runtime==null?LumiRuntimeController.State.IDLE:runtime.authoritative;
        boolean speaking=state==LumiRuntimeController.State.SPEAKING;
        boolean interrupted=state==LumiRuntimeController.State.INTERRUPTED || state==LumiRuntimeController.State.STOPPED;
        latest=new Snapshot(++sequence,speaking,interrupted,reason);
        return latest;
    }

    synchronized Snapshot latest(){ return latest; }
}
