package com.distressedelk.lumi;

import android.content.Intent;
import android.speech.RecognitionService;
import android.speech.SpeechRecognizer;

/** RecognitionService required by Android assistant-role qualification.
 * Lumi's interactive speech stack remains authoritative; this service is a system-facing adapter. */
public final class LumiRecognitionService extends RecognitionService {
    @Override
    protected void onStartListening(Intent recognizerIntent, Callback listener) {
        // The existing Lumi recognizer owns interactive capture. Avoid starting a second microphone owner.
        try {
            listener.error(SpeechRecognizer.ERROR_RECOGNIZER_BUSY);
        } catch (android.os.RemoteException ignored) {
            // Client disappeared before callback delivery. Nothing to clean up in this stateless adapter.
        }
    }

    @Override
    protected void onStopListening(Callback listener) {
        // Stateless adapter; no secondary recognizer is left running.
    }

    @Override
    protected void onCancel(Callback listener) {
        // Stateless adapter; no secondary recognizer is left running.
    }
}
