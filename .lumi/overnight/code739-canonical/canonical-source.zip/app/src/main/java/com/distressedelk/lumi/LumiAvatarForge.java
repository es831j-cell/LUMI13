package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Locale;

/** Code735: Lumi-Core-owned visibility gate; one committed state is applied by the live renderer. */
final class LumiAvatarForge {
    static final String FORGE_ID="avatar-forge-r445";
    static final String SCENE_ID="avatar-forge-scene-r445";
    static final String RENDERER_ID="filament-pbr-1.75.1";
    static final String BUNDLED_MODEL="avatar/lumi_pyramid_r422.glb";
    static final String BUNDLED_MODEL_ID="lumi_pyramid_r422.glb";
    static final String BUNDLED_SHA256="44f1bdb65d97137bd85912d403202fb473680d83ccb1a7c3df06597022d5b573";
    static final String REFERENCE_SHA256="82108daed36f6f0b3ad1e6ac4eb40bf53397b346f56d211ad5098da018acd87e";
    static final String CALIBRATION_SHA256="60feda73ce21d3947c8c4a856f721e9c8f3065e6069559ddb8b5f6e03dd970cf";
    static final long MAX_MODEL_BYTES=24L*1024L*1024L;
    private static final String EXTERNAL_REL="lumi_updates/assets/avatar-forge/active.glb";
    private LumiAvatarForge(){}

    static void ensureBaseline(Context c){
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        SharedPreferences.Editor e=p.edit()
                .putString("renderer_visual_authority","LUMI_CORE_AVATAR_FORGE")
                .putString("visual_scene_id",SCENE_ID)
                .putString("visual_core_renderer",RENDERER_ID)
                .putString("visual_palette_contract","MUTED_FOREST_PBR_R424")
                .putBoolean("visual_legacy_red_contract_blocked",true)
                .putString("avatar_forge_id",FORGE_ID)
                .putString("avatar_forge_reference_sha256",REFERENCE_SHA256)
                .putString("avatar_forge_calibration_sha256",CALIBRATION_SHA256)
                .putString("avatar_forge_bundled_sha256",BUNDLED_SHA256)
                .putBoolean("renderer_autotune_enabled",false);
        if(!p.contains("avatar_forge_camera_focal_mm")) e.putFloat("avatar_forge_camera_focal_mm",34f);
        if(!p.contains("avatar_forge_exposure_iso")) e.putFloat("avatar_forge_exposure_iso",50f);
        if(!p.contains("avatar_forge_committed_focal_mm")) e.putFloat("avatar_forge_committed_focal_mm",34f);
        if(!p.contains("avatar_forge_committed_iso")) e.putFloat("avatar_forge_committed_iso",50f);
        if(!p.contains("avatar_forge_committed_light_intensity")) e.putFloat("avatar_forge_committed_light_intensity",12000f);
        // Code714: one-time visual-gate migration. Stop the Code713 ISO/focal chase and
        // give Lumi Core one committed camera/light state that the renderer must apply verbatim.
        if(!p.getBoolean("avatar_forge_r424_migrated",false)){
            e.putBoolean("avatar_forge_r424_migrated",true)
             .putFloat("avatar_forge_committed_focal_mm",34f)
             .putFloat("avatar_forge_committed_iso",50f)
             .putFloat("avatar_forge_committed_light_intensity",12000f)
             .putFloat("avatar_forge_camera_focal_mm",34f)
             .putFloat("avatar_forge_exposure_iso",50f)
             .putInt("avatar_forge_tune_cycle",0)
             .putString("avatar_forge_state","CODE714_VISUAL_GATE_CALIBRATING")
             .putString("visual_gate_r424","CALIBRATING")
             .putBoolean("visual_gate_owner_approved",false);
        }
        if(!p.contains("avatar_forge_auto_evidence")) e.putBoolean("avatar_forge_auto_evidence",true);
        if(!p.contains("avatar_forge_prefer_external")) e.putBoolean("avatar_forge_prefer_external",false);
        if(!p.contains("avatar_forge_state")) e.putString("avatar_forge_state","READY");
        e.putLong("avatar_forge_baseline_at",System.currentTimeMillis()).apply();
    }

    static File externalModel(Context c){ return new File(c.getFilesDir(),EXTERNAL_REL); }

    static boolean externalModelValid(Context c,SharedPreferences p){
        File f=externalModel(c);
        String why="none"; boolean ok=false;
        try{
            if(!f.isFile()) why="missing";
            else if(f.length()<20L||f.length()>MAX_MODEL_BYTES) why="size="+f.length();
            else{
                try(FileInputStream in=new FileInputStream(f)){
                    byte[] h=new byte[12]; int n=in.read(h);
                    boolean magic=n==12&&h[0]=='g'&&h[1]=='l'&&h[2]=='T'&&h[3]=='F';
                    int version=n<8?-1:(h[4]&255)|((h[5]&255)<<8)|((h[6]&255)<<16)|((h[7]&255)<<24);
                    ok=magic&&version==2; why=ok?"valid-glb2":"header/version";
                }
            }
        }catch(Throwable t){why=t.getClass().getSimpleName();}
        p.edit().putBoolean("avatar_forge_external_valid",ok)
                .putString("avatar_forge_external_validation",why)
                .putLong("avatar_forge_external_validation_at",System.currentTimeMillis()).apply();
        return ok;
    }

    static byte[] loadActiveModelBytes(Context c,SharedPreferences p) throws Exception{
        ensureBaseline(c);
        boolean prefer=p.getBoolean("avatar_forge_prefer_external",false);
        byte[] data; String source; String id;
        if(prefer&&externalModelValid(c,p)){
            File f=externalModel(c); data=readAll(new FileInputStream(f),MAX_MODEL_BYTES); source="external-signed-content-slot"; id=f.getName();
        }else{
            data=readAll(c.getAssets().open(BUNDLED_MODEL),MAX_MODEL_BYTES); source="bundled-code712-reference-model"; id=BUNDLED_MODEL_ID;
        }
        String sha=sha256(data);
        if("bundled-code712-reference-model".equals(source)&&!BUNDLED_SHA256.equals(sha)) throw new SecurityException("Bundled avatar SHA mismatch");
        p.edit().putString("visual_active_model",id).putString("avatar_forge_active_source",source)
                .putString("avatar_forge_active_sha256",sha).putLong("avatar_forge_active_bytes",data.length)
                .putLong("avatar_forge_model_loaded_at",System.currentTimeMillis()).apply();
        return data;
    }

    static JSONObject applyOwnerGoal(Context c,SharedPreferences p,String raw) throws Exception{
        ensureBaseline(c);
        String s=raw==null?"":raw.trim().toLowerCase(Locale.US);
        SharedPreferences.Editor e=p.edit().putString("avatar_forge_last_goal",raw==null?"":raw)
                .putLong("avatar_forge_last_goal_at",System.currentTimeMillis());
        String state;
        if(s.contains("rollback")||s.contains("reference")||s.contains("approved lumi")||s.contains("approved look")){
            e.putBoolean("avatar_forge_prefer_external",false).putFloat("avatar_forge_camera_focal_mm",34f)
                    .putFloat("avatar_forge_exposure_iso",50f).putFloat("avatar_forge_committed_focal_mm",34f).putFloat("avatar_forge_committed_iso",50f).putFloat("avatar_forge_committed_light_intensity",12000f).putInt("avatar_forge_tune_cycle",0);
            state="REFERENCE_MODEL_ACTIVE";
        }else if(s.contains("humanoid")||s.contains("human avatar")||s.contains("use model")||s.contains("activate model")){
            if(externalModelValid(c,p)){
                e.putBoolean("avatar_forge_prefer_external",true); state="EXTERNAL_MODEL_ACTIVE";
            }else{
                e.putBoolean("avatar_forge_prefer_external",false)
                  .putString("maintenance_candidate_classification","CAPABILITY_GAP")
                  .putString("maintenance_candidate_area","visuals.avatar.asset")
                  .putString("maintenance_candidate_action","stage a signed GLB2 asset at asset/avatar-forge/active.glb, then activate it; do not rewrite Lumi Core")
                  .putLong("maintenance_candidate_last_at",System.currentTimeMillis());
                state="HUMANOID_ASSET_REQUIRED";
            }
        }else{
            state="REFERENCE_MATCH_TUNING";
        }
        e.putString("avatar_forge_state",state).putBoolean("avatar_forge_auto_evidence",true).apply();
        return status(c,p).put("goalResult",state);
    }

    static boolean applyCoreVisualPlan(Context c,SharedPreferences p,LumiCoreSelfStateEngine.VisualPlan plan){
        ensureBaseline(c);if(plan==null||!plan.adjust)return false;int cycle=p.getInt("avatar_forge_tune_cycle",0);if(cycle>=8){LumiEvidenceLedger.append(p,"VISUAL","ACTUATOR_BLOCKED","renderer","cycle limit","LumiAvatarForge");return false;}p.edit().putFloat("avatar_forge_committed_focal_mm",plan.focalMm).putFloat("avatar_forge_committed_iso",50f).putFloat("avatar_forge_committed_light_intensity",plan.lightIntensity).putFloat("avatar_forge_camera_focal_mm",plan.focalMm).putFloat("avatar_forge_exposure_iso",50f).putInt("avatar_forge_tune_cycle",cycle+1).putString("avatar_forge_state","CORE_AUTHORIZED_ACTUATION").putLong("avatar_forge_tune_at",System.currentTimeMillis()).apply();LumiEvidenceLedger.append(p,"VISUAL","ACTUATOR_RESULT","renderer","focal="+plan.focalMm+", light="+plan.lightIntensity,"LumiAvatarForge");return true;
    }

    static JSONObject status(Context c,SharedPreferences p) throws Exception{
        ensureBaseline(c);
        return new JSONObject().put("ok",true).put("forge",FORGE_ID).put("renderer",RENDERER_ID)
                .put("state",p.getString("avatar_forge_state","UNKNOWN"))
                .put("scene",p.getString("visual_scene_id",SCENE_ID)).put("model",p.getString("visual_active_model",BUNDLED_MODEL_ID))
                .put("source",p.getString("avatar_forge_active_source","not-loaded"))
                .put("sha256",p.getString("avatar_forge_active_sha256","none"))
                .put("externalValid",externalModelValid(c,p)).put("externalPreferred",p.getBoolean("avatar_forge_prefer_external",false))
                .put("focalMm",p.getFloat("avatar_forge_committed_focal_mm",34f)).put("iso",p.getFloat("avatar_forge_committed_iso",50f))
                .put("lightIntensity",p.getFloat("avatar_forge_committed_light_intensity",12000f))
                .put("liveFocalMm",p.getFloat("avatar_forge_live_focal_mm",-1f)).put("liveIso",p.getFloat("avatar_forge_live_iso",-1f))
                .put("liveLightIntensity",p.getFloat("avatar_forge_live_light_intensity",-1f)).put("liveAspect",p.getFloat("avatar_forge_live_aspect",-1f))
                .put("visualGate",p.getString("visual_gate_r424","UNTESTED"))
                .put("tuneCycle",p.getInt("avatar_forge_tune_cycle",0)).put("referenceSha256",REFERENCE_SHA256)
                .put("fallback",p.getBoolean("avatar_forge_fallback_active",false));
    }

    private static byte[] readAll(InputStream input,long max) throws Exception{
        try(InputStream in=input; ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] b=new byte[65536]; int n; long total=0;
            while((n=in.read(b))>0){total+=n;if(total>max)throw new IllegalArgumentException("avatar model exceeds limit");out.write(b,0,n);} return out.toByteArray();
        }
    }
    private static String sha256(byte[] data) throws Exception{
        MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] d=md.digest(data); StringBuilder b=new StringBuilder();
        for(byte x:d)b.append(String.format(Locale.US,"%02x",x&255)); return b.toString();
    }
}
