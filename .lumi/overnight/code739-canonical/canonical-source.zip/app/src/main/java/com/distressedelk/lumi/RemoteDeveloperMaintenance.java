package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

final class RemoteDeveloperMaintenance {
    private static int safeInc(int v){ return v<0?1:(v>=1000000?1000000:v+1); }
    // Code600: autonomous work-order runner is active through LumiMaintenanceBuildHandoff.reconcile.
    private static final long POLL_MS=15000L;
    private static final long AUTO_FAULT_UPLOAD_COOLDOWN_MS=120000L;
    private static final long ONLINE_BLACK_BOX_FAULT_REFRESH_MS=30L*1000L;
    private static final long ONLINE_BLACK_BOX_HEALTHY_REFRESH_MS=2L*60L*1000L;
    private static final int BLACK_BOX_RETAIN=5;
    private static final int MAX_BLACK_BOX_BYTES=128*1024;
    private static final ExecutorService worker=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"LumiRemoteDeveloperMaintenance");t.setDaemon(true);return t;});
    private static final AtomicBoolean busy=new AtomicBoolean(false);
    private static volatile long lastKickAt=0L;
    private static ScheduledThreadPoolExecutor poller;
    private static volatile Context appContext;
    private static final long PROCESS_STARTED_AT=System.currentTimeMillis();
    private static final String PROCESS_SESSION_ID="runtime-"+Long.toString(PROCESS_STARTED_AT);
    private static volatile long lastHeartbeatAt=0L;
    // Code583: autonomous self-maintenance loop. Reuse the existing continuity
    // clocks instead of creating another timing authority.
    private static volatile long lastMaintenanceLoopReportAt=0L;
    // Code585: continuous-improvement hunter. No extra scheduler is created.
    private static volatile long lastImprovementReportAt=0L;
    private static volatile boolean networkCallbackRegistered=false;
    // Code558: edge-trigger connectivity recovery. Repeated VALIDATED capability
    // callbacks on an already-usable network must not bypass the 15s poll throttle.
    private static final Set<Network> validatedNetworks=ConcurrentHashMap.newKeySet();
    private static final AtomicLong duplicateValidatedNetworkCallbacks=new AtomicLong(0L);
    private static volatile long lastSchedulerTickAt=0L;
    private static volatile long schedulerGeneration=0L;
    private RemoteDeveloperMaintenance(){}

    private static int runningVersionCode(Context c){
        try{
            android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0);
            if(android.os.Build.VERSION.SDK_INT>=28) return (int)pi.getLongVersionCode();
            return pi.versionCode;
        }catch(Throwable ignored){ return -1; }
    }

    static synchronized void start(Context context){
        if(context==null) return;
        appContext=context.getApplicationContext();
        SharedPreferences startPrefs=appContext.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        startPrefs.edit()
                .putInt("remote_maintenance_runtime_version_code",runningVersionCode(appContext))
                .putString("remote_maintenance_runtime_version_name",runningVersionName(appContext))
                .putString("remote_maintenance_process_session_id",PROCESS_SESSION_ID)
                .putLong("remote_maintenance_foreground_rearm_at",System.currentTimeMillis())
                .apply();
        registerNetworkRecovery(appContext);
        if(poller!=null && !poller.isShutdown() && !poller.isTerminated()){
            kick(appContext);
            return;
        }
        poller=new ScheduledThreadPoolExecutor(1,r->{
            Thread t=new Thread(r,"LumiRemoteMaintenancePoller");
            t.setDaemon(false);
            return t;
        });
        poller.setRemoveOnCancelPolicy(true);
        schedulerGeneration++;
        poller.scheduleAtFixedRate(()->{
            lastSchedulerTickAt=System.currentTimeMillis();
            Context c=appContext;
            if(c!=null) kick(c);
        },0L,POLL_MS,TimeUnit.MILLISECONDS);
    }

    static synchronized void ensureAlive(Context context,String reason){
        if(context==null)return;
        Context app=context.getApplicationContext();
        appContext=app;
        SharedPreferences p=app.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        long now=System.currentTimeMillis();
        long tickAge=lastSchedulerTickAt<=0L?Long.MAX_VALUE:Math.max(0L,now-lastSchedulerTickAt);
        long pollAt=p.getLong("remote_maintenance_last_poll_at",0L);
        long pollAge=pollAt<=0L?Long.MAX_VALUE:Math.max(0L,now-pollAt);
        long sidecarAt=p.getLong("live_diag_heartbeat_at",0L);
        long sidecarAge=sidecarAt<=0L?Long.MAX_VALUE:Math.max(0L,now-sidecarAt);
        boolean executorBad=poller==null || poller.isShutdown() || poller.isTerminated();
        boolean tickStale=tickAge>45000L;
        boolean sidecarFresh=sidecarAge<=15000L;

        // Code548: the 5s LiveMaintenanceSidecar and 15s maintenance poller are both
        // continuity clocks. A stale poller tick is observational while the independent
        // sidecar is demonstrably fresh; destroying a healthy executor in that case caused
        // repeated scheduler-generation/rebuild churn with no bridge outage.
        boolean destructiveRebuild=executorBad || tickStale;
        String rebuildCause="";
        if(executorBad) rebuildCause="EXECUTOR_UNAVAILABLE";
        else if(tickStale) rebuildCause="TICK_STALE";
        else if(tickStale && sidecarFresh) rebuildCause="TICK_STALE_SIDECAR_FRESH_OBSERVE_ONLY";

        if(destructiveRebuild){
            try{if(poller!=null)poller.shutdownNow();}catch(Throwable ignored){}
            poller=null;
            lastKickAt=0L;
            p.edit().putInt("code449_remote_scheduler_rebuild_count",safeInc(p.getInt("code449_remote_scheduler_rebuild_count",0)))
                    .putLong("code449_remote_scheduler_rebuild_at",now)
                    .putString("code449_remote_scheduler_rebuild_reason",reason==null?"":reason)
                    .putString("code548_scheduler_rebuild_cause",rebuildCause)
                    .putInt("code548_destructive_rebuild_count",safeInc(p.getInt("code548_destructive_rebuild_count",0))).apply();
            start(app);
        }else if(tickStale && sidecarFresh){
            p.edit().putLong("code548_stale_tick_observed_at",now)
                    .putString("code548_scheduler_rebuild_cause",rebuildCause)
                    .putInt("code548_observe_only_count",safeInc(p.getInt("code548_observe_only_count",0))).apply();
        }
        if(pollAge>30000L){ lastKickAt=0L; kick(app); }
        p.edit().putLong("code449_remote_ensure_alive_at",now)
                .putLong("code449_remote_scheduler_tick_age_ms",tickAge==Long.MAX_VALUE?-1L:tickAge)
                .putLong("code449_remote_poll_age_ms",pollAge==Long.MAX_VALUE?-1L:pollAge)
                .putLong("code449_remote_scheduler_generation",schedulerGeneration)
                .putLong("code548_sidecar_age_ms",sidecarAge==Long.MAX_VALUE?-1L:sidecarAge)
                .putBoolean("code548_sidecar_fresh",sidecarFresh)
                .putBoolean("code548_tick_stale",tickStale)
                .putBoolean("code548_executor_bad",executorBad)
                .putString("code449_remote_ensure_alive_reason",reason==null?"":reason).apply();
    }

    private static synchronized void registerNetworkRecovery(Context context){
        if(networkCallbackRegistered || context==null) return;
        try{
            ConnectivityManager cm=(ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if(cm==null) return;
            NetworkRequest req=new NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
            cm.registerNetworkCallback(req,new ConnectivityManager.NetworkCallback(){
                private void recoverOnValidatedEdge(Network network){
                    if(network==null) return;
                    boolean added=validatedNetworks.add(network);
                    if(!added){ duplicateValidatedNetworkCallbacks.incrementAndGet(); return; }
                    if(validatedNetworks.size()!=1) return;
                    Context c=appContext;
                    if(c==null) return;
                    lastKickAt=0L;
                    SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
                    p.edit().putString("remote_maintenance_bridge_state","NETWORK_AVAILABLE_RETRY")
                            .putLong("remote_maintenance_network_recovery_at",System.currentTimeMillis())
                            .putInt("remote_maintenance_network_recovery_count",safeInc(p.getInt("remote_maintenance_network_recovery_count",0))).apply();
                    kick(c);
                }
                @Override public void onAvailable(Network network){
                    // Wait for NET_CAPABILITY_VALIDATED before treating availability as recovery.
                }
                @Override public void onCapabilitiesChanged(Network network,NetworkCapabilities caps){
                    boolean validated=caps!=null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                    if(validated) recoverOnValidatedEdge(network);
                    else if(network!=null) validatedNetworks.remove(network);
                }
                @Override public void onLost(Network network){
                    if(network!=null) validatedNetworks.remove(network);
                }
            });
            networkCallbackRegistered=true;
        }catch(Throwable ignored){}
    }

    static void noteActivityForeground(Context context){
        if(context==null)return;
        Context app=context.getApplicationContext();
        SharedPreferences p=app.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        long now=System.currentTimeMillis();
        p.edit().putBoolean("remote_maintenance_activity_foreground",true)
                .putLong("remote_maintenance_activity_foreground_at",now)
                .putInt("remote_maintenance_runtime_version_code",runningVersionCode(app))
                .putString("remote_maintenance_runtime_version_name",runningVersionName(app))
                .putString("remote_maintenance_process_session_id",PROCESS_SESSION_ID).apply();
        start(app);
        ensureAlive(app,"MAIN_ACTIVITY_FOREGROUND");
        forceKick(app,"MAIN_ACTIVITY_FOREGROUND");
    }

    static void noteActivityBackground(Context context){
        if(context==null)return;
        Context app=context.getApplicationContext();
        app.getSharedPreferences("lumi",Context.MODE_PRIVATE).edit()
                .putBoolean("remote_maintenance_activity_foreground",false)
                .putLong("remote_maintenance_activity_background_at",System.currentTimeMillis()).apply();
    }

    static void forceKick(Context context,String reason){
        if(context==null)return;
        Context app=context.getApplicationContext();
        SharedPreferences p=app.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        synchronized(RemoteDeveloperMaintenance.class){ lastKickAt=0L; }
        p.edit().putLong("remote_maintenance_force_kick_at",System.currentTimeMillis())
                .putString("remote_maintenance_force_kick_reason",reason==null?"":reason).apply();
        kick(app);
    }

    static void kick(Context context){
        if(context==null) return;
        long now=System.currentTimeMillis();
        if(now-lastKickAt<POLL_MS || !busy.compareAndSet(false,true)) return;
        lastKickAt=now; Context app=context.getApplicationContext();
        worker.execute(()->{try{poll(app);}catch(Throwable t){recordError(app,t);}finally{busy.set(false);}});
    }

    private static void code603ResetLifetimeCountersOnce(Context c,SharedPreferences p,long now){
        if(c==null||p==null||p.getBoolean("code603_lifetime_counters_reset",false)) return;
        int oldPass=p.getInt("maintenance_loop_pass_count",0);
        int oldIssues=p.getInt("maintenance_issue_detection_count",0);
        int oldRepairs=p.getInt("maintenance_loop_repair_count",0);
        int oldCandidates=p.getInt("maintenance_candidate_detection_count",0);
        p.edit()
                .putInt("code603_archived_lifetime_passes",oldPass)
                .putInt("code603_archived_lifetime_issue_detections",oldIssues)
                .putInt("code603_archived_lifetime_repairs",oldRepairs)
                .putInt("code603_archived_candidate_detections",oldCandidates)
                .putInt("maintenance_loop_pass_count",0)
                .putInt("maintenance_issue_detection_count",0)
                .putInt("maintenance_loop_repair_count",0)
                .putInt("maintenance_candidate_detection_count",0)
                .putInt("maintenance_current_build_passes",0)
                .putInt("maintenance_current_build_issue_detections",0)
                .putInt("maintenance_current_build_repairs",0)
                .putInt("maintenance_ledger_build_version",runningVersionCode(c))
                .putInt("maintenance_ledger_build_pass_base",0)
                .putInt("maintenance_ledger_build_repair_base",0)
                .putInt("maintenance_ledger_build_issue_base",0)
                .putBoolean("code603_lifetime_counters_reset",true)
                .putLong("code603_lifetime_counters_reset_at",now).apply();
        appendRepairLedger(c,p,"Code603 lifetime maintenance counter reset",
                "Code602 reset occurred after cumulative counters had already been read, so the same tick restored stale totals",
                "reset at the first executable line of maintenanceLoopTick before cumulative accounting is read",
                "passes="+oldPass+" issues="+oldIssues+" repairs="+oldRepairs+" candidates="+oldCandidates,
                "passes=0 issues=0 repairs=0 candidates=0","COUNTERS_RESET_CODE603_PRE_READ");
    }

    private static void maintenanceLoopTick(Context c,SharedPreferences p){
        if(c==null || p==null) return;
        code603ResetLifetimeCountersOnce(c,p,System.currentTimeMillis());
        long now=System.currentTimeMillis();
        boolean enabled=p.getBoolean("maintenance_loop_enabled",true);
        if(!enabled){
            p.edit().putBoolean("maintenance_loop_active",false).putLong("maintenance_loop_last_tick_at",now).apply();
            return;
        }
        ensureRepairLedgerBuildBaseline(c,p);
        int issues=0;
        int repairs=0;
        StringBuilder diagnosis=new StringBuilder();

        long tickAge=lastSchedulerTickAt<=0L?Long.MAX_VALUE:Math.max(0L,now-lastSchedulerTickAt);
        long sidecarAt=p.getLong("live_diag_heartbeat_at",0L);
        long sidecarAge=sidecarAt<=0L?Long.MAX_VALUE:Math.max(0L,now-sidecarAt);
        boolean schedulerExecutorBad=poller==null || poller.isShutdown() || poller.isTerminated();
        boolean schedulerTickStale=tickAge>45000L;
        boolean sidecarFresh=sidecarAge<=15000L;
        // Code608: maintenance-loop fault authority must match Code548 continuity authority.
        boolean schedulerBad=schedulerExecutorBad || schedulerTickStale;
        if(schedulerBad){
            issues++;
            diagnosis.append("scheduler_unhealthy;");
            try{
                ensureAlive(c,"MAINTENANCE_LOOP");
                repairs++;
                diagnosis.append("scheduler_recovery_requested;");
            }catch(Throwable t){ diagnosis.append("scheduler_recovery_failed;"); }
                }

String relayError=p.getString("remote_maintenance_last_error","");
        if(relayError!=null && !relayError.trim().isEmpty()){
            issues++;
            diagnosis.append("relay_error;");
            String beforeRelay=relayError;
            lastKickAt=0L;
            repairs++;
            diagnosis.append("bridge_retry_requested;");
            appendRepairLedger(c,p,"maintenance relay error","remote_maintenance_last_error was non-empty","reset lastKickAt and request authenticated bridge retry",
                    beforeRelay,"retry requested; lastKickAt reset","REQUESTED_AWAIT_NEXT_HEARTBEAT");
        }

        boolean coreStarted=p.getBoolean("code449_core_foreground_started",false);
        if(!coreStarted){ issues++; diagnosis.append("core_foreground_not_proven;"); }

        String visualStatus=p.getString("lumi_core_domain_state_visual","UNKNOWN");
        boolean ownerVisualConcern=p.getBoolean("lumi_owner_concern_unresolved",false) && "VISUAL".equals(p.getString("lumi_owner_concern_component",""));
        boolean visualFault="KNOWN_WRONG_CAUSE_UNKNOWN".equals(visualStatus)||"FAIL".equals(visualStatus)||"OBSERVED_LIMITED".equals(visualStatus)||ownerVisualConcern;
        if(visualFault){issues++;diagnosis.append("core_visual_state:").append(visualStatus).append(';');try{final MainActivity a=MainActivity.activeMaintenanceInstance;if(a!=null&&a.avatarSceneView!=null){a.runOnUiThread(()->{try{LumiVisualSelfCheck.schedule(a,a.avatarSceneView,p);}catch(Throwable ignored){}});diagnosis.append("visual_reobservation_requested;");}}catch(Throwable ignored){}}

        long pending=p.getLong("pending_core_version_code",-1L);
        long published=p.getLong("github_update_available_version",-1L);
        if(pending>0L) diagnosis.append("update_pending_").append(pending).append(';');
        else if(published>runningVersionCode(c)) diagnosis.append("newer_published_").append(published).append(';');

        int cumulativeRepairs=p.getInt("maintenance_loop_repair_count",0)+repairs;
        int cumulativePasses=p.getInt("maintenance_loop_pass_count",0)+1;
        improvementHuntTick(c,p,now,issues);
        code593ResetMaintenanceCountersOnce(c,p,now);
        code602ResetLifetimeCountersOnce(c,p,now);
        proactiveMaintenanceKickoff(c,p,now);
        boundedMaintenanceExecutorTick(c,p,now);
        LumiMaintenanceBuildHandoff.reconcile(c,p,now);
        selfAwareCandidateSweep(c,p,now);
        p.edit()
                .putBoolean("maintenance_loop_enabled",true)
                .putBoolean("maintenance_loop_active",true)
                .putLong("maintenance_loop_last_tick_at",now)
                .putInt("maintenance_loop_last_issue_count",issues)
                .putInt("maintenance_issue_detection_count",p.getInt("maintenance_issue_detection_count",0)+issues)
                .putInt("maintenance_loop_repair_count",cumulativeRepairs)
                .putInt("maintenance_loop_pass_count",cumulativePasses)
                .putString("maintenance_loop_last_diagnosis",diagnosis.toString())
                .apply();
        finalizeExplicitMaintenanceTransaction(c,p,now,issues,repairs,diagnosis.toString());

        if(now-lastMaintenanceLoopReportAt<15L*60L*1000L) return;
        try{
            JSONObject report=new JSONObject()
                    .put("format","LumiMaintenanceLoopStatus")
                    .put("formatVersion",1)
                     .put("versionCode",runningVersionCode(c))
                    .put("versionName",runningVersionName(c))
                    .put("active",true)
                    .put("enabled",true)
                    .put("tickAt",now)
                    .put("passCount",cumulativePasses)
                    .put("issueCount",p.getInt("whole_self_current_fault_count_v2",issues))
                    .put("repairCount",p.getInt("maintenance_verified_repairs_v2",0))
                    .put("repairAttempts",p.getInt("maintenance_repair_attempts_v2",0))
                    .put("changesApplied",p.getInt("maintenance_changes_applied_v2",0))
                    .put("rollbacks",p.getInt("maintenance_rollbacks_v2",0))
                    .put("escalations",p.getInt("maintenance_escalations_v2",0))
                    .put("diagnosis",diagnosis.toString())
                    .put("bridgeState",p.getString("remote_maintenance_bridge_state","UNKNOWN"))
                    .put("schedulerTickAgeMs",tickAge==Long.MAX_VALUE?-1L:tickAge)
                    .put("schedulerExecutorBad",schedulerExecutorBad)
                    .put("schedulerTickStale",schedulerTickStale)
                    .put("sidecarAgeMs",sidecarAge==Long.MAX_VALUE?-1L:sidecarAge)
                    .put("sidecarFresh",sidecarFresh)
                    .put("coreForegroundStarted",coreStarted)
                    .put("publishedUpdateVersion",published)
                    .put("pendingCoreVersion",pending)
                    .put("lastRelayError",relayError==null?"":relayError);
            TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/remote/maintenance-loop.json",report.toString(2)+"\n","Lumi maintenance loop [skip ci]");
            lastMaintenanceLoopReportAt=now;
        }catch(Throwable t){ recordError(c,t); }
    }

    private static void improvementHuntTick(Context c,SharedPreferences p,long now,int activeFaults){
        if(c==null || p==null) return;
        String censusStatus=p.getString("whole_self_audit_status","");
        long censusAt=p.getLong("whole_self_audit_at",0L);
        boolean censusFresh=("COMPLETE_CODE"+runningVersionCode(c)).equals(censusStatus) && censusAt>0L && now>=censusAt && now-censusAt<=10L*60L*1000L;
        if(!censusFresh){
            try{LumiWholeSelfAudit.schedule(c,p);}catch(Throwable ignored){}
        }
        // Faults always win. When health is clean, hunt for measurable Lumi 1.0 improvements.
        String mode=activeFaults>0?"REPAIR":"IMPROVE";
        int opportunities=0;
        int high=0;
        JSONArray backlog=new JSONArray();
        try{
            if(activeFaults>0){
                backlog.put(new JSONObject().put("priority",100).put("area","reliability")
                        .put("kind","fault-first").put("evidence","active_faults="+activeFaults)
                        .put("nextAction","finish bounded repair and verify before optimization"));
            } else {
                int net=p.getInt("remote_maintenance_network_recovery_count",0);
                int netFail=p.getInt("remote_maintenance_network_failure_count",0);
                int lastNet=p.getInt("maintenance_improvement_prev_network_recovery",net);
                int lastFail=p.getInt("maintenance_improvement_prev_network_failure",netFail);
                long lastSample=p.getLong("maintenance_improvement_prev_sample_at",now);
                long age=Math.max(1L,now-lastSample);
                int netDelta=Math.max(0,net-lastNet);
                int failDelta=Math.max(0,netFail-lastFail);
                if(age>=300000L && netDelta>=8 && failDelta==0){
                    opportunities++; high++;
                    backlog.put(new JSONObject().put("priority",90).put("area","efficiency")
                            .put("kind","network-recovery-churn")
                            .put("evidence","recovery_delta="+netDelta+" failure_delta=0 window_ms="+age)
                            .put("rootCauseHypothesis","recovery callbacks are firing more often than proven network failures")
                            .put("nextAction","compare callback edge triggers before changing recovery policy"));
                }

                int rebuild=p.getInt("code449_remote_scheduler_rebuild_count",0);
                int lastRebuild=p.getInt("maintenance_improvement_prev_scheduler_rebuild",rebuild);
                int rebuildDelta=Math.max(0,rebuild-lastRebuild);
                if(age>=300000L && rebuildDelta>=3){
                    opportunities++; high++;
                    backlog.put(new JSONObject().put("priority",88).put("area","reliability")
                            .put("kind","scheduler-rebuild-churn")
                            .put("evidence","rebuild_delta="+rebuildDelta+" window_ms="+age)
                            .put("rootCauseHypothesis","continuity scheduler is rebuilding more often than a healthy steady state requires")
                            .put("nextAction","compare poller and sidecar freshness before any threshold change"));
                }

                boolean aurora=p.getBoolean("lumi_voice_profile_runtime_verified",false);
                String voice=p.getString("lumi_voice_profile","none");
                if("Aurora".equalsIgnoreCase(voice) && !aurora){
                    opportunities++; high++;
                    backlog.put(new JSONObject().put("priority",86).put("area","voice")
                            .put("kind","voice-runtime-unverified").put("evidence","profile=Aurora runtimeVerified=false")
                            .put("rootCauseHypothesis","configured voice profile is not proven active in the current runtime")
                            .put("nextAction","run bounded voice/runtime validation before retuning speech"));
                }

                String ai=p.getString("ai_connection_state","UNKNOWN");
                if(!"CONNECTED".equalsIgnoreCase(ai) && !"UNKNOWN".equalsIgnoreCase(ai)){
                    opportunities++;
                    backlog.put(new JSONObject().put("priority",78).put("area","reasoning")
                            .put("kind","online-route-not-connected").put("evidence","ai_connection_state="+ai)
                            .put("rootCauseHypothesis","strong-brain route is configured but not currently connected")
                            .put("nextAction","validate provider route and fallback latency without disabling local-first behavior"));
                }

                String renderer=p.getString("visual_core_renderer","");
                String rendererLc=renderer.toLowerCase(Locale.US);
                boolean approvedRenderer=rendererLc.contains("lumi_approved_code400_r117_calibrated_r264")
                        || rendererLc.contains("approved-code400-r117-calibrated-r264")
                        || rendererLc.contains("approved-layered-pyramid")
                        || rendererLc.contains("inverted-pyramid");
                if(!renderer.isEmpty() && !approvedRenderer){
                    opportunities++; high++;
                    backlog.put(new JSONObject().put("priority",92).put("area","visuals")
                            .put("kind","approved-renderer-drift").put("classification","FAULT")
                            .put("evidence","visual_core_renderer="+renderer)
                            .put("rootCauseHypothesis","runtime renderer identity is outside the frozen approved renderer family")
                            .put("nextAction","compare installed render against frozen approved reference before changing geometry"));
                } else if(approvedRenderer){
                    opportunities++;
                    // Code607: one visual telemetry authority. Prefer the current Code594+ self-vision keys;
                    // retain legacy Code588 keys only as backward-compatible fallback.
                    String pxState=p.getString("visual_self_check_status","NOT_RUN");
                    float pxMismatch=p.getFloat("visual_self_check_mismatch_pct",-1f);
                    String pxRef=p.getString("visual_self_check_reference","none");
                    String evidence="approved renderer active; pixelSelfCheck="+pxState+" reference="+pxRef
                            +(pxMismatch>=0f?" mismatchPct="+pxMismatch:"");
                    backlog.put(new JSONObject().put("priority",80).put("area","visuals")
                            .put("kind","visual-reference-unverified").put("classification","VERIFICATION_GAP")
                            .put("evidence",evidence)
                            .put("rootCauseHypothesis","actual phone pixels are now capturable/comparable, but owner approval remains the frozen final visual gate")
                            .put("nextAction","use measured pixel evidence plus owner-approved reference; never declare visual PASS from renderer identity alone"));
                }

                long pending=p.getLong("pending_core_version_code",-1L);
                long published=p.getLong("github_update_available_version",-1L);
                int installed=runningVersionCode(c);
                if(pending<=0L && installed>0 && published>installed){
                    opportunities++;
                    backlog.put(new JSONObject().put("priority",84).put("area","update")
                            .put("kind","newer-release-available").put("classification","VERIFICATION_GAP")
                            .put("evidence","published="+published+" installed="+installed)
                            .put("rootCauseHypothesis","a newer verified release exists but is not staged")
                            .put("nextAction","use existing signed update discovery lane"));
                    try{ kick(c); }catch(Throwable ignored){}
                }

                p.edit().putInt("maintenance_improvement_prev_network_recovery",net)
                        .putInt("maintenance_improvement_prev_network_failure",netFail)
                        .putInt("maintenance_improvement_prev_scheduler_rebuild",rebuild)
                        .putLong("maintenance_improvement_prev_sample_at",now).apply();
            }

            int censusFaults=censusFresh?p.getInt("whole_self_current_fault_count_v2",0):0;
            int censusCleanup=censusFresh?p.getInt("whole_self_cleanup_count_v2",0):0;
            int censusGaps=censusFresh?p.getInt("whole_self_verification_gap_count_v2",0):0;
            int censusImprovements=censusFresh?p.getInt("whole_self_improvement_count_v2",0):0;
            int censusHistorical=censusFresh?p.getInt("whole_self_historical_signal_count_v2",0):0;
            activeFaults=Math.max(activeFaults,censusFaults);
            try{
                JSONArray census=new JSONArray(p.getString("whole_self_candidates_v2_json","[]"));
                java.util.HashSet<String> seen=new java.util.HashSet<>();
                for(int i=0;i<backlog.length();i++){JSONObject q=backlog.optJSONObject(i);if(q!=null)seen.add(q.optString("id",q.optString("kind","")));}
                for(int i=0;i<census.length()&&backlog.length()<64;i++){
                    JSONObject q=census.optJSONObject(i);if(q==null)continue;
                    String id=q.optString("id","");if(!id.isEmpty()&&seen.contains(id))continue;
                    backlog.put(q);if(!id.isEmpty())seen.add(id);
                }
            }catch(Throwable ignored){}
            opportunities=Math.max(opportunities,censusCleanup+censusImprovements);
            high=Math.max(high,p.getInt("whole_self_high_priority_count_v2",0));
            String selfGate=censusFresh?p.getString("self_improvement_discovery_gate","UNVERIFIED"):"UNVERIFIED";
            boolean discoveryVerified="VERIFIED".equals(selfGate);
            if(!discoveryVerified)p.edit().putString("self_repair_discovery_authority","HOLD_CODE642")
                    .putString("self_repair_discovery_hold_reason","discovery truth="+selfGate).apply();

            String state=!censusFresh?"DIAGNOSING":(activeFaults>0?"REPAIRING":(opportunities>0?"IMPROVING":"HEALTHY_HUNTING"));
            p.edit().putBoolean("maintenance_improvement_enabled",true)
                    .putLong("maintenance_improvement_last_scan_at",now)
                    .putString("maintenance_improvement_state",state)
                    .putString("maintenance_improvement_current_area",opportunities>0?p.getString("maintenance_improvement_current_area",""):"")
                    .putString("maintenance_improvement_current_action",opportunities>0?p.getString("maintenance_improvement_current_action",""):"")
                    .putInt("maintenance_truth_fault_count",activeFaults)
                    .putInt("maintenance_truth_verification_gap_count",opportunities>0?opportunities:0)
                    .putInt("maintenance_improvement_opportunity_count",opportunities)
                    .putInt("maintenance_improvement_high_priority_count",high).apply();

            if(now-lastImprovementReportAt<15L*60L*1000L) return;
            JSONObject report=new JSONObject()
                    .put("format","LumiContinuousImprovementStatus").put("formatVersion",1)
                    .put("versionCode",runningVersionCode(c)).put("versionName",runningVersionName(c))
                    .put("mode",mode).put("state",state).put("scanAt",now)
                    .put("activeFaults",activeFaults).put("opportunityCount",opportunities)
                    .put("highPriorityCount",high)
                    .put("diagnosticFaultCount",p.getInt("whole_self_current_fault_count_v2",0))
                    .put("cleanupCount",p.getInt("whole_self_cleanup_count_v2",0))
                    .put("verificationGapCount",p.getInt("whole_self_verification_gap_count_v2",0))
                    .put("improvementCount",p.getInt("whole_self_improvement_count_v2",0))
                    .put("historicalSignalCount",p.getInt("whole_self_historical_signal_count_v2",0))
                    .put("diagnosticDomainCount",censusFresh?p.getInt("whole_self_audit_domain_count",0):0)
                    .put("selfImprovementDiscoveryGate",selfGate).put("backlog",backlog)
                    .put("policy","faults-first; evidence-before-change; bounded-safe-actions-only; compiled-core changes require trusted build/install authority")
                    .put("nextCycle","continue immediately; healthy cycles hunt improvements instead of declaring success");
            TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/remote/improvement-backlog.json",report.toString(2)+"\n","Lumi Code593 improvement hunt [skip ci]");
            lastImprovementReportAt=now;
        }catch(Throwable t){ recordError(c,t); }
    }

    static synchronized String requestExplicitMaintenance(Context c,SharedPreferences p,String ownerCommand){
        if(c==null || p==null) return "Maintenance request rejected: runtime unavailable.";
        long now=System.currentTimeMillis();
        String tx="mtx-"+now+"-c"+runningVersionCode(c);
        p.edit().putBoolean("maintenance_loop_enabled",true)
                .putString("maintenance_explicit_tx_id",tx)
                .putInt("maintenance_explicit_tx_version",runningVersionCode(c))
                .putString("maintenance_explicit_tx_state","REQUESTED")
                .putString("maintenance_explicit_tx_command",ownerCommand==null?"":ownerCommand.trim())
                .putLong("maintenance_explicit_tx_requested_at",now)
                .putLong("maintenance_explicit_tx_completed_at",0L)
                .putString("maintenance_explicit_tx_result","")
                .putInt("maintenance_explicit_request_count",p.getInt("maintenance_explicit_request_count",0)+1)
                .apply();
        // Execute a bounded maintenance pass now so the reply can be backed by a real transaction.
        maintenanceLoopTick(c,p);
        try{
            android.os.Bundle h=BootstrapHealth.healthBundle(c,p);
            p.edit().putLong("maintenance_verification_sweep_at",System.currentTimeMillis())
                    .putBoolean("maintenance_verification_core_certified",h.getBoolean("certified",false))
                    .putString("maintenance_verification_core_summary",h.getString("summary","unavailable"))
                    .putString("maintenance_verification_interactive_gaps","spoken-endurance,owner-voice,spoken-barge-in,interactive-memory")
                    .apply();
        }catch(Throwable ignored){}
        try{ kick(c); }catch(Throwable ignored){}
        String state=p.getString("maintenance_explicit_tx_state","REQUESTED");
        String result=p.getString("maintenance_explicit_tx_result","");
        if(result==null || result.trim().isEmpty()) result="transaction="+tx+" state="+state;
        return result;
    }

    private static void finalizeExplicitMaintenanceTransaction(Context c,SharedPreferences p,long now,int issues,int repairs,String diagnosis){
        if(!"REQUESTED".equals(p.getString("maintenance_explicit_tx_state",""))) return;
        String tx=p.getString("maintenance_explicit_tx_id","");
        long tickAge=lastSchedulerTickAt<=0L?Long.MAX_VALUE:Math.max(0L,now-lastSchedulerTickAt);
        boolean schedulerStillBad=poller==null || poller.isShutdown() || poller.isTerminated() || tickAge>45000L;
        String relay=p.getString("remote_maintenance_last_error","");
        boolean coreStarted=p.getBoolean("code449_core_foreground_started",false);
        int remaining=0;
        if(schedulerStillBad) remaining++;
        if(relay!=null && !relay.trim().isEmpty()) remaining++;
        if(!coreStarted) remaining++;
        boolean countedVisualFault=!"PASS".equals(p.getString("lumi_core_domain_state_visual","UNKNOWN"));
        boolean countedOwnerConcern=p.getBoolean("lumi_owner_concern_unresolved",false);
        if(countedVisualFault) remaining++;
        if(countedOwnerConcern) remaining++;
        int gaps=p.getInt("maintenance_truth_verification_gap_count",0);
        boolean visualHealthy="PASS".equals(p.getString("lumi_core_domain_state_visual","UNKNOWN"));
        if(visualHealthy){p.edit().putBoolean("lumi_owner_concern_unresolved",false).apply();if(countedVisualFault)remaining=Math.max(0,remaining-1);if(countedOwnerConcern)remaining=Math.max(0,remaining-1);}
        String state=issues==0?"VERIFIED_NO_ACTIVE_FAULTS":(remaining==0?"APPLIED_VERIFIED":(repairs>0?"PARTIAL":"NO_SAFE_REPAIR"));
        String result="transaction="+tx+" state="+state+" faultsFound="+issues+" repairsAttempted="+repairs+" remainingFaults="+remaining+" verificationGaps="+gaps;
        p.edit().putString("maintenance_explicit_tx_state",state)
                .putLong("maintenance_explicit_tx_completed_at",System.currentTimeMillis())
                .putString("maintenance_explicit_tx_result",result)
                .putInt("maintenance_explicit_tx_faults_found",issues)
                .putInt("maintenance_explicit_tx_repairs_attempted",repairs)
                .putInt("maintenance_explicit_tx_remaining_faults",remaining)
                .putInt("maintenance_explicit_proof_count",p.getInt("maintenance_explicit_proof_count",0)+1)
                .apply();
        try{
            JSONObject proof=new JSONObject().put("format","LumiExplicitMaintenanceTransaction").put("formatVersion",1)
                    .put("versionCode",runningVersionCode(c)).put("transactionId",tx).put("state",state)
                    .put("requestedAt",p.getLong("maintenance_explicit_tx_requested_at",0L)).put("completedAt",System.currentTimeMillis())
                    .put("faultsFound",issues).put("repairsAttempted",repairs).put("remainingFaults",remaining)
                    .put("verificationGaps",gaps).put("diagnosis",diagnosis==null?"":diagnosis)
                    .put("policy","ledger-backed result only; bounded safe repairs; compiled-core changes still require trusted signed build/install");
            TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/remote/maintenance-command-result.json",proof.toString(2)+"\n","Lumi Code588 maintenance transaction [skip ci]");
        }catch(Throwable t){ recordError(c,t); }
    }

    private static void ensureRepairLedgerBuildBaseline(Context c,SharedPreferences p){
        int v=runningVersionCode(c);
        if(p.getInt("maintenance_ledger_build_version",-1)==v) return;
        p.edit().putInt("maintenance_ledger_build_version",v)
                .putInt("maintenance_ledger_build_pass_base",p.getInt("maintenance_loop_pass_count",0))
                .putInt("maintenance_ledger_build_repair_base",p.getInt("maintenance_loop_repair_count",0))
                .putInt("maintenance_ledger_build_issue_base",p.getInt("maintenance_issue_detection_count",0))
                .putLong("maintenance_ledger_build_started_at",System.currentTimeMillis()).apply();
    }

    private static void appendRepairLedger(Context c,SharedPreferences p,String issue,String rootCause,String action,String before,String after,String verification){
        if(c==null||p==null) return;
        ensureRepairLedgerBuildBaseline(c,p);
        try{
            JSONArray a;
            try{ a=new JSONArray(p.getString("maintenance_repair_ledger_json","[]")); }catch(Throwable bad){ a=new JSONArray(); }
            JSONObject e=new JSONObject().put("timestamp",System.currentTimeMillis()).put("versionCode",runningVersionCode(c))
                    .put("issue",issue==null?"":issue).put("rootCause",rootCause==null?"":rootCause)
                    .put("action",action==null?"":action).put("before",before==null?"":before)
                    .put("after",after==null?"":after).put("verification",verification==null?"":verification);
            a.put(e);
            while(a.length()>100){ JSONArray n=new JSONArray(); for(int i=1;i<a.length();i++) n.put(a.get(i)); a=n; }
            p.edit().putString("maintenance_repair_ledger_json",a.toString())
                    .putInt("maintenance_repair_ledger_entry_count",p.getInt("maintenance_repair_ledger_entry_count",0)+1)
                    .putLong("maintenance_repair_ledger_last_at",System.currentTimeMillis()).apply();
        }catch(Throwable t){ recordError(c,t); }
    }

    private static void selfAwareCandidateSweep(Context c,SharedPreferences p,long now){
        if(c==null||p==null) return;
        int faults=Math.max(0,p.getInt("maintenance_truth_fault_count",0));
        int gaps=Math.max(0,p.getInt("maintenance_truth_verification_gap_count",0));
        int opportunities=Math.max(0,p.getInt("maintenance_improvement_opportunity_count",0));
        int detected=Math.max(faults,Math.max(gaps,opportunities));
        String area=p.getString("maintenance_improvement_current_area","");
        String action=p.getString("maintenance_improvement_current_action","");
        String visualState=p.getString("visual_self_check_status","NOT_RUN");
        String fingerprint=faults+"|"+gaps+"|"+opportunities+"|"+area+"|"+action+"|"+visualState;
        String prior=p.getString("maintenance_candidate_last_fingerprint","");
        if(detected<=0){
            if(!prior.isEmpty()) p.edit().putString("maintenance_candidate_last_fingerprint","").apply();
            return;
        }
        if(fingerprint.equals(prior)) return;

        String classification=faults>0?"FAULT":(gaps>0?"VERIFICATION_GAP":"IMPROVEMENT");
        String issue="self-awareness candidate: "+classification+" area="+(area.isEmpty()?"unspecified":area)+" count="+detected;
        String before="faults="+faults+" gaps="+gaps+" opportunities="+opportunities+" visualSelfCheck="+visualState;
        String next=action==null||action.trim().isEmpty()?"rank, verify, then use bounded safe repair or trusted build":action.trim();
        appendRepairLedger(c,p,issue,"Improvement Advisor finding was not represented in Code589 repair detection truth",next,before,
                "candidate persisted and ranked for maintenance","DETECTED_REPAIR_CANDIDATE");
        p.edit().putString("maintenance_candidate_last_fingerprint",fingerprint)
                .putLong("maintenance_candidate_last_at",now)
                .putInt("maintenance_candidate_detection_count",p.getInt("maintenance_candidate_detection_count",0)+detected)
                .putInt("maintenance_issue_detection_count",p.getInt("maintenance_issue_detection_count",0)+detected)
                .putString("maintenance_candidate_classification",classification)
                .putString("maintenance_candidate_area",area)
                .putString("maintenance_candidate_action",next)
                .apply();
    }

    private static void code593ResetMaintenanceCountersOnce(Context c,SharedPreferences p,long now){
        if(c==null||p==null) return;
        if(p.getBoolean("code593_maintenance_counters_reset",false)) return;
        appendRepairLedger(c,p,"Code593 maintenance counter reset",
                "Code592 counters mixed detections, scheduler recoveries and escalations with actual autonomous repair proof",
                "reset maintenance accounting; preserve historical ledger and speech evidence",
                "applied="+p.getInt("maintenance_executor_applied_changes",0)+" verified="+p.getInt("maintenance_executor_verified_repairs",0)+" escalations="+p.getInt("maintenance_executor_escalations",0),
                "all Code593 maintenance counters start at zero","COUNTERS_RESET_CODE593");
        p.edit()
                .putInt("maintenance_current_build_passes",0)
                .putInt("maintenance_current_build_issue_detections",0)
                .putInt("maintenance_current_build_repairs",0)
                .putInt("maintenance_issue_detection_count",0)
                .putInt("maintenance_candidate_detection_count",0)
                .putInt("maintenance_executor_applied_changes",0)
                .putInt("maintenance_executor_verified_repairs",0)
                .putInt("maintenance_executor_rollbacks",0)
                .putInt("maintenance_executor_escalations",0)
                .putBoolean("maintenance_executor_trial_active",false)
                .putBoolean("maintenance_executor_escalation_pending",false)
                .putLong("maintenance_executor_last_candidate_at",0L)
                .putString("maintenance_executor_last_result","RESET_CODE593")
                .putBoolean("maintenance_proactive_kickoff_done",false)
                .putString("maintenance_proactive_kickoff_result","RESET_PENDING")
                .putString("maintenance_candidate_classification","none")
                .putString("maintenance_candidate_area","")
                .putString("maintenance_candidate_action","")
                .putLong("maintenance_candidate_last_at",0L)
                .putBoolean("code593_maintenance_counters_reset",true)
                .putLong("code593_maintenance_counters_reset_at",now)
                .apply();
    }

    private static void code602ResetLifetimeCountersOnce(Context c,SharedPreferences p,long now){
        if(c==null||p==null||p.getBoolean("code602_lifetime_counters_reset",false)) return;
        int oldPass=p.getInt("maintenance_loop_pass_count",0);
        int oldIssues=p.getInt("maintenance_issue_detection_count",0);
        int oldRepairs=p.getInt("maintenance_loop_repair_count",0);
        int oldCandidates=p.getInt("maintenance_candidate_detection_count",0);
        p.edit()
                .putInt("code602_archived_lifetime_passes",oldPass)
                .putInt("code602_archived_lifetime_issue_detections",oldIssues)
                .putInt("code602_archived_lifetime_repairs",oldRepairs)
                .putInt("code602_archived_candidate_detections",oldCandidates)
                .putInt("maintenance_loop_pass_count",0)
                .putInt("maintenance_issue_detection_count",0)
                .putInt("maintenance_loop_repair_count",0)
                .putInt("maintenance_candidate_detection_count",0)
                .putInt("maintenance_current_build_passes",0)
                .putInt("maintenance_current_build_issue_detections",0)
                .putInt("maintenance_current_build_repairs",0)
                .putInt("maintenance_ledger_build_version",runningVersionCode(c))
                .putInt("maintenance_ledger_build_pass_base",0)
                .putInt("maintenance_ledger_build_repair_base",0)
                .putInt("maintenance_ledger_build_issue_base",0)
                .putBoolean("code602_lifetime_counters_reset",true)
                .putLong("code602_lifetime_counters_reset_at",now).apply();
        appendRepairLedger(c,p,"Code602 lifetime maintenance counter reset",
                "owner requested clean lifetime accounting baseline",
                "archive prior totals then reset displayed lifetime counters without deleting repair ledger history",
                "passes="+oldPass+" issues="+oldIssues+" repairs="+oldRepairs+" candidates="+oldCandidates,
                "passes=0 issues=0 repairs=0 candidates=0","COUNTERS_RESET_CODE602");
    }

    private static void proactiveMaintenanceKickoff(Context c,SharedPreferences p,long now){
        if(c==null||p==null) return;
        if(p.getBoolean("maintenance_proactive_kickoff_done",false)) return;
        if(p.getBoolean("maintenance_executor_trial_active",false)){
            p.edit().putBoolean("maintenance_proactive_kickoff_done",true).apply();
            return;
        }
        String cls=p.getString("maintenance_candidate_classification","none");
        String existingArea=p.getString("maintenance_candidate_area","");
        String existingAction=p.getString("maintenance_candidate_action","");
        long candidateAt=p.getLong("maintenance_candidate_last_at",0L);
        String existingHay=((existingArea==null?"":existingArea)+" "+(existingAction==null?"":existingAction)).toLowerCase(java.util.Locale.US);
        boolean existingActionable=candidateAt>0L && cls!=null && !"none".equalsIgnoreCase(cls) &&
                (existingHay.contains("recognizer")||existingHay.contains("speech")||existingHay.contains("start callback"));
        if(existingActionable){
            p.edit().putBoolean("maintenance_proactive_kickoff_done",true)
                    .putString("maintenance_proactive_kickoff_result","EXISTING_ACTIONABLE_CANDIDATE").apply();
            return;
        }

        int rebuilds=Math.max(0,p.getInt("speech_recognizer_rebuilds",0));
        int stalls=Math.max(0,p.getInt("speech_recognizer_callback_stalls",0));
        if(rebuilds>0 || stalls>0){
            String issue="proactive startup candidate: recurring speech recognizer recovery";
            String before="historicalRebuilds="+rebuilds+" callbackStalls="+stalls;
            String action="bounded recognizer start callback timeout trial";
            appendRepairLedger(c,p,issue,
                    "Code591 executor was waiting for a newly timestamped candidate despite unresolved historical recovery evidence",
                    action,before,"candidate seeded at executor startup","DETECTED_REPAIR_CANDIDATE");
            p.edit().putString("maintenance_candidate_classification","FAULT")
                    .putString("maintenance_candidate_area","speech recognizer start callback")
                    .putString("maintenance_candidate_action",action)
                    .putLong("maintenance_candidate_last_at",now)
                    .putInt("maintenance_candidate_detection_count",p.getInt("maintenance_candidate_detection_count",0)+1)
                    .putInt("maintenance_issue_detection_count",p.getInt("maintenance_issue_detection_count",0)+1)
                    .putBoolean("maintenance_proactive_kickoff_done",true)
                    .putString("maintenance_proactive_kickoff_result","SEEDED_RECOGNIZER_CANDIDATE_CODE593")
                    .apply();
            return;
        }

        p.edit().putBoolean("maintenance_proactive_kickoff_done",true)
                .putString("maintenance_proactive_kickoff_result","NO_EXISTING_UNRESOLVED_EVIDENCE").apply();
    }

    private static void boundedMaintenanceExecutorTick(Context c,SharedPreferences p,long now){
        if(c==null||p==null) return;
        final long TRIAL_MS=120000L;
        boolean trial=p.getBoolean("maintenance_executor_trial_active",false);
        if(trial){
            long started=p.getLong("maintenance_executor_trial_started_at",0L);
            if(started>0L && now-started>=TRIAL_MS){
                int baseline=p.getInt("maintenance_executor_trial_baseline_rebuilds",0);
                int current=p.getInt("speech_recognizer_rebuilds",0);
                int delta=Math.max(0,current-baseline);
                int startBaseline=p.getInt("maintenance_executor_trial_baseline_recognizer_starts",0);
                int starts=p.getInt("maintenance_recognizer_start_attempts",0);
                int startDelta=Math.max(0,starts-startBaseline);
                int applied=p.getInt("maintenance_recognizer_start_timeout_ms",6500);
                int previous=p.getInt("maintenance_executor_trial_previous_timeout_ms",6500);
                if(delta==0 && startDelta>=3){
                    appendRepairLedger(c,p,"bounded maintenance trial: recognizer start timeout",
                            "recurring recognizer start callback recovery candidate",
                            "kept runtime timeout="+applied+"ms after zero rebuilds during trial",
                            "baselineRebuilds="+baseline,"currentRebuilds="+current,"VERIFIED_REPAIR_PASS");
                    p.edit().putBoolean("maintenance_executor_trial_active",false)
                            .putInt("maintenance_executor_verified_repairs",p.getInt("maintenance_executor_verified_repairs",0)+1)
                            .putInt("maintenance_verified_repairs_v2",p.getInt("maintenance_verified_repairs_v2",0)+1)
                            .putString("maintenance_executor_last_result","KEEP timeout="+applied+"ms rebuildDelta=0")
                            .putLong("maintenance_executor_last_completed_at",now).apply();
                }else{
                    p.edit().putInt("maintenance_recognizer_start_timeout_ms",previous)
                            .putBoolean("maintenance_executor_trial_active",false)
                            .putInt("maintenance_executor_rollbacks",p.getInt("maintenance_executor_rollbacks",0)+1)
                            .putInt("maintenance_rollbacks_v2",p.getInt("maintenance_rollbacks_v2",0)+1)
                            .putString("maintenance_executor_last_result","ROLLBACK timeout="+applied+"->"+previous+"ms rebuildDelta="+delta)
                            .putLong("maintenance_executor_last_completed_at",now).apply();
                    appendRepairLedger(c,p,"bounded maintenance trial rollback: recognizer start timeout",
                            "trial did not eliminate recognizer rebuilds",
                            "restored previous runtime timeout="+previous+"ms",
                            "trialTimeout="+applied+"ms baselineRebuilds="+baseline,
                            "currentRebuilds="+current,"VERIFIED_REPAIR_ROLLBACK");
                }
            }
            return;
        }

        String cls=p.getString("maintenance_candidate_classification","none");
        String area=p.getString("maintenance_candidate_area","");
        String action=p.getString("maintenance_candidate_action","");
        long candidateAt=p.getLong("maintenance_candidate_last_at",0L);
        long handledAt=p.getLong("maintenance_executor_last_candidate_at",0L);
        if(candidateAt<=0L || candidateAt<=handledAt || "none".equalsIgnoreCase(cls)) return;
        String hay=((area==null?"":area)+" "+(action==null?"":action)).toLowerCase(java.util.Locale.US);

        if("VERIFICATION_GAP".equalsIgnoreCase(cls)){
            p.edit().putLong("maintenance_executor_last_candidate_at",candidateAt)
                    .putString("maintenance_executor_last_result","TARGETED_VERIFICATION_REQUIRED")
                    .putString("maintenance_verification_requested_area",area==null?"":area)
                    .putString("maintenance_verification_requested_action",action==null?"":action).apply();
            appendRepairLedger(c,p,"verification required: "+area,"finding is unproven, not a demonstrated defect",
                    action,"no mutation attempted","targeted verification queued","VERIFICATION_NOT_REPAIR");
            return;
        }

        if(hay.contains("recognizer") || hay.contains("speech") || hay.contains("start callback")){
            int previous=Math.max(6500,Math.min(9000,p.getInt("maintenance_recognizer_start_timeout_ms",6500)));
            int next=Math.min(9000,previous+500);
            if(next>previous){
                int rebuilds=p.getInt("speech_recognizer_rebuilds",0);
                p.edit().putInt("maintenance_recognizer_start_timeout_ms",next)
                        .putBoolean("maintenance_executor_trial_active",true)
                        .putLong("maintenance_executor_trial_started_at",now)
                        .putInt("maintenance_executor_trial_baseline_rebuilds",rebuilds)
                        .putInt("maintenance_executor_trial_previous_timeout_ms",previous)
                        .putLong("maintenance_executor_last_candidate_at",candidateAt)
                        .putInt("maintenance_executor_applied_changes",p.getInt("maintenance_executor_applied_changes",0)+1)
                        .putInt("maintenance_repair_attempts_v2",p.getInt("maintenance_repair_attempts_v2",0)+1)
                        .putInt("maintenance_changes_applied_v2",p.getInt("maintenance_changes_applied_v2",0)+1)
                        .putString("maintenance_executor_last_result","TRIAL recognizerStartTimeout "+previous+"->"+next+"ms")
                        .apply();
                appendRepairLedger(c,p,"bounded maintenance change: recognizer start timeout",
                        "speech/recognizer candidate selected a whitelisted runtime actuator",
                        "trial "+next+"ms for 120s; keep only with zero recognizer rebuilds",
                        "timeout="+previous+"ms rebuilds="+rebuilds,
                        "timeout="+next+"ms trial active","REPAIR_TRIAL_ACTIVE");
                return;
            }
        }

        p.edit().putLong("maintenance_executor_last_candidate_at",candidateAt)
                .putBoolean("maintenance_executor_escalation_pending",true)
                .putInt("maintenance_executor_escalations",p.getInt("maintenance_executor_escalations",0)+1)
                .putInt("maintenance_escalations_v2",p.getInt("maintenance_escalations_v2",0)+1)
                .putString("maintenance_executor_escalation_classification",cls)
                .putString("maintenance_executor_escalation_area",area==null?"":area)
                .putString("maintenance_executor_escalation_action",action==null?"":action)
                .putString("maintenance_executor_last_result","ESCALATE signed-build required")
                .apply();
        appendRepairLedger(c,p,"maintenance executor escalation: "+cls+" area="+area,
                "candidate has no whitelisted runtime actuator",
                "send precise change through trusted signed build lane",
                "candidateAction="+action,"no unsafe runtime mutation performed","ESCALATED_SIGNED_BUILD");
        LumiMaintenanceBuildHandoff.enqueue(c,p,cls,area,action,now);
    }

    static String repairLedgerBlackBoxSection(Context c,SharedPreferences p){
        ensureRepairLedgerBuildBaseline(c,p);
        int lifePass=p.getInt("maintenance_loop_pass_count",0), lifeRep=p.getInt("maintenance_loop_repair_count",0), lifeIssues=p.getInt("maintenance_issue_detection_count",0);
        int curPass=Math.max(0,lifePass-p.getInt("maintenance_ledger_build_pass_base",lifePass));
        int curRep=Math.max(0,lifeRep-p.getInt("maintenance_ledger_build_repair_base",lifeRep));
        int curIssues=Math.max(0,lifeIssues-p.getInt("maintenance_ledger_build_issue_base",lifeIssues));
        StringBuilder b=new StringBuilder();
        b.append("MAINTENANCE EVENT LEDGER\n");
        b.append("Audit coverage: itemized repair history begins with Code589; older cumulative repairs were not itemized by prior builds.\n");
        b.append("Current build code: ").append(runningVersionCode(c)).append("\n");
        b.append("Current build passes: ").append(curPass).append("\n");
        b.append("Current build issue detections: ").append(curIssues).append("\n");
        b.append("Verified repairs (Code610 truth): ").append(p.getInt("maintenance_verified_repairs_v2",0)).append("\n");
        b.append("Repair attempts: ").append(p.getInt("maintenance_repair_attempts_v2",0)).append(" • changes applied: ").append(p.getInt("maintenance_changes_applied_v2",0)).append(" • rollbacks: ").append(p.getInt("maintenance_rollbacks_v2",0)).append(" • escalations: ").append(p.getInt("maintenance_escalations_v2",0)).append("\n");
        b.append("Itemized ledger entries: ").append(p.getInt("maintenance_repair_ledger_entry_count",0)).append("\n");
        b.append("Self-aware candidate detections: ").append(p.getInt("maintenance_candidate_detection_count",0)).append("\n");
        b.append("Current candidate: ").append(p.getString("maintenance_candidate_classification","none"))
                .append(" • area=").append(p.getString("maintenance_candidate_area","none"))
                .append(" • action=").append(p.getString("maintenance_candidate_action","none")).append("\n");        b.append("Maintenance executor: applied=").append(p.getInt("maintenance_executor_applied_changes",0))
                .append(" verified=").append(p.getInt("maintenance_executor_verified_repairs",0))
                .append(" rollbacks=").append(p.getInt("maintenance_executor_rollbacks",0))
                .append(" escalations=").append(p.getInt("maintenance_executor_escalations",0))
                .append(" trial=").append(p.getBoolean("maintenance_executor_trial_active",false))
                .append(" result=").append(p.getString("maintenance_executor_last_result","none")).append("\n");        b.append("Diagnostic census v2: faults=").append(p.getInt("whole_self_current_fault_count_v2",0))
                .append(" cleanup=").append(p.getInt("whole_self_cleanup_count_v2",0))
                .append(" verificationGaps=").append(p.getInt("whole_self_verification_gap_count_v2",0))
                .append(" improvements=").append(p.getInt("whole_self_improvement_count_v2",0))
                .append(" historicalSignals=").append(p.getInt("whole_self_historical_signal_count_v2",0))
                .append(" domains=").append(p.getInt("whole_self_audit_domain_count",0))
                .append(" selfImprovementGate=").append(p.getString("self_improvement_discovery_gate","NOT_RUN")).append("\n");
        b.append("Fault queue: ").append(p.getString("whole_self_fault_queue_v2","none")).append("\n");
        b.append("Cleanup queue: ").append(p.getString("whole_self_cleanup_queue_v2","none")).append("\n");
        b.append("Verification queue: ").append(p.getString("whole_self_verification_queue_v2","none")).append("\n");
        b.append("Improvement queue: ").append(p.getString("whole_self_improvement_queue_v2","none")).append("\n");
        b.append("Build handoff: status=").append(p.getString("maintenance_build_handoff_status","NOT_REQUESTED"))
                .append(" request=").append(p.getString("maintenance_build_handoff_request_id","none"))
                .append(" tools=").append(p.getString("maintenance_build_handoff_tools","none"))
                .append(" error=").append(p.getString("maintenance_build_handoff_error","none")).append("\n");        b.append("Proactive kickoff: ").append(p.getString("maintenance_proactive_kickoff_result","NOT_RUN")).append("\n");        b.append("Lumi Codex: ").append(LumiCodex.summary(p)).append("\n");
        b.append("Lumi living self: ").append(LumiLivingSelf.summary(p)).append("\n");
        b.append("Lumi self authority: ").append(LumiSelfAuthority.summary(p)).append("\n");        b.append("Lumi runtime self model: ").append(LumiRuntimeSelfModel.snapshot(c,p)).append("\n");
        b.append("Causal current truth: ").append(LumiCausalJournal.currentTruthSummary(c,p)).append("\n");
        b.append("Workstation bridge: ").append(LumiWorkstationBridge.status(c,p)).append("\n");

        b.append("Whole-self audit: status=").append(p.getString("whole_self_audit_status","NOT_RUN")).append(" findings=").append(p.getInt("whole_self_audit_findings",0)).append(" domains=").append(p.getString("whole_self_audit_domains","none")).append("\n");
        b.append("Whole-self queue: ").append(p.getString("whole_self_audit_queue","none")).append("\n");
        b.append("Visual self-check: status=").append(p.getString("visual_self_check_status","NOT_RUN")).append(" step=").append(p.getString("visual_self_check_step","NOT_RUN")).append(" mismatchPct=").append(p.getFloat("visual_self_check_mismatch_pct",-1f)).append(" bboxWDelta=").append(p.getFloat("visual_self_check_bbox_width_delta_pct",-1f)).append(" bboxHDelta=").append(p.getFloat("visual_self_check_bbox_height_delta_pct",-1f)).append(" dx=").append(p.getFloat("visual_self_check_centroid_dx_pct",-1f)).append(" dy=").append(p.getFloat("visual_self_check_centroid_dy_pct",-1f)).append(" error=").append(p.getString("visual_self_check_error","none")).append("\n");

        try{
            JSONArray a=new JSONArray(p.getString("maintenance_repair_ledger_json","[]"));
            int start=Math.max(0,a.length()-50);
            for(int i=start;i<a.length();i++){
                JSONObject e=a.optJSONObject(i); if(e==null) continue;
                b.append("EVENT #").append(i+1).append(" | at=").append(e.optLong("timestamp",0L)).append(" | code=").append(e.optInt("versionCode",-1)).append("\n")
                        .append("  issue: ").append(e.optString("issue","")).append("\n")
                        .append("  root cause: ").append(e.optString("rootCause","")).append("\n")
                        .append("  action: ").append(e.optString("action","")).append("\n")
                        .append("  before: ").append(e.optString("before","")).append("\n")
                        .append("  after: ").append(e.optString("after","")).append("\n")
                        .append("  verification: ").append(e.optString("verification","")).append("\n");
            }
        }catch(Throwable t){ b.append("Ledger parse error: ").append(t.getClass().getSimpleName()).append("\n"); }
        return b.toString();
    }

    static void publishBlackBoxAsync(Context context,byte[] payload,String source){
        if(context==null||payload==null||payload.length==0) return;
        Context app=context.getApplicationContext(); byte[] copy=payload.clone();
        worker.execute(()->{try{publishBlackBoxNow(app,copy,source);}catch(Throwable t){recordError(app,t);}});
    }

    private static void poll(Context c)throws Exception{
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        if(!TrustedBuildRelayClient.developerChannelConfigured(p)) return;
        final boolean privilegedMaintenance=IdentityHierarchy.developerOwnerBypassEnabled(p) && !p.getBoolean("remote_maintenance_revoked",false);
        long pollOkAt=System.currentTimeMillis();
        p.edit().putBoolean("remote_maintenance_link_ok",true).putBoolean("remote_maintenance_last_ok",true)
                .putLong("remote_maintenance_last_poll_at",pollOkAt).putLong("remote_maintenance_last_recovered_at",pollOkAt)
                .putString("remote_maintenance_bridge_state","ONLINE").remove("remote_maintenance_last_error")
                .remove("remote_maintenance_last_error_at").apply();
        publishStartupHandshake(c,p);
        publishHeartbeat(c,p);
        if(privilegedMaintenance) autoFaultPublish(c,p);
        periodicOnlineBlackBoxPublish(c,p);
        maintenanceLoopTick(c,p);
        JSONObject f=TrustedBuildRelayClient.readDeveloperFile(p,".lumi/remote/command.json");
        if(f.optBoolean("missing",false)) return;
        String raw=f.optString("text","").trim(); if(raw.isEmpty()) return;
        JSONObject cmd=new JSONObject(raw);
        if(!"LumiRemoteMaintenanceCommand".equals(cmd.optString("format",""))) return;
        String id=safeId(cmd.optString("id","")); if(id.isEmpty()) return;
        if(id.equals(p.getString("remote_maintenance_last_command_id",""))) return;
        String requestedAction=cmd.optString("action","").trim().toUpperCase(Locale.US);
        boolean productionUpdateLane=!privilegedMaintenance
                && !p.getBoolean("remote_maintenance_revoked",false)
                && p.getBoolean("admin_voice_enrolled",false)
                && ("CHECK_UPDATE".equals(requestedAction) || "INSTALL_UPDATE".equals(requestedAction) || "ASK_LUMI_TEST".equals(requestedAction) || "RUN_REPLY_TEST".equals(requestedAction));
        if(!privilegedMaintenance && !productionUpdateLane){
            p.edit().putString("remote_maintenance_last_command_id",id)
                    .putLong("remote_maintenance_last_command_at",System.currentTimeMillis())
                    .putBoolean("remote_diagnostic_request_ok",false).apply();
            JSONObject denied=new JSONObject().put("ok",false).put("state","PRODUCTION_COMMAND_DENIED")
                    .put("reason","Only signed update check/install, ASK_LUMI_TEST, and RUN_REPLY_TEST are allowed with production identity");
            String deniedPath=".lumi/remote/responses/"+id+".json";
            denied.put("format","LumiRemoteMaintenanceResponse").put("id",id).put("action",requestedAction)
                    .put("versionCode",runningVersionCode(c)).put("completedAt",System.currentTimeMillis());
            TrustedBuildRelayClient.writeDeveloperFile(p,deniedPath,denied.toString(2)+"\n","Lumi production-safe remote denial "+id);
            TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/remote/latest-response.json",denied.put("responsePath",deniedPath).toString(2)+"\n","Update Lumi latest remote response");
            return;
        }
        if(productionUpdateLane){
            p.edit().putLong("code525_production_update_lane_at",System.currentTimeMillis())
                    .putString("code525_production_update_lane_action",requestedAction).apply();
        }
        long expires=cmd.optLong("expiresAt",0L);
        JSONObject result;
        if(expires>0L && System.currentTimeMillis()>expires) result=new JSONObject().put("ok",false).put("state","EXPIRED");
        else result=execute(c,p,id,requestedAction,cmd.optJSONObject("args"));
        result.put("format","LumiRemoteMaintenanceResponse").put("id",id).put("action",cmd.optString("action","")).put("versionCode",installedVersionCode(c)).put("completedAt",System.currentTimeMillis());
        String responsePath=".lumi/remote/responses/"+id+".json";
        TrustedBuildRelayClient.writeDeveloperFile(p,responsePath,result.toString(2)+"\n","Lumi remote response "+id);
        TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/remote/latest-response.json",result.put("responsePath",responsePath).toString(2)+"\n","Update Lumi latest remote response");
        boolean retryableInstallUnavailable="INSTALL_UPDATE".equals(requestedAction)
                && !result.optBoolean("ok",false)
                && "ACTIVITY_UNAVAILABLE".equals(result.optString("state",""));
        android.content.SharedPreferences.Editor commandResult=p.edit()
                .putLong("remote_maintenance_last_command_at",System.currentTimeMillis())
                .putBoolean("remote_diagnostic_request_ok",result.optBoolean("ok",false));
        if(retryableInstallUnavailable){
            commandResult.putString("remote_maintenance_retryable_install_command_id",id)
                    .putLong("remote_maintenance_retryable_install_unavailable_at",System.currentTimeMillis());
        }else{
            commandResult.putString("remote_maintenance_last_command_id",id)
                    .remove("remote_maintenance_retryable_install_command_id")
                    .remove("remote_maintenance_retryable_install_unavailable_at");
        }
        commandResult.apply();
        // Code568: after command-result persistence, publish authoritative post-command heartbeat truth.
        // Observability only: command permissions, updater verification and installer authority are unchanged.
        lastHeartbeatAt=0L;
        publishHeartbeat(c,p);
    }

    private static void publishStartupHandshake(Context c,SharedPreferences p){
        if(PROCESS_SESSION_ID.equals(p.getString("remote_maintenance_handshake_session",""))) return;
        try{
            JSONObject h=new JSONObject()
                    .put("format","LumiRemoteMaintenanceHandshake")
                    .put("formatVersion",1)
                    .put("versionCode",installedVersionCode(c))
                    .put("versionName",installedVersionName(c))
                    .put("sessionId",PROCESS_SESSION_ID)
                    .put("processStartedAt",PROCESS_STARTED_AT)
                    .put("handshakeAt",System.currentTimeMillis())
                    .put("bridgeConnected",true)
                    .put("activityActive",MainActivity.activeMaintenanceInstance!=null)
                    .put("blackBoxOnline",p.getBoolean("remote_black_box_upload_ok",false))
                    .put("blackBoxLastAt",p.getLong("remote_black_box_last_at",0L))
                    .put("blackBoxLastPath",p.getString("remote_black_box_last_path",""))
                    .put("blackBoxAgeMs",p.getLong("remote_black_box_last_at",0L)<=0L?-1L:Math.max(0L,System.currentTimeMillis()-p.getLong("remote_black_box_last_at",0L)))
                    .put("lastRelayError",p.getString("remote_maintenance_last_error",""));
            TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/remote/handshake.json",h.toString(2)+"\n","Lumi Code445 remote startup handshake");
            p.edit().putString("remote_maintenance_handshake_session",PROCESS_SESSION_ID)
                    .putLong("remote_maintenance_handshake_at",System.currentTimeMillis()).apply();
        }catch(Throwable t){
            recordError(c,t);
        }
    }

    private static void publishHeartbeat(Context c,SharedPreferences p){
        long now=System.currentTimeMillis();
        if(now-lastHeartbeatAt<60000L) return;
        try{
            JSONObject h=new JSONObject()
                    .put("format","LumiRemoteMaintenanceHeartbeat")
                    .put("formatVersion",1)
                    .put("versionCode",installedVersionCode(c))
                    .put("versionName",installedVersionName(c))
                    .put("sessionId",PROCESS_SESSION_ID)
                    .put("heartbeatAt",now)
                    .put("bridgeConnected",true)
                    .put("activityActive",MainActivity.activeMaintenanceInstance!=null)
                    .put("lastCommandId",p.getString("remote_maintenance_last_command_id",""))
                    .put("lastPollAt",p.getLong("remote_maintenance_last_poll_at",0L))
                    .put("bridgeState",p.getString("remote_maintenance_bridge_state","UNKNOWN"))
                    .put("bootstrapLineage","445->447->448->449").put("remoteUpdateDrill","CODE448_R165").put("backgroundContinuity","CODE449_R166").put("remoteUpdateStaging","CODE450_R168").put("remoteUpdateProof","CODE451_R169").put("fastBrainContextRecovery","CODE452_R170").put("fastBrainHedgeContinuity","CODE453_R171").put("fastBrainRoutePriority","CODE454_R172").put("fastBrainDirectOutput","CODE455_R173").put("fastBrainChatTemplate","CODE456_R174").put("conversationCore","CODE457_R175")
                    .put("publishedUpdateVersion",p.getLong("github_update_available_version",-1L))
                    .put("publishedUpdateId",p.getString("github_update_available_id",""))
                    .put("pendingCoreVersion",p.getLong("pending_core_version_code",-1L))
                    .put("updateState",p.getString("github_update_check_state","UNKNOWN"))
                    .put("lastInstallRequestedTarget",p.getLong("self_update_install_requested_target",-1L))
                    .put("networkRecoveryCount",p.getInt("remote_maintenance_network_recovery_count",0))
                    .put("networkFailureCount",p.getInt("remote_maintenance_network_failure_count",0))
                    .put("validatedNetworkCount",validatedNetworks.size())
                    .put("duplicateValidatedNetworkCallbacks",duplicateValidatedNetworkCallbacks.get())
                    .put("schedulerGeneration",schedulerGeneration)
                    .put("schedulerTickAt",lastSchedulerTickAt)
                    .put("coreForegroundStarted",p.getBoolean("code449_core_foreground_started",false))
                    .put("coreWakeLockHeld",p.getBoolean("code449_core_wakelock_held",false))
                    .put("coreWatchdogAt",p.getLong("code449_core_watchdog_at",0L))
                    .put("coreWatchdogCount",p.getInt("code449_core_watchdog_count",0))
                    .put("schedulerRebuildCount",p.getInt("code449_remote_scheduler_rebuild_count",0))
                    .put("schedulerRebuildCause",p.getString("code548_scheduler_rebuild_cause",""))
                    .put("schedulerTickAgeMs",lastSchedulerTickAt<=0L?-1L:Math.max(0L,now-lastSchedulerTickAt))
                    .put("sidecarAgeMs",p.getLong("code548_sidecar_age_ms",-1L))
                    .put("sidecarFresh",p.getBoolean("code548_sidecar_fresh",false))
                    .put("schedulerTickStale",lastSchedulerTickAt<=0L || Math.max(0L,now-lastSchedulerTickAt)>45000L)
                    .put("schedulerExecutorBad",p.getBoolean("code548_executor_bad",false))
                    .put("schedulerObserveOnlyCount",p.getInt("code548_observe_only_count",0))
                    .put("schedulerDestructiveRebuildCount",p.getInt("code548_destructive_rebuild_count",0))
                    .put("developerOwnerBypass",IdentityHierarchy.developerOwnerBypassEnabled(p))
                    .put("ownerVoiceEnrolled",p.getBoolean("admin_voice_enrolled",false))
                    .put("productionSafeUpdateLane",true)
                    .put("productionUpdateLaneAt",p.getLong("code525_production_update_lane_at",0L))
                    .put("productionUpdateLaneAction",p.getString("code525_production_update_lane_action",""))
                    .put("retryableInstallCommandId",p.getString("remote_maintenance_retryable_install_command_id",""))
                    .put("retryableInstallUnavailableAt",p.getLong("remote_maintenance_retryable_install_unavailable_at",0L))
                    .put("auroraProfile",p.getString("lumi_voice_profile","none"))
                    .put("auroraRuntimeVerified",p.getBoolean("lumi_voice_profile_runtime_verified",false))
                    .put("auroraApplyCount",p.getInt("lumi_voice_profile_apply_count",0))
                    .put("lastRelayError",p.getString("remote_maintenance_last_error",""));
            TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/remote/heartbeat.json",h.toString(2)+"\n","Lumi Code"+h.optInt("versionCode",0)+" remote heartbeat [skip ci]");
            lastHeartbeatAt=now;
        }catch(Throwable t){ recordError(c,t); }
    }

    private static JSONObject execute(Context c,SharedPreferences p,String id,String actionRaw,JSONObject args)throws Exception{
        String action=(actionRaw==null?"":actionRaw.trim().toUpperCase(Locale.US));
        MainActivity a=MainActivity.activeMaintenanceInstance;
        if("PING".equals(action)){
            long now=System.currentTimeMillis();
            long lastPoll=p.getLong("remote_maintenance_last_poll_at",0L);
            return new JSONObject().put("ok",true).put("state","PONG")
                    .put("sessionId",PROCESS_SESSION_ID).put("versionCode",installedVersionCode(c))
                    .put("versionName",installedVersionName(c))
                    .put("backgroundContinuity","CODE449_R166").put("remoteUpdateStaging","CODE450_R168").put("remoteUpdateProof","CODE451_R169").put("fastBrainContextRecovery","CODE452_R170").put("fastBrainHedgeContinuity","CODE453_R171").put("fastBrainRoutePriority","CODE454_R172").put("fastBrainDirectOutput","CODE455_R173").put("fastBrainChatTemplate","CODE456_R174").put("conversationCore","CODE457_R175")
                    .put("bridgeConnected",p.getBoolean("remote_maintenance_link_ok",false))
                    .put("lastPollAt",lastPoll)
                    .put("pollAgeMs",lastPoll<=0L?-1L:Math.max(0L,now-lastPoll))
                    .put("schedulerGeneration",schedulerGeneration)
                    .put("schedulerTickAt",lastSchedulerTickAt)
                    .put("coreForegroundStarted",p.getBoolean("code449_core_foreground_started",false))
                    .put("coreWakeLockHeld",p.getBoolean("code449_core_wakelock_held",false))
                    .put("coreWatchdogAt",p.getLong("code449_core_watchdog_at",0L))
                    .put("schedulerRebuildCount",p.getInt("code449_remote_scheduler_rebuild_count",0));
        }
        if("VOICE_STATUS".equals(action)){
            MainActivity voiceActivity=MainActivity.activeMaintenanceInstance;
            JSONObject v=new JSONObject().put("ok",true)
                    .put("auroraProfile",p.getString("lumi_voice_profile","none"))
                    .put("auroraRuntimeVerified",p.getBoolean("lumi_voice_profile_runtime_verified",false))
                    .put("auroraApplyCount",p.getInt("lumi_voice_profile_apply_count",0))
                    .put("auroraPitch",p.getFloat("lumi_voice_profile_pitch",0f))
                    .put("auroraRate",p.getFloat("lumi_voice_profile_rate",0f))
                    .put("engineVoice",p.getString("lumi_voice_profile_engine_voice","unknown"))
                    .put("ownerVoiceEnrolled",p.getBoolean("admin_voice_enrolled",false));
            if(voiceActivity!=null) v.put("identityDiagnostics",voiceActivity.code401IdentityDiagnosticsSnapshot());
            return v;
        }
        if("RENDERER_PROFILE_STATUS".equals(action)){
            return new JSONObject().put("ok",true).put("state","RENDERER_PROFILE_STATUS").put("versionCode",620)
                    .put("revision",p.getLong(LumiRendererControl.REV,0L)).put("profile",LumiRendererControl.snapshot(p))
                    .put("capabilities",LumiRendererControl.capabilityMap()).put("autotuneEnabled",p.getBoolean("renderer_autotune_enabled",true))
                    .put("autotuneState",p.getString("renderer_autotune_state","READY")).put("bestScore",p.getFloat("renderer_autotune_best_score",-1f));
        }
        if("RENDERER_TUNE".equals(action)){
            JSONObject vals=args==null?new JSONObject():args.optJSONObject("values"); if(vals==null)vals=args==null?new JSONObject():args;
            return LumiRendererControl.apply(c,vals,"remote-live-tune").put("state","APPLIED_LIVE");
        }
        if("RENDERER_AUTOTUNE".equals(action)){p.edit().putBoolean("renderer_autotune_enabled",false).putString("renderer_autotune_state","RETIRED_CORE_AUTHORITY_R436").apply();return new JSONObject().put("ok",false).put("state","RETIRED_CORE_AUTHORITY").put("owner","LumiCoreSelfStateEngine");}
        if("RENDERER_REVERT".equals(action)) return LumiRendererControl.revert(c).put("state","REVERTED");
        if("RENDERER_COMMIT".equals(action)) return new JSONObject().put("ok",true).put("state","COMMITTED").put("profile",LumiRendererControl.commit(c,"remote-commit"));
        if("RENDERER_PUBLISH".equals(action)) return LumiRendererControl.publish(c,"remote-publish",p.getFloat("visual_self_check_mismatch_pct",100f)).put("state","PROFILE_PUBLISHED");
        if("STATUS".equals(action)){
            JSONObject out=new JSONObject().put("ok",true).put("live",bundleJson(LiveMaintenanceSidecar.snapshot(c)))
                    .put("remoteSessionId",PROCESS_SESSION_ID)
                    .put("developerOwnerBypass",IdentityHierarchy.developerOwnerBypassEnabled(p))
                    .put("auroraRuntimeVerified",p.getBoolean("lumi_voice_profile_runtime_verified",false))
                    .put("ownerVoiceEnrolled",p.getBoolean("admin_voice_enrolled",false));
            if(a!=null){try{out.put("status",new JSONObject(LumiMaintenanceTools.execute(a,p,"get_lumi_status",new JSONObject(),"developer remote approved")));}catch(Throwable t){out.put("statusError",safe(t));}}
            return out;
        }
        if("ASK_LUMI_TEST".equals(action)){
            if(a==null) return new JSONObject().put("ok",false).put("state","ACTIVITY_UNAVAILABLE");
            String q=args==null?"":args.optString("question","").trim();
            long timeout=args==null?30000L:args.optLong("timeoutMs",30000L);
            JSONObject probe=a.remoteQuestionProbe(q,timeout);
            probe.put("action","ASK_LUMI_TEST").put("versionCode",runningVersionCode(c)).put("versionName",runningVersionName(c));
            return probe;
        }
        if("RUN_REPLY_TEST".equals(action)){
            if(a==null) return new JSONObject().put("ok",false).put("state","ACTIVITY_UNAVAILABLE");
            JSONArray questions=args==null?null:args.optJSONArray("questions");
            if(questions==null || questions.length()==0) return new JSONObject().put("ok",false).put("state","NO_QUESTIONS");
            int requested=Math.min(30,questions.length());
            long timeout=args==null?30000L:args.optLong("timeoutMs",30000L);
            JSONArray results=new JSONArray();
            int completed=0,clean=0,failed=0,degraded=0,stallRecoveries=0;
            long maxLatency=0L,totalLatency=0L;
            long started=System.currentTimeMillis();
            for(int i=0;i<requested;i++){
                String q=questions.optString(i,"").trim();
                JSONObject probe=a.remoteQuestionProbe(q,timeout); results.put(probe);
                boolean complete=probe.optBoolean("ok",false) && "COMPLETE".equals(probe.optString("state",""));
                String reply=probe.optString("reply","").trim();
                String route=probe.optString("route","").trim().toLowerCase(Locale.US);
                String stage=probe.optString("stage","").trim().toLowerCase(Locale.US);
                String low=reply.toLowerCase(Locale.US);
                boolean fallback=route.equals("safe-offline")||stage.contains("offline fallback")||
                        low.contains("couldn't get a clean local answer")||low.contains("still offline")||
                        low.contains("local answer did not pass my quality check")||low.contains("won't guess");
                int stalls=Math.max(0,probe.optInt("stallRecoveriesDelta",0));
                long latency=Math.max(0L,probe.optLong("responseLatencyMs",0L));
                stallRecoveries+=stalls;
                if(complete){completed++;totalLatency+=latency;maxLatency=Math.max(maxLatency,latency);}
                boolean cleanReply=complete&&!reply.isEmpty()&&stalls==0&&!fallback;
                if(fallback)degraded++;
                if(cleanReply)clean++;else failed++;
                probe.put("quality",cleanReply?"CLEAN":fallback?"DEGRADED_FALLBACK":"OBSERVED_FAILURE");
            }
            boolean pass=requested>0&&clean==requested;
            long now=System.currentTimeMillis();
            p.edit().putLong("remote_reply_test_at",now).putInt("remote_reply_test_requested",requested)
                    .putInt("remote_reply_test_completed",completed).putInt("remote_reply_test_clean",clean)
                    .putInt("remote_reply_test_failed",failed).putInt("remote_reply_test_degraded",degraded)
                    .putInt("remote_reply_test_stall_recoveries",stallRecoveries).putBoolean("remote_reply_test_pass",pass).apply();
            return new JSONObject().put("ok",pass).put("state",pass?"PASS":"COMPLETE_WITH_FAILURES")
                    .put("requested",requested).put("completed",completed).put("clean",clean).put("failed",failed).put("degraded",degraded)
                    .put("stallRecoveries",stallRecoveries).put("avgLatencyMs",completed==0?-1L:totalLatency/completed)
                    .put("maxLatencyMs",completed==0?-1L:maxLatency).put("elapsedMs",Math.max(0L,now-started)).put("results",results);
        }
        if("SEND_BLACK_BOX".equals(action)){
            byte[] b=LumiBlackBox2.bytes(c,p);
            if(b.length==0) return new JSONObject().put("ok",false).put("state","ACTIVITY_UNAVAILABLE");
            JSONObject uploaded=publishBlackBoxNow(c,b,"remote-command:"+id);
            p.edit().putBoolean("remote_black_box_request_ok",uploaded.optBoolean("ok",false)).apply();
            return uploaded;
        }
        if("CHECK_UPDATE".equals(action)){
            JSONObject update=TrustedBuildRelayClient.checkPublishedUpdate(c,p,true);
            return new JSONObject().put("ok",true)
                    .put("state",update.optString("state","CHECK_COMPLETE"))
                    .put("update",update)
                    .put("pendingCoreVersion",p.getLong("pending_core_version_code",-1L))
                    .put("downloadState",p.getString("github_update_check_state",""));
        }
        if("INSTALL_UPDATE".equals(action)){
            if(a==null) return new JSONObject().put("ok",false).put("state","ACTIVITY_UNAVAILABLE")
                    .put("reason","Android installer handoff needs a usable Lumi activity; package security is not bypassed");
            JSONObject update=TrustedBuildRelayClient.checkPublishedUpdate(a,p,true);
            long installed=-1L;
            try{android.content.pm.PackageInfo pi=a.getPackageManager().getPackageInfo(a.getPackageName(),0); installed=android.os.Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode;}catch(Throwable ignored){}
            long freshTarget=update.optLong("target_version",-1L);
            String freshState=update.optString("state","");
            long pending=p.getLong("pending_core_version_code",-1L);
            if("UPDATE_DOWNLOADED".equals(freshState) && freshTarget>installed && (pending<=installed || pending!=freshTarget)){
                java.io.File cached=TrustedBuildRelayClient.publishedUpdatePackageFile(a,p);
                if(cached==null || !cached.isFile())
                    return new JSONObject().put("ok",false).put("state","DOWNLOADED_CACHE_MISSING").put("freshTarget",freshTarget);
                LumiUpdateManager.Result staged=LumiUpdateManager.applyTrustedPackageBlocking(a,p,cached,null);
                pending=p.getLong("pending_core_version_code",-1L);
                p.edit().putLong("code450_remote_stage_attempt_at",System.currentTimeMillis())
                        .putLong("code450_remote_stage_target",freshTarget)
                        .putLong("code450_remote_stage_pending",pending)
                        .putBoolean("code450_remote_stage_core_ready",staged!=null && staged.coreInstallReady).apply();
            }
            if(!"UPDATE_DOWNLOADED".equals(freshState) || pending<=installed || freshTarget<=installed || pending!=freshTarget){
                return new JSONObject().put("ok",false).put("state","PENDING_CORE_STALE_OR_MISSING")
                        .put("installedVersion",installed).put("freshTarget",freshTarget).put("pendingCoreVersion",pending)
                        .put("update",update).put("downloadState",p.getString("github_update_check_state",""));
            }
            boolean launched=LumiUpdateManager.launchPendingCoreInstaller(a,p);
            return new JSONObject().put("ok",true)
                    .put("state",launched?"INSTALL_PREPARATION_DISPATCHED":"INSTALL_HANDOFF_ALREADY_ACTIVE")
                    .put("installedVersion",installed)
                    .put("freshTarget",freshTarget)
                    .put("pendingCoreVersion",pending)
                    .put("androidApprovalMayBeRequired",true);
        }
        if("RESTART_LUMI".equals(action)){
            if(a==null) return new JSONObject().put("ok",false).put("state","ACTIVITY_UNAVAILABLE");
            final MainActivity target=a;
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->{
                try{
                    android.content.Intent launch=target.getPackageManager().getLaunchIntentForPackage(target.getPackageName());
                    if(launch!=null){
                        launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK|android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        target.startActivity(launch);
                    }
                    target.finishAffinity();
                }catch(Throwable ignored){}
            },1500L);
            return new JSONObject().put("ok",true).put("state","RESTART_SCHEDULED").put("delayMs",1500);
        }
        if("REPAIR_SPEECH".equals(action)) return guardianRepair(a,p,id,"speech_rebuild");
        if("BRIDGE_REINITIALIZE".equals(action)) return guardianRepair(a,p,id,"bridge_reinitialize");
        if("FAST_BRAIN_RECOVER".equals(action)) return guardianRepair(a,p,id,"fast_brain_recover");
        return new JSONObject().put("ok",false).put("state","ACTION_NOT_ALLOWLISTED").put("allowed",new JSONArray().put("PING").put("STATUS").put("VOICE_STATUS").put("ASK_LUMI_TEST").put("RUN_REPLY_TEST").put("SEND_BLACK_BOX").put("CHECK_UPDATE").put("INSTALL_UPDATE").put("RESTART_LUMI").put("REPAIR_SPEECH").put("BRIDGE_REINITIALIZE").put("FAST_BRAIN_RECOVER"));
    }

    private static JSONObject guardianRepair(MainActivity a,SharedPreferences p,String commandId,String action)throws Exception{
        if(a==null) return new JSONObject().put("ok",false).put("state","ACTIVITY_UNAVAILABLE");
        JSONObject requestArgs=new JSONObject().put("requested_change","Developer remote bounded runtime repair: "+action).put("change_type","runtime_tuning");
        JSONObject req=new JSONObject(LumiMaintenanceTools.execute(a,p,"submit_maintenance_request",requestArgs,"developer remote approved"));
        if(!req.optBoolean("ok",false)) return new JSONObject().put("ok",false).put("state","GUARDIAN_REQUEST_REJECTED").put("guardian",req);
        String requestId=req.optString("request_id",req.optString("requestId",req.optString("transactionId","")));
        if(requestId.isEmpty()) return new JSONObject().put("ok",false).put("state","GUARDIAN_REQUEST_ID_MISSING").put("guardian",req);
        JSONObject fixArgs=new JSONObject().put("request_id",requestId).put("action",action);
        JSONObject fix=new JSONObject(LumiMaintenanceTools.execute(a,p,"apply_runtime_fix",fixArgs,"developer remote approved"));
        boolean ok=fix.optBoolean("ok",false);
        p.edit().putBoolean("remote_guardian_authorization_ok",ok).putBoolean("remote_repair_ok",ok).putLong("remote_repair_last_at",System.currentTimeMillis()).apply();
        return new JSONObject().put("ok",ok).put("state",ok?"GUARDIAN_REPAIR_ACCEPTED":"GUARDIAN_REPAIR_FAILED").put("requestId",requestId).put("guardianRequest",req).put("repair",fix).put("commandId",commandId);
    }

    private static long installedVersionCode(Context c){
        try{ android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0); return android.os.Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode; }catch(Throwable ignored){ return -1L; }
    }

    private static String installedVersionName(Context c){
        try{ android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0); return pi.versionName==null?"unknown":pi.versionName; }catch(Throwable ignored){ return "unknown"; }
    }

    private static JSONObject publishBlackBoxNow(Context c,byte[] payload,String source)throws Exception{
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        if(!TrustedBuildRelayClient.developerChannelConfigured(p)) return new JSONObject().put("ok",false).put("state","RELAY_NOT_CONFIGURED");
        byte[] bounded=bound(currentStateOnly(payload),MAX_BLACK_BOX_BYTES);
        long now=System.currentTimeMillis(); String name="Lumi-BlackBox-"+now+".txt"; String path=".lumi/blackbox/"+name;
        String text=new String(bounded,StandardCharsets.UTF_8);
        TrustedBuildRelayClient.writeDeveloperFile(p,path,text,"Publish Lumi Black Box "+now);
        TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/blackbox/current.txt",text,"Update stable Lumi Black Box 2 current evidence [skip ci]");
        p.edit().putInt("remote_black_box_stable_version",(int)installedVersionCode(c)).putLong("remote_black_box_stable_at",now)
                .putString("remote_black_box_stable_path",".lumi/blackbox/current.txt").apply();
        String sha=sha256(bounded);
        JSONObject latest=new JSONObject().put("format","LumiBlackBoxPointer").put("versionCode",installedVersionCode(c)).put("path",path).put("sha256",sha).put("bytes",bounded.length).put("source",source==null?"unknown":source).put("publishedAt",now);
        TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/blackbox/latest.json",latest.toString(2)+"\n","Update latest Lumi Black Box pointer");
        rotate(p,path);
        p.edit().putBoolean("remote_black_box_upload_ok",true).putString("remote_black_box_last_path",path).putString("remote_black_box_last_sha256",sha)
                .putLong("remote_black_box_last_at",now).putInt("remote_black_box_upload_count",safeInc(p.getInt("remote_black_box_upload_count",0))).apply();
        return new JSONObject().put("ok",true).put("state","BLACK_BOX_PUBLISHED").put("path",path).put("sha256",sha).put("bytes",bounded.length).put("source",source);
    }

    private static void rotate(SharedPreferences p,String newPath)throws Exception{
        JSONObject idxFile=TrustedBuildRelayClient.readDeveloperFile(p,".lumi/blackbox/index.json");
        JSONArray a=new JSONArray();
        if(!idxFile.optBoolean("missing",false)) try{a=new JSONObject(idxFile.optString("text","{}")).optJSONArray("paths"); if(a==null)a=new JSONArray();}catch(Throwable ignored){a=new JSONArray();}
        JSONArray next=new JSONArray(); next.put(newPath);
        for(int i=0;i<a.length();i++){String x=a.optString(i,""); if(!x.isEmpty()&&!x.equals(newPath))next.put(x);}
        while(next.length()>BLACK_BOX_RETAIN){String old=next.optString(next.length()-1,""); if(!old.isEmpty())try{TrustedBuildRelayClient.deleteDeveloperFile(p,old,"Rotate old Lumi Black Box");}catch(Throwable ignored){}; JSONArray trimmed=new JSONArray(); for(int i=0;i<next.length()-1;i++)trimmed.put(next.optString(i)); next=trimmed;}
        TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/blackbox/index.json",new JSONObject().put("format","LumiBlackBoxIndex").put("retain",BLACK_BOX_RETAIN).put("paths",next).put("updatedAt",System.currentTimeMillis()).toString(2)+"\n","Update Lumi Black Box retention index");
    }


    static void publishCompactBlackBoxAsync(Context context,String source){
        if(context==null)return;
        Context app=context.getApplicationContext();
        worker.execute(()->{
            SharedPreferences p=app.getSharedPreferences("lumi",Context.MODE_PRIVATE);
            try{ publishBlackBoxNow(app,LumiBlackBox2.bytes(app,p),source==null?"automatic-code660":source); }
            catch(Throwable t){ p.edit().putInt("remote_black_box_stable_write_failures",p.getInt("remote_black_box_stable_write_failures",0)+1).apply(); recordError(app,t); }
        });
    }

    private static void periodicOnlineBlackBoxPublish(Context c,SharedPreferences p){
        long now=System.currentTimeMillis();
        int faults=Math.max(0,p.getInt("whole_self_current_fault_count_v2",0));
        long interval=faults>0?ONLINE_BLACK_BOX_FAULT_REFRESH_MS:ONLINE_BLACK_BOX_HEALTHY_REFRESH_MS;
        long last=p.getLong("remote_black_box_last_at",0L);
        boolean bootPending=p.getBoolean("code622_boot_black_box_pending",false);
        if(!bootPending && last>0L && now-last<interval)return;
        byte[] b=LumiBlackBox2.bytes(c,p);
        if(b==null||b.length==0){
            p.edit().putBoolean("remote_black_box_online_ready",false).putString("remote_black_box_online_state","ACTIVITY_UNAVAILABLE").apply();
            return;
        }
        try{
            JSONObject pub=publishBlackBoxNow(c,b,"periodic-online-current");
            boolean ok=pub.optBoolean("ok",false);
            p.edit().putBoolean("remote_black_box_online_ready",ok).putString("remote_black_box_online_state",pub.optString("state","UNKNOWN"))
                    .putLong("remote_black_box_online_refresh_at",now).apply();
            if(ok){
                p.edit().putBoolean("code622_boot_black_box_pending",false).putLong("code622_boot_black_box_published_at",now).apply();
                JSONObject summary=new JSONObject().put("format","LumiBlackBoxOnlineSummary").put("formatVersion",1)
                        .put("versionCode",runningVersionCode(c)).put("versionName",runningVersionName(c))
                        .put("publishedAt",now).put("blackBoxPath",pub.optString("path",""))
                        .put("blackBoxSha256",pub.optString("sha256",""))
                        .put("currentFaults",p.getInt("whole_self_current_fault_count_v2",0))
                        .put("cleanup",p.getInt("whole_self_cleanup_count_v2",0))
                        .put("verificationGaps",p.getInt("whole_self_verification_gap_count_v2",0))
                        .put("improvements",p.getInt("whole_self_improvement_count_v2",0))
                        .put("selfImprovementGate",p.getString("self_improvement_discovery_gate","NOT_RUN"))
                        .put("recognizerPhase",p.getString("code612_recognizer_phase","UNKNOWN"))
                        .put("conversationState",p.getString("conversation_runtime_state","UNKNOWN"))
                        .put("verifiedRepairs",p.getInt("maintenance_verified_repairs_v2",0));
                TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/blackbox/latest-summary.json",summary.toString(2)+"\n","Update Lumi online Black Box summary");
            }
        }catch(Throwable t){recordError(c,t);}
    }

    private static void autoFaultPublish(Context c,SharedPreferences p){
        int speech=p.getInt("speech_recognizer_rebuilds",0), stalls=p.getInt("runtime_stall_recoveries",0), deaf=p.getInt("ready_but_deaf_incidents",0);
        if(!p.getBoolean("remote_fault_baseline_initialized",false)){
            p.edit().putBoolean("remote_fault_baseline_initialized",true).putInt("remote_fault_speech",speech).putInt("remote_fault_stalls",stalls).putInt("remote_fault_deaf",deaf).apply(); return;
        }
        boolean changed=speech>p.getInt("remote_fault_speech",speech)||stalls>p.getInt("remote_fault_stalls",stalls)||deaf>p.getInt("remote_fault_deaf",deaf);
        p.edit().putInt("remote_fault_speech",speech).putInt("remote_fault_stalls",stalls).putInt("remote_fault_deaf",deaf).apply();
        if(!changed) return;
        long now=System.currentTimeMillis(); if(now-p.getLong("remote_fault_last_black_box_at",0L)<AUTO_FAULT_UPLOAD_COOLDOWN_MS)return;
        byte[] b=LumiBlackBox2.bytes(c,p); if(b.length==0)return;
        try{publishBlackBoxNow(c,b,"automatic-runtime-fault");p.edit().putLong("remote_fault_last_black_box_at",now).apply();}catch(Throwable t){recordError(c,t);}
    }

    private static byte[] currentStateOnly(byte[] in){
        if(in==null||in.length==0)return new byte[0];
        String text=new String(in,StandardCharsets.UTF_8);
        StringBuilder out=new StringBuilder(Math.min(text.length(),128*1024));
        boolean skip=false;
        for(String line:text.split("\n",-1)){
            String u=line.trim().toUpperCase(Locale.US);
            boolean historical=u.contains("HISTORICAL")||u.contains("LIFETIME COUNTER")||u.contains("ARCHIVED LIFETIME")||u.startsWith("PROCESS EXIT HISTORY")||u.startsWith("FORENSIC INCIDENT HISTORY");
            boolean section=u.matches("^[A-Z0-9][A-Z0-9 /_()-]{5,}$");
            if(historical){ skip=true; continue; }
            if(skip && section) skip=false;
            if(!skip) out.append(line).append('\n');
        }
        return out.toString().getBytes(StandardCharsets.UTF_8);
    }

    private static byte[] bound(byte[] in,int max){
        if(in==null)return new byte[0]; if(in.length<=max)return in;
        String header="LUMI BLACK BOX REMOTE PROFILE\nOldest content clipped to remote ceiling. Full on-device recorder remains intact.\n\n";
        byte[] h=header.getBytes(StandardCharsets.UTF_8); int keep=Math.max(0,max-h.length); byte[] out=new byte[h.length+keep];
        System.arraycopy(h,0,out,0,h.length); System.arraycopy(in,in.length-keep,out,h.length,keep); return out;
    }
    private static JSONObject bundleJson(Bundle b)throws Exception{JSONObject o=new JSONObject(); if(b==null)return o; for(String k:b.keySet()){Object v=b.get(k); o.put(k,v==null?JSONObject.NULL:String.valueOf(v));} return o;}
    private static String sha256(byte[] b)throws Exception{MessageDigest m=MessageDigest.getInstance("SHA-256");StringBuilder s=new StringBuilder();for(byte x:m.digest(b))s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static String safeId(String s){String x=s==null?"":s.trim();return x.matches("[A-Za-z0-9._-]{3,80}")?x:"";}
    private static String safe(Throwable t){return t==null?"":SecretStore.redact(t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()));}
    private static void recordError(Context c,Throwable t){
        try{
            SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
            SharedPreferences.Editor e=p.edit().putBoolean("remote_maintenance_last_ok",false)
                    .putString("remote_maintenance_last_error",safe(t)).putLong("remote_maintenance_last_error_at",System.currentTimeMillis());
            if(TrustedBuildRelayClient.isRetryable(t)){
                e.putString("remote_maintenance_bridge_state","NETWORK_RETRY_PENDING")
                        .putInt("remote_maintenance_network_failure_count",p.getInt("remote_maintenance_network_failure_count",0)+1);
            }else e.putString("remote_maintenance_bridge_state","ERROR");
            e.apply();
        }catch(Throwable ignored){}
    }
    private static String runningVersionName(Context c){
        try{
            android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0);
            return pi.versionName==null?"unknown":pi.versionName;
        }catch(Throwable t){ return "unknown"; }
    }
}

// CODE458_R176: recognizer rearm circuit release marker

// CODE459_R177: recovery idle handoff release marker

// CODE460_R178: recognizer idle phase synchronization marker

// CODE461_R179: authoritative recovery runtime idle commit marker

// CODE463_R181: Core2 fresh-runtime boundary + baseline metrics marker

// CODE464_R182: Core2 shadow runtime controller marker

// CODE465_R183: Core2 UI authority snapshot marker

// CODE466_R184: Core2 SpeechEngine + AudioCoordinator + required-Core catch-up marker

// CODE467_R185: quiet-terminal recognizer semantics + bounded startup acquisition marker

// CODE473_R191: conversation latency hotfix marker
