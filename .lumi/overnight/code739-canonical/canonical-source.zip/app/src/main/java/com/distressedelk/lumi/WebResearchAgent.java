package com.distressedelk.lumi;

import android.content.SharedPreferences;
import com.distressedelk.lumi.intelligence.Evidence;
import com.distressedelk.lumi.intelligence.EvidenceSet;
import com.distressedelk.lumi.intelligence.FreeWebEndpoints;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

/** Code516 web answer hardening.
 * Web retrieval is allowed to be messy; Lumi's spoken answer is not. This layer now
 * blocks vague recommendation searches, strips markup/CSS/navigation debris, and
 * refuses to speak raw scraped payloads when synthesis fails.
 */
final class WebResearchAgent {
    interface Callback{void onSuccess(String answer,String evidence);void onFailure(String error);}
    private WebResearchAgent(){}

    private static final Pattern VAGUE_RECOMMENDATION=Pattern.compile(
            "^\\s*(what\\s+do\\s+you\\s+recommend|what\\s+would\\s+you\\s+recommend|recommend\\s+something|any\\s+recommendations|what\\s+should\\s+i\\s+(read|watch|eat|buy|listen\\s+to)?)\\s*[?.!]*\\s*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern DIRTY_PAYLOAD=Pattern.compile(
            "(?is)(@media|font-family|line-height|letter-spacing|z-index|\\{\s*color\s*:|\\.[a-z0-9_-]+\s*\\{|</?[a-z][^>]*>|rd-box-title|card-box-title|GENERAL ENGLISH|IELTS|\\bnav\\b|\\bfooter\\b|\\bContact\\s+General\\b|\\s[{};]{2,})");

    static boolean shouldResearch(String q){
        String l=q==null?"":q.toLowerCase(Locale.US);
        if(isVagueRecommendation(q))return false;
        return l.matches(".*\\b(today|current|currently|latest|recent|news|price|schedule|release|version|who is|where is|what happened|this week|right now)\\b.*")
                || l.length()>180
                || l.matches(".*\\b(compare|research|verify|look up|find out|check online|search the web|analyze|evaluate|pros and cons|which is better|what are the risks|recommend)\\b.*");
    }

    static void lookup(SharedPreferences prefs,String query,Callback cb){
        if(isVagueRecommendation(query)){ cb.onSuccess(clarifyRecommendation(),""); return; }
        new Thread(()->{
            long started=System.currentTimeMillis();
            try{
                String direct=sanitizeAnswer(duckDuckGoLookup(query));
                if(direct!=null && !direct.isBlank() && !looksDirty(direct)){
                    recordLookup(prefs,query,1,System.currentTimeMillis()-started,0.76f,false,"duckduckgo-instant");
                    cb.onSuccess(direct,"DuckDuckGo Instant Answer");
                    return;
                }
                Lookup wiki=wikipediaLookup(query);
                if(wiki!=null && !wiki.text.isBlank()){
                    String answer=sanitizeAnswer(compactSentences(wiki.text,3,700));
                    if(!wiki.url.isBlank()) answer += "\nSource: "+wiki.url;
                    recordLookup(prefs,query,1,System.currentTimeMillis()-started,0.84f,false,"wikipedia-summary");
                    cb.onSuccess(answer,wiki.text);
                    return;
                }
                cb.onFailure("No structured direct answer");
            }catch(Throwable t){ cb.onFailure(t.getClass().getSimpleName()+": "+safe(t.getMessage())); }
        },"LumiWebLookup").start();
    }

    static void research(SharedPreferences prefs,String query,Callback cb){ research(prefs,query,3,cb); }

    static void research(SharedPreferences prefs,String query,int desiredSources,Callback cb){
        if(isVagueRecommendation(query)){ cb.onSuccess(clarifyRecommendation(),""); return; }
        new Thread(()->{
            long started=System.currentTimeMillis();
            try{
                int target=Math.max(2,Math.min(4,desiredSources));
                String qLower=query==null?"":query.toLowerCase(Locale.US);
                boolean newsLike=qLower.matches(".*\\b(news|latest|today|this week|current developments|what happened)\\b.*");
                String searchUrl="https://html.duckduckgo.com/html/?q="+URLEncoder.encode(query,"UTF-8")+(newsLike?"&df=w":"");
                String html=get(searchUrl,9000,13000,350000,"text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5");
                ArrayList<ResultLink> results=parseResults(html);
                if(results.isEmpty())throw new IOException("No useful search results returned");

                EvidenceSet evidenceSet=new EvidenceSet();
                StringBuilder evidenceText=new StringBuilder();
                int pagesRead=0;
                for(ResultLink r:results){
                    if(pagesRead>=target)break;
                    String targetUrl=unwrapDuckDuckGo(r.href);
                    if(!(targetUrl.startsWith("https://")||targetUrl.startsWith("http://")))continue;
                    try{
                        String page=get(targetUrl,8000,12000,300000,"text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.5");
                        String text=cleanPageText(page);
                        if(text.length()<120 || looksDirty(text))continue;
                        text=compactSentences(text,8,2600);
                        if(looksDirty(text)) text=cleanLooseText(text);
                        if(text.length()<120 || looksDirty(text))continue;
                        String publisher=publisher(targetUrl);
                        Evidence ev=new Evidence(cleanLooseText(r.title),targetUrl,publisher,text,System.currentTimeMillis(),quality(targetUrl),true);
                        evidenceSet.add(ev);
                        pagesRead++;
                    }catch(Throwable ignored){}
                }
                if(evidenceSet.size()==0) throw new IOException("Search returned links but no clean readable pages");

                int n=0;
                for(Evidence ev:evidenceSet.ranked()){
                    n++;
                    evidenceText.append("SOURCE ").append(n).append(": ").append(ev.title()).append("\nURL: ").append(ev.url()).append("\n").append(ev.text()).append("\n\n");
                }
                final String evText=evidenceText.toString();
                final int sourceCount=evidenceSet.size();
                final float confidence=(float)evidenceSet.confidence();
                final boolean corroborated=evidenceSet.hasIndependentCorroboration();
                final long retrievalMs=System.currentTimeMillis()-started;
                prefs.edit().putString("last_web_query",query)
                        .putInt("last_web_source_count",sourceCount)
                        .putInt("last_web_pages_read",pagesRead)
                        .putFloat("last_web_evidence_confidence",confidence)
                        .putBoolean("last_web_independent_corroboration",corroborated)
                        .putLong("last_web_retrieval_ms",retrievalMs)
                        .putLong("last_web_research_at",System.currentTimeMillis()).apply();

                if(!CloudBrainRouter.anyConfigured(prefs)){
                    cb.onSuccess(deterministicEvidenceAnswer(evidenceSet,query),evText);
                    return;
                }
                final long reasoningStarted=System.currentTimeMillis();
                CloudBrainRouter.requestConsensus(prefs,
                        "Use only the independently opened web evidence below as current external grounding. Compare claims across sources. Prefer primary or official sources when present. If sources disagree, say so. Answer the user's actual question concisely in natural language. Never output HTML, CSS, site navigation, source page boilerplate, or raw snippets. If the request is too vague, ask one short clarifying question.\n\nWEB EVIDENCE:\n"+bounded(evText,9000),
                        "",query,new CloudBrainRouter.Callback(){
                    public void onSuccess(String reply,String provider,String model){
                        prefs.edit().putLong("last_web_reasoning_ms",System.currentTimeMillis()-reasoningStarted).apply();
                        String clean=sanitizeAnswer(reply);
                        if(clean.isBlank() || looksDirty(clean)) clean=deterministicEvidenceAnswer(evidenceSet,query);
                        cb.onSuccess(clean,evText);
                    }
                    public void onFailure(String error){
                        prefs.edit().putString("last_web_reasoning_error",safe(error)).putLong("last_web_reasoning_ms",System.currentTimeMillis()-reasoningStarted).apply();
                        cb.onSuccess(deterministicEvidenceAnswer(evidenceSet,query),evText);
                    }
                });
            }catch(Throwable t){cb.onFailure(t.getClass().getSimpleName()+": "+safe(t.getMessage()));}
        },"LumiWebResearch").start();
    }

    private static void recordLookup(SharedPreferences prefs,String q,int count,long ms,float confidence,boolean corroborated,String route){
        prefs.edit().putString("last_web_query",q).putInt("last_web_source_count",count).putInt("last_web_pages_read",count)
                .putFloat("last_web_evidence_confidence",confidence).putBoolean("last_web_independent_corroboration",corroborated)
                .putLong("last_web_retrieval_ms",ms).putString("last_web_lookup_route",route).putLong("last_web_research_at",System.currentTimeMillis()).apply();
    }

    private static String duckDuckGoLookup(String query)throws Exception{
        String raw=get(FreeWebEndpoints.duckDuckGoInstant(query),7000,10000,220000,"application/json,text/plain;q=0.9,*/*;q=0.5");
        JSONObject o=new JSONObject(raw);
        String text=firstNonBlank(o.optString("Answer",""),o.optString("AbstractText",""),o.optString("Definition",""));
        if(text.isBlank()) return null;
        String url=firstNonBlank(o.optString("AbstractURL",""),o.optString("DefinitionURL",""));
        String answer=compactSentences(text,3,650);
        return url.isBlank()?answer:answer+"\nSource: "+url;
    }

    private static final class Lookup{final String text,url;Lookup(String t,String u){text=t;url=u;}}
    private static Lookup wikipediaLookup(String query)throws Exception{
        String raw=get(FreeWebEndpoints.wikipediaOpenSearch(query),7000,10000,180000,"application/json,text/plain;q=0.9,*/*;q=0.5");
        JSONArray a=new JSONArray(raw); if(a.length()<4)return null;
        JSONArray titles=a.optJSONArray(1), urls=a.optJSONArray(3); if(titles==null||titles.length()==0)return null;
        String title=titles.optString(0,""); if(title.isBlank())return null;
        String summaryRaw=get(FreeWebEndpoints.wikipediaSummary(title),7000,10000,220000,"application/json,text/plain;q=0.9,*/*;q=0.5");
        JSONObject s=new JSONObject(summaryRaw); String text=s.optString("extract","");
        String url=urls==null?"":urls.optString(0,"");
        return text.isBlank()?null:new Lookup(text,url);
    }

    private static String deterministicEvidenceAnswer(EvidenceSet set,String query){
        List<Evidence> ranked=set.ranked();
        if(ranked.isEmpty())return "I reached the web, but I couldn't extract enough clean text to answer safely.";
        Set<String> terms=queryTerms(query);
        StringBuilder out=new StringBuilder();
        int used=0;
        for(Evidence e:ranked){
            String sentence=bestRelevantSentence(e.text(),terms,360);
            sentence=sanitizeAnswer(sentence);
            if(sentence.isBlank() || looksDirty(sentence))continue;
            if(!terms.isEmpty() && relevanceScore(sentence,terms)<=0)continue;
            if(out.length()>0)out.append(" ");
            out.append(sentence);
            if(++used>=2)break;
        }
        if(out.length()==0)
            return "I found current sources, but they didn't cleanly answer that question. Ask me a more specific version and I won't guess from unrelated page text.";
        if(set.hasIndependentCorroboration()) out.append(" [Checked across ").append(set.size()).append(" independent sources.]");
        else out.append(" [One usable publisher; confidence is limited.]");
        String answer=bounded(out.toString(),760);
        return looksDirty(answer)?"I found sources, but the page text was too messy to turn into a clean answer.":answer;
    }

    private static Set<String> queryTerms(String query){
        LinkedHashSet<String> out=new LinkedHashSet<>();
        if(query==null)return out;
        Set<String> stop=new HashSet<>(Arrays.asList("what","whats","what's","when","where","which","who","why","how","the","a","an","is","are","was","were","be","been","to","of","for","and","or","in","on","at","with","from","about","today","latest","current","currently","recent","right","now","please","tell","me"));
        for(String x:query.toLowerCase(Locale.US).replaceAll("[^a-z0-9 ]"," ").split("\\s+"))
            if(x.length()>=3 && !stop.contains(x)) out.add(x);
        return out;
    }

    private static int relevanceScore(String sentence,Set<String> terms){
        if(sentence==null||terms==null||terms.isEmpty())return 0;
        String l=sentence.toLowerCase(Locale.US);int score=0;
        for(String t:terms)if(l.contains(t))score++;
        return score;
    }

    private static String bestRelevantSentence(String text,Set<String> terms,int maxChars){
        String clean=cleanLooseText(text); if(clean.isBlank())return "";
        String[] parts=clean.split("(?<=[.!?])\\s+");
        String best="";int bestScore=-1;
        for(String p:parts){
            String x=p.trim(); if(x.isEmpty()||looksDirty(x))continue;
            int score=terms==null||terms.isEmpty()?0:relevanceScore(x,terms);
            if(score>bestScore){best=x;bestScore=score;}
            if(score>=Math.min(2,terms==null?0:terms.size()))break;
        }
        return bounded(best,maxChars);
    }

    private static boolean isVagueRecommendation(String q){return q!=null && VAGUE_RECOMMENDATION.matcher(q.trim()).matches();}
    private static String clarifyRecommendation(){return "Sure. What kind of recommendation do you want: food, books, movies, music, shopping, or something else?";}

    private static boolean looksDirty(String s){
        String x=s==null?"":s;
        if(DIRTY_PAYLOAD.matcher(x).find())return true;
        int braces=0, semis=0;
        for(int i=0;i<x.length();i++){char c=x.charAt(i); if(c=='{'||c=='}')braces++; if(c==';')semis++;}
        return (x.length()>120 && braces+semis>8) || x.matches("(?s).*\\b[A-Z]{4,}(\\s+[A-Z]{4,}){4,}.*");
    }

    private static String sanitizeAnswer(String s){
        String x=cleanLooseText(s);
        if(x.length()>1000)x=bounded(x,1000);
        return x;
    }

    private static String cleanPageText(String s){
        if(s==null)return "";
        String x=s.replaceAll("(?is)<script.*?</script>"," ")
                .replaceAll("(?is)<style.*?</style>"," ")
                .replaceAll("(?is)<noscript.*?</noscript>"," ")
                .replaceAll("(?is)<nav.*?</nav>"," ")
                .replaceAll("(?is)<footer.*?</footer>"," ")
                .replaceAll("(?is)<header.*?</header>"," ")
                .replaceAll("(?is)\\{[^{}]{0,900}(font-family|line-height|z-index|letter-spacing|color\s*:)[^{}]{0,900}\\}"," ");
        x=decodeHtml(x.replaceAll("(?s)<[^>]+>"," "));
        return cleanLooseText(x);
    }

    private static String cleanLooseText(String s){
        String x=decodeHtml(s==null?"":s);
        x=x.replaceAll("(?is)\\{[^{}]{0,900}(font-family|line-height|z-index|letter-spacing|color\s*:)[^{}]{0,900}\\}"," ");
        x=x.replaceAll("(?is)@media\\s*\\([^)]*\\)\\s*\\{[^{}]{0,1200}\\}"," ");
        x=x.replaceAll("(?is)\\.[a-z0-9_-]+\\s*\\{[^{}]{0,1200}\\}"," ");
        x=x.replaceAll("(?is)(GENERAL ENGLISH|IELTS READING|IELTS SPEAKING|IELTS WRITING|WORKSHOPS & WEBINARS|Contact General English Fluency).*?(Articles and Tips)?"," ");
        x=x.replaceAll("\\s+"," ").trim();
        return x;
    }

    private static String publisher(String url){
        try{String h=new URI(url).getHost();if(h==null)return "unknown";return h.toLowerCase(Locale.US).replaceFirst("^www\\.","");}catch(Exception e){return "unknown";}
    }
    private static double quality(String url){
        String p=publisher(url);
        if(p.endsWith(".gov")||p.endsWith(".mil")||p.endsWith(".edu"))return 0.94;
        if(p.contains("wikipedia.org"))return 0.82;
        if(p.contains("reuters.com")||p.contains("apnews.com")||p.contains("bbc.")||p.contains("npr.org"))return 0.90;
        if(p.contains(".org"))return 0.76;
        return 0.68;
    }

    private static final class ResultLink{final String href,title;ResultLink(String h,String t){href=h;title=t;}}
    private static ArrayList<ResultLink> parseResults(String html){
        ArrayList<ResultLink> out=new ArrayList<>();
        Matcher m=Pattern.compile("<a[^>]*class=\\\"result__a\\\"[^>]*href=\\\"([^\\\"]+)\\\"[^>]*>(.*?)</a>",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(html==null?"":html);
        while(m.find()&&out.size()<10){String h=decodeHtml(m.group(1));String t=cleanLooseText(strip(m.group(2)));if(!h.isEmpty()&&!t.isEmpty()&&!looksDirty(t))out.add(new ResultLink(h,t));}
        return out;
    }
    private static String unwrapDuckDuckGo(String href){
        try{
            String h=href==null?"":href; if(h.startsWith("//"))h="https:"+h;
            URI u=new URI(h); String q=u.getRawQuery();
            if(q!=null){for(String part:q.split("&")){int i=part.indexOf('=');if(i>0&&"uddg".equals(part.substring(0,i)))return URLDecoder.decode(part.substring(i+1),"UTF-8");}}
            return h;
        }catch(Exception e){return href==null?"":href;}
    }
    private static String get(String u,int connect,int read,int maxBytes,String accept)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        try{
            c.setInstanceFollowRedirects(true); c.setConnectTimeout(connect); c.setReadTimeout(read);
            c.setRequestProperty("User-Agent","Lumi/4.1 FunctionalCore"); c.setRequestProperty("Accept",accept);
            int code=c.getResponseCode(); if(code<200||code>=400)throw new IOException("HTTP "+code);
            try(InputStream in=c.getInputStream()){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n;while((n=in.read(x))>0&&b.size()<maxBytes)b.write(x,0,n);return b.toString("UTF-8");}
        }finally{c.disconnect();}
    }
    private static String compactSentences(String s,int maxSentences,int maxChars){
        String clean=cleanLooseText(s); if(clean.length()<=maxChars && maxSentences>=8)return clean;
        String[] parts=clean.split("(?<=[.!?])\\s+"); StringBuilder out=new StringBuilder(); int n=0;
        for(String part:parts){String x=part.trim();if(x.isEmpty()||looksDirty(x))continue;if(out.length()+x.length()+1>maxChars)break;if(out.length()>0)out.append(' ');out.append(x);if(++n>=maxSentences)break;}
        if(out.length()==0)return bounded(clean,maxChars); return out.toString();
    }
    private static String strip(String s){return decodeHtml((s==null?"":s).replaceAll("<[^>]+>"," ")).replaceAll("\\s+"," ").trim();}
    private static String decodeHtml(String s){return (s==null?"":s).replace("&amp;","&").replace("&quot;","\"").replace("&#x27;","'").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">").replace("&nbsp;"," ");}
    private static String firstNonBlank(String...xs){for(String x:xs)if(x!=null&&!x.trim().isEmpty())return x.trim();return "";}
    private static String bounded(String s,int max){if(s==null)return "";return s.length()<=max?s:s.substring(0,max)+"…";}
    private static String safe(String s){return s==null?"":s.replace('\n',' ').replace('\r',' ').trim();}
}
