package com.distressedelk.lumi;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;
import android.service.voice.VoiceInteractionSessionService;
public final class LumiVoiceInteractionSessionService extends VoiceInteractionSessionService {
  @Override public VoiceInteractionSession onNewSession(Bundle args){ return new LumiVoiceInteractionSession(this); }
}
