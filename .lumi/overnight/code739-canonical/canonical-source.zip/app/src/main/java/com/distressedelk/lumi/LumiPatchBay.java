package com.distressedelk.lumi;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.nio.charset.StandardCharsets;

/**
 * Code464 Patch Bay foundation.
 *
 * Hard invariant: STAGED software has zero authority over the running Lumi process.
 * This class only stores bytes + metadata in app-private storage. It never loads code,
 * registers services, changes permissions/configuration, migrates data, or writes active
 * application files. Installation remains behind the normal trusted Lumi/Guardian path.
 */
final class LumiPatchBay {
    static final String PATCH_BAY_STAGED_SOFTWARE_INERT = "STAGED_SOFTWARE_HAS_ZERO_RUNTIME_AUTHORITY";

    enum Classification {
        CORE_REQUIRED,
        REQUIRED_DEPENDENCY,
        OPTIONAL,
        EXPERIMENTAL;

        static Classification parse(String raw){
            if(raw==null) return CORE_REQUIRED; // unknown legacy package fails safe as required core.
            try { return valueOf(raw.trim().toUpperCase(Locale.US)); }
            catch(Throwable ignored){ return CORE_REQUIRED; }
        }
    }

    enum State {
        AVAILABLE, DOWNLOADED, STAGED, VALIDATED, WAITING_FOR_USER,
        AUTHORIZED, INSTALLING, ACTIVE, FAILED, ROLLBACK,
        PREVIOUS_KNOWN_GOOD, DELETED
    }

    static final class Validation {
        final boolean ok;
        final String code;
        final Classification classification;
        Validation(boolean ok,String code,Classification classification){
            this.ok=ok; this.code=code; this.classification=classification;
        }
    }

    private static final Set<String> PROTECTED_CORE=new HashSet<>();
    static {
        String[] names={"core","guardian","updater","update","speech","conversation","memory",
                "fastbrain","fast_brain","router","identity","barge-in","barge_in","recovery",
                "signing","installer","permissions"};
        for(String n:names) PROTECTED_CORE.add(n);
    }

    private static File root(Context c){ return new File(c.getFilesDir(),"patch-bay"); }
    private static File stagedRoot(Context c){ return new File(root(c),"staged"); }
    private static File archiveRoot(Context c){ return new File(root(c),"archive"); }

    static Validation validate(JSONObject m){
        Classification classification=Classification.parse(m.optString("classification",null));
        String id=m.optString("patchId","").trim();
        if(id.length()<3 || !id.matches("[A-Za-z0-9._-]+"))
            return new Validation(false,"INVALID_PATCH_ID",classification);

        // Core and major changes never enter the optional Patch Bay lane.
        if(classification==Classification.CORE_REQUIRED || classification==Classification.REQUIRED_DEPENDENCY)
            return new Validation(false,"CORE_BYPASSES_PATCH_BAY",classification);

        if(m.optBoolean("majorUpdate",false) || m.optBoolean("coreUpdate",false))
            return new Validation(false,"MAJOR_OR_CORE_MUST_BE_REQUIRED",classification);

        // Optional / experimental content can never self-promote or auto-install.
        if(m.optBoolean("automaticInstallAllowed",false))
            return new Validation(false,"OPTIONAL_AUTO_INSTALL_FORBIDDEN",classification);

        JSONArray affected=m.optJSONArray("affectedModules");
        if(affected!=null){
            for(int i=0;i<affected.length();i++){
                String n=affected.optString(i,"").trim().toLowerCase(Locale.US);
                if(PROTECTED_CORE.contains(n))
                    return new Validation(false,"OPTIONAL_TOUCHES_PROTECTED_CORE_REPACKAGE_AS_REQUIRED",classification);
            }
        }
        JSONArray files=m.optJSONArray("filesModified");
        if(files!=null){
            for(int i=0;i<files.length();i++){
                String p=files.optString(i,"").toLowerCase(Locale.US);
                if(p.contains("guardian") || p.contains("lumiupdatemanager") || p.contains("trustedbuildrelay")
                        || p.contains("conversationruntime") || p.contains("fastbrain") || p.contains("memorymanager"))
                    return new Validation(false,"OPTIONAL_FILE_CROSSES_CORE_BOUNDARY_REPACKAGE_AS_REQUIRED",classification);
            }
        }
        if(m.optString("packageSha256","").length()!=64)
            return new Validation(false,"PACKAGE_SHA256_REQUIRED",classification);
        if(m.optString("signingIdentity","").trim().isEmpty())
            return new Validation(false,"SIGNING_IDENTITY_REQUIRED",classification);
        if(m.optString("riskClassification","").trim().isEmpty())
            return new Validation(false,"RISK_CLASSIFICATION_REQUIRED",classification);
        return new Validation(true,"PATCH_BAY_PREFLIGHT_OK",classification);
    }

    static synchronized JSONObject stage(Context c,JSONObject manifest,File packageFile) throws Exception {
        Validation v=validate(manifest);
        if(!v.ok) return result(false,v.code,manifest.optString("patchId",""),State.FAILED);
        if(packageFile==null || !packageFile.isFile())
            return result(false,"PACKAGE_FILE_MISSING",manifest.optString("patchId",""),State.FAILED);
        String expected=manifest.optString("packageSha256","").toLowerCase(Locale.US);
        String actual=sha256(packageFile);
        if(!expected.equals(actual))
            return result(false,"PACKAGE_HASH_MISMATCH",manifest.optString("patchId",""),State.FAILED);

        String id=manifest.getString("patchId");
        File dir=new File(stagedRoot(c),id);
        if(!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("cannot create Patch Bay stage directory");
        File dst=new File(dir,"package.bin");
        copy(packageFile,dst);
        JSONObject record=new JSONObject(manifest.toString());
        record.put("state",State.WAITING_FOR_USER.name());
        record.put("stagedAt",System.currentTimeMillis());
        record.put("authorizedAt",JSONObject.NULL);
        record.put("automaticInstallAllowed",false);
        record.put("runtimeAuthority",false);
        record.put("stagingInvariant",PATCH_BAY_STAGED_SOFTWARE_INERT);
        writeJson(new File(dir,"manifest.json"),record);
        return result(true,"WAITING_FOR_USER",id,State.WAITING_FOR_USER);
    }

    static synchronized JSONObject authorize(Context c,String patchId) throws Exception {
        File f=manifestFile(c,patchId);
        if(!f.isFile()) return result(false,"NOT_STAGED",patchId,State.FAILED);
        JSONObject m=readJson(f);
        Validation v=validate(m);
        if(!v.ok) return result(false,v.code,patchId,State.FAILED);
        String state=m.optString("state","");
        if(!State.WAITING_FOR_USER.name().equals(state) && !State.VALIDATED.name().equals(state))
            return result(false,"NOT_WAITING_FOR_USER",patchId,State.FAILED);
        // Explicit local user selection is the only promotion out of WAITING_FOR_USER.
        m.put("state",State.AUTHORIZED.name());
        m.put("authorizedAt",System.currentTimeMillis());
        m.put("automaticInstallAllowed",false);
        m.put("runtimeAuthority",false);
        writeJson(f,m);
        return result(true,"AUTHORIZED_FOR_TRUSTED_INSTALL_PATH",patchId,State.AUTHORIZED);
    }

    static synchronized File beginAuthorizedInstall(Context c,String patchId) throws Exception {
        File f=manifestFile(c,patchId);
        if(!f.isFile()) throw new SecurityException("Optional package is not staged");
        JSONObject m=readJson(f);
        Validation v=validate(m);
        if(!v.ok) throw new SecurityException(v.code);
        if(!State.AUTHORIZED.name().equals(m.optString("state",""))) throw new SecurityException("Optional package is not authorized");
        File pkg=new File(f.getParentFile(),"package.bin");
        if(!pkg.isFile()) throw new SecurityException("Optional package bytes are missing");
        String expected=m.optString("packageSha256","").toLowerCase(Locale.US);
        if(!expected.equals(sha256(pkg))) throw new SecurityException("Optional package changed after staging");
        // Defense in depth: Patch Bay may hand off signed CONTENT packages only. Core APKs
        // can never cross this lane even if catalog metadata is malformed.
        try(ZipFile zip=new ZipFile(pkg)){
            ZipEntry e=zip.getEntry(LumiUpdateManager.MANIFEST_NAME);
            if(e==null) throw new SecurityException("Optional package has no Lumi manifest");
            BufferedReader r=new BufferedReader(new InputStreamReader(zip.getInputStream(e),StandardCharsets.UTF_8));
            StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null) b.append(line).append('\n'); r.close();
            JSONObject inner=new JSONObject(b.toString());
            if(!"content".equalsIgnoreCase(inner.optString("type",""))) throw new SecurityException("Patch Bay accepts signed content packages only");
            if(inner.has("apk")) throw new SecurityException("Optional package cannot contain a core APK descriptor");
        }
        m.put("state",State.INSTALLING.name());
        m.put("installStartedAt",System.currentTimeMillis());
        m.put("runtimeAuthority",false);
        writeJson(f,m);
        return pkg;
    }

    static synchronized void finishAuthorizedInstall(Context c,String patchId,boolean ok,String detail) throws Exception {
        File f=manifestFile(c,patchId);
        if(!f.isFile()) return;
        JSONObject m=readJson(f);
        m.put("state",ok?State.ACTIVE.name():State.FAILED.name());
        m.put("installFinishedAt",System.currentTimeMillis());
        m.put("runtimeAuthority",ok);
        m.put("installResult",detail==null?"":detail);
        writeJson(f,m);
    }

    static synchronized JSONObject revoke(Context c,String patchId) throws Exception {
        File f=manifestFile(c,patchId);
        if(!f.isFile()) return result(false,"NOT_STAGED",patchId,State.FAILED);
        JSONObject m=readJson(f);
        m.put("state",State.WAITING_FOR_USER.name());
        m.put("authorizedAt",JSONObject.NULL);
        m.put("runtimeAuthority",false);
        writeJson(f,m);
        return result(true,"AUTHORIZATION_REVOKED",patchId,State.WAITING_FOR_USER);
    }

    static synchronized JSONObject delete(Context c,String patchId) throws Exception {
        File dir=new File(stagedRoot(c),safeId(patchId));
        if(!dir.exists()) return result(false,"NOT_STAGED",patchId,State.DELETED);
        File archive=archiveRoot(c);
        if(!archive.exists()) archive.mkdirs();
        File to=new File(archive,safeId(patchId)+"-deleted-"+System.currentTimeMillis());
        boolean moved=dir.renameTo(to);
        if(!moved){ deleteRecursive(dir); }
        return result(true,"DELETED",patchId,State.DELETED);
    }

    static synchronized JSONArray list(Context c) throws Exception {
        JSONArray out=new JSONArray();
        File base=stagedRoot(c);
        File[] dirs=base.listFiles();
        if(dirs==null) return out;
        for(File d:dirs){
            File f=new File(d,"manifest.json");
            if(f.isFile()){
                try { out.put(readJson(f)); } catch(Throwable ignored){}
            }
        }
        return out;
    }

    static synchronized JSONObject status(Context c,String patchId) throws Exception {
        File f=manifestFile(c,patchId);
        if(!f.isFile()) return result(false,"NOT_STAGED",patchId,State.FAILED);
        return readJson(f);
    }

    private static File manifestFile(Context c,String id){ return new File(new File(stagedRoot(c),safeId(id)),"manifest.json"); }
    private static String safeId(String id){
        String s=id==null?"":id.trim();
        if(!s.matches("[A-Za-z0-9._-]+")) throw new IllegalArgumentException("invalid patch id");
        return s;
    }
    private static JSONObject result(boolean ok,String code,String id,State state) throws Exception {
        return new JSONObject().put("ok",ok).put("code",code).put("patchId",id).put("state",state.name());
    }
    private static JSONObject readJson(File f) throws Exception {
        StringBuilder b=new StringBuilder();
        BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(f),"UTF-8"));
        try { String line; while((line=r.readLine())!=null) b.append(line).append('\n'); }
        finally { r.close(); }
        return new JSONObject(b.toString());
    }
    private static void writeJson(File f,JSONObject o) throws Exception {
        File p=f.getParentFile(); if(!p.exists() && !p.mkdirs()) throw new IllegalStateException("cannot create directory");
        File tmp=new File(p,f.getName()+".tmp");
        FileOutputStream out=new FileOutputStream(tmp,false);
        try { out.write((o.toString(2)+"\n").getBytes("UTF-8")); out.getFD().sync(); }
        finally { out.close(); }
        if(f.exists() && !f.delete()) throw new IllegalStateException("cannot replace manifest");
        if(!tmp.renameTo(f)) throw new IllegalStateException("cannot commit manifest");
    }
    private static void copy(File from,File to) throws Exception {
        FileInputStream in=new FileInputStream(from); FileOutputStream out=new FileOutputStream(to,false);
        try { byte[] buf=new byte[32768]; int n; while((n=in.read(buf))>0) out.write(buf,0,n); out.getFD().sync(); }
        finally { try{in.close();}finally{out.close();} }
    }
    private static String sha256(File f) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        FileInputStream in=new FileInputStream(f);
        try { byte[] buf=new byte[32768]; int n; while((n=in.read(buf))>0) md.update(buf,0,n); }
        finally { in.close(); }
        StringBuilder b=new StringBuilder(); for(byte x:md.digest()) b.append(String.format(Locale.US,"%02x",x&0xff));
        return b.toString();
    }
    private static void deleteRecursive(File f){
        File[] kids=f.listFiles(); if(kids!=null) for(File k:kids) deleteRecursive(k); f.delete();
    }
}
