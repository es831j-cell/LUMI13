package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.FrameLayout;
import android.widget.ImageView;

/** Code495 R213: reference Lumi runtime. Core must boot and converse before bolt-ons are admitted. */
final class SafeCoreProfile {
    static final String VISUALS="visuals.default";
    static final String BRAIN_SEARCH="brain.search";
    static final String VOICE_AURORA="voice.aurora";
    static final String DIAGNOSTICS_ADVANCED="diagnostics.advanced";
    private static final String[] IDS={VISUALS,BRAIN_SEARCH,VOICE_AURORA,DIAGNOSTICS_ADVANCED};
    private static final String[] LABELS={"Live Visuals","Brain Search / Cloud","Aurora Voice","Advanced Diagnostics"};
    private SafeCoreProfile(){}

    static String key(String id){ return "safe_core_module_"+id.replace('.','_')+"_enabled"; }
    static boolean active(SharedPreferences p){ if(p!=null && !p.getBoolean("code518_owner_full_runtime_migrated",false)){
            p.edit()
                    .putBoolean("code518_owner_full_runtime_migrated",true)
                    .putBoolean("safe_core_mode",false)
                    .putString("safe_core_reason","Owner requested full runtime for conversation evaluation")
                    .putString("visual_runtime_mode","live-module")
                    .putLong("code518_owner_full_runtime_at",System.currentTimeMillis())
                    .apply();
        }
        return p!=null && p.getBoolean("safe_core_mode",false); }
    static boolean enabled(SharedPreferences p,String id){
        if(p==null) return false;
        if(!active(p)) return true;
        return p.getBoolean(key(id),false);
    }
    static String[] ids(){ return IDS.clone(); }
    static String[] labels(){ return LABELS.clone(); }

    static void ensureDefaults(Context c,SharedPreferences p){
        if(p==null) return;
        if(!p.getBoolean("code495_safe_core_initialized",false)){
            SharedPreferences.Editor e=p.edit()
                    .putBoolean("code495_safe_core_initialized",true)
                    .putBoolean("safe_core_mode",false)
                    .putLong("safe_core_entered_at",System.currentTimeMillis())
                    .putString("safe_core_reason","Code495 default reference baseline")
                    .putString("safe_core_visual_asset","lumi_3d_reference_r256_owner_approved")
                    .putString("visual_runtime_mode","safe-static-reference")
                    .putBoolean("live_entity_enabled",false)
                    .putString("live_entity_state","disabled-safe-core")
                    .putString("lumi_voice_profile","none")
                    .putBoolean("lumi_voice_profile_runtime_verified",false);
            for(String id:IDS)e.putBoolean(key(id),false);
            e.apply();
        }
        applyRuntimeFlags(p);
    }

    static void disableAll(SharedPreferences p){
        if(p==null)return;
        SharedPreferences.Editor e=p.edit();
        for(String id:IDS)e.putBoolean(key(id),false);
        e.putBoolean("live_entity_enabled",false)
                .putString("live_entity_state","disabled-safe-core")
                .putString("visual_runtime_mode","safe-static-reference")
                .putString("lumi_voice_profile","none")
                .putBoolean("lumi_voice_profile_runtime_verified",false)
                .putLong("safe_core_last_reset_at",System.currentTimeMillis()).apply();
    }

    static void setEnabled(SharedPreferences p,String id,boolean on){
        if(p==null)return;
        boolean known=false; for(String x:IDS)if(x.equals(id)){known=true;break;}
        if(!known)return;
        SharedPreferences.Editor e=p.edit().putBoolean(key(id),on)
                .putLong("safe_core_module_change_at",System.currentTimeMillis())
                .putString("safe_core_last_module_changed",id+"="+on);
        if(VISUALS.equals(id)) e.putString("visual_runtime_mode",on?"live-module":"safe-static-reference");
        if(VOICE_AURORA.equals(id) && !on) e.putString("lumi_voice_profile","none").putBoolean("lumi_voice_profile_runtime_verified",false);
        e.apply();
        applyRuntimeFlags(p);
    }

    static void applyRuntimeFlags(SharedPreferences p){
        if(p==null || !active(p))return;
        SharedPreferences.Editor e=p.edit();
        // Presence/live-entity is not part of the minimum conversational core. Keep it dormant
        // until it is promoted to an independently controlled module in a later verified step.
        e.putBoolean("live_entity_enabled",false);
        if(!enabled(p,VISUALS))e.putString("visual_runtime_mode","safe-static-reference");
        if(!enabled(p,VOICE_AURORA))e.putString("lumi_voice_profile","none").putBoolean("lumi_voice_profile_runtime_verified",false);
        e.apply();
    }

    static ImageView attachDiagnosticStaticReference(Context c,FrameLayout stage){
        if(c==null || stage==null) return null;
        ImageView image=new ImageView(c);
        image.setImageDrawable(null);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        image.setAdjustViewBounds(true);
        stage.addView(image,new FrameLayout.LayoutParams(-1,-1));
        return image;
    }

    static String summary(SharedPreferences p){
        if(!active(p))return "Safe Core OFF";
        StringBuilder b=new StringBuilder("Safe Core ON");
        for(String id:IDS)b.append(" • ").append(id).append('=').append(enabled(p,id)?"ON":"OFF");
        return b.toString();
    }
}
