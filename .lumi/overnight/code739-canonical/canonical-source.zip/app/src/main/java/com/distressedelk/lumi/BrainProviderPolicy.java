package com.distressedelk.lumi;

import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Brain & Intelligence provider policy. Search AI defaults to AUTO but is independently configurable. */
final class BrainProviderPolicy {
    static final String PREF_DEFAULT_SEARCH_AI = "brain_default_search_ai";
    static final String AUTO = "auto";
    private BrainProviderPolicy() {}

    static void ensureDefaults(SharedPreferences prefs) {
        if (prefs == null) return;
        String current = normalize(prefs.getString(PREF_DEFAULT_SEARCH_AI, AUTO));
        prefs.edit().putString(PREF_DEFAULT_SEARCH_AI, current).apply();
    }

    static String defaultSearchAi(SharedPreferences prefs) {
        if (prefs == null) return AUTO;
        return normalize(prefs.getString(PREF_DEFAULT_SEARCH_AI, AUTO));
    }

    static List<CloudBrainRouter.Provider> orderForSearch(SharedPreferences prefs, List<CloudBrainRouter.Provider> base) {
        ArrayList<CloudBrainRouter.Provider> ordered = new ArrayList<>();
        if (base != null) ordered.addAll(base);
        String preferred = defaultSearchAi(prefs);
        if (AUTO.equals(preferred) || ordered.size() < 2) {
            recordEffective(prefs, preferred, ordered.isEmpty() ? "none" : ordered.get(0).id);
            return ordered;
        }
        int match = -1;
        for (int i = 0; i < ordered.size(); i++) {
            if (preferred.equals(ordered.get(i).id)) { match = i; break; }
        }
        if (match > 0) {
            CloudBrainRouter.Provider selected = ordered.remove(match);
            ordered.add(0, selected);
        }
        recordEffective(prefs, preferred, match >= 0 ? preferred : (ordered.isEmpty() ? "none" : ordered.get(0).id));
        return ordered;
    }

    static String summary(SharedPreferences prefs) {
        String preferred = defaultSearchAi(prefs);
        String effective = prefs == null ? "unknown" : prefs.getString("brain_search_ai_effective", "not-yet-used");
        return "default=" + preferred + " • effective=" + effective;
    }

    private static void recordEffective(SharedPreferences prefs, String preferred, String effective) {
        if (prefs == null) return;
        prefs.edit().putString("brain_search_ai_preferred", preferred)
                .putString("brain_search_ai_effective", effective)
                .putLong("brain_search_ai_policy_at", System.currentTimeMillis()).apply();
    }

    private static String normalize(String value) {
        String v = value == null ? AUTO : value.trim().toLowerCase(Locale.US);
        if (AUTO.equals(v) || "openrouter".equals(v) || "groq".equals(v) || "gemini".equals(v) || "cloudflare".equals(v)) return v;
        return AUTO;
    }
}
