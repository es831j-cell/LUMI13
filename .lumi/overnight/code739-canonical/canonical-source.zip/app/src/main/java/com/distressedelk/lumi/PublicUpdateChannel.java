package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Code704 R414: anonymous read-only distribution lane for already-signed Lumi updates. */
final class PublicUpdateChannel {
    private static final String POINTER_URL="https://raw.githubusercontent.com/es831j-cell/LUMI13/main/.lumi/public-updates/latest-update.json";
    private static final String PACKAGE_BASE="https://raw.githubusercontent.com/es831j-cell/LUMI13/main/.lumi/public-updates/";
    private static final String INDEX_URL=PACKAGE_BASE+"index.json";
    private static final int CONNECT_MS=12000, READ_MS=45000;

    private PublicUpdateChannel(){}

    static JSONObject check(Context c, SharedPreferences p, boolean downloadPackage) throws Exception {
        final long checkedAt=System.currentTimeMillis();
        final long installed=currentVersionCode(c);
        UpdateBridgeTelemetry.beginDiscovery(c,p,downloadPackage);
        try{
            UpdateBridgeTelemetry.mark(c,p,"PUBLIC_POINTER_FETCH_START","url=raw.githubusercontent.com/es831j-cell/LUMI13");
            JSONObject m=new JSONObject(fetchText(POINTER_URL,512*1024));
            if(!"LumiPublicUpdate".equals(m.optString("format","")) || m.optInt("formatVersion",-1)!=1)
                throw new SecurityException("Unsupported public Lumi update pointer format");
            String updateId=m.optString("updateId","").trim();
            if(!updateId.matches("[A-Za-z0-9._-]{1,96}")) throw new SecurityException("Public update id is invalid");
            long target=m.optLong("targetVersionCode",-1L);
            if(target<=0L) throw new SecurityException("Public update target version is invalid");
            long base=m.optLong("baseVersionCode",-1L);
            long minBase=m.optLong("minBaseVersionCode",base);
            long maxBase=m.optLong("maxBaseVersionCode",base);
            if(base>0L && (minBase<=0L || maxBase<minBase || base<minBase || base>maxBase))
                throw new SecurityException("Public update compatibility range is invalid");
            String targetName=m.optString("targetVersionName","").trim();
            String packageFile=m.optString("packageFile","").trim();
            if(!packageFile.matches("Lumi-Code[0-9]+-[A-Za-z0-9._-]+\\.zip"))
                throw new SecurityException("Public update package filename is invalid");
            String packageSha=m.optString("packageSha256","").trim().toLowerCase(Locale.US);
            if(!packageSha.matches("[0-9a-f]{64}")) throw new SecurityException("Public update package SHA-256 is invalid");

            UpdateBridgeTelemetry.bindTarget(c,p,updateId,target,"public-channel base="+base+" range="+minBase+".."+maxBase+" installed="+installed+" package="+packageFile);
            UpdateBridgeTelemetry.mark(c,p,"PUBLIC_POINTER_VERIFIED","target="+target+" sha256="+packageSha.substring(0,12)+"…");

            if(target<=installed){
                p.edit().putString("github_update_check_state","UP_TO_DATE")
                        .putLong("github_update_last_check_at",checkedAt)
                        .putLong("github_update_available_version",target)
                        .putString("github_update_available_name",targetName)
                        .putString("github_update_available_id",updateId)
                        .putString("github_update_channel_branch","public-main")
                        .remove("github_update_check_error").apply();
                return new JSONObject().put("ok",true).put("state","UP_TO_DATE").put("installed",installed).put("published",target);
            }
            if(base>0L && (installed<minBase || installed>maxBase)){
                JSONObject compatible=findCompatibleFromIndex(installed);
                if(compatible!=null){
                    m=compatible;
                    updateId=m.optString("updateId","").trim();
                    target=m.optLong("targetVersionCode",-1L);
                    base=m.optLong("baseVersionCode",-1L);
                    minBase=m.optLong("minBaseVersionCode",base);
                    maxBase=m.optLong("maxBaseVersionCode",base);
                    targetName=m.optString("targetVersionName","").trim();
                    packageFile=m.optString("packageFile","").trim();
                    packageSha=m.optString("packageSha256","").trim().toLowerCase(Locale.US);
                    if(!updateId.matches("[A-Za-z0-9._-]{1,96}") || target<=installed
                            || !packageFile.matches("Lumi-Code[0-9]+-[A-Za-z0-9._-]+\\.zip")
                            || !packageSha.matches("[0-9a-f]{64}"))
                        throw new SecurityException("Compatible public update index entry is invalid");
                    UpdateBridgeTelemetry.bindTarget(c,p,updateId,target,"public-index base="+base+" range="+minBase+".."+maxBase+" installed="+installed+" package="+packageFile);
                    UpdateBridgeTelemetry.mark(c,p,"PUBLIC_INDEX_COMPATIBLE_TARGET","target="+target+" base="+base);
                }else{
                    p.edit().putString("github_update_check_state","UPDATE_REQUIRED_BLOCKED")
                            .putLong("github_update_last_check_at",checkedAt)
                            .putLong("github_update_available_version",target)
                            .putString("github_update_available_name",targetName)
                            .putString("github_update_available_id",updateId)
                            .putString("github_update_check_error","No compatible sequential public update is available for installed code "+installed).apply();
                    return new JSONObject().put("ok",false).put("state","UPDATE_REQUIRED_BLOCKED").put("installed",installed).put("base",base).put("target",target);
                }
            }

            File cached=null;
            if(downloadPackage){
                File dir=new File(c.getFilesDir(),"lumi_updates/public_channel");
                if(!dir.exists()&&!dir.mkdirs()) throw new java.io.IOException("Could not create public update cache");
                cached=new File(dir,updateId.replaceAll("[^A-Za-z0-9._-]","_")+".zip");
                boolean reuse=false;
                if(cached.isFile() && cached.length()>0L && cached.length()<=LumiUpdateManager.MAX_IMPORT_BYTES){
                    String existing=SourcePatchManager.sha256(cached).toLowerCase(Locale.US);
                    reuse=packageSha.equals(existing);
                    if(!reuse && !cached.delete()) throw new java.io.IOException("Could not clear stale public update cache");
                }
                if(!reuse){
                    if(c.getFilesDir().getUsableSpace()<LumiUpdateManager.MIN_FREE_SPACE_BYTES)
                        throw new java.io.IOException("Not enough free storage for Lumi update staging");
                    File part=new File(cached.getAbsolutePath()+".part");
                    if(part.exists()&&!part.delete()) throw new java.io.IOException("Could not clear partial public update");
                    download(PACKAGE_BASE+packageFile,part,LumiUpdateManager.MAX_IMPORT_BYTES);
                    String actual=SourcePatchManager.sha256(part).toLowerCase(Locale.US);
                    if(!packageSha.equals(actual)){ part.delete(); throw new SecurityException("Public Lumi update checksum mismatch"); }
                    if(cached.exists()&&!cached.delete()) throw new java.io.IOException("Could not replace public update cache");
                    if(!part.renameTo(cached)) throw new java.io.IOException("Could not publish public update cache");
                    UpdateBridgeTelemetry.mark(c,p,"PUBLIC_PACKAGE_SHA_VERIFIED","bytes="+cached.length()+" sha256="+actual.substring(0,12)+"…");
                }else{
                    UpdateBridgeTelemetry.mark(c,p,"PUBLIC_PACKAGE_CACHE_REUSED","bytes="+cached.length());
                }
            }

            SharedPreferences.Editor e=p.edit().putString("github_update_check_state",downloadPackage?"UPDATE_DOWNLOADED":"UPDATE_AVAILABLE")
                    .putLong("github_update_last_check_at",checkedAt)
                    .putLong("github_update_available_version",target)
                    .putString("github_update_available_name",targetName)
                    .putString("github_update_available_id",updateId)
                    .putString("github_update_package_path","public:"+packageFile)
                    .putString("github_update_package_sha256",packageSha)
                    .putString("github_update_channel_branch","public-main")
                    .remove("github_update_check_error");
            if(cached!=null)e.putString("github_update_cached_file",cached.getAbsolutePath()).putLong("github_update_downloaded_at",System.currentTimeMillis());
            if(downloadPackage){ if(!e.commit()) throw new java.io.IOException("Could not persist public update state"); } else e.apply();
            return new JSONObject().put("ok",true).put("state",downloadPackage?"UPDATE_DOWNLOADED":"UPDATE_AVAILABLE")
                    .put("update_id",updateId).put("target_version",target).put("target_name",targetName).put("downloaded",cached!=null);
        }catch(Exception ex){
            p.edit().putString("github_update_check_state","CHECK_FAILED")
                    .putLong("github_update_last_check_at",checkedAt)
                    .putString("github_update_check_error",safe(ex.getClass().getSimpleName()+": "+String.valueOf(ex.getMessage()))).apply();
            UpdateBridgeTelemetry.fail(c,p,"PUBLIC_DISCOVERY_OR_DOWNLOAD_FAILED",ex);
            throw ex;
        }
    }

    private static JSONObject findCompatibleFromIndex(long installed)throws Exception{
        try{
            JSONObject root=new JSONObject(fetchText(INDEX_URL,1024*1024));
            if(!"LumiPublicUpdateIndex".equals(root.optString("format","")) || root.optInt("formatVersion",-1)!=1)return null;
            JSONArray a=root.optJSONArray("updates"); if(a==null)return null;
            JSONObject best=null; long bestTarget=Long.MAX_VALUE;
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null)continue;
                long target=x.optLong("targetVersionCode",-1L);
                long base=x.optLong("baseVersionCode",-1L);
                long min=x.optLong("minBaseVersionCode",base),max=x.optLong("maxBaseVersionCode",base);
                if(target>installed && installed>=min && installed<=max && target<bestTarget){best=x;bestTarget=target;}
            }
            return best;
        }catch(java.io.IOException e){ return null; }
    }

    private static String fetchText(String urlText,int max)throws Exception{
        String sep=urlText.contains("?")?"&":"?";
        String fresh=urlText+sep+"lumi_cb="+System.currentTimeMillis();
        HttpURLConnection h=(HttpURLConnection)new URL(fresh).openConnection();
        try{
            h.setUseCaches(false);h.setDefaultUseCaches(false);
            h.setInstanceFollowRedirects(true);h.setConnectTimeout(CONNECT_MS);h.setReadTimeout(READ_MS);
            h.setRequestProperty("Accept","application/json");h.setRequestProperty("User-Agent","Lumi-Public-Update/1");
            h.setRequestProperty("Cache-Control","no-cache, no-store, max-age=0");
            h.setRequestProperty("Pragma","no-cache");
            int code=h.getResponseCode(); if(code<200||code>=300)throw new java.io.IOException("Public update pointer HTTP "+code);
            try(InputStream in=h.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] b=new byte[8192];int n,total=0;while((n=in.read(b))>0){total+=n;if(total>max)throw new SecurityException("Public update pointer too large");out.write(b,0,n);}
                return new String(out.toByteArray(),StandardCharsets.UTF_8);
            }
        }finally{h.disconnect();}
    }

    private static long download(String urlText,File dest,long max)throws Exception{
        URL u=new URL(urlText); if(!"https".equalsIgnoreCase(u.getProtocol())||!"raw.githubusercontent.com".equalsIgnoreCase(u.getHost()))
            throw new SecurityException("Untrusted public update host");
        HttpURLConnection h=(HttpURLConnection)u.openConnection();
        try{
            h.setInstanceFollowRedirects(true);h.setConnectTimeout(CONNECT_MS);h.setReadTimeout(READ_MS);
            h.setRequestProperty("Accept","application/octet-stream");h.setRequestProperty("User-Agent","Lumi-Public-Update/1");
            int code=h.getResponseCode(); if(code<200||code>=300)throw new java.io.IOException("Public update package HTTP "+code);
            long total=0;try(InputStream in=h.getInputStream();FileOutputStream out=new FileOutputStream(dest)){
                byte[] b=new byte[64*1024];int n;while((n=in.read(b))>0){total+=n;if(total>max){dest.delete();throw new SecurityException("Public update package exceeds size limit");}out.write(b,0,n);}out.getFD().sync();
            }
            if(total<=0L){dest.delete();throw new java.io.IOException("Public update package was empty");}
            return total;
        }finally{h.disconnect();}
    }

    private static long currentVersionCode(Context c){
        try{android.content.pm.PackageInfo i=c.getPackageManager().getPackageInfo(c.getPackageName(),0);return android.os.Build.VERSION.SDK_INT>=28?i.getLongVersionCode():i.versionCode;}catch(Exception e){return -1L;}
    }
    private static String safe(String s){return s==null?"":SecretStore.redact(s.replace('\n',' ').replace('\r',' ').trim());}
}
