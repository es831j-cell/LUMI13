package com.distressedelk.lumi;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import android.provider.AlarmClock;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Code405 Core Local Actions.
 * Rules-first, on-device utility execution. These commands never require ChatGPT,
 * a cloud model, or internet access. Android/system apps are used only as local OS surfaces.
 */
final class CoreLocalActions {
    private CoreLocalActions(){}

    static final class Result {
        final boolean handled;
        final String action;
        final String reply;
        final String detail;
        private Result(boolean h,String a,String r,String d){handled=h;action=a;reply=r;detail=d;}
        static Result no(){return new Result(false,"","","");}
        static Result yes(String a,String r,String d){return new Result(true,a,r,d);}
    }

    static Result tryHandle(Context context,SharedPreferences prefs,String raw){
        if(context==null||prefs==null||raw==null)return Result.no();
        String q=raw.trim();if(q.isEmpty())return Result.no();
        Result deviceHealth=DeviceHealthEngine.tryHandle(context,prefs,q);if(deviceHealth.handled)return deviceHealth;
        String s=norm(q);
        if(s.equals("start lumi 1.0 acceptance test") || s.equals("begin lumi 1.0 acceptance test") ||
                s.equals("arm lumi 1.0 acceptance test"))
            return Result.yes("lumi1-acceptance-arm",LumiRelease1Gatekeeper.armAcceptance(context,prefs,"explicit-owner-command"),"explicit-owner-test-arm");
        Result visual=visualTune(context,prefs,s);if(visual.handled)return visual;
        String memoryReply=PeopleMemoryGraph.tryHandleLocal(context,prefs,q);
        if(memoryReply!=null)return Result.yes("relationship-memory",memoryReply,"structured-people-graph");
        Result r;
        r=systemFacts(context,prefs,s);if(r.handled)return r;
        r=reminder(context,s,q);if(r.handled)return r;
        r=timer(context,s);if(r.handled)return r;
        r=alarm(context,s);if(r.handled)return r;
        r=stopwatch(prefs,s);if(r.handled)return r;
        r=flashlight(context,prefs,s);if(r.handled)return r;
        r=volume(context,s);if(r.handled)return r;
        r=openApp(context,s);if(r.handled)return r;
        r=calculator(q,s);if(r.handled)return r;
        return Result.no();
    }

    private static Result visualTune(Context c,SharedPreferences p,String s){
        boolean direct=(s.contains("avatar")||s.contains("visual")||s.contains("appearance")||s.contains("humanoid"))&&
                (s.contains("tune")||s.contains("fix")||s.contains("change")||s.contains("make")||s.contains("match")||s.contains("use")||s.contains("activate")||s.contains("rollback"));
        boolean continuation=LumiLivingSelf.activeActionGoalMentionsVisuals(p)&&
                (s.equals("full")||s.equals("make it")||s.equals("do it")||s.equals("fix it")||s.equals("try again")||s.equals("continue"));
        if(!direct&&!continuation)return Result.no();
        if("LUMI_CORE_AVATAR_FORGE".equals(p.getString("renderer_visual_authority",""))||"LUMI_CORE_VISUAL_SCENE".equals(p.getString("renderer_visual_authority",""))){
            try{
                org.json.JSONObject out=LumiAvatarForge.applyOwnerGoal(c,p,s);
                if(c instanceof MainActivity){MainActivity a=(MainActivity)c;if(a.avatarSceneView!=null)a.avatarSceneView.reloadAvatarModel();}
                return Result.yes("visual-tune","I accepted the visual goal into Avatar Forge. I loaded the governed model slot and I'm checking the actual phone render before I call it improved.",out.toString());
            }catch(Throwable t){
                p.edit().putString("avatar_forge_state","GOAL_ERROR").putString("avatar_forge_last_error",t.getClass().getSimpleName()+":"+String.valueOf(t.getMessage())).apply();
                return Result.yes("visual-tune","Avatar Forge couldn't apply that visual goal. I kept the current verified model and recorded the failure.","forge-error="+t.getClass().getSimpleName());
            }
        }
        return Result.no();
    }

    private static Result systemFacts(Context c,SharedPreferences p,String s){
        if((s.contains("what build")||s.contains("which build")||s.contains("what version")||s.contains("which version"))&&(s.contains("you")||s.contains("lumi")||s.contains("operating")||s.contains("running"))){
            try{
                android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0);
                long vc=android.os.Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode;
                String vn=pi.versionName==null?"unknown":pi.versionName;
                return Result.yes("build-info","I'm running Lumi "+vn+" (code "+vc+").","versionCode="+vc+" versionName="+vn);
            }catch(Throwable t){return Result.yes("build-info","I couldn't read my installed build information locally.","package-info-error");}
        }
        if((s.contains("use")||s.contains("access")||s.contains("control")) && s.contains("clock") && (s.contains("android")||s.contains("phone")||s.contains("timer")||s.contains("alarm")))
            return Result.yes("clock-capability","Yes. I can set timers and alarms through my local phone controls, with my own local timer fallback when the Clock app does not accept Android's timer intent.","clock-capability=true");
        if((s.contains("export")||s.contains("save"))&&s.contains("black box"))
            return Result.yes("export-black-box","Opening the Black Box export.","local-export-request");
        if(s.contains("contact card")&&(s.contains("on me")||s.contains("for me")||s.contains("my contact"))){
            String n=IdentityHierarchy.contactName(p,IdentityHierarchy.PRIMARY_CONTACT_ID);
            return Result.yes("owner-contact-card","Yes. Your primary administrator contact card is "+n+".","contact="+IdentityHierarchy.PRIMARY_CONTACT_ID);
        }
        return Result.no();
    }

    private static Result timer(Context c,String s){
        if(!(s.contains("timer")||s.contains("countdown")))return Result.no();
        long sec=parseDurationSeconds(s);if(sec<=0)return Result.no();
        if(sec>Integer.MAX_VALUE)return Result.yes("timer","That timer is too long for this timer control.","seconds="+sec);
        Intent i=new Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH,(int)sec).putExtra(AlarmClock.EXTRA_MESSAGE,"Lumi timer").putExtra(AlarmClock.EXTRA_SKIP_UI,true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if(launchResolved(c,i))return Result.yes("timer","Timer set for "+friendlyDuration(sec)+".","seconds="+sec+" backend=android-clock");
        scheduleLumiTimer(c,sec);
        return Result.yes("timer","Timer set for "+friendlyDuration(sec)+".","seconds="+sec+" backend=lumi-local-fallback");
    }

    private static void scheduleLumiTimer(Context context,long sec){
        final Context app=context.getApplicationContext();
        final long delay=Math.max(1000L,Math.min((long)Integer.MAX_VALUE*1000L,sec*1000L));
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try{
                Toast.makeText(app,"Lumi timer finished.",Toast.LENGTH_LONG).show();
                android.net.Uri uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if(uri==null)uri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                final Ringtone ring=uri==null?null:RingtoneManager.getRingtone(app,uri);
                if(ring!=null){
                    ring.play();
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {try{ring.stop();}catch(Throwable ignored){}},10000L);
                }
            }catch(Throwable ignored){}
        },delay);
    }

    private static Result alarm(Context c,String s){
        if(!s.contains("alarm"))return Result.no();
        TimeOfDay t=parseTime(s);if(t==null)return Result.no();
        Intent i=new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR,t.hour).putExtra(AlarmClock.EXTRA_MINUTES,t.minute).putExtra(AlarmClock.EXTRA_MESSAGE,"Lumi alarm").putExtra(AlarmClock.EXTRA_SKIP_UI,true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if(!launchResolved(c,i))return Result.yes("alarm","I couldn't find a local Clock app that accepts alarms.","clock-unavailable");
        return Result.yes("alarm","Alarm set for "+formatTime(t.hour,t.minute)+".","hour="+t.hour+" minute="+t.minute);
    }

    private static Result reminder(Context c,String s,String raw){
        if(!s.startsWith("remind me"))return Result.no();
        Matcher m=Pattern.compile("(?i)^remind me(?: to)?\\s+(.+?)\\s+(in|at)\\s+(.+)$").matcher(raw.trim());
        if(m.matches()){
            String task=m.group(1).trim(),mode=m.group(2).toLowerCase(Locale.US),when=m.group(3).trim();
            if(mode.equals("in")){
                long sec=parseDurationSeconds(when);
                if(sec<=0||sec>Integer.MAX_VALUE)return Result.no();
                Intent i=new Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH,(int)sec).putExtra(AlarmClock.EXTRA_MESSAGE,"Reminder: "+task).putExtra(AlarmClock.EXTRA_SKIP_UI,true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if(!launchResolved(c,i))return Result.yes("reminder","I couldn't find a local Clock app that accepts reminders.","clock-unavailable");
                return Result.yes("reminder","I'll remind you to "+task+" in "+friendlyDuration(sec)+".","relative seconds="+sec);
            }
            TimeOfDay t=parseTime(when);
            if(t==null)return Result.no();
            Intent i=new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR,t.hour).putExtra(AlarmClock.EXTRA_MINUTES,t.minute).putExtra(AlarmClock.EXTRA_MESSAGE,"Reminder: "+task).putExtra(AlarmClock.EXTRA_SKIP_UI,true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if(!launchResolved(c,i))return Result.yes("reminder","I couldn't find a local Clock app that accepts reminders.","clock-unavailable");
            return Result.yes("reminder","I'll remind you to "+task+" at "+formatTime(t.hour,t.minute)+".","absolute hour="+t.hour+" minute="+t.minute);
        }
        Matcher alt=Pattern.compile("(?i)^remind me\\s+(in|at)\\s+(.+?)\\s+to\\s+(.+)$").matcher(raw.trim());
        if(alt.matches())return reminder(c,"remind me to "+alt.group(3)+" "+alt.group(1)+" "+alt.group(2),"remind me to "+alt.group(3)+" "+alt.group(1)+" "+alt.group(2));
        return Result.no();
    }

    private static Result stopwatch(SharedPreferences p,String s){
        if(!s.contains("stopwatch"))return Result.no();
        long now=System.currentTimeMillis();
        long started=p.getLong("code405_stopwatch_started_at",0L),acc=p.getLong("code405_stopwatch_accumulated_ms",0L);
        if(s.contains("reset")||s.contains("clear")){
            p.edit().putLong("code405_stopwatch_started_at",0L).putLong("code405_stopwatch_accumulated_ms",0L).apply();
            return Result.yes("stopwatch","Stopwatch reset.","reset");
        }
        if(s.contains("start")||s.contains("resume")){
            if(started<=0){p.edit().putLong("code405_stopwatch_started_at",now).apply();return Result.yes("stopwatch",acc>0?"Stopwatch resumed.":"Stopwatch started.","running=true");}
            return Result.yes("stopwatch","The stopwatch is already running at "+friendlyElapsed(acc+Math.max(0,now-started))+".","already-running");
        }
        if(s.contains("stop")||s.contains("pause")){
            if(started>0){acc+=Math.max(0,now-started);p.edit().putLong("code405_stopwatch_started_at",0L).putLong("code405_stopwatch_accumulated_ms",acc).apply();}
            return Result.yes("stopwatch","Stopwatch "+(s.contains("pause")?"paused":"stopped")+" at "+friendlyElapsed(acc)+".","elapsedMs="+acc);
        }
        long elapsed=acc+(started>0?Math.max(0,now-started):0L);
        return Result.yes("stopwatch","Stopwatch is at "+friendlyElapsed(elapsed)+(started>0?" and running.":".") ,"elapsedMs="+elapsed+" running="+(started>0));
    }

    private static Result flashlight(Context c,SharedPreferences p,String s){
        boolean mentions=s.contains("flashlight")||s.contains("torch");if(!mentions)return Result.no();
        boolean current=p.getBoolean("code405_flashlight_on",false);boolean target;
        if(s.contains("off"))target=false;else if(s.contains("on"))target=true;else if(s.contains("toggle"))target=!current;else return Result.no();
        try{
            CameraManager cm=(CameraManager)c.getSystemService(Context.CAMERA_SERVICE);if(cm==null)throw new IllegalStateException("camera service unavailable");
            String id=null;for(String x:cm.getCameraIdList()){Boolean f=cm.getCameraCharacteristics(x).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);if(Boolean.TRUE.equals(f)){id=x;break;}}
            if(id==null)return Result.yes("flashlight","This device doesn't report an available flashlight.","no-flash-camera");
            cm.setTorchMode(id,target);p.edit().putBoolean("code405_flashlight_on",target).apply();
            return Result.yes("flashlight","Flashlight "+(target?"on.":"off."),"enabled="+target);
        }catch(SecurityException e){return Result.yes("flashlight","I need Camera permission before I can control the flashlight.","camera-permission-required");}
        catch(Throwable t){return Result.yes("flashlight","I couldn't change the flashlight right now.",t.getClass().getSimpleName());}
    }

    private static Result volume(Context c,String s){
        if(!s.contains("volume")&&!s.matches(".*\\b(mute|unmute)\\b.*"))return Result.no();
        AudioManager a=(AudioManager)c.getSystemService(Context.AUDIO_SERVICE);if(a==null)return Result.yes("volume","Android audio control isn't available right now.","audio-service-unavailable");
        int stream=AudioManager.STREAM_MUSIC,max=a.getStreamMaxVolume(stream);
        try{
            Matcher pct=Pattern.compile("(?:volume(?: to| at)?\\s*)?(\\d{1,3})\\s*(?:%|percent)\\b").matcher(s);
            if(pct.find()){int v=Math.max(0,Math.min(100,Integer.parseInt(pct.group(1))));a.setStreamVolume(stream,Math.round(max*(v/100f)),0);return Result.yes("volume","Media volume set to "+v+" percent.","percent="+v);}
            Matcher plain=Pattern.compile("(?:set|make)\\s+(?:the\\s+)?volume\\s+(?:to\\s+)?(\\d{1,3})\\b").matcher(s);
            if(plain.find()){int v=Math.max(0,Math.min(100,Integer.parseInt(plain.group(1))));a.setStreamVolume(stream,Math.round(max*(v/100f)),0);return Result.yes("volume","Media volume set to "+v+" percent.","percent="+v);}
            if(s.contains("unmute")){a.adjustStreamVolume(stream,AudioManager.ADJUST_UNMUTE,0);return Result.yes("volume","Media audio unmuted.","unmute");}
            if(s.matches(".*\\bmute\\b.*")){a.adjustStreamVolume(stream,AudioManager.ADJUST_MUTE,0);return Result.yes("volume","Media audio muted.","mute");}
            if(s.contains("up")||s.contains("louder")||s.contains("increase")){a.adjustStreamVolume(stream,AudioManager.ADJUST_RAISE,0);return Result.yes("volume","Volume up.","raise");}
            if(s.contains("down")||s.contains("quieter")||s.contains("decrease")||s.contains("lower")){a.adjustStreamVolume(stream,AudioManager.ADJUST_LOWER,0);return Result.yes("volume","Volume down.","lower");}
        }catch(Throwable t){return Result.yes("volume","I couldn't change media volume right now.",t.getClass().getSimpleName());}
        return Result.no();
    }

    private static Result openApp(Context c,String s){
        Matcher m=Pattern.compile("^(?:please\\s+)?(?:open|launch)\\s+(.+?)(?:\\s+app)?$").matcher(s);if(!m.matches())return Result.no();
        String wanted=m.group(1).trim();if(wanted.isEmpty())return Result.no();
        try{
            PackageManager pm=c.getPackageManager();Intent launcher=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> list=pm.queryIntentActivities(launcher,0);
            ResolveInfo best=null;int score=-1;
            for(ResolveInfo ri:list){String label=String.valueOf(ri.loadLabel(pm)).trim().toLowerCase(Locale.US);int x=label.equals(wanted)?100:label.startsWith(wanted)?80:label.contains(wanted)?60:wanted.contains(label)?40:-1;if(x>score){score=x;best=ri;}}
            if(best==null||score<0)return Result.yes("open-app","I couldn't find an installed app named "+wanted+".","not-found name="+wanted);
            Intent i=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(best.activityInfo.packageName,best.activityInfo.name)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);c.startActivity(i);
            String label=String.valueOf(best.loadLabel(pm));return Result.yes("open-app","Opening "+label+".","package="+best.activityInfo.packageName);
        }catch(Throwable t){return Result.yes("open-app","I couldn't open that app right now.",t.getClass().getSimpleName());}
    }

    private static Result calculator(String raw,String s){
        // CODE498 R216: mathematical operators come from untouched input, not generic text norm().
        String e=raw==null?"":raw.trim().toLowerCase(Locale.US);
        // CODE497 R215: accept terse arithmetic such as "What 8x8" as a Core calculator request.
        e=e.replaceAll("^what(?:'s| is)?\\s+","").replaceAll("^(?:calculate|compute)\\s+","").trim();
        e=e.replaceAll("(?i)multiplied by","*").replaceAll("(?i)times","*").replaceAll("(?i)divided by","/").replaceAll("(?i)plus","+").replaceAll("(?i)minus","-");
        e=e.replaceAll("(?<=\\d)\\s*[x×]\\s*(?=\\d)","*").replace("÷","/").replace(",","").trim();
        e=e.replaceAll("(\\d+(?:\\.\\d+)?)%","($1/100)");
        if(!FastBrainAnswerGuard.isArithmeticRequest(s,e))return Result.no();
        try{double v=new ExpressionParser(e).parse();if(Double.isNaN(v)||Double.isInfinite(v))throw new ArithmeticException("non-finite");DecimalFormat f=new DecimalFormat("0.##########",DecimalFormatSymbols.getInstance(Locale.US));return Result.yes("calculator",f.format(v)+".","expression="+e);}
        catch(Throwable t){return Result.yes("calculator","I couldn't evaluate that calculation.","parse-error");}
    }

    private static long parseDurationSeconds(String s){
        Matcher m=Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\\b",Pattern.CASE_INSENSITIVE).matcher(s);double total=0;boolean found=false;
        while(m.find()){found=true;double n=Double.parseDouble(m.group(1));String u=m.group(2).toLowerCase(Locale.US);if(u.startsWith("hour")||u.startsWith("hr"))total+=n*3600d;else if(u.startsWith("min"))total+=n*60d;else total+=n;}
        return found?Math.max(1L,Math.round(total)):-1L;
    }

    private static final class TimeOfDay{final int hour,minute;TimeOfDay(int h,int m){hour=h;minute=m;}}
    private static TimeOfDay parseTime(String s){
        Matcher m=Pattern.compile("(?:^|\\b(?:for|at)\\s+)(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?\\b",Pattern.CASE_INSENSITIVE).matcher(s.trim());if(!m.find())return null;
        int h=Integer.parseInt(m.group(1)),min=m.group(2)==null?0:Integer.parseInt(m.group(2));if(min>59)return null;String ap=m.group(3);
        if(ap!=null){if(h<1||h>12)return null;boolean pm=ap.toLowerCase(Locale.US).startsWith("p");h=h%12+(pm?12:0);return new TimeOfDay(h,min);}
        if(h>23)return null;if(h>12)return new TimeOfDay(h,min);
        Calendar now=Calendar.getInstance();int cur=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE);int a=(h%12)*60+min,b=a+12*60;int chosen=a>cur?a:(b>cur?b:a);return new TimeOfDay((chosen/60)%24,chosen%60);
    }

    private static boolean launchResolved(Context c,Intent i){
        try{
            // Code411: starting an implicit Clock action does not require package enumeration.
            // On Android 11+, resolveActivity() may return null solely because package visibility
            // hides the handler even though startActivity() is allowed to deliver the intent.
            // Fire the user-requested local action directly and treat ActivityNotFound as the real
            // unavailable condition. Timer/alarm intents already carry EXTRA_SKIP_UI=true, so Lumi
            // does not intentionally open the system Clock wheel/picker surface.
            c.startActivity(i);
            return true;
        }catch(android.content.ActivityNotFoundException e){return false;}
        catch(Throwable t){return false;}
    }
    private static String formatTime(int h,int m){int x=h%12;if(x==0)x=12;return String.format(Locale.US,"%d:%02d %s",x,m,h<12?"AM":"PM");}
    private static String friendlyDuration(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;StringBuilder b=new StringBuilder();if(h>0)b.append(h).append(h==1?" hour":" hours");if(m>0){if(b.length()>0)b.append(" ");b.append(m).append(m==1?" minute":" minutes");}if(s>0||b.length()==0){if(b.length()>0)b.append(" ");b.append(s).append(s==1?" second":" seconds");}return b.toString();}
    private static String friendlyElapsed(long ms){long tenths=Math.max(0,ms)/100;long totalSec=tenths/10;long tenth=tenths%10,h=totalSec/3600,m=(totalSec%3600)/60,s=totalSec%60;if(h>0)return String.format(Locale.US,"%d:%02d:%02d.%d",h,m,s,tenth);return String.format(Locale.US,"%d:%02d.%d",m,s,tenth);}
    private static String norm(String s){return numberWords(s.toLowerCase(Locale.US).replace('’','\'').replace('-', ' ').replace('–',' ').replace('—',' ').replaceAll("[,!?]+"," ").replaceAll("\\s+"," ").trim());}
    private static String numberWords(String s){String[][] m={{"one","1"},{"two","2"},{"three","3"},{"four","4"},{"five","5"},{"six","6"},{"seven","7"},{"eight","8"},{"nine","9"},{"ten","10"}};String out=s;for(String[] x:m)out=out.replaceAll("\\b"+x[0]+"\\b",x[1]);return out;}

    private static final class ExpressionParser{
        final String s;int p=0;ExpressionParser(String x){s=x;}
        double parse(){double v=expr();ws();if(p!=s.length())throw new IllegalArgumentException();return v;}
        double expr(){double v=term();while(true){ws();if(eat('+'))v+=term();else if(eat('-'))v-=term();else return v;}}
        double term(){double v=factor();while(true){ws();if(eat('*'))v*=factor();else if(eat('/'))v/=factor();else return v;}}
        double factor(){ws();if(eat('+'))return factor();if(eat('-'))return-factor();if(eat('(')){double v=expr();if(!eat(')'))throw new IllegalArgumentException();return v;}int st=p;while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;if(st==p)throw new IllegalArgumentException();return Double.parseDouble(s.substring(st,p));}
        boolean eat(char c){ws();if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}void ws(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
    }
}
