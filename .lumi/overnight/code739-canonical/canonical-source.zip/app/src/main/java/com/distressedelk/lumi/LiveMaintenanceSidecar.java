package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

final class LiveMaintenanceSidecar {
    private static final long HEARTBEAT_MS=5000L;
    private static final int ROLLING_SAMPLES=60; // 5 minutes at 5 seconds/sample.
    private static final AtomicLong sequence=new AtomicLong(0L);
    private static final Object lock=new Object();
    private static ScheduledThreadPoolExecutor executor;
    private static Context app;

    private LiveMaintenanceSidecar(){}

    static synchronized void start(Context context){
        if(context==null) return;
        app=context.getApplicationContext();
        if(executor!=null && !executor.isShutdown()) return;
        executor=new ScheduledThreadPoolExecutor(1,r->{
            Thread t=new Thread(r,"LumiLiveMaintenanceSidecar");
            t.setDaemon(true);
            return t;
        });
        executor.setRemoveOnCancelPolicy(true);
        executor.scheduleAtFixedRate(LiveMaintenanceSidecar::tick,0L,HEARTBEAT_MS,TimeUnit.MILLISECONDS);
    }

    static synchronized void stop(){
        if(executor!=null){
            executor.shutdownNow();
            executor=null;
        }
    }

    static Bundle snapshot(Context context){
        Context c=context==null?app:context.getApplicationContext();
        Bundle out=new Bundle();
        long now=System.currentTimeMillis();
        if(c==null){
            out.putBoolean("ok",false);
            out.putString("state","SIDECAR_CONTEXT_UNAVAILABLE");
            return out;
        }
        SharedPreferences p=c.getSharedPreferences("lumi",0);
        long at=p.getLong("live_diag_heartbeat_at",0L);
        long age=at<=0?Long.MAX_VALUE:Math.max(0L,now-at);
        out.putBoolean("ok",true);
        out.putString("state",age<=15000L?"LIVE":"STALE");
        out.putBoolean("sidecarLive",age<=15000L);
        out.putLong("heartbeatAt",at);
        out.putLong("heartbeatAgeMs",age==Long.MAX_VALUE?-1L:age);
        out.putLong("heartbeatSequence",p.getLong("live_diag_heartbeat_seq",0L));
        out.putLong("processUptimeMs",SystemClock.elapsedRealtime());
        out.putInt("rollingWindowSeconds",300);
        out.putString("repairState",p.getString("maintenance_runtime_repair_state","NONE"));
        out.putString("repairAction",p.getString("maintenance_runtime_repair_action",""));
        out.putString("repairResult",p.getString("maintenance_runtime_repair_result",""));
        Bundle live=MainActivity.liveMaintenanceSnapshot();
        out.putAll(live);
        return out;
    }

    private static void tick(){
        Context c=app;
        if(c==null) return;
        try{
            long now=System.currentTimeMillis();
            long seq=sequence.incrementAndGet();
            SharedPreferences p=c.getSharedPreferences("lumi",0);
            Bundle live=MainActivity.liveMaintenanceSnapshot();
            p.edit().putLong("live_diag_heartbeat_at",now)
                    .putLong("live_diag_heartbeat_seq",seq)
                    .putLong("live_diag_process_uptime_ms",SystemClock.elapsedRealtime())
                    .putBoolean("live_diag_activity_active",live.getBoolean("activityActive",false))
                    .putString("live_diag_recognizer_phase",live.getString("recognizerPhase",""))
                    .putBoolean("live_diag_tts_active",live.getBoolean("ttsOutputActive",false))
                    .putBoolean("live_diag_audio_focus_held",live.getBoolean("audioFocusHeld",false))
                    .putString("live_diag_request_stage",live.getString("activeRequestStage",""))
                    .apply();
            appendRolling(c,now,seq,live);
        }catch(Throwable t){
            try{
                c.getSharedPreferences("lumi",0).edit()
                        .putString("live_diag_last_error",t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage()))
                        .putLong("live_diag_last_error_at",System.currentTimeMillis()).apply();
            }catch(Throwable ignored){}
        }
    }

    private static void appendRolling(Context c,long now,long seq,Bundle b) throws Exception{
        synchronized(lock){
            File dir=new File(c.getFilesDir(),"live-maintenance");
            if(!dir.exists() && !dir.mkdirs()) return;
            File f=new File(dir,"heartbeat-5min.jsonl");
            Deque<String> lines=new ArrayDeque<>(ROLLING_SAMPLES);
            if(f.isFile()){
                try(BufferedReader r=new BufferedReader(new FileReader(f))){
                    String line;
                    while((line=r.readLine())!=null){
                        if(lines.size()>=ROLLING_SAMPLES-1) lines.removeFirst();
                        lines.addLast(line);
                    }
                }
            }
            String row=String.format(Locale.US,
                    "{\"at\":%d,\"seq\":%d,\"activity\":%s,\"conversation\":%s,\"recognizer\":\"%s\",\"tts\":%s,\"barge\":%s,\"focus\":%s,\"aiBusy\":%s,\"request\":\"%s\",\"circuitOpen\":%s}",
                    now,seq,
                    b.getBoolean("activityActive",false),
                    b.getBoolean("conversationMode",false),
                    clean(b.getString("recognizerPhase","")),
                    b.getBoolean("ttsOutputActive",false),
                    b.getBoolean("bargeInListening",false),
                    b.getBoolean("audioFocusHeld",false),
                    b.getBoolean("aiBusy",false),
                    clean(b.getString("activeRequestStage","")),
                    b.getBoolean("recognizerRecoveryCircuitOpen",false));
            lines.addLast(row);
            try(FileWriter w=new FileWriter(f,false)){
                for(String line:lines){ w.write(line); w.write('\n'); }
            }
        }
    }

    private static String clean(String value){
        String s=value==null?"":value;
        if(s.length()>80) s=s.substring(0,80);
        return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," ");
    }
}
