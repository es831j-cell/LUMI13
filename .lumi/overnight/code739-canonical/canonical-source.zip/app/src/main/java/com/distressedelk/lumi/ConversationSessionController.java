package com.distressedelk.lumi;

import java.util.Locale;
import java.util.UUID;

final class ConversationSessionController {
    static final long QUIET_BEFORE_CONFIRM_MS=15000L, END_CONFIRM_WINDOW_MS=12000L;
    private boolean active=false,awaiting=false,suspended=false;
    private long started=0,lastActivity=0,lastLumiFinished=0,endAsked=0;
    private long continuityGeneration=0,endPromptGeneration=-1;
    private int userTurns=0,lumiTurns=0,interruptions=0,recoveries=0,arms=0,ready=0,legacyBlocks=0;
    private String id="none",lastEndReason="none",suspendReason="none";

    synchronized void start(long now){if(active)return;active=true;awaiting=false;suspended=false;started=now;lastActivity=now;lastLumiFinished=0;id=UUID.randomUUID().toString();lastEndReason="none";continuityGeneration++;endPromptGeneration=-1;}
    synchronized void startOrContinue(long now,String reason){if(!active)start(now);else lastActivity=Math.max(lastActivity,now);}
    synchronized void stop(String reason){close(reason,System.currentTimeMillis());}
    synchronized void noteUserTurn(String text,long now){start(now);lastActivity=now;userTurns++;continuityGeneration++;awaiting=false;endAsked=0;endPromptGeneration=-1;}
    synchronized void noteLumiReply(String text,long now){if(!active)return;lastActivity=now;lumiTurns++;}
    synchronized void noteLumiFinished(long now){if(active){lastLumiFinished=now;lastActivity=now;}}
    synchronized void noteInterruption(long now){if(!active)return;interruptions++;lastActivity=now;continuityGeneration++;awaiting=false;endAsked=0;endPromptGeneration=-1;}
    synchronized void noteRecovery(long now){if(active){recoveries++;lastActivity=now;}}
    synchronized void noteRecognizerArm(long now){if(active)arms++;}
    synchronized void noteRecognizerReady(long now){if(active){ready++;lastActivity=now;}}
    synchronized void noteLegacyStateBlocked(){legacyBlocks++;}
    synchronized void suspend(String reason,long now){if(active){suspended=true;suspendReason=safe(reason);lastActivity=now;}}
    synchronized void resume(long now){if(active){suspended=false;suspendReason="none";lastActivity=now;}}
    synchronized boolean shouldAskEnd(long now,boolean aiBusy,boolean tts){return active&&!suspended&&!awaiting&&!aiBusy&&!tts&&lastLumiFinished>0&&now-lastLumiFinished>=QUIET_BEFORE_CONFIRM_MS;}
    synchronized boolean shouldPrompt(long now){return shouldAskEnd(now,false,false);}
    synchronized void markEndPrompt(long now){if(active){awaiting=true;endAsked=now;lastActivity=now;endPromptGeneration=continuityGeneration;}}
    synchronized void markPrompted(long now){markEndPrompt(now);}
    synchronized boolean confirmationExpired(long now){return active&&awaiting&&endAsked>0&&endPromptGeneration==continuityGeneration&&now-endAsked>=END_CONFIRM_WINDOW_MS;}
    synchronized boolean shouldAutoClose(long now){return confirmationExpired(now);}
    synchronized long millisUntilNextCheck(long now){if(!active)return 60000L;long target=awaiting&&endAsked>0?endAsked+END_CONFIRM_WINDOW_MS:(lastLumiFinished>0?lastLumiFinished+QUIET_BEFORE_CONFIRM_MS:now+QUIET_BEFORE_CONFIRM_MS);return Math.max(500L,target-now);}
    synchronized boolean explicitEndReply(String raw){return awaiting&&confirmsEnd(raw);}
    synchronized void close(String reason,long now){active=false;awaiting=false;suspended=false;lastActivity=now;lastEndReason=safe(reason);continuityGeneration++;endPromptGeneration=-1;endAsked=0;}
    synchronized boolean isActive(){return active;}
    synchronized boolean isSuspended(){return suspended;}
    synchronized boolean awaitingEndConfirmation(){return awaiting;}
    synchronized String sessionId(){return id;}
    synchronized String lastEndReason(){return lastEndReason;}
    synchronized String nextEndPrompt(){int n=(userTurns+lumiTurns)%4;return n==0?"Anything else you want to talk about?":n==1?"Anything else before I let you go?":n==2?"Want to keep going, or are we good for now?":"Anything else on your mind?";}
    synchronized boolean confirmsEnd(String raw){String s=norm(raw);return s.matches("^(no|nope|nah|nothing else|thats all|that is all|im good|i am good|were good|we are good|good for now|done|stop|stop listening|bye|goodbye|later)$");}
    synchronized boolean explicitlyContinues(String raw){String s=norm(raw);return !s.isEmpty()&&!confirmsEnd(s);}
    synchronized String modelGuidance(){return active?" Continue the same conversation naturally. Remember established people, relationships and topic context. Do not greet again or behave as if this is a new chat.":"";}
    synchronized String snapshot(long now){return "active="+active+" • suspended="+suspended+" • awaitingEndConfirmation="+awaiting+" • session="+id+" • ageMs="+(started>0?Math.max(0,now-started):0)+" • quietMs="+Math.max(0,now-lastActivity)+" • userTurns="+userTurns+" • lumiTurns="+lumiTurns+" • interruptions="+interruptions+" • recoveries="+recoveries+" • recognizerArms="+arms+" • recognizerReady="+ready+" • legacyStateBlocks="+legacyBlocks+" • suspendReason="+suspendReason+" • lastEndReason="+lastEndReason;}
    private static String norm(String s){return s==null?"":s.toLowerCase(Locale.US).replaceAll("[^a-z0-9' ]"," ").replaceAll("\\s+"," ").trim();}
    private static String safe(String s){return s==null?"":s.replace('\n',' ').replace('\r',' ').trim();}
}
