package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Runtime subsystem registry v2.
 *
 * Content modules are independently versioned and capability-addressed. Core is never installed
 * through this lane. Each replacement retains the prior registry record so LumiUpdateManager can
 * restore the matching transaction backup without rolling back unrelated subsystems.
 */
final class RuntimeModuleRegistry {
    static final String REGISTRY_RELATIVE = "lumi_updates/modules/active-modules.json";
    private static final Set<String> KINDS = new HashSet<>();
    private static final Set<String> TIERS = new HashSet<>();
    static {
        String[] kinds = {"skills","prompts","ui","voice","home","models","migrations","scripts"};
        for (String k : kinds) KINDS.add(k);
        String[] tiers = {"standard","optional","experimental"};
        for (String t : tiers) TIERS.add(t);
    }

    private RuntimeModuleRegistry() {}

    static JSONObject activate(Context context, SharedPreferences prefs, JSONObject updateManifest, String updateId) throws Exception {
        JSONArray declared = updateManifest.optJSONArray("modules");
        if (declared == null) return current(context);

        java.util.LinkedHashMap<String,JSONObject> merged = new java.util.LinkedHashMap<>();
        JSONArray prior = current(context).optJSONArray("modules");
        if (prior != null) {
            for (int i=0;i<prior.length();i++) {
                JSONObject old=prior.optJSONObject(i); if(old==null) continue;
                String oldId=old.optString("id","").trim();
                if(!oldId.isEmpty()) merged.put(oldId,new JSONObject(old.toString()));
            }
        }

        for (int i = 0; i < declared.length(); i++) {
            JSONObject m = declared.getJSONObject(i);
            String id = safeId(m.getString("id"), "module id");
            String kind = m.getString("kind").trim().toLowerCase(Locale.US);
            if (!KINDS.contains(kind)) throw new SecurityException("Unsupported Lumi module kind: " + kind);
            String tier = m.optString("tier", m.optBoolean("required", true) ? "standard" : "optional").trim().toLowerCase(Locale.US);
            if ("core".equals(tier)) throw new SecurityException("Core capability cannot be installed through the module lane: " + id);
            if (!TIERS.contains(tier)) throw new SecurityException("Unsupported Lumi module tier: " + tier);

            int minCore=m.optInt("minCoreVersionCode",0);
            int maxCore=m.optInt("maxCoreVersionCode",Integer.MAX_VALUE);
            android.content.pm.PackageInfo coreInfo=context.getPackageManager().getPackageInfo(context.getPackageName(),0);
            int core=android.os.Build.VERSION.SDK_INT>=28?(int)coreInfo.getLongVersionCode():coreInfo.versionCode;
            if(core<minCore || core>maxCore) throw new SecurityException("Module "+id+" is incompatible with Lumi Core "+core);

            String version = m.optString("version", updateId).trim();
            String entry = m.getString("entry").replace('\\','/').trim();
            if (!entry.startsWith(kind + "/") || entry.contains("../") || entry.startsWith("/")) {
                throw new SecurityException("Unsafe module entry: " + entry);
            }
            File file = new File(context.getFilesDir(), "lumi_updates/modules/" + entry);
            ensureInside(new File(context.getFilesDir(), "lumi_updates/modules"), file);
            if (!file.isFile() || file.length() <= 0) throw new SecurityException("Module payload is missing: " + id);

            String format = m.optString("format", inferFormat(entry)).toLowerCase(Locale.US);
            if ("json".equals(format)) {
                String raw = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8);
                new JSONObject(raw);
            }

            JSONObject previous=merged.get(id);
            JSONObject rec = new JSONObject();
            rec.put("id", id);
            rec.put("kind", kind);
            rec.put("tier", tier);
            rec.put("version", version);
            rec.put("entry", entry);
            rec.put("path", file.getAbsolutePath());
            rec.put("required", m.optBoolean("required", "standard".equals(tier)));
            rec.put("capabilities", m.optJSONArray("capabilities") == null ? new JSONArray() : m.optJSONArray("capabilities"));
            rec.put("state", "ACTIVE");
            rec.put("health", "UNASSESSED_CORE_OWNED");
            rec.put("activatedByUpdateId", updateId);
            rec.put("activatedAt", System.currentTimeMillis());
            rec.put("minCoreVersionCode", minCore);
            rec.put("maxCoreVersionCode", maxCore);
            rec.put("candidateVersion", "");
            if(previous!=null){
                rec.put("lastKnownGoodVersion", previous.optString("version", version));
                rec.put("previous", new JSONObject(previous.toString()));
            }else{
                rec.put("lastKnownGoodVersion", m.optString("lastKnownGoodVersion", version));
            }
            merged.put(id,rec);
        }

        JSONArray active = new JSONArray();
        for(JSONObject rec:merged.values()) active.put(rec);
        long epoch = Math.max(System.currentTimeMillis(), prefs.getLong("runtime_module_epoch", 0L) + 1L);
        JSONObject registry = new JSONObject();
        registry.put("schemaVersion", 2);
        registry.put("updateId", updateId);
        registry.put("activatedAt", System.currentTimeMillis());
        registry.put("epoch", epoch);
        registry.put("modules", active);
        persist(context,registry);
        prefs.edit().putLong("runtime_module_epoch", epoch).putString("active_module_update_id", updateId)
                .putInt("active_module_count", active.length()).putLong("active_module_activated_at", System.currentTimeMillis()).commit();
        LumiSystemRegistry.reconcile(context,prefs);
        return registry;
    }

    static JSONObject current(Context context) {
        try {
            File f = new File(context.getFilesDir(), REGISTRY_RELATIVE);
            if (!f.isFile()) return new JSONObject().put("schemaVersion",2).put("modules",new JSONArray());
            JSONObject r=new JSONObject(new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8));
            if(!r.has("schemaVersion")) r.put("schemaVersion",1);
            return r;
        } catch (Throwable t) {
            try { return new JSONObject().put("schemaVersion",2).put("error",String.valueOf(t.getMessage())).put("modules",new JSONArray()); }
            catch (Exception ignored) { return new JSONObject(); }
        }
    }

    static File resolve(Context context, String moduleId) {
        try {
            JSONObject m=find(current(context),moduleId);
            if(m==null)return null;
            File f=new File(m.optString("path",""));
            ensureInside(new File(context.getFilesDir(),"lumi_updates/modules"),f);
            return f.isFile()?f:null;
        } catch (Throwable ignored) { return null; }
    }

    static JSONObject record(Context context,String moduleId){
        try{JSONObject m=find(current(context),moduleId);return m==null?null:new JSONObject(m.toString());}
        catch(Throwable ignored){return null;}
    }

    static boolean rollbackAvailable(Context context,String moduleId){
        JSONObject m=record(context,moduleId);
        return m!=null && !m.optString("activatedByUpdateId","").isEmpty();
    }

    static JSONObject rollbackRecord(Context context,SharedPreferences prefs,String moduleId) throws Exception{
        JSONObject registry=current(context); JSONArray modules=registry.optJSONArray("modules");
        if(modules==null)throw new IllegalStateException("Module registry is empty");
        JSONArray next=new JSONArray(); boolean found=false;
        for(int i=0;i<modules.length();i++){
            JSONObject m=modules.getJSONObject(i);
            if(!moduleId.equals(m.optString("id"))){next.put(m);continue;}
            found=true;
            JSONObject previous=m.optJSONObject("previous");
            if(previous!=null){
                JSONObject restored=new JSONObject(previous.toString());
                restored.put("state","ACTIVE"); restored.put("health","UNASSESSED_CORE_OWNED");
                restored.put("rolledBackAt",System.currentTimeMillis());
                next.put(restored);
            }
        }
        if(!found)throw new IllegalArgumentException("Unknown module: "+moduleId);
        long epoch=Math.max(System.currentTimeMillis(),prefs.getLong("runtime_module_epoch",0L)+1L);
        registry.put("schemaVersion",2).put("epoch",epoch).put("modules",next)
                .put("lastRollbackModule",moduleId).put("lastRollbackAt",System.currentTimeMillis());
        persist(context,registry);
        prefs.edit().putLong("runtime_module_epoch",epoch).putInt("active_module_count",next.length())
                .putString("last_module_rollback_id",moduleId).putLong("last_module_rollback_at",System.currentTimeMillis()).commit();
        LumiSystemRegistry.reconcile(context,prefs);
        return registry;
    }

    static String health(Context context, SharedPreferences prefs) {
        try {
            JSONObject r=current(context); JSONArray a=r.optJSONArray("modules"); int count=a==null?0:a.length(); int missing=0; StringBuilder detail=new StringBuilder();
            if(r.has("error")){String v="registryError="+r.optString("error");LumiEvidenceLedger.append(prefs,"SELF","RAW_MODULE_OBSERVATION","registry",v,"RuntimeModuleRegistry");return v;}
            for(int i=0;i<count;i++){JSONObject m=a.getJSONObject(i);File f=new File(m.optString("path",""));if(!f.isFile()){missing++;if(detail.length()>0)detail.append(',');detail.append(m.optString("id"));}}
            long epoch=prefs.getLong("runtime_module_epoch",0L);String v="count="+count+", missingFiles="+missing+", missingIds="+detail+", epoch="+epoch;LumiEvidenceLedger.append(prefs,"SELF","RAW_MODULE_OBSERVATION","modules",v,"RuntimeModuleRegistry");return v;
        } catch (Throwable t) {String v="registryException="+t.getClass().getSimpleName();LumiEvidenceLedger.append(prefs,"SELF","RAW_MODULE_OBSERVATION","modules",v,"RuntimeModuleRegistry");return v;}
    }

    private static JSONObject find(JSONObject registry,String id){
        JSONArray a=registry.optJSONArray("modules"); if(a==null)return null;
        for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);if(m!=null&&id.equals(m.optString("id")))return m;}
        return null;
    }
    private static void persist(Context context,JSONObject registry)throws Exception{
        File target = new File(context.getFilesDir(), REGISTRY_RELATIVE);
        File parent = target.getParentFile(); if (parent != null && !parent.exists() && !parent.mkdirs()) throw new java.io.IOException("Could not create module registry directory");
        File tmp = new File(parent, target.getName() + ".tmp");
        Files.write(tmp.toPath(), registry.toString(2).getBytes(StandardCharsets.UTF_8));
        if (target.exists() && !target.delete()) throw new java.io.IOException("Could not rotate old module registry");
        if (!tmp.renameTo(target)) throw new java.io.IOException("Could not publish module registry");
    }
    private static String inferFormat(String entry) { return entry.toLowerCase(Locale.US).endsWith(".json") ? "json" : "raw"; }
    private static String safeId(String v,String what) { String s=v.trim(); if(!s.matches("[A-Za-z0-9._-]{1,96}")) throw new SecurityException("Invalid "+what); return s; }
    private static void ensureInside(File base, File child) throws Exception { String b=base.getCanonicalPath()+File.separator; String c=child.getCanonicalPath(); if(!c.startsWith(b)) throw new SecurityException("Unsafe module path"); }
}
