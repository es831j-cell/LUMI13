package com.distressedelk.lumi;

import java.util.Locale;

/** Pure-Java intent classification for Code661. No Android or provider dependency. */
final class LumiCoreIntentClassifier {
    enum Kind { CONVERSATION, INFORMATION, ACTION, SELF }
    private static final String ACTION_VERBS="make|change|set|create|build|publish|install|update|fix|tune|send|open|close|turn|start|stop|run|check|remind|call|text|delete|remove|add|save|export|apply|play|schedule|move|rename|connect|disconnect|download|upload";
    // Keep modal/indirect action grammar explicit and reusable so both runtime behavior and
    // release validation prove the same grammar surface.
    private static final String MODAL_ACTION_PREFIX="(?:please\\s+)?(?:can|could|would|will)\\s+you\\s+(?:please\\s+)?";
    private LumiCoreIntentClassifier(){}

    static Kind classify(String raw,boolean selfReference,boolean priorAction,boolean priorOpen){
        if(selfReference)return Kind.SELF;
        if(isActionRequest(raw,priorAction,priorOpen))return Kind.ACTION;
        String n=norm(raw);
        if(n.isEmpty())return Kind.CONVERSATION;
        if(n.matches("^(?:please\\s+)?(?:can|could|would|will)\\s+you\\s+(?:please\\s+)?(?:tell|explain|describe|answer)\\b.*"))return Kind.INFORMATION;
        if(n.matches("^(who|what|when|where|why|how)\\b.*")||n.startsWith("tell me ")||n.startsWith("explain ")||n.startsWith("describe ")||n.startsWith("do you know "))return Kind.INFORMATION;
        return Kind.CONVERSATION;
    }

    /** General action signal used by Core even when a self-reference makes the top-level kind SELF. */
    static boolean isActionRequest(String raw,boolean priorAction,boolean priorOpen){
        String n=norm(raw);
        if(n.isEmpty())return false;
        if(priorAction && priorOpen && isContinuation(n))return true;
        if(priorAction && priorOpen && isActionStatusQuery(n))return true;
        if(n.matches("^(?:please\\s+)?(?:"+ACTION_VERBS+")\\b.*"))return true;
        if(n.matches("^"+MODAL_ACTION_PREFIX+"(?:"+ACTION_VERBS+")\\b.*"))return true;
        if(n.matches("^then\\s+(?:please\\s+)?(?:"+ACTION_VERBS+")\\b.*"))return true;
        return n.contains("i want you to ")||n.contains("i need you to ")||n.contains("i'd like you to ")||n.contains("i would like you to ");
    }

    static boolean isActionStatusQuery(String raw){
        String x=norm(raw).replaceAll("[.!?]+$","").trim();
        if(x.matches("^(did|have|has)\\s+you\\b.*"))return true;
        if(x.matches("^(is|was)\\s+(it|that|this)\\s+(done|finished|complete|completed|ready|working|fixed|updated|installed|published|sent|saved|created|made)\\b.*"))return true;
        if(x.matches("^(did|does)\\s+(it|that|this)\\s+(work|finish|complete|send|save|install|publish|update)\\b.*"))return true;
        if(x.matches("^are\\s+you\\s+(done|finished|still working|still doing|still making|still setting)\\b.*"))return true;
        return x.startsWith("what happened with ")||x.startsWith("what happened to ")||x.startsWith("where are we on ")||x.startsWith("what's the status of ")||x.startsWith("whats the status of ");
    }

    static boolean isContinuation(String raw){
        String x=norm(raw).replaceAll("[.!?]+$","").trim();
        if(x.matches("^(then\\s+)?(do it|make it|fix it|set it up|go ahead|proceed|continue|yes|okay|ok)$"))return true;
        if(x.matches("^then\\s+(make|change|set|create|build|publish|install|update|fix|send|open|start|run|add|save|apply|play|schedule|connect|download|upload)\\b.*"))return true;
        return x.startsWith("try again")||x.startsWith("still not ")||x.startsWith("that didn't ")||x.startsWith("that didnt ");
    }

    private static String norm(String raw){return raw==null?"":raw.trim().toLowerCase(Locale.US);}
}
