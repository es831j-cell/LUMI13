package com.distressedelk.lumi;

import android.content.SharedPreferences;
import java.util.Locale;
import java.util.List;

/**
 * Code640: Lumi's living operational self.
 * This is Core state, not a capability subsystem. It tracks what Lumi is trying to
 * accomplish, what she has actually done, what evidence exists, and whether the
 * owner's goal is satisfied. Providers and capabilities may advise or act, but
 * they cannot mark an action goal complete merely by producing text.
 */
final class LumiLivingSelf {
    static final String VERSION="1";
    static final long CONTINUATION_WINDOW_MS=10L*60L*1000L;

    enum GoalKind { INFORMATION, ACTION, CONVERSATION }
    enum GoalState { IDLE, UNDERSTANDING, ACTIVE, ACTING, VERIFYING, ANSWERED, SATISFIED, BLOCKED, FAILED, NEEDS_INPUT, PAUSED }

    private LumiLivingSelf(){}

    static void resetForRelease(SharedPreferences p,int oldCode,int newCode){
        if(p==null)return;
        String prior=summary(p);
        p.edit().putString("lumi_goal_previous_release_summary","code="+oldCode+" "+prior)
                .putLong("lumi_goal_id",0L)
                .putString("lumi_goal_kind","NONE")
                .putString("lumi_goal_state",GoalState.IDLE.name())
                .putString("lumi_goal_text","")
                .putString("lumi_goal_desired_outcome","")
                .putString("lumi_goal_current_action","")
                .putString("lumi_goal_last_observation","")
                .putString("lumi_goal_last_evidence","")
                .putBoolean("lumi_goal_action_evidence",false)
                .putBoolean("lumi_goal_outcome_verified",false)
                .putInt("lumi_goal_attempts",0)
                .putInt("lumi_goal_failed_attempts",0)
                .putInt("lumi_goal_confidence",0)
                .putLong("lumi_goal_release_code",newCode)
                .putLong("lumi_goal_last_at",System.currentTimeMillis()).apply();
    }

    static void onUserTurn(SharedPreferences p,long turnId,String raw){
        if(p==null)return;
        long now=System.currentTimeMillis();
        String q=raw==null?"":raw.trim();
        String n=q.toLowerCase(Locale.US);
        GoalState prior=state(p);
        boolean open=isOpen(prior);
        long age=Math.max(0L,now-p.getLong("lumi_goal_last_at",0L));
        boolean correction=isFailureReport(n);
        boolean continuation=open && age<=CONTINUATION_WINDOW_MS && (correction||isContinuation(n));
        SharedPreferences.Editor e=p.edit();
        if(!continuation){
            GoalKind kind=classify(n);
            e.putLong("lumi_goal_id",turnId)
             .putString("lumi_goal_kind",kind.name())
             .putString("lumi_goal_state",GoalState.UNDERSTANDING.name())
             .putString("lumi_goal_text",q)
             .putString("lumi_goal_desired_outcome",desiredOutcome(kind,q))
             .putString("lumi_goal_current_action","")
             .putString("lumi_goal_last_observation","")
             .putString("lumi_goal_last_evidence","")
             .putBoolean("lumi_goal_action_evidence",false)
             .putBoolean("lumi_goal_outcome_verified",false)
             .putInt("lumi_goal_attempts",0)
             .putInt("lumi_goal_failed_attempts",0)
             .putInt("lumi_goal_confidence",kind==GoalKind.CONVERSATION?70:85)
             .putLong("lumi_goal_started_at",now);
        }else{
            e.putLong("lumi_goal_last_turn_id",turnId)
             .putString("lumi_goal_last_user_input",q);
            if(correction){
                int failed=p.getInt("lumi_goal_failed_attempts",0)+1;
                e.putInt("lumi_goal_failed_attempts",failed)
                 .putString("lumi_goal_state",GoalState.ACTIVE.name())
                 .putString("lumi_goal_last_observation","OWNER_REPORTED_FAILURE: "+q)
                 .putBoolean("lumi_goal_outcome_verified",false)
                 .putInt("lumi_goal_confidence",Math.max(20,p.getInt("lumi_goal_confidence",70)-20));
            }
        }
        e.putLong("lumi_goal_last_at",now).apply();
        if(!continuation){
            p.edit().putString("lumi_goal_state",GoalState.ACTIVE.name()).apply();
        }
    }

    static void noteActionStarted(SharedPreferences p,String capability,String detail){
        if(p==null)return;
        p.edit().putString("lumi_goal_state",GoalState.ACTING.name())
         .putString("lumi_goal_current_action",safe(capability))
         .putString("lumi_goal_last_evidence","ACTION_STARTED: "+safe(detail))
         .putInt("lumi_goal_attempts",p.getInt("lumi_goal_attempts",0)+1)
         .putLong("lumi_goal_last_at",System.currentTimeMillis()).apply();
    }

    static void noteLocalAction(SharedPreferences p,String action,String detail,String reply){
        if(p==null)return;
        GoalKind kind=kind(p);
        if(kind==GoalKind.INFORMATION){
            p.edit().putString("lumi_goal_state",GoalState.ANSWERED.name())
             .putBoolean("lumi_goal_outcome_verified",true)
             .putString("lumi_goal_last_evidence","LOCAL_INFORMATION: "+safe(action)+" "+safe(detail))
             .putLong("lumi_goal_last_at",System.currentTimeMillis()).apply();
            return;
        }
        if(kind!=GoalKind.ACTION)return;
        String d=(detail==null?"":detail).toLowerCase(Locale.US);
        boolean blocked=d.contains("unavailable")||d.contains("not-found")||d.contains("permission-required")||
                d.contains("error")||d.contains("failed")||d.contains("missing");
        boolean visual="visual-tune".equals(action);
        SharedPreferences.Editor e=p.edit().putString("lumi_goal_current_action",safe(action))
                .putInt("lumi_goal_attempts",p.getInt("lumi_goal_attempts",0)+1)
                .putLong("lumi_goal_last_at",System.currentTimeMillis());
        if(blocked){
            e.putString("lumi_goal_state",GoalState.BLOCKED.name())
             .putBoolean("lumi_goal_action_evidence",false)
             .putBoolean("lumi_goal_outcome_verified",false)
             .putString("lumi_goal_last_evidence","ACTION_BLOCKED: "+safe(detail));
        }else if(visual){
            boolean applied=d.contains("step-applied")||d.contains("changed=true");
            e.putString("lumi_goal_state",GoalState.VERIFYING.name())
             .putBoolean("lumi_goal_action_evidence",applied)
             .putBoolean("lumi_goal_outcome_verified",false)
             .putString("lumi_goal_last_evidence",applied?"ACTION_ACCEPTED_AWAITING_OBSERVATION: "+safe(detail):
                     "MEASUREMENT_REQUIRED_BEFORE_ACTION: "+safe(detail));
        }else{
            e.putString("lumi_goal_state",GoalState.SATISFIED.name())
             .putBoolean("lumi_goal_action_evidence",true)
             .putBoolean("lumi_goal_outcome_verified",true)
             .putString("lumi_goal_last_evidence","LOCAL_ACTION_VERIFIED: "+safe(action)+" "+safe(detail));
        }
        e.apply();
    }

    static void noteVisualObservation(SharedPreferences p,String status,float mismatch,boolean changed){
        if(p==null||kind(p)!=GoalKind.ACTION)return;
        String target=p.getString("lumi_goal_text","").toLowerCase(Locale.US);
        String desired=p.getString("lumi_goal_desired_outcome","").toLowerCase(Locale.US);
        if(!(target.contains("avatar")||target.contains("look")||target.contains("visual")||
                desired.contains("avatar")||desired.contains("visual")))return;
        boolean close="CAPTURED_CLOSE_REQUIRES_OWNER".equals(status);
        String evidence="VISUAL_OBSERVATION status="+safe(status)+" mismatchPct="+mismatch+" rendererChanged="+changed;
        SharedPreferences.Editor e=p.edit().putString("lumi_goal_last_observation",evidence)
                .putString("lumi_goal_last_evidence",evidence)
                .putLong("lumi_goal_last_at",System.currentTimeMillis());
        if(close){
            e.putString("lumi_goal_state",GoalState.SATISFIED.name())
             .putBoolean("lumi_goal_action_evidence",true)
             .putBoolean("lumi_goal_outcome_verified",true)
             .putInt("lumi_goal_confidence",95);
        }else{
            e.putString("lumi_goal_state",changed?GoalState.VERIFYING.name():GoalState.ACTIVE.name())
             .putBoolean("lumi_goal_outcome_verified",false);
        }
        e.apply();
    }

    static void onTurnTerminal(SharedPreferences p,String terminal,String route,String why){
        if(p==null)return;
        GoalKind k=kind(p);GoalState s=state(p);
        String t=terminal==null?"":terminal;
        SharedPreferences.Editor e=p.edit().putString("lumi_goal_last_route",safe(route))
                .putString("lumi_goal_last_turn_terminal",safe(t))
                .putLong("lumi_goal_last_at",System.currentTimeMillis());
        if("FAILED".equals(t)||"TIMEOUT".equals(t)){
            e.putString("lumi_goal_state",GoalState.FAILED.name())
             .putString("lumi_goal_last_evidence","TURN_"+t+": "+safe(why)).apply();return;
        }
        if("CANCELLED".equals(t)){
            if(isOpen(s))e.putString("lumi_goal_state",GoalState.PAUSED.name());
            e.apply();return;
        }
        if(!"COMPLETE".equals(t)){e.apply();return;}
        if(k==GoalKind.INFORMATION){
            e.putString("lumi_goal_state",GoalState.ANSWERED.name())
             .putBoolean("lumi_goal_outcome_verified",true)
             .putString("lumi_goal_last_evidence","ANSWER_COMMITTED route="+safe(route)).apply();
        }else if(k==GoalKind.ACTION){
            boolean verified=p.getBoolean("lumi_goal_outcome_verified",false);
            boolean acted=p.getBoolean("lumi_goal_action_evidence",false);
            if(verified)e.putString("lumi_goal_state",GoalState.SATISFIED.name());
            else if(acted)e.putString("lumi_goal_state",GoalState.VERIFYING.name());
            else e.putString("lumi_goal_state",GoalState.ACTIVE.name())
                  .putString("lumi_goal_last_evidence","REPLY_COMMITTED_WITHOUT_ACTION_EVIDENCE");
            e.apply();
        }else{
            e.putString("lumi_goal_state",GoalState.ANSWERED.name()).apply();
        }
    }

    static String guardReply(SharedPreferences p,String message){
        if(p==null||message==null||kind(p)!=GoalKind.ACTION)return message;
        if(p.getBoolean("lumi_goal_outcome_verified",false))return message;
        boolean acted=p.getBoolean("lumi_goal_action_evidence",false);
        String m=message.toLowerCase(Locale.US);
        boolean overclaim=m.contains("i've updated")||m.contains("i have updated")||m.contains("i changed")||
                m.contains("i've changed")||m.contains("i fixed")||m.contains("i've fixed")||
                m.contains("updating your avatar right now")||m.contains("updating it right now")||
                m.contains("i'm updating")||m.contains("im updating")||m.contains("i'll update")||
                m.contains("i will update")||m.contains("i'll change")||m.contains("i will change")||
                m.matches("(?s).*\\b(done|completed|finished)\\b.*");
        if(!acted && overclaim){
            p.edit().putString("lumi_goal_claim_guard_last_original",message)
             .putString("lumi_goal_claim_guard_last_result","BLOCKED_UNVERIFIED_SUCCESS_CLAIM")
             .putLong("lumi_goal_claim_guard_at",System.currentTimeMillis()).apply();
            return "I understand what you want, but I don't have evidence that I've actually done it yet. I'm keeping the goal open while I act or identify what's blocking me.";
        }
        return message;
    }

    static void audit(SharedPreferences p,List<String> findings){
        if(p==null||findings==null)return;
        GoalKind k=kind(p);GoalState s=state(p);
        if(k==GoalKind.ACTION && isOpen(s) && !p.getBoolean("lumi_goal_action_evidence",false)){
            String ev=p.getString("lumi_goal_last_evidence","");
            if("REPLY_COMMITTED_WITHOUT_ACTION_EVIDENCE".equals(ev))
                findings.add("S1 Lumi action goal remains open because a reply was committed without action evidence");
        }
        if(k==GoalKind.ACTION && p.getInt("lumi_goal_failed_attempts",0)>0 && !p.getBoolean("lumi_goal_outcome_verified",false))
            findings.add("S2 Lumi has owner-reported failed attempt(s) on the active goal and must revise the plan before claiming success");
    }

    static String summary(SharedPreferences p){
        if(p==null)return "unavailable";
        return "goal="+p.getLong("lumi_goal_id",0L)+
                " kind="+p.getString("lumi_goal_kind","NONE")+
                " state="+p.getString("lumi_goal_state","IDLE")+
                " confidence="+p.getInt("lumi_goal_confidence",0)+
                " actionEvidence="+p.getBoolean("lumi_goal_action_evidence",false)+
                " outcomeVerified="+p.getBoolean("lumi_goal_outcome_verified",false)+
                " attempts="+p.getInt("lumi_goal_attempts",0)+
                " failedAttempts="+p.getInt("lumi_goal_failed_attempts",0)+
                " desired="+safe(p.getString("lumi_goal_desired_outcome",""));
    }

    static String activeGoalText(SharedPreferences p){return p==null?"":p.getString("lumi_goal_text","");}
    static boolean activeActionGoalMentionsVisuals(SharedPreferences p){
        if(p==null||kind(p)!=GoalKind.ACTION||!isOpen(state(p)))return false;
        String x=(p.getString("lumi_goal_text","")+" "+p.getString("lumi_goal_desired_outcome","")).toLowerCase(Locale.US);
        return x.contains("avatar")||x.contains("visual")||x.contains("look like")||x.contains("appearance");
    }

    private static GoalKind classify(String n){
        if(n==null||n.isEmpty())return GoalKind.CONVERSATION;
        LumiSelfIntentResolver.Decision selfDecision=LumiSelfIntentResolver.resolve(n);
        if(selfDecision.actionIntent())return GoalKind.ACTION;
        if(selfDecision.localAuthorityIntent())return GoalKind.INFORMATION;
        if(n.matches("^(who|what|when|where|why|how)\\b.*")||
           n.startsWith("tell me ")||n.startsWith("explain ")||n.startsWith("do you know "))
            return GoalKind.INFORMATION;
        String x=n.replaceFirst("^please\\s+","");
        if(x.matches("^(make|change|set|create|build|publish|install|update|fix|tune|send|open|close|turn|start|stop|run|check|remind|call|text|delete|remove|add|save|export|apply)\\b.*")||
           x.contains("i want you to ")||x.contains("i need you to "))
            return GoalKind.ACTION;
        return GoalKind.CONVERSATION;
    }
    private static String desiredOutcome(GoalKind k,String q){
        if(k==GoalKind.ACTION)return "Requested state/action is observably completed: "+safe(q);
        if(k==GoalKind.INFORMATION)return "Requested information is answered accurately: "+safe(q);
        return "Conversation remains coherent and responsive: "+safe(q);
    }
    private static boolean isContinuation(String n){
        if(n==null)return false;
        if(n.length()<=24 && (n.equals("full")||n.equals("do it")||n.equals("make it")||n.equals("fix it")||
                n.equals("proceed")||n.equals("continue")||n.equals("yes")||n.equals("no")||n.equals("go ahead")))return true;
        return n.startsWith("it's not ")||n.startsWith("its not ")||n.startsWith("that didn't ")||
                n.startsWith("that didnt ")||n.startsWith("still not ")||n.startsWith("try again");
    }
    private static boolean isFailureReport(String n){
        return n!=null&&(n.contains("not changing")||n.contains("not working")||n.contains("didn't work")||
                n.contains("didnt work")||n.contains("still wrong")||n.contains("still not")||
                n.contains("that failed")||n.contains("it failed"));
    }
    private static boolean isOpen(GoalState s){
        return s==GoalState.UNDERSTANDING||s==GoalState.ACTIVE||s==GoalState.ACTING||s==GoalState.VERIFYING||
               s==GoalState.BLOCKED||s==GoalState.FAILED||s==GoalState.NEEDS_INPUT||s==GoalState.PAUSED;
    }
    private static GoalKind kind(SharedPreferences p){
        try{return GoalKind.valueOf(p.getString("lumi_goal_kind",GoalKind.CONVERSATION.name()));}catch(Throwable t){return GoalKind.CONVERSATION;}
    }
    private static GoalState state(SharedPreferences p){
        try{return GoalState.valueOf(p.getString("lumi_goal_state",GoalState.IDLE.name()));}catch(Throwable t){return GoalState.IDLE;}
    }
    private static String safe(String s){
        if(s==null)return "";
        s=s.replace('\n',' ').replace('\r',' ').trim();
        return s.length()>240?s.substring(0,240):s;
    }
}
