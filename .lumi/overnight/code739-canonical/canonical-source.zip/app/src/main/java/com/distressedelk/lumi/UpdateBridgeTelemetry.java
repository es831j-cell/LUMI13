package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Code396 R113: hardened durable flight recorder for Lumi's native GitHub self-update path.
 *
 * Reinforcement goals:
 * - preserve one trace across Android's package-replacement boundary;
 * - prevent a post-install discovery check from overwriting the just-completed update trace;
 * - expose per-stage delta/elapsed timing, retry count, checkpoint use and the real source/target;
 * - keep every emitted event credential-safe and Black-Box visible;
 * - synchronously persist installer-boundary facts so Android process replacement cannot erase them;
 * - retain checkpoint duration and usage truth across package replacement.
 */
final class UpdateBridgeTelemetry {
    private static final int MAX_TIMELINE_CHARS = 32000;
    private static final long INSTALL_FINALIZATION_GRACE_MS = 15L*60L*1000L;
    private static final String TRACE_ID="update_bridge_trace_id";
    private static final String STAGE="update_bridge_stage";
    private static final String TIMELINE="update_bridge_timeline";
    private static final String STARTED="update_bridge_started_at";
    private static final String LAST_AT="update_bridge_last_event_at";
    private static final String SOURCE="update_bridge_source_version";
    private static final String TARGET="update_bridge_target_version";
    private static final String UPDATE_ID="update_bridge_update_id";
    private static final String LAST_ERROR="update_bridge_last_error";
    private static final String RETRIES="update_bridge_retry_count";
    private static final String CHECKPOINT_USED="update_bridge_checkpoint_used";
    private static final String CHECKPOINT_STARTED="update_bridge_checkpoint_started_at";
    private static final String CHECKPOINT_DURATION="update_bridge_checkpoint_duration_ms";
    private static final String LAST_COMPLETED_TRACE="update_bridge_last_completed_trace_id";
    private static final String LAST_COMPLETED_TIMELINE="update_bridge_last_completed_timeline";
    private static final String LAST_COMPLETED_AT="update_bridge_last_completed_at";
    private static final String LAST_COMPLETED_SOURCE="update_bridge_last_completed_source";
    private static final String LAST_COMPLETED_TARGET="update_bridge_last_completed_target";
    private static final String LAST_COMPLETED_RESULT="update_bridge_last_completed_result";
    private static final String LAST_COMPLETED_DURATION="update_bridge_last_completed_duration_ms";
    private static final String LAST_COMPLETED_RETRIES="update_bridge_last_completed_retry_count";
    private static final String LAST_COMPLETED_CHECKPOINT="update_bridge_last_completed_checkpoint_used";
    private static final String LAST_COMPLETED_CHECKPOINT_DURATION="update_bridge_last_completed_checkpoint_duration_ms";

    private UpdateBridgeTelemetry(){}

    static synchronized boolean awaitingPostInstallFinalization(Context c,SharedPreferences p){
        if(c==null||p==null)return false;
        long installed=currentVersion(c);
        long target=p.getLong(TARGET,-1L);
        long requested=p.getLong("self_update_install_requested_target",-1L);
        long requestedAt=p.getLong("self_update_install_requested_at",0L);
        String stage=p.getString(STAGE,"");
        if(stage.isEmpty()||terminal(stage)||target<=0L||requested!=target||installed<target||requestedAt<=0L)return false;
        long age=Math.max(0L,System.currentTimeMillis()-requestedAt);
        return age<=INSTALL_FINALIZATION_GRACE_MS;
    }

    static synchronized void beginDiscovery(Context c, SharedPreferences p, boolean downloadPackage){
        if(c==null||p==null)return;
        long now=System.currentTimeMillis();
        long installed=currentVersion(c);
        String currentStage=p.getString(STAGE,"");
        long currentTarget=p.getLong(TARGET,-1L);
        // Preserve an active pre-install trace. It must survive until PACKAGE_REPLACED finalizes it.
        if(!currentStage.isEmpty() && !terminal(currentStage) && currentTarget>installed){
            mark(c,p,"DISCOVERY_REENTERED","installed="+installed+" target="+currentTarget+" download="+downloadPackage);
            return;
        }
        String trace="u"+now+"-c"+installed;
        p.edit().putString(TRACE_ID,trace).putString(STAGE,"DISCOVERY_START")
                .putString(TIMELINE,"").putLong(STARTED,now).putLong(LAST_AT,now)
                .putLong(SOURCE,installed).putLong(TARGET,-1L).putInt(RETRIES,0)
                .putBoolean(CHECKPOINT_USED,false).putLong(CHECKPOINT_STARTED,0L).putLong(CHECKPOINT_DURATION,-1L)
                .remove(UPDATE_ID).remove(LAST_ERROR).apply();
        mark(c,p,"DISCOVERY_START","installed="+installed+" download="+downloadPackage);
    }

    static synchronized void bindTarget(Context c,SharedPreferences p,String updateId,long target,String detail){
        if(p==null)return;
        p.edit().putString(UPDATE_ID,safe(updateId,96)).putLong(TARGET,target).apply();
        mark(c,p,"TARGET_BOUND","id="+safe(updateId,96)+" target="+target+(detail==null||detail.isEmpty()?"":" "+detail));
    }

    static synchronized void mark(Context c,SharedPreferences p,String stage,String detail){
        if(c==null||p==null)return;
        long now=System.currentTimeMillis();
        String st=safe(stage,120); if(st.isEmpty())st="UNKNOWN";
        String d=safe(detail,900);
        String trace=p.getString(TRACE_ID,"");
        if(trace.isEmpty()){
            trace="u"+now+"-c"+currentVersion(c);
            p.edit().putString(TRACE_ID,trace).putLong(STARTED,now).putLong(LAST_AT,now).putLong(SOURCE,currentVersion(c)).apply();
        }
        long started=p.getLong(STARTED,now);
        long priorAt=p.getLong(LAST_AT,started);
        long delta=Math.max(0L,now-priorAt);
        long elapsed=Math.max(0L,now-started);
        if("DOWNLOAD_ATTEMPT_FAILED".equals(st))p.edit().putInt(RETRIES,p.getInt(RETRIES,0)+1).apply();
        if("RECOVERY_CHECKPOINT_START".equals(st)) p.edit().putLong(CHECKPOINT_STARTED,now).commit();
        if("RECOVERY_CHECKPOINT_COMPLETE".equals(st)){
            long cpStart=p.getLong(CHECKPOINT_STARTED,now);
            p.edit().putBoolean(CHECKPOINT_USED,true).putLong(CHECKPOINT_DURATION,Math.max(0L,now-cpStart)).commit();
        }
        String stamp=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS Z",Locale.US).format(new Date(now));
        String line=stamp+" | "+st+" | +"+delta+"ms | t+"+elapsed+"ms"+(d.isEmpty()?"":" | "+d);
        String old=p.getString(TIMELINE,"");
        String next=(old.isEmpty()?line:old+"\n"+line);
        if(next.length()>MAX_TIMELINE_CHARS)next="[older update-pipeline events omitted]\n"+next.substring(next.length()-MAX_TIMELINE_CHARS);
        SharedPreferences.Editor eventEdit=p.edit().putString(STAGE,st).putString(TIMELINE,next).putLong(LAST_AT,now);
        boolean critical="RECOVERY_CHECKPOINT_COMPLETE".equals(st)||"ANDROID_INSTALLER_HANDOFF_START".equals(st)||"ANDROID_INSTALLER_PRESENTED".equals(st);
        if(critical) eventEdit.commit(); else eventEdit.apply();
        DeveloperFlightRecorder.record(c,p,-1L,"UPDATE_PIPELINE",st,d+" deltaMs="+delta+" elapsedMs="+elapsed,"github-native-update","","update-bridge",false,false,false);
        try{
            String auditDetail="stage="+st+" updateId="+safe(p.getString(UPDATE_ID,""),96)+" source="+p.getLong(SOURCE,-1L)+" target="+p.getLong(TARGET,-1L)
                    +" packageSha256="+safe(p.getString("github_update_package_sha256",""),80)+" installPolicy=REQUIRED_CORE_CHANNEL authorization=OWNER_STANDING_CORE_POLICY"
                    +" checkpoint="+p.getBoolean(CHECKPOINT_USED,false)+(d.isEmpty()?"":" detail="+d);
            LumiMemoryVault.get(c).ledger("update-lifecycle",st,auditDetail,trace);
        }catch(Throwable ignored){}
    }

    static synchronized void fail(Context c,SharedPreferences p,String stage,Throwable t){
        String message=t==null?"unknown":t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage());
        fail(c,p,stage,message);
    }

    static synchronized void fail(Context c,SharedPreferences p,String stage,String message){
        if(p==null)return;
        String d=safe(SecretStore.redact(message==null?"":message),900);
        p.edit().putString(LAST_ERROR,d).apply();
        mark(c,p,stage==null||stage.isEmpty()?"FAILED":stage,d);
    }

    static synchronized void complete(Context c,SharedPreferences p,String result){
        if(c==null||p==null)return;
        long now=System.currentTimeMillis();
        long duration=Math.max(0L,now-p.getLong(STARTED,now));
        int retries=p.getInt(RETRIES,0);
        boolean checkpoint=p.getBoolean(CHECKPOINT_USED,false);
        long checkpointMs=p.getLong(CHECKPOINT_DURATION,-1L);
        String enriched=safe(result,760)+" totalMs="+duration+" retries="+retries+" checkpoint="+checkpoint+(checkpointMs>=0?" checkpointMs="+checkpointMs:"");
        mark(c,p,"POST_INSTALL_COMPLETE",enriched);
        now=System.currentTimeMillis();
        p.edit().putString(LAST_COMPLETED_TRACE,p.getString(TRACE_ID,""))
                .putString(LAST_COMPLETED_TIMELINE,p.getString(TIMELINE,""))
                .putLong(LAST_COMPLETED_AT,now)
                .putLong(LAST_COMPLETED_SOURCE,p.getLong(SOURCE,-1L))
                .putLong(LAST_COMPLETED_TARGET,p.getLong(TARGET,-1L))
                .putLong(LAST_COMPLETED_DURATION,duration)
                .putInt(LAST_COMPLETED_RETRIES,retries)
                .putBoolean(LAST_COMPLETED_CHECKPOINT,checkpoint)
                .putLong(LAST_COMPLETED_CHECKPOINT_DURATION,checkpointMs)
                .putString(LAST_COMPLETED_RESULT,enriched)
                .putString(STAGE,"COMPLETE").putLong(LAST_AT,now).remove(LAST_ERROR)
                .remove("self_update_install_requested_at").remove("self_update_install_requested_target").apply();
    }

    static String report(Context c,SharedPreferences p){
        if(p==null)return "Update bridge telemetry unavailable.";
        StringBuilder s=new StringBuilder();
        s.append("Instrumentation: Code400 R117 cleanup/avatar baseline; Code399 drives the first ciphertext-snapshot checkpoint proof flight into baseline 400\n");
        s.append("Current trace: ").append(p.getString(TRACE_ID,"none"))
                .append(" • stage=").append(p.getString(STAGE,"not-started"))
                .append(" • source=").append(p.getLong(SOURCE,-1L))
                .append(" • target=").append(p.getLong(TARGET,-1L))
                .append(" • retries=").append(p.getInt(RETRIES,0))
                .append(" • checkpoint=").append(p.getBoolean(CHECKPOINT_USED,false))
                .append(" • checkpointMs=").append(p.getLong(CHECKPOINT_DURATION,-1L)).append("\n");
        long started=p.getLong(STARTED,0L),last=p.getLong(LAST_AT,0L);
        if(started>0L)s.append("Current trace elapsed: ").append(Math.max(0L,(last>0L?last:System.currentTimeMillis())-started)).append(" ms\n");
        String err=p.getString(LAST_ERROR,""); if(!err.isEmpty())s.append("Current trace error: ").append(err).append("\n");
        String active=p.getString(TIMELINE,""); if(!active.isEmpty())s.append("\nCURRENT TRACE TIMELINE\n").append(active).append("\n");
        String prior=p.getString(LAST_COMPLETED_TIMELINE,"");
        if(!prior.isEmpty()){
            s.append("\nLAST COMPLETED UPDATE\nTrace: ").append(p.getString(LAST_COMPLETED_TRACE,""))
                    .append(" • source=").append(p.getLong(LAST_COMPLETED_SOURCE,-1L))
                    .append(" • target=").append(p.getLong(LAST_COMPLETED_TARGET,-1L))
                    .append(" • durationMs=").append(p.getLong(LAST_COMPLETED_DURATION,-1L))
                    .append(" • retries=").append(p.getInt(LAST_COMPLETED_RETRIES,0))
                    .append(" • checkpoint=").append(p.getBoolean(LAST_COMPLETED_CHECKPOINT,false))
                    .append(" • checkpointMs=").append(p.getLong(LAST_COMPLETED_CHECKPOINT_DURATION,-1L))
                    .append(" • completed=").append(new Date(p.getLong(LAST_COMPLETED_AT,0L))).append("\n")
                    .append("Result: ").append(p.getString(LAST_COMPLETED_RESULT,"")).append("\n")
                    .append(prior).append("\n");
        }
        return SecretStore.redact(s.toString().trim());
    }

    private static boolean terminal(String s){String x=safe(s,120).toUpperCase(Locale.US);return x.equals("COMPLETE")||x.equals("UP_TO_DATE")||x.equals("NO_PUBLISHED_UPDATE")||x.endsWith("_FAILED")||x.equals("FAILED");}
    private static long currentVersion(Context c){try{android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0);return android.os.Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode;}catch(Throwable t){return -1L;}}
    private static String safe(String s,int max){String x=s==null?"":s.replace('\n',' ').replace('\r',' ').trim();if(x.length()>max)x=x.substring(0,max);return x;}
}
