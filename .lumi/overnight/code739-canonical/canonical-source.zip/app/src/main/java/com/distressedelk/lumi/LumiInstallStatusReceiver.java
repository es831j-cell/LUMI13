package com.distressedelk.lumi;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

/** Code407 self-install bridge. Android PackageInstaller remains the security boundary. */
public final class LumiInstallStatusReceiver extends BroadcastReceiver {
    private static final String ACTION_STATUS="com.distressedelk.lumi.CODE407_INSTALL_STATUS";
    private static final String CHANNEL="lumi_maintenance";
    private static final int NOTIFY_ID=40701;

    static void commitPendingSelfUpdate(Context context,SharedPreferences prefs,boolean overnight) throws Exception {
        File apk=LumiUpdateManager.pendingCoreApkFile(prefs);if(apk==null||!apk.isFile()||apk.length()<=0L)throw new java.io.FileNotFoundException("Verified staged Lumi APK is missing");
        long target=prefs.getLong("pending_core_version_code",prefs.getLong("github_update_available_version",-1L));if(target<=0L)throw new IllegalStateException("Pending Lumi target version is unknown");
        PackageInstaller installer=context.getPackageManager().getPackageInstaller();PackageInstaller.SessionParams sp=new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);sp.setAppPackageName(context.getPackageName());sp.setSize(apk.length());if(Build.VERSION.SDK_INT>=31)sp.setRequireUserAction(overnight?PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED:PackageInstaller.SessionParams.USER_ACTION_REQUIRED);
        int sessionId=installer.createSession(sp);boolean committed=false;
        try(PackageInstaller.Session session=installer.openSession(sessionId);InputStream in=new java.io.BufferedInputStream(new java.io.FileInputStream(apk));OutputStream out=session.openWrite("base.apk",0,apk.length())){
            byte[] buffer=new byte[1024*1024];int n;while((n=in.read(buffer))>0)out.write(buffer,0,n);session.fsync(out);
            Intent callback=new Intent(context,LumiInstallStatusReceiver.class).setAction(ACTION_STATUS).putExtra("target_version",target).putExtra("overnight",overnight).putExtra("session_id",sessionId);
            int flags=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;PendingIntent pi=PendingIntent.getBroadcast(context,sessionId,callback,flags);
            prefs.edit().putInt("code407_installer_session_id",sessionId).putLong("code407_installer_target_version",target).putLong("code407_installer_commit_at",System.currentTimeMillis()).putBoolean("code407_installer_overnight",overnight).putBoolean("code407_installer_user_action_pending",false).putString("code407_installer_state","COMMITTING").apply();
            DeviceHealthEngine.notePostInstallPending(context,prefs,target);record(context,prefs,"PACKAGE_INSTALLER_COMMIT","session="+sessionId+" target="+target+" overnight="+overnight+" requestUserAction=NOT_REQUIRED_WHEN_ANDROID_PERMITS");session.commit(pi.getIntentSender());committed=true;
        }finally{if(!committed)try{installer.abandonSession(sessionId);}catch(Throwable ignored){}}
    }

    @Override public void onReceive(Context context,Intent intent){
        if(context==null||intent==null||!ACTION_STATUS.equals(intent.getAction()))return;SharedPreferences p=context.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        int status=intent.getIntExtra(PackageInstaller.EXTRA_STATUS,PackageInstaller.STATUS_FAILURE);String message=intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);int session=intent.getIntExtra("session_id",p.getInt("code407_installer_session_id",-1));long target=intent.getLongExtra("target_version",p.getLong("code407_installer_target_version",-1L));boolean overnight=intent.getBooleanExtra("overnight",p.getBoolean("code407_installer_overnight",false));
        if(status==PackageInstaller.STATUS_PENDING_USER_ACTION){
            Intent confirm=null;if(Build.VERSION.SDK_INT>=33)confirm=intent.getParcelableExtra(Intent.EXTRA_INTENT,Intent.class);else try{confirm=(Intent)intent.getParcelableExtra(Intent.EXTRA_INTENT);}catch(Throwable ignored){}
            final long now=System.currentTimeMillis();
            final Intent approval=confirm;
            p.edit().putBoolean("self_update_install_flow_active",false)
                    .putBoolean("self_update_installer_waiting",false)
                    .putString("code407_installer_state","ANDROID_APPROVAL_REQUIRED_CODE722")
                    .putBoolean("code407_installer_user_action_pending",true)
                    .putBoolean("code722_confirmation_intent_present",approval!=null)
                    .putBoolean("code722_confirmation_launch_attempted",false)
                    .putBoolean("code722_confirmation_launch_succeeded",false)
                    .remove("code722_confirmation_launch_error")
                    .putLong("code722_pending_user_action_at",now)
                    .putString("code407_installer_status_message",safe(message))
                    .putBoolean("code407_overnight_update_in_progress",false)
                    .putBoolean("code407_maintenance_report_pending",true)
                    .putString("pending_core_install_state","ANDROID_INSTALL_APPROVAL_REQUIRED_CODE722")
                    .putString("code407_last_maintenance_result","Android requested approval for Lumi code "+target+"; Lumi is surfacing the confirmation now.").commit();
            record(context,p,"ANDROID_INSTALL_APPROVAL_REQUIRED_CODE722","session="+session+" target="+target+" confirmPresent="+(approval!=null)+" detail="+safe(message));
            if(approval==null){
                p.edit().putString("pending_core_install_state","ANDROID_APPROVAL_INTENT_MISSING_CODE722")
                        .putString("code407_installer_state","ANDROID_APPROVAL_INTENT_MISSING_CODE722").apply();
                record(context,p,"ANDROID_APPROVAL_INTENT_MISSING_CODE722","session="+session+" target="+target);
                return;
            }

            final MainActivity active=MainActivity.activeMaintenanceInstance;
            if(active!=null && !active.isFinishing() && !(Build.VERSION.SDK_INT>=17 && active.isDestroyed())){
                active.runOnUiThread(()->{
                    try{
                        p.edit().putBoolean("code722_confirmation_launch_attempted",true).putLong("code722_confirmation_launch_at",System.currentTimeMillis()).apply();
                        active.startActivity(approval);
                        p.edit().putBoolean("code722_confirmation_launch_succeeded",true)
                                .putString("code407_installer_state","ANDROID_APPROVAL_UI_LAUNCHED_CODE722")
                                .putString("pending_core_install_state","ANDROID_APPROVAL_UI_LAUNCHED_CODE722").apply();
                        record(context,p,"ANDROID_APPROVAL_UI_LAUNCHED_CODE722","session="+session+" target="+target+" route=ACTIVE_ACTIVITY");
                    }catch(Throwable launchError){
                        p.edit().putBoolean("code722_confirmation_launch_succeeded",false)
                                .putString("code722_confirmation_launch_error",launchError.getClass().getSimpleName()+": "+safe(launchError.getMessage()))
                                .putString("pending_core_install_state","ANDROID_APPROVAL_UI_LAUNCH_FAILED_CODE722").apply();
                        record(context,p,"ANDROID_APPROVAL_UI_LAUNCH_FAILED_CODE722","session="+session+" target="+target+" route=ACTIVE_ACTIVITY error="+launchError.getClass().getSimpleName());
                        postApprovalNotification(context,p,approval,target);
                    }
                });
                return;
            }

            try{
                approval.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                p.edit().putBoolean("code722_confirmation_launch_attempted",true).putLong("code722_confirmation_launch_at",System.currentTimeMillis()).apply();
                context.startActivity(approval);
                p.edit().putBoolean("code722_confirmation_launch_succeeded",true)
                        .putString("code407_installer_state","ANDROID_APPROVAL_UI_LAUNCHED_CODE722")
                        .putString("pending_core_install_state","ANDROID_APPROVAL_UI_LAUNCHED_CODE722").apply();
                record(context,p,"ANDROID_APPROVAL_UI_LAUNCHED_CODE722","session="+session+" target="+target+" route=APPLICATION_CONTEXT");
            }catch(Throwable launchError){
                p.edit().putBoolean("code722_confirmation_launch_succeeded",false)
                        .putString("code722_confirmation_launch_error",launchError.getClass().getSimpleName()+": "+safe(launchError.getMessage()))
                        .putString("pending_core_install_state","ANDROID_APPROVAL_UI_LAUNCH_FAILED_CODE722").apply();
                record(context,p,"ANDROID_APPROVAL_UI_LAUNCH_FAILED_CODE722","session="+session+" target="+target+" route=APPLICATION_CONTEXT error="+launchError.getClass().getSimpleName());
                postApprovalNotification(context,p,approval,target);
            }
            return;
        }
        if(status==PackageInstaller.STATUS_SUCCESS){p.edit().putString("code407_installer_state","ANDROID_INSTALL_SUCCESS").putBoolean("code407_installer_user_action_pending",false).putBoolean("self_update_install_flow_active",false).putLong("code407_installer_success_at",System.currentTimeMillis()).putBoolean("code407_maintenance_report_pending",true).putString("code407_last_maintenance_result","Android installed Lumi code "+target+"; post-install validation is running.").apply();cancelApprovalNotification(context);record(context,p,"ANDROID_INSTALL_SUCCESS","session="+session+" target="+target+" overnight="+overnight);return;}
        p.edit().putString("code407_installer_state","ANDROID_INSTALL_FAILED").putBoolean("code407_installer_user_action_pending",false).putBoolean("self_update_install_flow_active",false).putBoolean("code407_overnight_update_in_progress",false).putString("code407_installer_status_message",safe(message)).putBoolean("code407_maintenance_report_pending",true).putString("code407_last_maintenance_result","Lumi update installation failed safely: "+safe(message)).apply();cancelApprovalNotification(context);record(context,p,"ANDROID_INSTALL_FAILED","session="+session+" target="+target+" status="+status+" message="+safe(message));if(p.getBoolean("code407_overnight_updates_enabled",false))AutonomousMaintenanceJobService.scheduleNext(context,p,"installer-failure");
    }

    static void maybeNotifyPendingApproval(Context c,SharedPreferences p){if(c==null||p==null||!p.getBoolean("code407_installer_user_action_pending",false))return;record(c,p,"ANDROID_APPROVAL_STILL_PENDING","target="+p.getLong("code407_installer_target_version",-1L));}
    private static void postApprovalNotification(Context c,SharedPreferences p,Intent confirm,long target){try{NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"Lumi maintenance",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Approved Lumi updates and Android install confirmations");nm.createNotificationChannel(ch);}int flags=PendingIntent.FLAG_UPDATE_CURRENT;if(Build.VERSION.SDK_INT>=23)flags|=PendingIntent.FLAG_IMMUTABLE;PendingIntent approve=PendingIntent.getActivity(c,NOTIFY_ID,confirm,flags);NotificationCompat.Builder b=new NotificationCompat.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download_done).setContentTitle("Lumi update needs approval").setContentText("Android requires confirmation to install Lumi code "+target+".").setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(approve);nm.notify(NOTIFY_ID,b.build());}catch(Throwable t){p.edit().putString("code407_installer_notification_error",t.getClass().getSimpleName()+": "+safe(t.getMessage())).apply();}}
    private static void cancelApprovalNotification(Context c){try{NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.cancel(NOTIFY_ID);}catch(Throwable ignored){}}
    private static void record(Context c,SharedPreferences p,String a,String d){try{DeveloperFlightRecorder.record(c,p,-1L,"UPDATE_PIPELINE",a,d,"github-native-update","","code407-installer",false,false,false);}catch(Throwable ignored){}}
    private static String safe(String s){return s==null?"":s.replace('\n',' ').replace('\r',' ').trim();}
}
