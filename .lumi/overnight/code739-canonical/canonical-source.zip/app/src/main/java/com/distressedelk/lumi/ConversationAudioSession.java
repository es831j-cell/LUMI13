package com.distressedelk.lumi;

final class ConversationAudioSession {
    private boolean active=false,suspended=false,focusHeld=false;
    private long started=0,lastRequest=0,lastChange=0;
    private int losses=0,reacquires=0,denials=0;
    private String lastReason="none",suspendReason="none";
    synchronized void start(long now){if(!active){active=true;suspended=false;started=now;}}
    synchronized void begin(long now){start(now);}
    synchronized void close(){active=false;suspended=false;focusHeld=false;suspendReason="none";}
    synchronized void end(){close();}
    synchronized boolean shouldHoldFocus(){return active&&!suspended;}
    synchronized boolean isActive(){return active;}
    synchronized void noteRequest(String reason,long now){lastRequest=now;lastReason=safe(reason);}
    synchronized void noteGranted(long now){if(active&&!focusHeld&&lastChange>0)reacquires++;focusHeld=true;suspended=false;lastChange=now;suspendReason="none";}
    synchronized void noteDenied(String reason,long now){denials++;focusHeld=false;lastReason=safe(reason);lastChange=now;}
    synchronized void noteLoss(int change,long now){losses++;focusHeld=false;lastChange=now;if(active){suspended=true;suspendReason="focus-"+change;}}
    synchronized void noteGain(long now){focusHeld=true;lastChange=now;if(active){suspended=false;suspendReason="none";reacquires++;}}
    synchronized String snapshot(long now){return "active="+active+" • suspended="+suspended+" • focusHeld="+focusHeld+" • ageMs="+(started>0?Math.max(0,now-started):0)+" • focusLosses="+losses+" • reacquires="+reacquires+" • denials="+denials+" • lastFocusReason="+lastReason+" • suspendReason="+suspendReason+" • requestAgeMs="+(lastRequest>0?Math.max(0,now-lastRequest):0);}
    private static String safe(String s){return s==null?"":s.replace('\n',' ').replace('\r',' ').trim();}
}
