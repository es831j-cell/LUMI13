package com.distressedelk.lumi;

import android.content.SharedPreferences;

/** Code661 sole product-turn intent, capability, outcome and final-reply authority. */
final class LumiCoreAuthority {
    static final int BASELINE=661;
    static final long CONTINUATION_WINDOW_MS=10L*60L*1000L;
    enum IntentKind { CONVERSATION, INFORMATION, ACTION, SELF }
    enum CoreState { IDLE, ACTIVE, ACTING, VERIFYING, ANSWERED, SATISFIED, BLOCKED, FAILED, PAUSED }
    private LumiCoreAuthority(){}

    // Code709: owner-granted full runtime authority. This does not bypass Android security.
    // OS permissions, biometrics, package signing and installer approval remain mandatory boundaries.
    static final String AUTHORITY_MODE="OWNER_GRANTED_FULL_RUNTIME";
    static final String AUTHORITY_CHAIN="OWNER>LUMI_CORE>DELEGATE>EVIDENCE>LUMI_CORE_COMMIT";
    static final String SECURITY_BOUNDARY="ANDROID_PERMISSION_BIOMETRIC_SIGNING_INSTALLER";

    static void applyOwnerGrantedRuntimeAuthority(SharedPreferences p){
        if(p==null)return;
        p.edit()
                .putString("lumi_core_authority_mode",AUTHORITY_MODE)
                .putString("lumi_core_authority_chain",AUTHORITY_CHAIN)
                .putString("lumi_core_security_boundary",SECURITY_BOUNDARY)
                .putBoolean("lumi_core_full_runtime_authority",true)
                .putString("lumi_command_authority","LUMI_CORE")
                .putString("lumi_owner_conversation","LUMI_CORE")
                .putString("lumi_owner_reasoning","LUMI_CORE")
                .putString("lumi_owner_memory","LUMI_CORE")
                .putString("lumi_owner_actions","LUMI_CORE")
                .putString("lumi_owner_health","LUMI_CORE")
                .putString("lumi_owner_maintenance","LUMI_CORE")
                .putString("lumi_owner_updates","LUMI_CORE")
                .putString("lumi_owner_black_box","LUMI_CORE")
                .putString("lumi_delegate_authority","ADVISORY_OR_BOUNDED_EXECUTOR_ONLY")
                .putLong("code709_authority_converged_at",System.currentTimeMillis()).apply();
    }

    static void noteDelegate(SharedPreferences p,String delegate,String role){
        if(p==null)return;
        applyOwnerGrantedRuntimeAuthority(p);
        p.edit().putString("lumi_core_active_delegate",safe(delegate))
                .putString("lumi_core_active_delegate_role",safe(role))
                .putString("product_turn_authority","LUMI_CORE")
                .putLong("lumi_core_delegate_noted_at",System.currentTimeMillis()).apply();
    }

    static void onUserTurn(SharedPreferences p,long turnId,String raw,String source){
        applyOwnerGrantedRuntimeAuthority(p);
        if(p==null)return;
        long now=System.currentTimeMillis();String q=raw==null?"":raw.trim();
        String priorKind=p.getString("lumi_core_goal_kind",IntentKind.CONVERSATION.name());
        String priorState=p.getString("lumi_core_goal_state",CoreState.IDLE.name());
        long priorAt=p.getLong("lumi_core_goal_last_at",0L);
        boolean priorAction=IntentKind.ACTION.name().equals(priorKind)||(IntentKind.SELF.name().equals(priorKind)&&p.getBoolean("lumi_core_self_action",false));
        boolean priorOpen=isOpen(priorState)&&now-priorAt<=CONTINUATION_WINDOW_MS;
        boolean statusContinuation=priorAction&&priorOpen&&LumiCoreIntentClassifier.isActionStatusQuery(q);

        // Compatibility helpers are delegates. Core snapshots continuity before they see the turn.
        LumiLivingSelf.onUserTurn(p,turnId,q);
        LumiSelfAuthority.onUserTurn(p,turnId,q);
        boolean selfReference=p.getBoolean("lumi_self_authority_self_reference",false);
        String selfIntent=p.getString("lumi_self_authority_intent","NONE");
        boolean generalAction=LumiCoreIntentClassifier.isActionRequest(q,priorAction,priorOpen);
        boolean selfAction=selfReference&&(generalAction||"SELF_REPAIR".equals(selfIntent)||"SELF_UPDATE".equals(selfIntent));
        IntentKind kind=IntentKind.valueOf(LumiCoreIntentClassifier.classify(q,selfReference,priorAction,priorOpen).name());
        boolean inheritedAction=(kind==IntentKind.ACTION||selfAction)&&priorAction&&priorOpen&&(LumiCoreIntentClassifier.isContinuation(q)||statusContinuation);
        String priorGoalText=p.getString("lumi_core_goal_text",q);
        String livingKind=(kind==IntentKind.ACTION||selfAction)?"ACTION":((kind==IntentKind.INFORMATION||kind==IntentKind.SELF)?"INFORMATION":"CONVERSATION");

        SharedPreferences.Editor e=p.edit().putLong("lumi_core_goal_id",turnId).putLong("lumi_core_active_turn_id",turnId)
                .putString("lumi_core_goal_kind",kind.name()).putString("lumi_core_goal_state",CoreState.ACTIVE.name())
                .putString("lumi_core_goal_text",inheritedAction?priorGoalText:q)
                .putString("lumi_core_last_user_input",q).putString("lumi_core_turn_source",safe(source))
                .putString("lumi_core_self_intent",selfIntent).putBoolean("lumi_core_self_action",selfAction)
                .putBoolean("lumi_core_action_inherited",inheritedAction).putBoolean("lumi_core_action_status_query",statusContinuation)
                .putLong("lumi_core_goal_last_at",now)
                .putString("lumi_goal_kind",livingKind).putString("lumi_goal_state","ACTIVE")
                .putString("lumi_core_capability_state",(kind==IntentKind.ACTION||selfAction)?(statusContinuation?"STATUS_CHECK":"CHECKING"):"NOT_REQUIRED")
                .putString("lumi_core_capability_executor","").putString("lumi_core_capability_detail","")
                .putBoolean("lumi_core_final_reply_committed",false).putBoolean("lumi_core_adviser_material_used",false);
        if((kind==IntentKind.ACTION||selfAction)&&!inheritedAction){
            e.putBoolean("lumi_goal_action_evidence",false).putBoolean("lumi_goal_outcome_verified",false)
             .putBoolean("lumi_core_action_evidence",false).putBoolean("lumi_core_outcome_verified",false)
             .putString("lumi_goal_last_evidence","");
        }
        e.apply();
    }

    static boolean isActionTurn(SharedPreferences p){return p!=null&&isAction(p);}
    static boolean isActionStatusTurn(SharedPreferences p){return p!=null&&p.getBoolean("lumi_core_action_status_query",false);}

    static void noteCapabilityMiss(SharedPreferences p,String executor,String detail){
        if(p==null||!isAction(p)||isActionStatusTurn(p))return;
        p.edit().putString("lumi_core_capability_state","LOCAL_NOT_HANDLED")
                .putString("lumi_core_capability_executor",safe(executor))
                .putString("lumi_core_capability_detail",safe(detail))
                .putLong("lumi_core_capability_checked_at",System.currentTimeMillis()).apply();
    }

    static void noteLocalAction(SharedPreferences p,String action,String detail,String reply){
        if(p==null)return;LumiLivingSelf.noteLocalAction(p,action,detail,reply);
        boolean acted=p.getBoolean("lumi_goal_action_evidence",false),verified=p.getBoolean("lumi_goal_outcome_verified",false);
        boolean localExecuted=action!=null&&!action.trim().isEmpty();
        SharedPreferences.Editor e=p.edit().putString("lumi_core_last_executor",safe(action)).putString("lumi_core_last_action_detail",safe(detail))
                .putBoolean("lumi_core_local_executor_ran",localExecuted)
                .putString("lumi_core_capability_state",(isAction(p)?acted:localExecuted)?"SUPPORTED_EXECUTED":"SUPPORTED_NOT_EXECUTED")
                .putString("lumi_core_capability_executor",safe(action)).putString("lumi_core_capability_detail",safe(detail))
                .putBoolean("lumi_core_action_evidence",acted).putBoolean("lumi_core_outcome_verified",verified).putLong("lumi_core_last_action_at",System.currentTimeMillis());
        if(isAction(p)){String s=verified?CoreState.SATISFIED.name():(acted?CoreState.VERIFYING.name():CoreState.BLOCKED.name());e.putString("lumi_core_goal_state",s).putString("lumi_goal_state",s);}e.apply();
    }

    static void noteVisualObservation(SharedPreferences p,String status,float mismatch,boolean changed){
        if(p==null)return;LumiLivingSelf.noteVisualObservation(p,status,mismatch,changed);
        boolean acted=p.getBoolean("lumi_goal_action_evidence",false),verified=p.getBoolean("lumi_goal_outcome_verified",false);
        SharedPreferences.Editor e=p.edit().putBoolean("lumi_core_action_evidence",acted).putBoolean("lumi_core_outcome_verified",verified)
                .putString("lumi_core_visual_status",safe(status)).putFloat("lumi_core_visual_mismatch",mismatch).putBoolean("lumi_core_visual_changed",changed)
                .putLong("lumi_core_visual_at",System.currentTimeMillis());
        if(isAction(p))e.putString("lumi_core_goal_state",verified?CoreState.SATISFIED.name():CoreState.VERIFYING.name()).putString("lumi_goal_state",verified?"SATISFIED":"VERIFYING");e.apply();
    }

    static String commitReply(SharedPreferences p,String route,String candidate){
        if(candidate==null)return null;if(p==null)return candidate;
        boolean adviser=LumiProviderAdviserContract.isAdviceEnvelope(candidate);
        String coreCandidate=adviser?LumiProviderAdviserContract.renderForLumiCore(candidate,p.getString("lumi_core_last_user_input","")):candidate;
        String out=LumiLivingSelf.guardReply(p,coreCandidate);out=LumiSelfAuthority.guardReply(p,route,out);
        if(isAction(p)){
            boolean acted=p.getBoolean("lumi_goal_action_evidence",false)||p.getBoolean("lumi_core_action_evidence",false);
            boolean verified=p.getBoolean("lumi_goal_outcome_verified",false)||p.getBoolean("lumi_core_outcome_verified",false);
            if(isActionStatusTurn(p)){
                out=verified?"Yes. I have outcome evidence that the requested action completed.":(acted?"I have evidence that I started the action, but I still don't have verified completion.":"No. I don't have execution evidence for that action yet.");
            }else if(!verified)out=acted?"I started the requested action, but I don't have verification that it completed yet. I'm keeping it open until I can verify the outcome.":"I understand the action you want, but I haven't executed it. I won't claim it's done until I have real action evidence.";
        }
        String adviceBody=adviser?LumiProviderAdviserContract.adviceBody(candidate):"";
        p.edit().putString("lumi_core_last_candidate_route",safe(route)).putString("lumi_core_last_candidate_reply",safe(coreCandidate))
                .putString("lumi_core_last_committed_reply",safe(out)).putBoolean("lumi_core_final_reply_committed",true)
                .putBoolean("lumi_core_adviser_material_used",adviser).putString("lumi_core_adviser_route",adviser?safe(route):"")
                .putInt("lumi_core_adviser_chars",adviser?adviceBody.length():0).putLong("lumi_core_adviser_at",adviser?System.currentTimeMillis():0L)
                .putString("product_turn_final_authority","LUMI_CORE")
                .putLong("lumi_core_last_commit_at",System.currentTimeMillis()).apply();String code730ProviderTrace=LumiEvidenceLedger.activeTrace(p,"PROVIDERS");LumiEvidenceLedger.appendTrace(p,"PROVIDERS","CORE_COMMIT","coreFinalDecision","true","LumiCoreAuthority",code730ProviderTrace);LumiEvidenceLedger.endTrace(p,"PROVIDERS",code730ProviderTrace);return out;
    }

    static void onTurnTerminal(SharedPreferences p,String terminal,String route,String why){
        if(p==null)return;String t=terminal==null?"":terminal,s;
        if("FAILED".equals(t)||"TIMEOUT".equals(t))s=CoreState.FAILED.name();
        else if("CANCELLED".equals(t))s=CoreState.PAUSED.name();
        else if(!"COMPLETE".equals(t))s=p.getString("lumi_core_goal_state",CoreState.ACTIVE.name());
        else if(isAction(p)){boolean acted=p.getBoolean("lumi_goal_action_evidence",false)||p.getBoolean("lumi_core_action_evidence",false);boolean verified=p.getBoolean("lumi_goal_outcome_verified",false)||p.getBoolean("lumi_core_outcome_verified",false);s=verified?CoreState.SATISFIED.name():(acted?CoreState.VERIFYING.name():CoreState.ACTIVE.name());}
        else s=CoreState.ANSWERED.name();
        p.edit().putString("lumi_core_goal_state",s).putString("lumi_goal_state",s).putString("lumi_core_last_terminal",safe(t))
                .putString("lumi_core_last_route",safe(route)).putString("lumi_core_last_terminal_reason",safe(why)).putLong("lumi_core_goal_last_at",System.currentTimeMillis()).apply();
    }

    static String summary(SharedPreferences p){return p==null?"unavailable":"kind="+p.getString("lumi_core_goal_kind","CONVERSATION")+" state="+p.getString("lumi_core_goal_state","IDLE")+" capability="+p.getString("lumi_core_capability_state","UNKNOWN")+" executor="+safe(p.getString("lumi_core_capability_executor",""))+" localExecution="+p.getBoolean("lumi_core_local_executor_ran",false)+" statusQuery="+p.getBoolean("lumi_core_action_status_query",false)+" actionEvidence="+(p.getBoolean("lumi_goal_action_evidence",false)||p.getBoolean("lumi_core_action_evidence",false))+" outcomeVerified="+(p.getBoolean("lumi_goal_outcome_verified",false)||p.getBoolean("lumi_core_outcome_verified",false))+" adviserUsed="+p.getBoolean("lumi_core_adviser_material_used",false)+" adviserRoute="+safe(p.getString("lumi_core_adviser_route",""))+" route="+safe(p.getString("lumi_core_last_route",""))+" finalAuthority="+safe(p.getString("product_turn_final_authority",""));}
    private static boolean isOpen(String s){return CoreState.ACTIVE.name().equals(s)||CoreState.ACTING.name().equals(s)||CoreState.VERIFYING.name().equals(s)||CoreState.BLOCKED.name().equals(s)||CoreState.FAILED.name().equals(s)||CoreState.PAUSED.name().equals(s);}
    private static boolean isAction(SharedPreferences p){IntentKind k=kind(p);return k==IntentKind.ACTION||(k==IntentKind.SELF&&p.getBoolean("lumi_core_self_action",false));}
    private static IntentKind kind(SharedPreferences p){try{return IntentKind.valueOf(p.getString("lumi_core_goal_kind",IntentKind.CONVERSATION.name()));}catch(Throwable ignored){return IntentKind.CONVERSATION;}}
    private static String safe(String s){return s==null?"":s;}
}
