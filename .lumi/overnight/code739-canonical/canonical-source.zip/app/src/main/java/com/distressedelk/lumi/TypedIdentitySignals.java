package com.distressedelk.lumi;

import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Code401 soft typed-identity evidence.
 * Stores aggregate style features only, never raw owner text. Style can recognize a likely
 * contact for conversational continuity, but it can never grant administrator authority.
 */
final class TypedIdentitySignals {
    private static final String PROFILE_KEY="typed_owner_style_profile_v1";
    private static final int MIN_SAMPLES=6;

    static JSONObject assess(SharedPreferences p,String text){
        JSONObject out=new JSONObject();
        try{
            double[] f=features(text);
            JSONObject prof=new JSONObject(p.getString(PROFILE_KEY,"{}"));
            int count=prof.optInt("count",0);
            out.put("sampleCount",count).put("eligible",count>=MIN_SAMPLES && useful(text));
            if(count<MIN_SAMPLES || !useful(text)) return out.put("score",0).put("reason",count<MIN_SAMPLES?"insufficient trusted owner style samples":"typed turn too short for style evidence");
            JSONArray means=prof.optJSONArray("means");
            if(means==null || means.length()!=f.length) return out.put("score",0).put("reason","profile shape unavailable");
            double[] scale={2.4,8.0,5.0,3.5,3.0,3.0,4.0,4.0,4.0,4.0};
            double dist=0;
            for(int i=0;i<f.length;i++) dist+=Math.min(3.0,Math.abs(f[i]-means.optDouble(i,0))/scale[i]);
            dist/=f.length;
            int score=(int)Math.round(Math.max(0,Math.min(100,100.0-dist*32.0)));
            out.put("score",score).put("reason","aggregate lexical/punctuation rhythm similarity; soft evidence only");
            return out;
        }catch(Exception e){ try{return out.put("score",0).put("reason","style assessment unavailable");}catch(Exception ignored){return out;} }
    }

    static void noteTrustedOwnerText(SharedPreferences p,String text){
        if(p==null || !useful(text)) return;
        try{
            double[] f=features(text);
            JSONObject prof=new JSONObject(p.getString(PROFILE_KEY,"{}"));
            int count=prof.optInt("count",0);
            JSONArray old=prof.optJSONArray("means");
            JSONArray means=new JSONArray();
            for(int i=0;i<f.length;i++){
                double prior=(old!=null && old.length()==f.length)?old.optDouble(i,f[i]):f[i];
                double next=count<=0?f[i]:prior+(f[i]-prior)/(count+1.0);
                means.put(next);
            }
            prof.put("format","LumiTypedOwnerStyle").put("formatVersion",1).put("count",count+1).put("means",means)
                    .put("updatedAt",System.currentTimeMillis()).put("rawTextStored",false).put("authority","SOFT_IDENTITY_ONLY");
            p.edit().putString(PROFILE_KEY,prof.toString()).putInt("typed_owner_style_sample_count",count+1).apply();
        }catch(Exception ignored){}
    }

    static String summary(SharedPreferences p){
        try{
            JSONObject prof=new JSONObject(p.getString(PROFILE_KEY,"{}"));
            return "profileSamples="+prof.optInt("count",0)+" • rawTextStored=false • authority=SOFT_IDENTITY_ONLY • lastScore="+p.getInt("typed_identity_last_score",0)+" • lastDecision="+p.getString("typed_identity_last_decision","not-tested");
        }catch(Exception e){ return "profile unavailable"; }
    }

    private static boolean useful(String text){ return text!=null && text.trim().length()>=18 && text.trim().split("\\s+").length>=4; }

    private static double[] features(String raw){
        String s=raw==null?"":raw.trim(); String l=s.toLowerCase(Locale.US);
        String[] words=l.isEmpty()?new String[0]:l.split("\\s+"); int wc=Math.max(1,words.length);
        int letters=0; for(String w:words) letters+=w.replaceAll("[^a-z]","").length();
        int punct=count(s,'.')+count(s,',')+count(s,'!')+count(s,'?');
        int questions=count(s,'?');
        int fillers=containsCount(l,new String[]{"um","uh","uhm","you know"});
        int okay=containsCount(l,new String[]{"okay","ok","so ","alright","right "});
        int first=containsCount(l,new String[]{" i ","i'm","i'll","i want","i think"," i"});
        int second=containsCount(l,new String[]{" you ","you're","you can","you know"," you"});
        int contractions=0; for(String w:words) if(w.contains("'") || w.matches(".*(im|dont|cant|wont|ive|ill|youre|thats)$")) contractions++;
        int clauses=count(s,',')+count(s,';')+count(s,':')+1;
        return new double[]{
                letters/(double)wc,
                wc,
                punct*100.0/Math.max(1,s.length()),
                contractions*100.0/wc,
                fillers*100.0/wc,
                okay*100.0/wc,
                first*100.0/wc,
                second*100.0/wc,
                questions*100.0/Math.max(1,clauses),
                clauses*100.0/wc
        };
    }
    private static int count(String s,char c){ int n=0; for(int i=0;i<s.length();i++) if(s.charAt(i)==c)n++; return n; }
    private static int containsCount(String s,String[] terms){ int n=0; for(String t:terms){ int p=0; while((p=s.indexOf(t,p))>=0){n++;p+=Math.max(1,t.length());} } return n; }
}
