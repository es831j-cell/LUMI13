package com.distressedelk.lumi;

import android.content.SharedPreferences;
import java.util.Locale;

/** Independent acceptance policy for Core repair outcomes. */
final class LumiIndependentAcceptanceGate {
    static final class Decision { final boolean accepted; final String reason; Decision(boolean a,String r){accepted=a;reason=r;} }
    private LumiIndependentAcceptanceGate(){}
    static Decision evaluate(SharedPreferences p,String planId,boolean observedPass,String evidence){
        if(p==null||planId==null||planId.trim().isEmpty()) return new Decision(false,"missing-plan");
        String active=p.getString("lumi_core_last_repair_plan_id","");
        String completed=p.getString("maintenance_runtime_repair_completed_id","");
        String state=p.getString("maintenance_runtime_repair_state","");
        long dispatched=p.getLong("lumi_intent_last_dispatch_at",0L);
        long completedAt=p.getLong("maintenance_runtime_repair_completed_at",0L);
        String ev=evidence==null?"":evidence.trim();
        String low=ev.toLowerCase(Locale.US);
        if(!planId.equals(active)) return new Decision(false,"plan-not-active");
        if(!planId.equals(completed)) return new Decision(false,"completion-not-correlated");
        if(!"APPLIED".equals(state)) return new Decision(false,"actuator-not-applied");
        if(dispatched<=0L||completedAt<dispatched) return new Decision(false,"completion-precedes-dispatch");
        if(!observedPass) return new Decision(false,"observer-reported-fail");
        if(ev.isEmpty()) return new Decision(false,"missing-observation-evidence");
        if(low.contains("static gate")||low.contains("build proof")||low.contains("compile pass")||low.contains("boot pass")||low.contains("contract pass")) return new Decision(false,"non-runtime-evidence-rejected");
        return new Decision(true,"correlated-post-action-runtime-evidence");
    }
}
