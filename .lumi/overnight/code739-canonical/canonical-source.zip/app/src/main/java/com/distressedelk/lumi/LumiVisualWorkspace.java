package com.distressedelk.lumi;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Locale;

/**
 * Code715 R425. Lumi Core owns this bounded runtime visual workspace.
 * Visual/button changes are data, not source-code mutations, so Lumi can repair them locally
 * without an APK build. Action IDs remain allow-listed and keep existing handlers.
 */
final class LumiVisualWorkspace {
    static final String CONTRACT="visual-workspace-r425";
    private static final String SCHEMA="visual_workspace_schema_json";
    private static final String BACKUP="visual_workspace_schema_backup_json";
    private static final String MODE="visual_workspace_mode";
    private static final String CLEAN="CLEAN_SLATE";
    private static final String LUMI="LUMI_AUTHORED";

    private LumiVisualWorkspace(){}

    static boolean enabled(SharedPreferences p){ return p!=null && p.getBoolean("visual_workspace_r425_enabled",true); }

    static void ensureBaseline(MainActivity a,SharedPreferences p){
        if(a==null||p==null||p.getBoolean("visual_workspace_r425_initialized",false))return;
        JSONObject clean=cleanSchema();
        p.edit().putBoolean("visual_workspace_r425_initialized",true)
                .putBoolean("visual_workspace_r425_enabled",true)
                .putString(MODE,CLEAN).putString(SCHEMA,clean.toString()).putString(BACKUP,clean.toString())
                .putBoolean("visual_workspace_owner_grant",true)
                .putString("visual_workspace_owner_scope","HOME_VISUALS_BUTTONS_RUNTIME_ONLY")
                .putBoolean("visual_workspace_rebuild_needed",true)
                .putBoolean("visual_workspace_rebuild_inflight",false)
                .putInt("visual_workspace_rebuild_attempts",0)
                .putString("visual_workspace_rebuild_state","CLEAN_SLATE_READY_FOR_LUMI")
                .putString("visual_core_renderer","visual-workspace-r425-none")
                .putString("visual_scene_id","none-clean-slate")
                .putString("visual_active_model","none-clean-slate")
                .putBoolean("visual_legacy_surface_mounted",false)
                .putLong("visual_workspace_owner_grant_at",System.currentTimeMillis()).apply();
        a.flightRecord("VISUAL","CODE715_CLEAN_SLATE","old Home visuals/buttons suppressed; Lumi runtime visual authority armed");
    }

    static JSONObject status(SharedPreferences p){
        JSONObject o=new JSONObject();
        try{o.put("ok",true).put("contract",CONTRACT).put("mode",p.getString(MODE,CLEAN))
                .put("ownerGrant",p.getBoolean("visual_workspace_owner_grant",false))
                .put("rebuildNeeded",p.getBoolean("visual_workspace_rebuild_needed",true))
                .put("inflight",p.getBoolean("visual_workspace_rebuild_inflight",false))
                .put("attempts",p.getInt("visual_workspace_rebuild_attempts",0))
                .put("state",p.getString("visual_workspace_rebuild_state","unknown"))
                .put("lastSource",p.getString("visual_workspace_last_source","none"))
                .put("legacySurfaceMounted",p.getBoolean("visual_legacy_surface_mounted",false))
                .put("schema",schema(p));}catch(Exception ignored){}
        return o;
    }

    static int backgroundColor(SharedPreferences p){ return color(schema(p),"background",0xFF0B0E10); }

    static void styleButton(Button b,SharedPreferences p){
        if(b==null)return; JSONObject s=schema(p);
        GradientDrawable g=new GradientDrawable();
        g.setColor(color(s,"buttonFill",0xFF151B18));
        g.setCornerRadius(dp(b,14));
        g.setStroke(Math.max(1,dp(b,1)),color(s,"buttonStroke",0xFF355E4A));
        b.setBackground(g); b.setTextColor(color(s,"buttonText",0xFFF2F5F3)); b.setPadding(dp(b,12),dp(b,9),dp(b,12),dp(b,9));
    }

    static void showHome(MainActivity a,SharedPreferences p){
        ensureBaseline(a,p); ensureOwnerVisualRecovery(a,p); detachLegacy(a,p);
        JSONObject s=schema(p);
        int bg=color(s,"background",0xFF0B0E10), text=color(s,"text",0xFFF2F5F3), muted=color(s,"muted",0xFF9AA7A0), accent=color(s,"accent",0xFF355E4A);
        FrameLayout stage=new FrameLayout(a); stage.setBackgroundColor(bg);
        ScrollView scroll=new ScrollView(a); scroll.setFillViewport(true);
        LinearLayout page=new LinearLayout(a); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(a,18),dp(a,28),dp(a,18),dp(a,28));
        scroll.addView(page,new ScrollView.LayoutParams(-1,-2)); stage.addView(scroll,new FrameLayout.LayoutParams(-1,-1));

        TextView title=label(a,s.optString("title","Lumi"),30,text,true); page.addView(title);
        TextView runtime=label(a,runtimeStatus(a),13,accent,false); runtime.setPadding(0,dp(a,4),0,dp(a,4)); page.addView(runtime);
        TextView repair=label(a,"Visual authority: Lumi Core • "+p.getString("visual_workspace_rebuild_state","CLEAN_SLATE_READY_FOR_LUMI"),12,muted,false); page.addView(repair);
        TextView sub=label(a,s.optString("subtitle","Visual workspace reset. Lumi is rebuilding this interface."),16,text,false); sub.setPadding(0,dp(a,12),0,dp(a,16)); page.addView(sub);

        String avatar=s.optString("avatarMode","none");
        if("static_reference".equals(avatar)){
            ImageView iv=new ImageView(a); iv.setImageResource(R.drawable.lumi_visual_owner_reference_r422); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(a,230)); ip.setMargins(0,0,0,dp(a,16)); page.addView(iv,ip);
            p.edit().putString("visual_core_renderer","visual-workspace-static-reference").putBoolean("visual_legacy_surface_mounted",false).apply();
        }else if("legacy_pbr".equals(avatar) && p.getBoolean("visual_workspace_owner_grant",false)){
            LumiAvatarSceneView av=new LumiAvatarSceneView(a); a.avatarSceneView=av;
            LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(a,320)); ip.setMargins(0,0,0,dp(a,16)); page.addView(av,ip); av.post(av::onResume);
            p.edit().putString("visual_core_renderer",LumiAvatarForge.RENDERER_ID).putBoolean("visual_legacy_surface_mounted",true).apply();
        }else{
            p.edit().putString("visual_core_renderer","visual-workspace-r425-none").putBoolean("visual_legacy_surface_mounted",false).apply();
        }

        JSONArray buttons=s.optJSONArray("buttons"); if(buttons==null)buttons=cleanSchema().optJSONArray("buttons");
        int cols=Math.max(1,Math.min(3,s.optInt("columns",2))), index=0;
        LinearLayout row=null;
        for(int i=0;i<buttons.length();i++){
            JSONObject spec=buttons.optJSONObject(i); if(spec==null)continue;
            String id=spec.optString("id",""); if(!allowed(id))continue;
            if(index%cols==0){ row=new LinearLayout(a); row.setOrientation(LinearLayout.HORIZONTAL); page.addView(row,new LinearLayout.LayoutParams(-1,-2)); }
            Button b=new Button(a); b.setAllCaps(false); b.setText(spec.optString("label",defaultLabel(id))); b.setTextSize(15); styleButton(b,p); b.setOnClickListener(v->dispatch(a,id));
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(a,62),1f); bp.setMargins(dp(a,4),dp(a,4),dp(a,4),dp(a,4)); row.addView(b,bp); index++;
        }
        a.setContentView(stage);
        if(p.getBoolean("visual_workspace_rebuild_needed",true) && !p.getBoolean("visual_workspace_rebuild_inflight",false)) a.conversationHandler.postDelayed(()->selfDesign(a,p),700L);
    }

    static JSONObject apply(MainActivity a,SharedPreferences p,JSONObject raw,String source)throws Exception{
        if(a==null||p==null)throw new IllegalArgumentException("active MainActivity required");
        if(!p.getBoolean("visual_workspace_owner_grant",false))throw new SecurityException("owner visual-workspace grant inactive");
        JSONObject n=normalize(raw); String prior=p.getString(SCHEMA,cleanSchema().toString());
        p.edit().putString(BACKUP,prior).putString(SCHEMA,n.toString()).putString(MODE,LUMI)
                .putBoolean("visual_workspace_rebuild_needed",false).putBoolean("visual_workspace_rebuild_inflight",false)
                .putString("visual_workspace_rebuild_state","LUMI_SELF_REPAIR_APPLIED")
                .putString("visual_workspace_last_source",safe(source)).putLong("visual_workspace_last_applied_at",System.currentTimeMillis())
                .remove("visual_workspace_last_error").apply();
        a.flightRecord("VISUAL","LUMI_WORKSPACE_COMMIT","source="+safe(source)); a.runOnUiThread(a::showHome); return status(p);
    }

    private static void selfDesign(MainActivity a,SharedPreferences p){
        if(a==null||a.isFinishing()||!p.getBoolean("visual_workspace_rebuild_needed",true))return;
        int attempt=p.getInt("visual_workspace_rebuild_attempts",0)+1;
        if(attempt>8){ p.edit().putBoolean("visual_workspace_rebuild_inflight",false).putString("visual_workspace_rebuild_state","LUMI_SELF_REPAIR_NEEDS_EVIDENCE").apply(); return; }
        p.edit().putBoolean("visual_workspace_rebuild_inflight",true).putInt("visual_workspace_rebuild_attempts",attempt).apply();
        if(!a.isFastModelReady()){
            p.edit().putBoolean("visual_workspace_rebuild_inflight",false).putString("visual_workspace_rebuild_state","FAST_BRAIN_RESOURCE_NOT_READY").apply();
            a.conversationHandler.postDelayed(()->showHome(a,p),5000L); return;
        }
        if(!LocalBrain.isLoaded()||!LocalBrain.isResponsive()){
            p.edit().putString("visual_workspace_rebuild_state","WARMING_LUMI_LOCAL_BRAIN").apply();
            LocalBrain.warmForRecovery(a.fastModelFile().getAbsolutePath(),MainActivity.FAST_BRAIN_CONTEXT_SIZE,a.localThreadBudget(),new LocalBrain.Callback(){
                @Override public void onReply(String text,double tps){ p.edit().putBoolean("visual_workspace_rebuild_inflight",false).apply(); a.runOnUiThread(()->selfDesign(a,p)); }
                @Override public void onError(String e){ retry(a,p,"LOCAL_BRAIN_WARM_RETRY",e); }
            }); return;
        }
        String prompt="Rebuild your own Home visual workspace from a clean slate. Return one JSON object only. You are Lumi Core choosing your presentation. Owner preference: muted forest greens, not bright neon; calm readable spacing; stable geometry; no rendering artifacts. The owner has explicitly restored Lumi's live pyramid. avatarMode must be legacy_pbr and must not be none or static_reference. Preserve essential action ids. Keys: background,text,muted,accent,buttonFill,buttonText,buttonStroke,columns,title,subtitle,avatarMode,buttons[{id,label}]. Allowed ids: chat,voice,keyboard,listen,stop_listening,diagnostics,modules,black_box,update_center,open_update_zip,admin_voice,transcript,more. Required: chat,keyboard,listen,stop_listening,diagnostics,black_box,update_center,more.";
        String system="You are Lumi Core rebuilding your own Android UI. Output valid compact JSON only, no markdown. Colors are #RRGGBB. columns is 1, 2, or 3.";
        final long designStartedAt=System.currentTimeMillis(); final int designAttempt=attempt;
        p.edit().putString("visual_workspace_rebuild_state","LUMI_DESIGNING_RUNTIME_SCHEMA").putLong("visual_workspace_design_started_at",designStartedAt).apply();
        a.conversationHandler.postDelayed(()->{
            if(a.isFinishing()||!p.getBoolean("visual_workspace_rebuild_inflight",false))return;
            if(p.getInt("visual_workspace_rebuild_attempts",0)!=designAttempt||p.getLong("visual_workspace_design_started_at",0L)!=designStartedAt)return;
            p.edit().putBoolean("visual_workspace_rebuild_inflight",false).putString("visual_workspace_rebuild_state","LUMI_LOCAL_GENERATION_STALE_RECOVERY")
                    .putString("visual_workspace_last_error","self-design callback exceeded 35s; resetting isolated Fast Brain worker").apply();
            a.flightRecord("VISUAL","CODE716_SELF_DESIGN_STALE_RECOVERY","attempt="+designAttempt+" generation="+LocalBrain.activeGenerationId()+" stage="+LocalBrain.workerStage());
            LocalBrain.cancelActiveGeneration("visual-workspace-stale-attempt-"+designAttempt);
            a.conversationHandler.postDelayed(()->showHome(a,p),1200L);
        },35000L);
        LocalBrain.askRaw(a.fastModelFile().getAbsolutePath(),MainActivity.FAST_BRAIN_CONTEXT_SIZE,a.localThreadBudget(),prompt,system,360,new LocalBrain.Callback(){
            @Override public void onReply(String raw,double tps){
                a.runOnUiThread(()->{ try{ apply(a,p,parse(raw),"LUMI_LOCAL_FAST_BRAIN"); p.edit().putFloat("visual_workspace_design_tps",(float)tps).apply(); }
                    catch(Throwable x){ retry(a,p,"LUMI_SCHEMA_REJECTED_RETRY",x.getClass().getSimpleName()+": "+x.getMessage()); }});
            }
            @Override public void onError(String e){ retry(a,p,"LUMI_LOCAL_DESIGN_RETRY",e); }
        });
    }

    private static void retry(MainActivity a,SharedPreferences p,String state,String error){
        p.edit().putBoolean("visual_workspace_rebuild_inflight",false).putString("visual_workspace_rebuild_state",state).putString("visual_workspace_last_error",safe(error)).apply();
        a.conversationHandler.postDelayed(()->showHome(a,p),5000L);
    }

    private static void ensureOwnerVisualRecovery(MainActivity a,SharedPreferences p){
        if(a==null||p==null||p.getInt("visual_workspace_recovery_version",0)>=737)return;
        JSONObject restored;
        try{restored=normalize(new JSONObject(p.getString(SCHEMA,cleanSchema().toString())));}catch(Throwable t){restored=cleanSchema();}
        try{restored.put("avatarMode","legacy_pbr"); restored.put("subtitle","Lumi visual online.");}catch(Throwable ignored){}
        p.edit().putInt("visual_workspace_recovery_version",737).putString(MODE,LUMI).putString(SCHEMA,restored.toString())
                .putBoolean("visual_workspace_rebuild_needed",false).putBoolean("visual_workspace_rebuild_inflight",false)
                .putBoolean("visual_workspace_pbr_owner_override",true).putString("visual_workspace_rebuild_state","OWNER_VISUAL_FINALIZED_CODE737")
                .putString("visual_workspace_last_source","OWNER_APPROVED_CODE736_VISUAL_FINALIZED").remove("visual_workspace_last_error").apply();
        a.flightRecord("VISUAL","CODE737_VISUAL_METADATA_CONVERGENCE","avatar=legacy_pbr ownerOverride=true");
    }

    private static JSONObject cleanSchema(){
        try{
            JSONArray b=new JSONArray(); String[][] d={{"chat","Chat"},{"keyboard","Keyboard"},{"listen","Listen"},{"stop_listening","Stop listening"},{"diagnostics","Diagnostics"},{"black_box","Export Black Box"},{"update_center","Update Center"},{"more","More"}};
            for(String[] x:d)b.put(new JSONObject().put("id",x[0]).put("label",x[1]));
            return new JSONObject().put("version",1).put("contract",CONTRACT).put("background","#0B0E10").put("text","#F2F5F3").put("muted","#9AA7A0").put("accent","#355E4A")
                    .put("buttonFill","#151B18").put("buttonText","#F2F5F3").put("buttonStroke","#355E4A").put("columns",2).put("title","Lumi")
                    .put("subtitle","Lumi visual online.").put("avatarMode","legacy_pbr").put("buttons",b);
        }catch(Exception e){return new JSONObject();}
    }

    private static JSONObject schema(SharedPreferences p){ try{return normalize(new JSONObject(p.getString(SCHEMA,cleanSchema().toString())));}catch(Throwable e){return cleanSchema();} }

    private static JSONObject normalize(JSONObject r)throws Exception{
        if(r==null)r=new JSONObject(); JSONObject o=new JSONObject().put("version",1).put("contract",CONTRACT);
        String[] keys={"background","text","muted","accent","buttonFill","buttonText","buttonStroke"}; String[] defs={"#0B0E10","#F2F5F3","#9AA7A0","#355E4A","#151B18","#F2F5F3","#355E4A"};
        for(int i=0;i<keys.length;i++)o.put(keys[i],validColor(r.optString(keys[i],defs[i]),defs[i]));
        int cols=r.optInt("columns",2); o.put("columns",cols<1||cols>3?2:cols).put("title",bound(r.optString("title","Lumi"),48)).put("subtitle",bound(r.optString("subtitle",""),180));
        String avatar=r.optString("avatarMode","legacy_pbr").toLowerCase(Locale.US); if(!avatar.equals("none")&&!avatar.equals("static_reference")&&!avatar.equals("legacy_pbr"))avatar="legacy_pbr"; o.put("avatarMode",avatar);
        JSONArray src=r.optJSONArray("buttons"); if(src==null)src=cleanSchema().getJSONArray("buttons"); JSONArray dst=new JSONArray(); HashSet<String> seen=new HashSet<>();
        for(int i=0;i<src.length()&&dst.length()<16;i++){ JSONObject x=src.optJSONObject(i); if(x==null)continue; String id=x.optString("id",""); if(!allowed(id)||!seen.add(id))continue; dst.put(new JSONObject().put("id",id).put("label",bound(x.optString("label",defaultLabel(id)),34))); }
        String[] req={"chat","keyboard","listen","stop_listening","diagnostics","black_box","update_center","more"}; for(String id:req)if(seen.add(id))dst.put(new JSONObject().put("id",id).put("label",defaultLabel(id))); o.put("buttons",dst); return o;
    }

    private static JSONObject parse(String raw)throws Exception{ String s=raw==null?"":raw.trim(); int a=s.indexOf('{'),z=s.lastIndexOf('}'); if(a<0||z<=a)throw new IllegalArgumentException("no JSON object"); return new JSONObject(s.substring(a,z+1)); }
    private static void detachLegacy(MainActivity a,SharedPreferences p){ a.avatarSceneView=null; a.avatarImage=null; p.edit().putBoolean("visual_legacy_surface_mounted",false).apply(); }
    private static String runtimeStatus(MainActivity a){ String brain=(LocalBrain.isLoaded()&&LocalBrain.isResponsive())?"Fast Brain ready":(a.isFastModelReady()?"Fast Brain resource ready":"Fast Brain unavailable"); return "FULL RUNTIME • Build "+a.installedVersionCode()+" • "+brain; }
    private static void dispatch(MainActivity a,String id){ a.flightRecord("UI","VISUAL_WORKSPACE_ACTION","id="+id); switch(id){
        case"chat":case"transcript":a.showTalk();break; case"voice":a.showVoiceCenter();break; case"keyboard":a.openTextEntryFromHome();break;
        case"listen":a.exitTextInputModeForVoice();a.userStartListening();a.showHome();break; case"stop_listening":a.userStopListening();a.showHome();break;
        case"diagnostics":a.showCommandCenter();break; case"modules":a.showSafeCoreModules();break; case"black_box":a.exportBlackBox();break;
        case"update_center":a.showUpdateCenter();break; case"open_update_zip":a.chooseLumiUpdatePackage();break; case"admin_voice":a.openAdministratorEnrollmentShortcut();break; case"more":a.showMore();break; }
    }
    private static boolean allowed(String id){return id!=null&&id.matches("chat|voice|keyboard|listen|stop_listening|diagnostics|modules|black_box|update_center|open_update_zip|admin_voice|transcript|more");}
    private static String defaultLabel(String id){ switch(id){case"chat":return"Chat";case"voice":return"Voice";case"keyboard":return"Keyboard";case"listen":return"Listen";case"stop_listening":return"Stop listening";case"diagnostics":return"Diagnostics";case"modules":return"Modules";case"black_box":return"Export Black Box";case"update_center":return"Update Center";case"open_update_zip":return"Open Update ZIP";case"admin_voice":return"Administrator Voice";case"transcript":return"Transcript";default:return"More";} }
    private static TextView label(MainActivity a,String s,int sp,int c,boolean bold){ TextView v=new TextView(a);v.setText(s);v.setTextSize(sp);v.setTextColor(c);if(bold)v.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);return v; }
    private static int color(JSONObject o,String k,int f){ try{return Color.parseColor(validColor(o.optString(k,""),String.format(Locale.US,"#%06X",f&0xFFFFFF)));}catch(Throwable t){return f;} }
    private static String validColor(String s,String f){String x=s==null?"":s.trim();return x.matches("#[0-9A-Fa-f]{6}")?x.toUpperCase(Locale.US):f;}
    private static int dp(View v,int n){return Math.round(n*v.getResources().getDisplayMetrics().density);} private static int dp(MainActivity a,int n){return Math.round(n*a.getResources().getDisplayMetrics().density);}
    private static String bound(String s,int n){if(s==null)return"";s=s.replace('\n',' ').replace('\r',' ').trim();return s.length()<=n?s:s.substring(0,n);} private static String safe(String s){return bound(s,300);}
}
