package com.distressedelk.lumi;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Code610: comprehensive diagnostic census + improvement-discovery gate.
 *
 * Important truth rule: seeing a finding is not a repair. Historical scars are not
 * current faults. Lumi may see many findings at once while the mutation lane remains
 * one bounded candidate at a time.
 */
public final class LumiWholeSelfAudit{
 private static final int MAX_FINDINGS=96;
 private static final int DOMAIN_COUNT=26;
 private static final long STALE_PROOF_MS=6L*60L*60L*1000L;
 private LumiWholeSelfAudit(){}

 static final class Finding{
  final String id,classification,area,severity,evidence,nextAction,verificationPlan;
  final int priority;
  Finding(String i,String c,String a,String s,int p,String e,String n,String v){id=i;classification=c;area=a;severity=s;priority=p;evidence=e;nextAction=n;verificationPlan=v;}
  JSONObject json(){
   JSONObject o=new JSONObject();
   try{o.put("id",id).put("classification",classification).put("authority","EVIDENCE_ONLY").put("area",area)
    .put("severity",severity).put("priority",priority).put("evidence",evidence)
    .put("nextAction",nextAction).put("verificationPlan",verificationPlan);}catch(Throwable ignored){}
   return o;
  }
 }

 private static volatile boolean RUNNING=false;

 public static void schedule(Context c,SharedPreferences p){
  if(c==null||p==null)return;
  synchronized(LumiWholeSelfAudit.class){
   if(RUNNING)return;
   RUNNING=true;
  }
  final Context app=c.getApplicationContext()==null?c:c.getApplicationContext();
  final long started=System.currentTimeMillis();
  p.edit().putString("whole_self_audit_status","RUNNING_CODE623")
   .putLong("whole_self_audit_scheduled_at",started).apply();
  new Thread(()->{
   try{run(app,p);}
   catch(Throwable t){
    p.edit().putString("whole_self_audit_status","FAILED_CODE623")
     .putString("whole_self_audit_error",String.valueOf(t)).putLong("whole_self_audit_failed_at",System.currentTimeMillis()).apply();
   }finally{
    synchronized(LumiWholeSelfAudit.class){RUNNING=false;}
   }
  },"LumiWholeSelfAudit").start();
 }

 private static void run(Context c,SharedPreferences p){
  code650SelfAuthorityAudit(p);
  long now=System.currentTimeMillis();
  if(!p.getBoolean("code614_conversation_baseline_initialized",false)){
   p.edit().putBoolean("code614_conversation_baseline_initialized",true)
    .putLong("code614_conversation_baseline_at",now)
    .putInt("code614_base_state_divergence",p.getInt("conversation_state_divergence",0))
    .putInt("code614_base_tts_watchdog",p.getInt("tts_watchdog_recoveries",0))
    .putInt("code614_base_recognizer_circuit",p.getInt("recognizer_restart_circuit_breaks",0))
    .putInt("code614_base_ready_deaf",p.getInt("ready_but_deaf_confirmed",0))
    .putInt("code614_base_runtime_stall",p.getInt("runtime_stall_recoveries",0))
    .putInt("code614_base_barge",p.getInt("spoken_barge_in_count",0))
    .putInt("code614_base_barge_tts_stop",p.getInt("spoken_barge_in_tts_stop_count",0))
    .putInt("code614_base_ai_preempt",p.getInt("code409_ai_preemptions",0))
    .putInt("code614_base_tts_replies",p.getInt("tts_reply_successes",0))
    .putInt("code614_base_recognizer_rebuilds",p.getInt("speech_recognizer_rebuilds",0)).apply();
  }
  if(!p.getBoolean("code610_repair_accounting_v2_initialized",false)){
   p.edit().putBoolean("code610_repair_accounting_v2_initialized",true)
    .putLong("code610_repair_accounting_v2_started_at",now)
    .putInt("maintenance_verified_repairs_v2",0).putInt("maintenance_repair_attempts_v2",0)
    .putInt("maintenance_changes_applied_v2",0).putInt("maintenance_rollbacks_v2",0)
    .putInt("maintenance_escalations_v2",0).putInt("maintenance_verified_improvements_v2",0).apply();
  }

  ArrayList<Finding> all=new ArrayList<>(); HashSet<String> ids=new HashSet<>();
  ArrayList<String> lumiCoreSelf=new ArrayList<>();
  LumiCodex.audit(p,lumiCoreSelf); LumiLivingSelf.audit(p,lumiCoreSelf);
  for(String x:lumiCoreSelf){
   if(x==null||x.trim().isEmpty())continue;
   boolean s1=x.startsWith("S1");
   add(all,ids,"LUMI_CORE_SELF_"+Integer.toHexString(x.hashCode()),
    s1?"OBSERVED_FAULT_EVIDENCE":"VERIFICATION_GAP","core.self",s1?"S1":"S2",s1?97:84,
    x,"revise the active goal/plan from evidence; do not substitute prose for action",
    "goal state advances only after evidence, an exact blocker, or required owner input");
  }
  visual(p,all,ids); speech(p,all,ids); conversation(p,all,ids); reasoning(p,all,ids);
  identity(p,all,ids); memory(p,all,ids); behavior(p,all,ids); capabilities(p,all,ids);
  performance(c,p,all,ids); update(p,all,ids); diagnostics(p,all,ids); audio(p,all,ids);
  permissions(p,all,ids); integrations(p,all,ids); privacySecurity(p,all,ids); sensors(p,all,ids);
  maintenance(p,all,ids,now); consistency(p,all,ids); degradation(p,all,ids);
  verification(p,all,ids,now); repairTruth(p,all,ids); dataHygiene(p,all,ids);
  resourceEfficiency(p,all,ids); userExperience(p,all,ids); selfImprovement(p,all,ids); trendSignals(p,all,ids);

  JSONArray json=new JSONArray();
  int faults=0,cleanup=0,gaps=0,improvements=0,historical=0,high=0;
  Set<String> improveDomains=new HashSet<>();
  StringBuilder fq=new StringBuilder(),cq=new StringBuilder(),vq=new StringBuilder(),iq=new StringBuilder(),hq=new StringBuilder();
  for(Finding x:all){
   json.put(x.json()); if(x.priority>=85)high++;
   if("OBSERVED_FAULT_EVIDENCE".equals(x.classification)){faults++;append(fq,x);}
   else if("CLEANUP".equals(x.classification)){cleanup++;append(cq,x);}
   else if("VERIFICATION_GAP".equals(x.classification)){gaps++;append(vq,x);}
   else if("IMPROVEMENT".equals(x.classification)){improvements++;improveDomains.add(x.area);append(iq,x);}
   else {historical++;append(hq,x);}
  }
  boolean discoveryEvidenceVerified=p.getBoolean("self_improvement_discovery_evidence_verified",false);
  boolean discoveryFailureProbe=p.getBoolean("code642_discovery_failure_probe",false);
  String gate=discoveryTruth(discoveryEvidenceVerified,discoveryFailureProbe);

  p.edit().putString("whole_self_audit_status","COMPLETE_CODE623")
   .putLong("whole_self_audit_at",now).putInt("whole_self_audit_domain_count",DOMAIN_COUNT)
   .putString("whole_self_audit_domains","visuals,speech,conversation,reasoning,identity,memory,behavior,capabilities,performance,update,diagnostics,audio,permissions,integrations,privacy-security,sensors,maintenance,consistency,degradation,verification,repair-truth,data-hygiene,resource-efficiency,user-experience,self-improvement,trend-signals")
   .putInt("whole_self_current_fault_count_v2",faults).putInt("whole_self_cleanup_count_v2",cleanup)
   .putInt("whole_self_verification_gap_count_v2",gaps).putInt("whole_self_improvement_count_v2",improvements)
   .putInt("whole_self_historical_signal_count_v2",historical).putInt("whole_self_high_priority_count_v2",high)
   .putString("whole_self_fault_queue_v2",fq.toString()).putString("whole_self_cleanup_queue_v2",cq.toString())
   .putString("whole_self_verification_queue_v2",vq.toString()).putString("whole_self_improvement_queue_v2",iq.toString())
   .putString("whole_self_historical_queue_v2",hq.toString()).putString("whole_self_candidates_v2_json",json.toString())
   .putString("self_improvement_discovery_gate",gate).putInt("self_improvement_discovery_domains",improveDomains.size())
   .putInt("whole_self_audit_findings",all.size()).putString("whole_self_audit_queue",combined(all)).apply();

  p.edit().putString("whole_self_audit_authority","EVIDENCE_ONLY").apply();
  for(Finding x:all)LumiEvidenceLedger.append(p,x.area.toUpperCase(Locale.US),"AUDIT_OBSERVATION",x.id,x.classification+": "+x.evidence,"LumiWholeSelfAudit");
 }

 static String discoveryTruth(boolean evidenceVerified,boolean forcedFailure){
  if(forcedFailure)return "FAILED";
  return evidenceVerified?"VERIFIED":"UNVERIFIED";
 }

 private static void code650SelfAuthorityAudit(SharedPreferences p){
  ArrayList<String> f=new ArrayList<>();LumiLivingSelf.audit(p,f);LumiSelfAuthority.audit(p,f);
  StringBuilder b=new StringBuilder();
  for(String x:f){if(x==null||x.trim().isEmpty())continue;if(b.length()>0)b.append(" || ");b.append(x.trim());}
  p.edit().putInt("code650_whole_self_authority_findings",f.size())
   .putString("code650_whole_self_authority_summary",b.toString())
   .putLong("code650_whole_self_authority_audit_at",System.currentTimeMillis()).apply();
 }

 private static void visual(SharedPreferences p,List<Finding>a,Set<String>ids){
  String st=p.getString("visual_self_check_status","NOT_RUN"); float mm=p.getFloat("visual_self_check_mismatch_pct",-1f);
  if("MISMATCH_DETECTED".equals(st)) add(a,ids,"VISUAL_PIXEL_MISMATCH","OBSERVED_FAULT_EVIDENCE","visuals","S1",99,
   "pixel self-check mismatch="+(mm>=0?String.valueOf(mm):"unknown")+"% reference="+p.getString("visual_self_check_reference","none"),
   "localize geometry/material/camera differences from measured deltas; build one bounded candidate at a time",
   "rerender installed phone against the frozen owner-approved reference and retain only a lower mismatch score");
  else if("CAPTURE_FAILED".equals(st)) add(a,ids,"VISUAL_SELF_CAPTURE_FAILED","OBSERVED_FAULT_EVIDENCE","visuals","S1",94,"visual self-capture failed step="+p.getString("visual_self_check_step","unknown"),"repair capture/comparison path before visual tuning","fresh on-phone capture completes and produces a comparison score");
  else if("NOT_RUN".equals(st)) add(a,ids,"VISUAL_SELF_CHECK_NOT_RUN","VERIFICATION_GAP","visuals","S2",82,"no current visual self-check result","run pixel comparison against frozen approved reference","persist current capture/reference/score without source mutation");
  if(mm>=0f && p.getLong("visual_self_check_at",0L)>0L) add(a,ids,"VISUAL_AUTOCALIBRATION_HEADROOM","IMPROVEMENT","visuals","S3",72,"visual comparator is available with status="+st,"use measured deltas to propose smaller deterministic visual candidates instead of guessing","each candidate must improve the installed-phone score before retention");
 }

 private static void speech(SharedPreferences p,List<Finding>a,Set<String>ids){
  String runtime=p.getString("conversation_runtime_state","IDLE");
  String phase=p.getString("code612_recognizer_phase","UNKNOWN");
  long phaseAt=p.getLong("code612_recognizer_phase_at",0L), age=phaseAt<=0L?Long.MAX_VALUE:Math.max(0L,System.currentTimeMillis()-phaseAt);
  boolean circuitOpen=p.getBoolean("recognizer_recovery_circuit_open",false);
  int circuitDelta=Math.max(0,p.getInt("recognizer_restart_circuit_breaks",0)-p.getInt("code614_base_recognizer_circuit",0));
  int rebuildNow=p.getInt("speech_recognizer_rebuilds",0), rebuildDelta=Math.max(0,rebuildNow-p.getInt("code614_base_recognizer_rebuilds",rebuildNow));
  if(circuitOpen || circuitDelta>0) add(a,ids,"SPEECH_RECOVERY_CIRCUIT_OPEN","OBSERVED_FAULT_EVIDENCE","speech","S1",98,"current Code614 recovery circuit open/delta="+circuitDelta,"rebuild/rearm through bounded speech authority and trace the triggering callback","circuit closes and no new circuit break occurs across acceptance");
  else if("LISTENING".equals(runtime) && ("RECOVERY_PAUSED".equals(phase) || ("STARTING".equals(phase)&&age>5000L)))
   add(a,ids,"SPEECH_RECOGNIZER_NOT_READY","OBSERVED_FAULT_EVIDENCE","speech","S1",96,"conversation expects LISTENING but recognizer phase="+phase+" ageMs="+age,"rearm the recognizer through the existing bounded authority; do not infer a fault while Lumi is intentionally idle","phase reaches READY and remains stable through repeated turns");
  else if("LISTENING".equals(runtime) && "UNKNOWN".equals(phase)) add(a,ids,"SPEECH_LIVE_PHASE_UNPROVEN","VERIFICATION_GAP","speech","S2",82,"conversation expects LISTENING but no Code614 live recognizer phase has been observed yet","exercise one spoken turn and record STARTING/READY callbacks","fresh phase telemetry proves listening authority without source mutation");
  if(rebuildDelta>0) add(a,ids,"SPEECH_REBUILD_CURRENT_WINDOW","CLEANUP","speech","S2",80,"Code614 recognizer rebuild delta="+rebuildDelta,"correlate each rebuild to a causal callback/recovery event","no unnecessary rebuilds across the clean-reply acceptance window");
  if(rebuildNow>=10) add(a,ids,"SPEECH_REBUILD_HISTORY","HISTORICAL_SIGNAL","speech","S2",52,"lifetime recognizer rebuild history="+rebuildNow,"retain as history while judging Code614 from the release delta","historical count no longer creates a false current fault");
  if(hasMeasuredPair(p,"naturalness")) add(a,ids,"SPEECH_NATURALNESS_SCORE","IMPROVEMENT","speech","S3",70,"TTS/recognizer pipeline exists; naturalness is a user-visible quality dimension","score pacing, pauses, prosody and volume consistency from clean spoken replies; tune only measured weaknesses","30-reply sample improves naturalness metrics without latency/regression cost");
 }

 private static void conversation(SharedPreferences p,List<Finding>a,Set<String>ids){
  int divNow=p.getInt("conversation_state_divergence",0), divDelta=Math.max(0,divNow-p.getInt("code614_base_state_divergence",divNow));
  int deafNow=p.getInt("ready_but_deaf_confirmed",0), deafDelta=Math.max(0,deafNow-p.getInt("code614_base_ready_deaf",deafNow));
  int stallNow=p.getInt("runtime_stall_recoveries",0), stallDelta=Math.max(0,stallNow-p.getInt("code614_base_runtime_stall",stallNow));
  int barge=Math.max(0,p.getInt("spoken_barge_in_count",0)-p.getInt("code614_base_barge",0));
  int bargeStop=Math.max(0,p.getInt("spoken_barge_in_tts_stop_count",0)-p.getInt("code614_base_barge_tts_stop",0));
  int preempt=Math.max(0,p.getInt("code409_ai_preemptions",0)-p.getInt("code614_base_ai_preempt",0));
  if(divDelta>0) add(a,ids,"CONVERSATION_STATE_DIVERGENCE","OBSERVED_FAULT_EVIDENCE","conversation","S1",98,"Code614 authoritative-state divergence delta="+divDelta,"trace the exact generation from STT through reasoning/TTS and remove the competing state write","zero further Code614 divergence events across acceptance");
  else if(divNow>0) add(a,ids,"CONVERSATION_DIVERGENCE_HISTORY","HISTORICAL_SIGNAL","conversation","S2",50,"lifetime divergence history="+divNow+" with Code614 delta=0","retain history without mislabeling it as a current fault","Code614 delta stays zero");
  if(deafDelta>0) add(a,ids,"READY_BUT_DEAF_CURRENT_WINDOW","OBSERVED_FAULT_EVIDENCE","conversation","S1",99,"Code614 READY-but-deaf delta="+deafDelta,"correlate recognizer READY, audio boundary and transcript callback; repair the causal handoff","zero further incidents across acceptance");
  if(stallDelta>0) add(a,ids,"INTERACTIVE_STALL_CURRENT_WINDOW","OBSERVED_FAULT_EVIDENCE","conversation","S1",97,"Code614 interactive stall recovery delta="+stallDelta,"trace request generation and completion ownership; remove stale/duplicate completion path","zero further stall recoveries across acceptance");
  if(barge==0 || bargeStop==0) add(a,ids,"BARGE_IN_PROOF_MISSING","VERIFICATION_GAP","conversation","S2",88,"Code614 spoken barge-in="+barge+" active-TTS-stop="+bargeStop,"exercise real spoken interruption while Lumi is actively speaking","causal active-TTS interruption is recorded and stale output stays cancelled");
  if(preempt==0) add(a,ids,"INTERACTIVE_PREEMPTION_PROOF_MISSING","VERIFICATION_GAP","conversation","S2",76,"Code614 interactive AI preemption proof=0","exercise user interruption of active reasoning","old generation is cancelled and only new turn can speak");
  if(hasMeasuredPair(p,"handoff")||hasMeasuredPair(p,"conversation_latency")) add(a,ids,"CONVERSATION_FLOW_HEADROOM","IMPROVEMENT","conversation","S3",66,"conversation core exposes turn timing and handoff instrumentation","optimize dead air and post-TTS handoff using P50/P95 timing rather than fixed guesses","lower tail handoff latency with no echo or lost-first-word regression");
 }

 private static void reasoning(SharedPreferences p,List<Finding>a,Set<String>ids){
  Boolean ready=findBool(p,"fast","ready"); if(Boolean.FALSE.equals(ready)) add(a,ids,"FAST_BRAIN_NOT_READY","OBSERVED_FAULT_EVIDENCE","reasoning","S1",95,"Fast Brain currently not ready","recover worker/model without weakening quality gate","fresh normal inference succeeds after recovery");
  Boolean quarantine=p.getBoolean("fast_brain_quarantined",false); if(Boolean.TRUE.equals(quarantine)) add(a,ids,"FAST_BRAIN_QUARANTINED","OBSERVED_FAULT_EVIDENCE","reasoning","S1",95,"Fast Brain quarantined","trace worker crash/quality reason and recover boundedly","worker is responsive and fresh normal inference passes");
  if(anyPositive(p,"quality","miss")) add(a,ids,"FAST_BRAIN_QUALITY_HISTORY","HISTORICAL_SIGNAL","reasoning","S2",55,"Fast Brain quality rejection history present","keep visible-quality gate and track current-release rejection rate","current release has acceptable rejection/fallback rate");
  if(hasMeasuredPair(p,"router")) add(a,ids,"ROUTER_HEALTH_SCORING","IMPROVEMENT","reasoning","S3",74,"multiple local/free/OpenAI maintenance routes exist","rank routes by fresh latency, success, quota health and quality rather than static order alone","shadow comparison shows better success/latency with no paid-routing policy violation");
 }

 private static void identity(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(Boolean.FALSE.equals(findBool(p,"secure","owner"))) add(a,ids,"OWNER_WAKE_SECURITY_DISABLED","OBSERVED_FAULT_EVIDENCE","identity","S0",100,"secure owner wake requirement reports disabled","restore production owner-voice requirement","unverified wake cannot gain owner authority");
  if(findIntContains(p,"owner","accept",0)==0) add(a,ids,"OWNER_VOICE_ACCEPTANCE_UNPROVEN","VERIFICATION_GAP","identity","S2",90,"owner voice accepts=0 in current acceptance window","exercise enrolled-owner voice after biometric/session transitions","owner accepted with causal voice/lease evidence and non-owner stays non-admin");
  int conf=findIntContains(p,"speaker","confidence",-1); if(conf==0) add(a,ids,"SPEAKER_CONFIDENCE_ZERO","VERIFICATION_GAP","identity","S2",72,"latest live speaker confidence=0%","separate no-PCM/no-sample state from actual low-confidence speaker result","voice test yields explicit evidence class without falsely granting admin");
  if(hasMeasuredPair(p,"speaker")) add(a,ids,"IDENTITY_CONFIDENCE_CALIBRATION","IMPROVEMENT","identity","S3",64,"owner enrollment and conversation lease infrastructure exist","calibrate confidence/continuity thresholds from owner/non-owner test samples","lower false rejects without increasing false owner accepts");
 }

 private static void memory(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(anyPositive(p,"memory","error")||anyPositive(p,"memory","fail")) add(a,ids,"MEMORY_RUNTIME_FAILURE","OBSERVED_FAULT_EVIDENCE","memory","S1",92,"memory failure evidence present","trace persistence/retrieval path and isolate stale/failed record","write/restart/read test passes for authoritative local memory");
  if(findIntContains(p,"memory","proof",0)==0) add(a,ids,"MEMORY_PROOF_MISSING","VERIFICATION_GAP","memory","S2",86,"authoritative local-memory proof missing","create controlled fact, restart/reopen, retrieve and verify provenance","same fact returns after restart from authoritative store");
  if(hasMeasuredPair(p,"memory_retrieval")) add(a,ids,"MEMORY_RETRIEVAL_QUALITY","IMPROVEMENT","memory","S3",62,"memory subsystem is present","measure retrieval precision, stale-fact suppression and relationship-context relevance","benchmark improves without leaking private context or inventing facts");
 }

 private static void behavior(SharedPreferences p,List<Finding>a,Set<String>ids){
  int clean=Math.max(0,p.getInt("tts_reply_successes",0)-p.getInt("code614_base_tts_replies",0));
  if(clean<30) add(a,ids,"CLEAN_SPOKEN_SAMPLE_INCOMPLETE","VERIFICATION_GAP","behavior","S2",89,"Code614 clean spoken reply sample="+clean+"/30","complete one natural uninterrupted 30-reply acceptance session","30 clean replies with no watchdog/recovery/divergence regressions");
  if(anyPositive(p,"echo","suppress")) add(a,ids,"ECHO_SUPPRESSION_ACTIVITY","HISTORICAL_SIGNAL","behavior","S3",48,"echo suppression activity exists","track current-release suppressions and rejected self-audio separately","no self-audio becomes user input and suppression rate remains bounded");
 }

 private static void capabilities(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(Boolean.FALSE.equals(findBool(p,"maintenance","host"))) add(a,ids,"MAINTENANCE_HOST_UNAVAILABLE","OBSERVED_FAULT_EVIDENCE","capabilities","S1",96,"maintenance host unavailable","restore host before autonomous mutation","maintenance tool probe succeeds");
  if(Boolean.FALSE.equals(findBool(p,"trusted","relay"))) add(a,ids,"TRUSTED_RELAY_UNAVAILABLE","OBSERVED_FAULT_EVIDENCE","capabilities","S1",99,"trusted relay unavailable","restore authenticated signed build lane","preflight/build/install validation passes");
 }

 private static void performance(Context c,SharedPreferences p,List<Finding>a,Set<String>ids){
  try{ActivityManager am=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);if(mi.lowMemory)add(a,ids,"ANDROID_LOW_MEMORY","OBSERVED_FAULT_EVIDENCE","performance","S1",97,"Android currently reports low memory","reduce retained/background allocations and inspect heap growth","30-minute endurance has no LOW_MEMORY exit");}catch(Throwable ignored){}
  int latency=findIntContains(p,"response","latency",-1); if(latency>5200) add(a,ids,"RESPONSE_LATENCY_OVER_GATE","OBSERVED_FAULT_EVIDENCE","performance","S1",91,"response latency="+latency+"ms above 5200ms target","profile local/hedge/cloud stages and remove avoidable waits","current-release spoken P95 is within frozen gate");
  if(latency>0) add(a,ids,"LATENCY_TAIL_OPTIMIZATION","IMPROVEMENT","performance","S3",68,"instrumented response latency is available","track P50/P95/P99 by route and optimize tail without sacrificing quality","measured tail improves over baseline");
 }

 private static void update(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(findIntContains(p,"pending","coreversion",-1)>0) add(a,ids,"PENDING_CORE_UPDATE","CLEANUP","update","S2",78,"pending core update exists","complete or explicitly reconcile current signed update transaction","pending version returns to -1 with post-install validation or clean abort");
  if(anyPositive(p,"update","rollback")) add(a,ids,"UPDATE_ROLLBACK_HISTORY","HISTORICAL_SIGNAL","update","S2",52,"rollback history present","keep per-release rollback cause metrics; do not call history a current fault","current release installs/validates without rollback");
  if(hasMeasuredPair(p,"update_cycle")) add(a,ids,"UPDATE_CYCLE_TIME","IMPROVEMENT","update","S3",60,"trusted update pipeline records stage timings","reduce detect-to-verified-install time by optimizing non-security waits only","cycle time improves while signing/checkpoint/installer gates remain intact");
 }

 private static void diagnostics(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(findIntContains(p,"dropped","event",0)>0) add(a,ids,"BLACKBOX_DROPPED_EVENTS","OBSERVED_FAULT_EVIDENCE","diagnostics","S1",94,"Black Box dropped events >0","repair recorder queue/backpressure","long run records zero drops");
  if(findIntContains(p,"write","fail",0)>0) add(a,ids,"BLACKBOX_WRITE_FAILURE","OBSERVED_FAULT_EVIDENCE","diagnostics","S1",94,"Black Box write failures >0","repair storage/rotation writer","long run has zero write failures");
  long bytes=findLongContains(p,"current","bytes",0L); int rotations=findIntContains(p,"rotation","count",0); if(bytes>16L*1024L*1024L && rotations==0) add(a,ids,"BLACKBOX_ROTATION_HEADROOM","CLEANUP","diagnostics","S2",80,"large recorder file with no observed rotation bytes="+bytes,"add bounded rotation/compaction while preserving causal context","recorder remains bounded with zero drops/write failures");
  if(hasMeasuredPair(p,"diagnostic_noise")) add(a,ids,"DIAGNOSTIC_SIGNAL_TO_NOISE","IMPROVEMENT","diagnostics","S3",67,"Black Box records warnings/errors/correlation data","deduplicate repetitive historical noise and emphasize current-release deltas/cause chains","smaller report retains all causal failures and acceptance evidence");
 }

 private static void audio(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(anyPositive(p,"self_audio","accept")) add(a,ids,"SELF_AUDIO_PROMOTED","OBSERVED_FAULT_EVIDENCE","audio","S0",100,"self-audio accept evidence present","reject self-generated audio before turn promotion","explicit self-audio test is rejected and never gains user authority");
  int wd=findIntContains(p,"tts","watchdog",0); if(wd>0) add(a,ids,"TTS_WATCHDOG_HISTORY","HISTORICAL_SIGNAL","audio","S2",50,"TTS watchdog recovery history="+wd,"track current-release watchdog delta separately","30 clean replies show zero new watchdog recoveries");
 }

 private static void permissions(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(anyPositive(p,"permission","denied")||anyPositive(p,"permission","missing")) add(a,ids,"REQUIRED_PERMISSION_PROBLEM","OBSERVED_FAULT_EVIDENCE","permissions","S1",90,"required permission denial/missing evidence present","identify exact capability and guide owner through Android-granted permission","capability probe passes without silent privilege expansion");
 }

 private static void integrations(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(anyPositive(p,"integration","error")||anyPositive(p,"integration","fail")) add(a,ids,"INTEGRATION_FAILURE","CLEANUP","integrations","S2",75,"integration failure evidence present","isolate provider/permission/contract failure and add health state","integration retries are bounded and successful path is verified");
  if(anyPositive(p,"web","failure")) add(a,ids,"WEB_PROVIDER_FAILURE_HISTORY","HISTORICAL_SIGNAL","integrations","S3",45,"web provider failure history present","track per-provider freshness/success and graceful fallback","fresh web task returns sourced result through healthy provider");
 }

 private static void privacySecurity(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(anyPositive(p,"privacy","violation")||anyPositive(p,"security","violation")) add(a,ids,"SECURITY_POLICY_VIOLATION","OBSERVED_FAULT_EVIDENCE","privacy-security","S0",100,"privacy/security violation evidence present","fail closed and isolate exact path before other maintenance","violation no longer reproduces and regression test remains locked");
  if(Boolean.TRUE.equals(findBool(p,"developer","bypass"))) add(a,ids,"DEVELOPER_BYPASS_ACTIVE","OBSERVED_FAULT_EVIDENCE","privacy-security","S0",100,"developer bypass enabled in production","disable bypass and preserve owner authentication","production heartbeat reports bypass=false");
 }

 private static void sensors(SharedPreferences p,List<Finding>a,Set<String>ids){
  Boolean mic=findBool(p,"microphone","available"); if(Boolean.FALSE.equals(mic)) add(a,ids,"MICROPHONE_UNAVAILABLE","OBSERVED_FAULT_EVIDENCE","sensors","S1",95,"microphone unavailable","repair permission/device acquisition path","explicit voice entry acquires mic and recognizes speech");
  if(anyPositive(p,"sensor","error")) add(a,ids,"SENSOR_ERROR","CLEANUP","sensors","S2",70,"sensor error evidence present","isolate affected sensor and degrade gracefully","healthy sensor probe or explicit unavailable state without repeated errors");
 }

 private static void maintenance(SharedPreferences p,List<Finding>a,Set<String>ids,long now){
  String st=p.getString("maintenance_build_handoff_status","NOT_REQUESTED");
  if("RUNNER_ERROR".equals(st)||"SELF_REPAIR_BLOCKED".equals(st)||"TRANSACTION_BIND_FAILED".equals(st)) add(a,ids,"SELF_REPAIR_PIPELINE_RETIRED_HISTORY","HISTORICAL_SIGNAL","maintenance","S1",99,"self-repair status="+st+" error="+bound(p.getString("maintenance_build_handoff_error",""),220),"trace same request through reasoning/source/relay/install and repair exact failed stage","same request reaches post-install validation without truth divergence");
  if(anyPositive(p,"maintenance_reasoning","failure")) add(a,ids,"MAINTENANCE_REASONING_FAILURE_HISTORY","HISTORICAL_SIGNAL","maintenance","S2",55,"maintenance reasoning failures recorded","track provider failures per release and verify OpenAI final fallback","fresh bounded fallback succeeds when free ladder is exhausted");
  if(!p.getBoolean("maintenance_openai_last_success",false)) add(a,ids,"OPENAI_MAINTENANCE_FALLBACK_UNPROVEN","VERIFICATION_GAP","maintenance","S2",84,"Code609 OpenAI maintenance success not yet proven","exercise a bounded maintenance turn after free-provider exhaustion without mutating twice","maintenance_reasoning_provider=openai and maintenance_openai_last_success=true with same-request tool proof");
  if(hasMeasuredPair(p,"repair_cycle")) add(a,ids,"SELF_REPAIR_CYCLE_METRICS","IMPROVEMENT","maintenance","S3",75,"self-repair has durable request/stage telemetry","measure detect-to-diagnose-to-patch-to-build-to-install-to-verify timing and success rate by failure class","verified repair throughput improves without weakening evidence gates");
 }

 private static void consistency(SharedPreferences p,List<Finding>a,Set<String>ids){
  boolean tts=Boolean.TRUE.equals(findBool(p,"speech_output","active")); String state=findStringContains(p,"runtime","state","");
  if(!tts&&"SPEAKING".equalsIgnoreCase(state)) add(a,ids,"SPEAKING_WITHOUT_TTS","OBSERVED_FAULT_EVIDENCE","consistency","S1",98,"runtime says SPEAKING while TTS inactive","collapse state authority onto causal TTS generation","no divergence across acceptance conversation");
  if(findIntContains(p,"current","fault",0)==0 && "RUNNER_ERROR".equals(p.getString("maintenance_build_handoff_status",""))) add(a,ids,"ZERO_FAULT_CONTRADICTION","OBSERVED_FAULT_EVIDENCE","consistency","S1",98,"zero-current-fault claim conflicts with self-repair RUNNER_ERROR","make diagnostic census authoritative over narrow maintenance issue integer","all status surfaces report the same current fault census");
 }

 private static void degradation(SharedPreferences p,List<Finding>a,Set<String>ids){
  int recover=findIntContains(p,"network","recovery",findIntContains(p,"recover","count",0)); if(recover>=100) add(a,ids,"RECOVERY_CHURN_HISTORY","HISTORICAL_SIGNAL","degradation","S2",54,"large cumulative recovery history="+recover,"replace lifetime alarms with per-release rate windows and deduplicated cause counters","current window distinguishes healthy historical scars from new churn");
 }

 private static void verification(SharedPreferences p,List<Finding>a,Set<String>ids,long now){
  if(findIntContains(p,"clean","reply",0)<30) add(a,ids,"GATE_30_CLEAN_REPLIES","VERIFICATION_GAP","verification","S2",93,"30-clean-spoken-reply gate not proven","complete 30 spoken replies after current release","30/30 clean with zero new critical recovery events");
  if(findIntContains(p,"owner","accept",0)==0) add(a,ids,"GATE_OWNER_VOICE","VERIFICATION_GAP","verification","S2",92,"owner voice acceptance gate not proven","exercise enrolled owner and non-owner separation","owner accepted; non-owner cannot inherit admin");
  long proof=findLongContains(p,"normal","inference",0L); if(proof<=0L||now-proof>STALE_PROOF_MS) add(a,ids,"GATE_FAST_BRAIN_FRESHNESS","VERIFICATION_GAP","verification","S2",80,"fresh normal-inference proof missing/stale","run fresh normal local inference","proof age under six hours with quality gate pass");
  Boolean endurance=findBool(p,"30min","endurance"); if(!Boolean.TRUE.equals(endurance)) add(a,ids,"GATE_30_MIN_ENDURANCE","VERIFICATION_GAP","verification","S2",87,"30-minute resource endurance not proven","run 30-minute mixed-use endurance","no LOW_MEMORY exit, recorder failure or responsiveness regression");
 }

 private static void repairTruth(SharedPreferences p,List<Finding>a,Set<String>ids){
  int raw=p.getInt("maintenance_loop_repair_count",0),verified=p.getInt("maintenance_verified_repairs_v2",0);
  if(raw>0) add(a,ids,"LEGACY_REPAIR_COUNTER_UNTRUSTED","CLEANUP","repair-truth","S1",96,"legacy repair-event counter="+raw+" is not a verified repair count","retain only as legacy event telemetry; expose verified repair v2 separately","verified repair count changes only after causal before/change/after proof");
  if(p.getInt("maintenance_executor_applied_changes",0)>0 && p.getInt("maintenance_executor_verified_repairs",0)==0) add(a,ids,"APPLIED_WITHOUT_VERIFIED_REPAIR","CLEANUP","repair-truth","S2",83,"maintenance changes were applied without verified-repair proof","separate attempts/changes/rollbacks/escalations from verified repairs","owner-facing repair metric equals causal verified outcomes only");
  if(verified<0) add(a,ids,"VERIFIED_REPAIR_COUNTER_INVALID","OBSERVED_FAULT_EVIDENCE","repair-truth","S1",99,"verified repair counter invalid","reset v2 accounting only, preserve event ledger","v2 verified repair count is nonnegative and evidence-backed");
 }

 private static void dataHygiene(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(p.getInt("maintenance_candidate_detection_count",0)>0 && p.getString("maintenance_candidate_area","").trim().isEmpty()) add(a,ids,"CANDIDATE_WITHOUT_AREA","CLEANUP","data-hygiene","S2",79,"candidate detections exist with blank/unspecified area","require stable candidate id, classification, area and evidence","every promoted candidate traces back to one census item");
  if(findIntContains(p,"telemetry","contradiction",0)>0) add(a,ids,"TELEMETRY_AUTHORITY_MAP","IMPROVEMENT","data-hygiene","S3",61,"multiple legacy/current telemetry generations coexist","publish one authority map per metric and mark legacy counters non-authoritative","diagnostic report has no contradictory duplicate authority");
 }

 private static void resourceEfficiency(SharedPreferences p,List<Finding>a,Set<String>ids){
  int dup=findIntContains(p,"duplicate","network",findIntContains(p,"duplicate","callback",0)); if(dup>=10) add(a,ids,"DUPLICATE_NETWORK_CALLBACKS","CLEANUP","resource-efficiency","S2",82,"duplicate validated network callbacks="+dup,"deduplicate callbacks at the edge and compare per-release delta","duplicate callback rate approaches zero without missing true transitions");
  int rebuild=findIntContains(p,"scheduler","rebuild",0); if(rebuild>=50) add(a,ids,"SCHEDULER_REBUILD_HISTORY","HISTORICAL_SIGNAL","resource-efficiency","S2",53,"scheduler rebuild history="+rebuild,"track destructive vs observe-only deltas per current release","healthy window has no unnecessary destructive rebuilds");
  int voiceApply=findIntContains(p,"aurora","apply",0); if(voiceApply>=25) add(a,ids,"AURORA_REAPPLY_HEADROOM","IMPROVEMENT","resource-efficiency","S3",63,"Aurora apply count is high="+voiceApply,"make unchanged voice-profile application idempotent and measure startup savings","fewer redundant applies with identical verified voice profile");
 }

 private static void userExperience(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(hasMeasuredPair(p,"maintenance_ux")) add(a,ids,"MAINTENANCE_STATUS_TRUTH_UX","IMPROVEMENT","user-experience","S3",69,"maintenance currently exposes passes/issues/raw repair events that can be misread","present census: current faults, cleanup, verification gaps, improvements, attempts, verified repairs","owner can tell what is broken, merely untested, improved, attempted and truly fixed at a glance");
 }

 private static void selfImprovement(SharedPreferences p,List<Finding>a,Set<String>ids){
  if(!"VERIFIED".equals(p.getString("self_improvement_discovery_gate",""))) add(a,ids,"SELF_IMPROVEMENT_DISCOVERY_UNPROVEN","VERIFICATION_GAP","self-improvement","S3",77,"three evidence-backed improvements across three domains have not yet been proven","collect measured baseline/current evidence; do not manufacture improvement objects","VERIFIED occurs only after three qualified measured opportunities exist");
 }

 private static void trendSignals(SharedPreferences p,List<Finding>a,Set<String>ids){
  int net=findIntContains(p,"network","recovery",0),fail=findIntContains(p,"network","failure",0);
  if(net>=100) add(a,ids,"NETWORK_RECOVERY_CUMULATIVE","HISTORICAL_SIGNAL","degradation","S3",42,"network recoveries cumulative="+net+" failures="+fail,"use release-window deltas for current fault decisions","current-window recovery/failure ratio is visible separately from lifetime history");
 }

 private static void promoteOneActionable(SharedPreferences p,List<Finding>all,long now){
  String cls=p.getString("maintenance_candidate_classification","none"),area=p.getString("maintenance_candidate_area","");
  boolean generic=cls==null||"none".equalsIgnoreCase(cls)||area==null||area.trim().isEmpty()||"unspecified".equalsIgnoreCase(area);
  if(!generic)return;
  Finding pick=null;
  for(String wanted:new String[]{"OBSERVED_FAULT_EVIDENCE","CLEANUP","VERIFICATION_GAP","IMPROVEMENT"}){
   for(Finding x:all) if(wanted.equals(x.classification)){pick=x;break;}
   if(pick!=null)break;
  }
  if(pick==null)return;
  String outClass="OBSERVED_FAULT_EVIDENCE".equals(pick.classification)?"FAULT":pick.classification;
  p.edit().putString("maintenance_candidate_classification",outClass).putString("maintenance_candidate_area",pick.area)
   .putString("maintenance_candidate_id_v2",pick.id).putString("maintenance_candidate_action",pick.nextAction)
   .putString("maintenance_candidate_evidence_v2",pick.evidence).putString("maintenance_candidate_verification_v2",pick.verificationPlan)
   .putLong("maintenance_candidate_last_at",now).apply();
 }

 private static void add(List<Finding>a,Set<String>ids,String id,String c,String area,String sev,int pri,String ev,String act,String ver){
  if(a.size()>=MAX_FINDINGS||id==null||ids.contains(id))return; ids.add(id); a.add(new Finding(id,c,area,sev,pri,ev,act,ver));
 }
 private static void append(StringBuilder b,Finding x){if(b.length()>0)b.append(" | ");b.append(x.id).append("[").append(x.area).append("] ").append(x.evidence);}
 private static String combined(List<Finding>a){StringBuilder b=new StringBuilder();for(int i=0;i<a.size();i++){if(i>0)b.append(" | ");Finding x=a.get(i);b.append(i+1).append(":").append(x.classification).append(":").append(x.id).append(":").append(x.evidence);}return b.toString();}
 private static String bound(String x,int n){String s=x==null?"":x.trim();return s.length()>n?s.substring(0,n):s;}


 private static boolean hasNumeric(SharedPreferences p,String... terms){
  outer: for(Map.Entry<String,?> e:all(p).entrySet()){
   String k=e.getKey().toLowerCase(Locale.US);
   for(String t:terms) if(t!=null&&!t.isEmpty()&&!k.contains(t.toLowerCase(Locale.US))) continue outer;
   if(e.getValue() instanceof Number) return true;
  }
  return false;
 }
 private static boolean hasMeasuredPair(SharedPreferences p,String topic){
  return hasNumeric(p,topic,"baseline") && (hasNumeric(p,topic,"current")||hasNumeric(p,topic,"score")||hasNumeric(p,topic,"p95")||hasNumeric(p,topic,"latency"));
 }
 private static Map<String,?> all(SharedPreferences p){return p==null?java.util.Collections.emptyMap():p.getAll();}
 private static boolean anyPositive(SharedPreferences p,String a,String b){for(Map.Entry<String,?>e:all(p).entrySet()){String k=e.getKey().toLowerCase(Locale.US);if(k.contains(a.toLowerCase(Locale.US))&&k.contains(b.toLowerCase(Locale.US))&&num(e.getValue())>0)return true;}return false;}
 private static int findIntContains(SharedPreferences p,String a,String b,int d){for(Map.Entry<String,?>e:all(p).entrySet()){String k=e.getKey().toLowerCase(Locale.US);if(k.contains(a.toLowerCase(Locale.US))&&k.contains(b.toLowerCase(Locale.US)))return (int)num(e.getValue());}return d;}
 private static int findIntContains(SharedPreferences p,String a,int d){for(Map.Entry<String,?>e:all(p).entrySet()){String k=e.getKey().toLowerCase(Locale.US);if(k.contains(a.toLowerCase(Locale.US)))return (int)num(e.getValue());}return d;}
 private static long findLongContains(SharedPreferences p,String a,String b,long d){for(Map.Entry<String,?>e:all(p).entrySet()){String k=e.getKey().toLowerCase(Locale.US);if(k.contains(a.toLowerCase(Locale.US))&&k.contains(b.toLowerCase(Locale.US)))return (long)num(e.getValue());}return d;}
 private static Boolean findBool(SharedPreferences p,String a,String b){for(Map.Entry<String,?>e:all(p).entrySet()){String k=e.getKey().toLowerCase(Locale.US);if(k.contains(a.toLowerCase(Locale.US))&&k.contains(b.toLowerCase(Locale.US))&&e.getValue() instanceof Boolean)return (Boolean)e.getValue();}return null;}
 private static String findStringContains(SharedPreferences p,String a,String b,String d){for(Map.Entry<String,?>e:all(p).entrySet()){String k=e.getKey().toLowerCase(Locale.US);if(k.contains(a.toLowerCase(Locale.US))&&k.contains(b.toLowerCase(Locale.US)))return String.valueOf(e.getValue());}return d;}
 private static double num(Object o){if(o instanceof Number)return ((Number)o).doubleValue();try{return Double.parseDouble(String.valueOf(o));}catch(Throwable t){return 0;}}
}
