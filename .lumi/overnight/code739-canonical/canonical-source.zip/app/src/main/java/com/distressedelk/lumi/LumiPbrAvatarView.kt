package com.distressedelk.lumi

import android.content.Context
import android.content.SharedPreferences
import android.view.Choreographer
import android.view.SurfaceView
import android.widget.FrameLayout
import com.google.android.filament.EntityManager
import com.google.android.filament.LightManager
import com.google.android.filament.utils.Utils
import com.google.android.filament.utils.Float3
import com.google.android.filament.utils.ModelViewer
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Code714: single live visual truth. Lumi Core commits; this view only applies and reports evidence. */
class LumiPbrAvatarView(context: Context) : FrameLayout(context), Choreographer.FrameCallback {
    private val prefs: SharedPreferences = context.getSharedPreferences("lumi", Context.MODE_PRIVATE)
    private val surface = SurfaceView(context)
    private var viewer: ModelViewer? = null
    private var lightEntity: Int = 0
    private var running = false
    private var requestedState = LumiPyramid3DView.VisualState.IDLE
    private var liveFocal = 34f
    private var liveIso = 50f
    private var liveLight = 12000f
    private var liveAspect = 0f

    init {
        LumiAvatarForge.ensureBaseline(context)
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        addView(surface, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    fun captureSurface(): SurfaceView = surface

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        try { createRenderer() } catch (t: Throwable) { recordFailure("attach", t); throw t }
        running = true
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDetachedFromWindow() {
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
        super.onDetachedFromWindow()
        viewer = null
        lightEntity = 0
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w > 0 && h > 0) post { applyCommittedVisualState() }
    }

    private fun createRenderer() {
        if (viewer != null) return
        Utils.init()
        val mv = ModelViewer(surface)
        viewer = mv
        val model = LumiAvatarForge.loadActiveModelBytes(context, prefs)
        val bb = ByteBuffer.allocateDirect(model.size).order(ByteOrder.nativeOrder())
        bb.put(model).flip()
        mv.loadModelGlb(bb)
        mv.transformToUnitCube(Float3(0f, -0.08f, -4f))
        lightEntity = EntityManager.get().create()
        LightManager.Builder(LightManager.Type.DIRECTIONAL)
            .color(0.78f, 0.90f, 0.82f)
            .intensity(prefs.getFloat("avatar_forge_committed_light_intensity", 12000f))
            .direction(0.25f, -0.65f, -1.0f)
            .castShadows(true)
            .build(mv.engine, lightEntity)
        mv.scene.addEntity(lightEntity)
        applyCommittedVisualState()
        prefs.edit().putString("avatar_forge_runtime","FILAMENT_PBR_ACTIVE")
            .putString("visual_model_mounted_class",javaClass.name)
            .putBoolean("avatar_forge_fallback_active",false)
            .putLong("avatar_forge_renderer_ready_at",System.currentTimeMillis()).apply()
    }

    private fun reloadModelInPlace() {
        val mv = viewer ?: run { if (isAttachedToWindow) createRenderer(); return }
        val model = LumiAvatarForge.loadActiveModelBytes(context, prefs)
        val bb = ByteBuffer.allocateDirect(model.size).order(ByteOrder.nativeOrder())
        bb.put(model).flip()
        mv.loadModelGlb(bb)
        mv.transformToUnitCube(Float3(0f, -0.08f, -4f))
        applyCommittedVisualState()
    }

    fun applyCommittedVisualState() {
        val mv = viewer ?: return
        val focal = prefs.getFloat("avatar_forge_committed_focal_mm", 34f).coerceIn(18f, 60f)
        val iso = prefs.getFloat("avatar_forge_committed_iso", 50f).coerceIn(20f, 200f)
        val light = prefs.getFloat("avatar_forge_committed_light_intensity", 12000f).coerceIn(2500f, 50000f)
        val w = if (surface.width > 0) surface.width else width
        val h = if (surface.height > 0) surface.height else height
        val aspect = if (w > 0 && h > 0) w.toDouble() / h.toDouble() else 9.0 / 19.5
        mv.camera.setLensProjection(focal.toDouble(), aspect, 0.05, 100.0)
        mv.camera.setExposure(16f, 1f/125f, iso)
        if (lightEntity != 0) {
            val lm = mv.engine.lightManager
            val inst = lm.getInstance(lightEntity)
            if (inst != 0) lm.setIntensity(inst, light)
        }
        liveFocal = focal
        liveIso = iso
        liveLight = light
        liveAspect = aspect.toFloat()
        prefs.edit()
            .putFloat("avatar_forge_camera_focal_mm", focal)
            .putFloat("avatar_forge_exposure_iso", iso)
            .putFloat("avatar_forge_live_focal_mm", focal)
            .putFloat("avatar_forge_live_iso", iso)
            .putFloat("avatar_forge_live_light_intensity", light)
            .putFloat("avatar_forge_live_aspect", liveAspect)
            .putInt("avatar_forge_viewport_width", w)
            .putInt("avatar_forge_viewport_height", h)
            .putLong("avatar_forge_live_applied_at", System.currentTimeMillis())
            .putString("visual_scene_runtime_snapshot", diagnosticSnapshot())
            .apply()
    }

    fun reloadModel() {
        try { reloadModelInPlace() } catch (t: Throwable) { recordFailure("reload", t); throw t }
        invalidate()
    }

    fun setVisualState(state: LumiPyramid3DView.VisualState) {
        requestedState = state
        prefs.edit().putString("avatar_forge_visual_state", state.name)
            .putLong("avatar_forge_visual_state_at", System.currentTimeMillis()).apply()
        applyCommittedVisualState()
    }

    fun requestModelRender() { invalidate() }
    fun onHostForeground(){ if(isAttachedToWindow&&!running){running=true;Choreographer.getInstance().postFrameCallback(this)};applyCommittedVisualState() }
    fun onHostBackground(){ running=false;Choreographer.getInstance().removeFrameCallback(this) }
    fun onResume(){ onHostForeground(); applyCommittedVisualState() }
    fun forceMaintenanceRecovery(){ reloadModel() }

    override fun doFrame(frameTimeNanos: Long) {
        val mv = viewer
        if (running && mv != null) {
            try { mv.render(frameTimeNanos) } catch(t:Throwable){ recordFailure("render",t) }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun recordFailure(stage:String,t:Throwable){
        prefs.edit().putString("avatar_forge_runtime","FILAMENT_PBR_FAILED")
            .putString("avatar_forge_last_error",stage+":"+t.javaClass.simpleName+":"+(t.message?:""))
            .putLong("avatar_forge_last_error_at",System.currentTimeMillis()).apply()
    }

    fun diagnosticSnapshot():String = "renderer=filament-pbr-1.75.1 • model="+prefs.getString("visual_active_model","unknown")+
        " • source="+prefs.getString("avatar_forge_active_source","unknown")+" • state="+requestedState.name+
        " • liveFocal="+liveFocal+" • liveIso="+liveIso+" • liveLight="+liveLight+" • aspect="+liveAspect+
        " • viewport="+prefs.getInt("avatar_forge_viewport_width",0)+"x"+prefs.getInt("avatar_forge_viewport_height",0)
}
