package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

/**
 * Code651 single runtime self model. It does not invent a second authority.
 * It is a calculated view over Lumi Core authority, living goal state, causal truth,
 * maintenance receipts and current release state.
 */
final class LumiRuntimeSelfModel {
    private LumiRuntimeSelfModel(){}

    static String snapshot(Context c, SharedPreferences p){
        if(c==null||p==null)return "unavailable";
        LumiCausalJournal.ensureRelease(c,p);
        int release=p.getInt("causal_truth_release_code",LumiCausalJournal.BASELINE);
        String maintenanceTx=p.getString("maintenance_explicit_tx_id","none");
        int maintenanceVersion=p.getInt("maintenance_explicit_tx_version",-1);
        if(maintenanceVersion<0 && maintenanceTx.matches(".*-c[0-9]+$")){
            try{maintenanceVersion=Integer.parseInt(maintenanceTx.substring(maintenanceTx.lastIndexOf("-c")+2));}catch(Throwable ignored){}
        }
        boolean maintenanceCurrent=maintenanceVersion==release;
        String maintenance=maintenanceCurrent
                ?("tx="+maintenanceTx+" state="+p.getString("maintenance_explicit_tx_state","none")+" release="+maintenanceVersion)
                :("current=none historicalLast="+maintenanceTx+" historicalRelease="+maintenanceVersion);
        return "identity=THIS_INSTALLED_LUMI_RUNTIME"
                +" release="+p.getInt("causal_truth_release_code",LumiCausalJournal.BASELINE)+"/"+p.getString("causal_truth_release_name",LumiCausalJournal.RELEASE_NAME)
                +" | authority={"+LumiSelfAuthority.summary(p)+"}"
                +" | goal={"+LumiLivingSelf.summary(p)+"}"
                +" | causal={"+LumiCausalJournal.currentTruthSummary(c,p)+"}"
                +" | maintenance={"+maintenance+"}"
                +" | workstation={"+LumiWorkstationBridge.status(c,p)+"}";
    }

    static String answer(Context c,SharedPreferences p,String raw){
        if(c==null||p==null||raw==null)return null;
        String s=norm(raw);
        if(s.matches(".*\\bwhat (are you doing|are you doing right now|are you working on)\\b.*")){
            String stage=p.getString("causal_current_stage","idle");
            String trace=p.getString("causal_current_trace_id","");
            String goal=p.getString("lumi_goal_current_action","");
            if(goal.isEmpty())goal=p.getString("lumi_goal_text","no active action");
            return "I'm using my current runtime state, not a model guess. My active goal/action is "+safe(goal)+"; causal stage="+safe(stage)+"; trace="+(trace.isEmpty()?"none":trace)+".";
        }
        if(s.contains("what just happened")||s.contains("what happened just now")||s.contains("what happened there")){
            return "From my current-release causal journal: trace="+p.getString("causal_last_trace_id","none")
                    +", result="+p.getString("causal_last_terminal","UNTESTED")
                    +", route="+p.getString("causal_last_route","none")
                    +", durationMs="+p.getLong("causal_last_duration_ms",-1L)
                    +", detail="+safe(p.getString("causal_last_result_detail","no completed trace yet"))+".";
        }
        if(s.contains("why did you do that")||s.contains("why did you choose that")||s.contains("why did you route")){
            String decision=p.getString("causal_last_decision","none recorded");
            String evidence=p.getString("causal_last_decision_evidence","no evidence recorded");
            String component=p.getString("causal_last_decision_component","unknown");
            return "My recorded decision was "+safe(decision)+" in "+safe(component)+". The evidence recorded at decision time was: "+safe(evidence)+".";
        }
        if(s.contains("what is wrong with you")||s.contains("what's wrong with you")||s.contains("whats wrong with you")||s.contains("what is your current fault")){
            return LumiCoreSelfStateEngine.answerWhatIsWrong(c,p);
        }
        if(s.contains("what changed since the last build")||s.contains("what changed in this build")){
            return "I'm running Code"+p.getInt("causal_truth_release_code",LumiCausalJournal.BASELINE)+" ("+p.getString("causal_truth_release_name",LumiCausalJournal.RELEASE_NAME)+"). Current truth is bound to this release epoch, and previous-release evidence is quarantined as history.";
        }
        return null;
    }

    static String blackBoxSection(Context c,SharedPreferences p){
        return "RUNTIME SELF MODEL\n"+snapshot(c,p)+"\n\n"
                +"CURRENT RELEASE TRUTH\n"+LumiCausalJournal.currentTruthSummary(c,p)+"\n\n"
                +"WORKSTATION LIVE BRIDGE\n"+LumiWorkstationBridge.status(c,p)+"\n\n"
                +"RECENT CAUSAL TRACE EVENTS\n"+LumiCausalJournal.recentTraceReport(c,p,160);
    }

    private static String norm(String s){return s.toLowerCase(Locale.US).replace('’','\'').replaceAll("\\s+"," ").trim();}
    private static String safe(String s){if(s==null)return "";s=s.replace('\n',' ').replace('\r',' ').trim();return s.length()>700?s.substring(0,700):s;}
}
