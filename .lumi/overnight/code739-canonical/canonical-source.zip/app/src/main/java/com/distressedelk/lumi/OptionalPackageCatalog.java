package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Code470: private, manual-only optional package discovery. */
final class OptionalPackageCatalog {
    static final String CATALOG_PATH=".lumi/optional-packages.json";
    private static final int MAX_JSON=2*1024*1024;
    private static final long MAX_PACKAGE=800L*1024L*1024L;
    private OptionalPackageCatalog(){}

    static int refreshAndStage(Context c,SharedPreferences p) throws Exception {
        String token=SecretStore.get(p,"github_build_token").trim();
        String owner=p.getString("build_relay_github_owner","").trim();
        String repo=p.getString("build_relay_github_repo","").trim();
        String branch=p.getString("build_relay_github_branch",TrustedBuildRelayClient.DEFAULT_BRANCH).trim();
        if(token.isEmpty()||!owner.matches("[A-Za-z0-9_.-]+")||!repo.matches("[A-Za-z0-9_.-]+")) throw new IllegalStateException("Trusted Build Relay is not configured");
        JSONObject envelope=getJson("https://api.github.com/repos/"+owner+"/"+repo+"/contents/"+CATALOG_PATH+"?ref="+URLEncoder.encode(branch,"UTF-8"),token);
        String raw=decodeContents(envelope,token);
        JSONObject catalog=new JSONObject(raw);
        if(catalog.optInt("formatVersion",-1)!=1) throw new SecurityException("Unsupported optional catalog format");
        JSONArray a=catalog.optJSONArray("patches"); if(a==null) return 0;
        int installed=currentVersion(c), staged=0;
        for(int i=0;i<a.length();i++){
            JSONObject m=a.optJSONObject(i); if(m==null) continue;
            String cls=m.optString("classification","").toUpperCase(Locale.US);
            if(!"OPTIONAL".equals(cls)&&!"EXPERIMENTAL".equals(cls)) continue;
            int min=m.optInt("minCore",0), max=m.optInt("maxCore",Integer.MAX_VALUE);
            if(installed<min||installed>max) continue;
            String path=safePath(m.optString("packagePath",""));
            File tmp=new File(c.getCacheDir(),"optional-"+System.currentTimeMillis()+"-"+i+".zip");
            try{
                downloadRepoFile(owner,repo,branch,path,token,tmp);
                JSONObject result=LumiPatchBay.stage(c,m,tmp);
                if(result.optBoolean("ok",false)) staged++;
            }finally{tmp.delete();}
        }
        UpdateBridgeTelemetry.mark(c,p,"OPTIONAL_CATALOG_REFRESH","items="+a.length()+" staged="+staged+" core="+installed);
        return staged;
    }

    private static int currentVersion(Context c) throws Exception {
        if(android.os.Build.VERSION.SDK_INT>=28) return (int)c.getPackageManager().getPackageInfo(c.getPackageName(),0).getLongVersionCode();
        return c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionCode;
    }
    private static String safePath(String x){String s=x==null?"":x.trim().replace('\\','/'); if(!s.startsWith(".lumi/optional/")||s.contains("..")||!s.matches("[A-Za-z0-9._/-]{12,240}")) throw new SecurityException("Unsafe optional package path"); return s;}
    private static JSONObject getJson(String url,String token)throws Exception{return new JSONObject(new String(getBytes(url,token,MAX_JSON),StandardCharsets.UTF_8));}
    private static String decodeContents(JSONObject e,String token)throws Exception{
        String content=e.optString("content","").replace("\\n","").replace("\n","");
        if(!content.isEmpty()) return new String(Base64.decode(content,Base64.DEFAULT),StandardCharsets.UTF_8);
        String u=e.optString("download_url",""); if(u.isEmpty()) throw new IOException("Catalog content unavailable");
        return new String(getBytes(u,token,MAX_JSON),StandardCharsets.UTF_8);
    }
    private static void downloadRepoFile(String owner,String repo,String branch,String path,String token,File out)throws Exception{
        JSONObject e=getJson("https://api.github.com/repos/"+owner+"/"+repo+"/contents/"+path+"?ref="+URLEncoder.encode(branch,"UTF-8"),token);
        String content=e.optString("content","").replace("\\n","").replace("\n","");
        if(!content.isEmpty()){
            byte[] b=Base64.decode(content,Base64.DEFAULT); if(b.length>MAX_PACKAGE) throw new IOException("Optional package too large");
            try(FileOutputStream f=new FileOutputStream(out)){f.write(b);f.getFD().sync();} return;
        }
        String u=e.optString("download_url",""); if(u.isEmpty()) throw new IOException("Optional package download unavailable");
        HttpURLConnection h=open(u,token); try(InputStream in=h.getInputStream();FileOutputStream f=new FileOutputStream(out)){byte[] b=new byte[32768];int n;long total=0;while((n=in.read(b))>0){total+=n;if(total>MAX_PACKAGE)throw new IOException("Optional package too large");f.write(b,0,n);}f.getFD().sync();}finally{h.disconnect();}
    }
    private static byte[] getBytes(String url,String token,int max)throws Exception{HttpURLConnection h=open(url,token);try(InputStream in=h.getInputStream();ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[] b=new byte[16384];int n,total=0;while((n=in.read(b))>0){total+=n;if(total>max)throw new IOException("GitHub response too large");o.write(b,0,n);}return o.toByteArray();}finally{h.disconnect();}}
    private static HttpURLConnection open(String url,String token)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setConnectTimeout(12000);h.setReadTimeout(45000);h.setRequestProperty("Authorization","Bearer "+token);h.setRequestProperty("Accept","application/vnd.github+json");h.setRequestProperty("X-GitHub-Api-Version","2022-11-28");h.setRequestProperty("User-Agent","Lumi-Code470");int code=h.getResponseCode();if(code<200||code>=300){String m="GitHub HTTP "+code;h.disconnect();throw new IOException(m);}return h;}
}
