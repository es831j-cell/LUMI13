package com.distressedelk.lumi;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.File;
import java.util.Calendar;

/** Code407 overnight maintenance. JobScheduler wakes Lumi; no continuous polling loop is used. */
public final class AutonomousMaintenanceJobService extends JobService {
    private static final int JOB_ID=0x4C554D57;
    private static final int DEFAULT_HOUR=2,DEFAULT_MINUTE=30;

    static void scheduleNext(Context c,SharedPreferences p,String reason){
        if(c==null||p==null||!p.getBoolean("code407_overnight_updates_enabled",false))return;
        p.edit().putBoolean("code407_chain_followup_pending",false).apply();
        long now=System.currentTimeMillis();Calendar next=Calendar.getInstance();next.setTimeInMillis(now);
        next.set(Calendar.HOUR_OF_DAY,p.getInt("code407_overnight_hour",DEFAULT_HOUR));next.set(Calendar.MINUTE,p.getInt("code407_overnight_minute",DEFAULT_MINUTE));next.set(Calendar.SECOND,0);next.set(Calendar.MILLISECOND,0);
        if(next.getTimeInMillis()<=now+60000L)next.add(Calendar.DAY_OF_YEAR,1);
        scheduleAt(c,p,Math.max(60000L,next.getTimeInMillis()-now),reason,false);
    }
    static void scheduleSoon(Context c,SharedPreferences p,long delayMs,String reason){
        if(c==null||p==null||!p.getBoolean("code407_overnight_updates_enabled",false))return;
        p.edit().putBoolean("code407_chain_followup_pending",true).apply();scheduleAt(c,p,Math.max(5000L,delayMs),reason,true);
    }
    private static void scheduleAt(Context c,SharedPreferences p,long delay,String reason,boolean chain){
        try{JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js==null)return;
            JobInfo.Builder b=new JobInfo.Builder(JOB_ID,new ComponentName(c,AutonomousMaintenanceJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED).setRequiresCharging(true).setRequiresBatteryNotLow(true).setRequiresStorageNotLow(true).setPersisted(true).setMinimumLatency(delay);
            if(!chain)b.setRequiresDeviceIdle(true);b.setOverrideDeadline(delay+(chain?20L*60L*1000L:3L*60L*60L*1000L));int result=js.schedule(b.build());
            p.edit().putLong("code407_overnight_next_earliest_at",System.currentTimeMillis()+delay).putString("code407_overnight_schedule_reason",reason==null?"":reason).putInt("code407_overnight_schedule_result",result).apply();
            log(c,p,"MAINTENANCE_SCHEDULED","delayMs="+delay+" chain="+chain+" reason="+reason+" result="+result);
        }catch(Throwable t){p.edit().putString("code407_overnight_schedule_error",t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage())).apply();}
    }
    static void cancel(Context c){try{JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js!=null)js.cancel(JOB_ID);}catch(Throwable ignored){}}

    @Override public boolean onStartJob(JobParameters params){SharedPreferences p=getSharedPreferences("lumi",MODE_PRIVATE);new Thread(()->runMaintenance(params,p),"LumiCode407OvernightMaintenance").start();return true;}
    private void runMaintenance(JobParameters params,SharedPreferences p){
        try{
            if(!p.getBoolean("code407_overnight_updates_enabled",false)){finish(params,p,"Overnight maintenance skipped because owner authorization is off.");return;}
            DeviceHealthEngine.Readiness ready=DeviceHealthEngine.assessUpdateReadiness(this,p,true);if(!ready.safe){finish(params,p,"Overnight update postponed: "+ready.reason+".");return;}
            p.edit().putBoolean("code407_overnight_update_in_progress",true).putLong("code407_overnight_update_started_at",System.currentTimeMillis()).putString("code407_maintenance_stage","DISCOVERY").apply();
            JSONObject check=TrustedBuildRelayClient.checkPublishedUpdate(this,p,true);String state=check.optString("state",p.getString("github_update_check_state","UNKNOWN"));
            if("UP_TO_DATE".equals(state)||"NO_PUBLISHED_UPDATE".equals(state)){finish(params,p,"Overnight maintenance checked for updates; Lumi is already current.");return;}
            File cached=TrustedBuildRelayClient.publishedUpdatePackageFile(this,p);if(!"UPDATE_DOWNLOADED".equals(state)||cached==null||!cached.isFile()){finish(params,p,"Overnight maintenance could not stage an update. Discovery state: "+state+".");return;}
            p.edit().putString("code407_maintenance_stage","VERIFY_AND_STAGE").apply();LumiUpdateManager.Result applied=LumiUpdateManager.applyTrustedPackageBlocking(this,p,cached,null);
            log(this,p,"OVERNIGHT_PACKAGE_STAGED","id="+applied.updateId+" coreReady="+applied.coreInstallReady);if(!applied.coreInstallReady){finish(params,p,"Update package applied, but no core APK installation was required.");return;}
            DeviceHealthEngine.Readiness second=DeviceHealthEngine.assessUpdateReadiness(this,p,true);if(!second.safe){finish(params,p,"Update was verified and staged, but installation was postponed: "+second.reason+".");return;}
            p.edit().putString("code407_maintenance_stage","PACKAGE_INSTALLER_COMMIT").apply();LumiInstallStatusReceiver.commitPendingSelfUpdate(this,p,true);
            p.edit().putString("code407_last_maintenance_result","Verified update committed to Android PackageInstaller.").putBoolean("code407_maintenance_report_pending",true).putString("code407_maintenance_stage","INSTALL_COMMITTED").apply();
            log(this,p,"OVERNIGHT_INSTALL_COMMITTED","PackageInstaller commit complete");jobFinished(params,false);
        }catch(Throwable t){finish(params,p,"Overnight maintenance failed safely: "+t.getClass().getSimpleName()+": "+safe(t.getMessage()));}
    }
    private void finish(JobParameters params,SharedPreferences p,String result){p.edit().putBoolean("code407_overnight_update_in_progress",false).putString("code407_last_maintenance_result",result).putLong("code407_last_maintenance_at",System.currentTimeMillis()).putBoolean("code407_maintenance_report_pending",true).putString("code407_maintenance_stage","IDLE").apply();log(this,p,"OVERNIGHT_MAINTENANCE_COMPLETE",result);jobFinished(params,false);scheduleNext(this,p,"post-run");}
    @Override public boolean onStopJob(JobParameters params){SharedPreferences p=getSharedPreferences("lumi",MODE_PRIVATE);p.edit().putString("code407_last_maintenance_result","Android paused overnight maintenance; it will be retried later.").putBoolean("code407_overnight_update_in_progress",false).apply();return true;}
    private static void log(Context c,SharedPreferences p,String a,String d){try{DeveloperFlightRecorder.record(c,p,-1L,"MAINTENANCE",a,d,"github-native-update","","code407-overnight",false,false,false);}catch(Throwable ignored){}}
    private static String safe(String s){return s==null?"":s.replace('\n',' ').replace('\r',' ').trim();}
}
