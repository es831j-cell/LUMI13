package com.distressedelk.lumi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/** Dedicated Android ACTION_ASSIST entry point used by system/default-assistant discovery. */
public final class LumiAssistActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Intent i=new Intent(this,MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra("lumi_system_assistant_invocation",true);
        startActivity(i);
        finish();
    }
}
