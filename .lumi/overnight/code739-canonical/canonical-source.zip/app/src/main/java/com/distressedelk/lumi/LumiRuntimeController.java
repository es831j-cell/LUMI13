package com.distressedelk.lumi;

/**
 * Code661: read-only runtime observer.
 * ConversationRuntimeState is the only conversation-state authority. This class no longer
 * derives a competing shadow state. It records legacy-signal contradictions without producing
 * another state decision that can disagree with Core.
 */
final class LumiRuntimeController {
    static final String MARKER="CODE661_SINGLE_RUNTIME_AUTHORITY";
    enum State { IDLE, LISTENING, THINKING, SPEAKING, INTERRUPTED, STOPPED, RECOVERING }

    static final class Snapshot {
        final long sequence;
        final long atMs;
        final State authoritative;
        final State shadow;
        final int generation;
        final String recognizerPhase;
        final boolean conversationMode;
        final boolean aiBusy;
        final boolean ttsSpeaking;
        final boolean recoveryCircuitOpen;
        final boolean manualStop;
        final boolean stateDivergence;
        final boolean legacyContradiction;
        final String reason;

        Snapshot(long sequence,long atMs,State authoritative,State shadow,int generation,
                 String recognizerPhase,boolean conversationMode,boolean aiBusy,
                 boolean ttsSpeaking,boolean recoveryCircuitOpen,boolean manualStop,
                 boolean stateDivergence,boolean legacyContradiction,String reason){
            this.sequence=sequence; this.atMs=atMs; this.authoritative=authoritative;
            this.shadow=shadow; this.generation=generation;
            this.recognizerPhase=recognizerPhase==null?"UNKNOWN":recognizerPhase;
            this.conversationMode=conversationMode; this.aiBusy=aiBusy;
            this.ttsSpeaking=ttsSpeaking; this.recoveryCircuitOpen=recoveryCircuitOpen;
            this.manualStop=manualStop; this.stateDivergence=stateDivergence;
            this.legacyContradiction=legacyContradiction; this.reason=reason==null?"":reason;
        }

        String uiLabel(){
            switch(authoritative){
                case LISTENING: return "Listening";
                case THINKING: return "Thinking";
                case SPEAKING: return "Speaking";
                case RECOVERING: return "Connecting...";
                case INTERRUPTED:
                case STOPPED:
                case IDLE:
                default: return "Ready";
            }
        }

        String compact(){
            return "seq="+sequence+" auth="+authoritative+" observer="+shadow+" gen="+generation
                    +" phase="+recognizerPhase+" conversationMode="+conversationMode
                    +" aiBusy="+aiBusy+" tts="+ttsSpeaking+" circuit="+recoveryCircuitOpen
                    +" manualStop="+manualStop+" divergence="+stateDivergence
                    +" legacyContradiction="+legacyContradiction+" reason="+reason;
        }
    }

    private long sequence=0L;
    private Snapshot latest=new Snapshot(0L,System.currentTimeMillis(),State.IDLE,State.IDLE,0,
            "IDLE",false,false,false,false,false,false,false,"init");
    private String lastFingerprint="";

    synchronized Snapshot observe(String runtimeState,int generation,String recognizerPhase,
                                  boolean conversationMode,boolean aiBusy,boolean ttsSpeaking,
                                  boolean recoveryCircuitOpen,boolean manualStop,String reason){
        State authoritative=parse(runtimeState);
        // Code661: no second state machine. The observer mirrors Core authority exactly.
        State observer=authoritative;
        boolean divergence=false;
        boolean legacyContradiction=(authoritative==State.IDLE && conversationMode)
                || (authoritative==State.SPEAKING && !ttsSpeaking)
                || (authoritative==State.LISTENING && (recognizerPhase==null || "IDLE".equals(recognizerPhase)))
                || (authoritative==State.THINKING && !aiBusy)
                || (manualStop && authoritative!=State.STOPPED);
        latest=new Snapshot(++sequence,System.currentTimeMillis(),authoritative,observer,generation,
                recognizerPhase,conversationMode,aiBusy,ttsSpeaking,recoveryCircuitOpen,manualStop,
                divergence,legacyContradiction,reason);
        return latest;
    }

    synchronized Snapshot latest(){ return latest; }

    synchronized boolean changedSinceLastRecord(){
        String fp=latest.authoritative+"|"+latest.generation+"|"+latest.recognizerPhase
                +"|"+latest.conversationMode+"|"+latest.aiBusy+"|"+latest.ttsSpeaking+"|"
                +latest.recoveryCircuitOpen+"|"+latest.manualStop+"|"+latest.legacyContradiction;
        if(fp.equals(lastFingerprint)) return false;
        lastFingerprint=fp;
        return true;
    }

    private static State parse(String value){
        if(value!=null){
            try { return State.valueOf(value); } catch(Exception ignored){}
        }
        return State.IDLE;
    }
}
