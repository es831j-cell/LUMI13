package com.distressedelk.lumi;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Lumi 1.0 persistent memory vault.
 *
 * The vault is deliberately independent from any OpenAI/local-model session.  Model sessions
 * may come and go; the relationship history remains in this on-device database.  No API keys,
 * tokens, passwords or signing secrets are accepted by this class.
 */
final class LumiMemoryVault extends SQLiteOpenHelper {
    private static final String DB_NAME = "lumi_memory_vault.db";
    private static final int DB_VERSION = 1;
    private static volatile LumiMemoryVault instance;
    private final Context app;

    static LumiMemoryVault get(Context context) {
        if (instance == null) {
            synchronized (LumiMemoryVault.class) {
                if (instance == null) instance = new LumiMemoryVault(context.getApplicationContext());
            }
        }
        return instance;
    }

    private LumiMemoryVault(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        app = context;
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, scope TEXT NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL, source TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_events_ts ON events(ts DESC)");
        db.execSQL("CREATE INDEX idx_events_scope ON events(scope, ts DESC)");
        db.execSQL("CREATE TABLE memories (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, category TEXT NOT NULL, memory_key TEXT NOT NULL, value TEXT NOT NULL, importance INTEGER NOT NULL DEFAULT 50, source TEXT NOT NULL, UNIQUE(category,memory_key) ON CONFLICT REPLACE)");
        db.execSQL("CREATE INDEX idx_memories_category ON memories(category, ts DESC)");
        db.execSQL("CREATE TABLE ledger (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, kind TEXT NOT NULL, summary TEXT NOT NULL, detail TEXT NOT NULL, transaction_id TEXT NOT NULL DEFAULT '', prev_hash TEXT NOT NULL DEFAULT '', record_hash TEXT NOT NULL DEFAULT '', chain_version INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE INDEX idx_ledger_ts ON ledger(ts DESC)");
        db.execSQL("CREATE TABLE meta (meta_key TEXT PRIMARY KEY, meta_value TEXT NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // v1 is the launch schema. Future schema changes must be forward migrations, never DROP.
        if (oldVersion < 1) onCreate(db);
    }

    synchronized void initializeFromLegacy(android.content.SharedPreferences prefs) {
        SQLiteDatabase db = getWritableDatabase();
        ensureAuditSchema(db);
        if (!"1".equals(meta(db, "legacy_import_complete"))) {
            String normal = prefs.getString("talk_transcript", "");
            importLegacyTranscript(db, normal, "general");
            String learned = prefs.getString("learned_facts", "").trim();
            if (!learned.isEmpty()) upsertMemory(db, "learned", "legacy_learned_facts", learned, 70, "legacy-preferences");
            String people = prefs.getString("people_cards_json", "").trim();
            if (!people.isEmpty() && !"[]".equals(people)) upsertMemory(db, "people", "legacy_people_cards", people, 75, "legacy-preferences");
            String ownerNotes = prefs.getString("owner_intro_notes", "").trim();
            if (!ownerNotes.isEmpty()) upsertMemory(db, "identity", "owner_intro_notes", ownerNotes, 95, "legacy-preferences");
            setMeta(db, "legacy_import_complete", "1");
            appendLedger(db, "migration", "Imported legacy Lumi memory into Memory Vault", "Preference transcript/memory migration completed.", "");
        }
        if (!"1".equals(meta(db, "launch_seed_import_complete"))) {
            try {
                String seed = readAsset("lumi-memory-seed.txt");
                if (!seed.trim().isEmpty()) upsertMemory(db, "project_history", "lumi_launch_history_seed", seed, 90, "Lumi-1.0-launch-seed");
            } catch (Exception ignored) {}
            setMeta(db, "launch_seed_import_complete", "1");
        }
        setMeta(db, "schema", "1");
        if (!"1".equals(meta(db,"code352_credential_scrub_complete"))) {
            scrubCredentialResidue(db);
            setMeta(db,"code352_credential_scrub_complete","1");
        }
    }

    private void scrubCredentialResidue(SQLiteDatabase db){
        db.beginTransaction();
        try{
            Cursor e=db.query("events",new String[]{"id","content"},null,null,null,null,null);
            try{ while(e.moveToNext()){ long id=e.getLong(0); String raw=PrivateStore.decrypt(e.getString(1)); String clean=SecretStore.redact(raw); if(!clean.equals(raw)){ ContentValues v=new ContentValues();v.put("content",PrivateStore.encrypt(clean));db.update("events",v,"id=?",new String[]{String.valueOf(id)}); } } }finally{e.close();}
            Cursor m=db.query("memories",new String[]{"id","value"},null,null,null,null,null);
            try{ while(m.moveToNext()){ long id=m.getLong(0); String raw=PrivateStore.decrypt(m.getString(1)); if(SecretStore.looksLikeCredential(raw)){db.delete("memories","id=?",new String[]{String.valueOf(id)});continue;} String clean=SecretStore.redact(raw); if(!clean.equals(raw)){ContentValues v=new ContentValues();v.put("value",PrivateStore.encrypt(clean));db.update("memories",v,"id=?",new String[]{String.valueOf(id)});} } }finally{m.close();}
            Cursor l=db.query("ledger",new String[]{"id","summary","detail"},null,null,null,null,null);
            try{ while(l.moveToNext()){ long id=l.getLong(0); String sr=PrivateStore.decrypt(l.getString(1)), dr=PrivateStore.decrypt(l.getString(2)); String sc=SecretStore.redact(sr), dc=SecretStore.redact(dr); if(!sc.equals(sr)||!dc.equals(dr)){ContentValues v=new ContentValues();v.put("summary",PrivateStore.encrypt(sc));v.put("detail",PrivateStore.encrypt(dc));db.update("ledger",v,"id=?",new String[]{String.valueOf(id)});} } }finally{l.close();}
            // CODE469: credential scrub can change historical ciphertext. Never rebuild the
            // complete hash chain on the caller/UI path. Mark it pending and repair asynchronously.
            if(ensureAuditSchema(db)) {
                setMeta(db,"audit_ledger_chain_v1_complete","0");
                setMeta(db,"audit_ledger_cached_valid","false");
                scheduleAuditMaintenance();
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    synchronized void recordTurn(String role, String content) {
        if (content == null || content.trim().isEmpty()) return;
        ContentValues v = new ContentValues();
        v.put("ts", System.currentTimeMillis());
        v.put("scope", "general");
        v.put("role", role == null ? "unknown" : role);
        v.put("content", PrivateStore.encrypt(bounded(SecretStore.redact(content.trim()), 20000)));
        v.put("source", "conversation");
        getWritableDatabase().insertOrThrow("events", null, v);
        pruneEvents(getWritableDatabase());
    }

    synchronized void remember(String category, String key, String value, int importance, String source) {
        rememberVerified(category,key,value,importance,source);
    }

    /** Code433: every durable memory write is synchronous and read back before success is reported. */
    synchronized boolean rememberVerified(String category,String key,String value,int importance,String source) {
        if(value==null || value.trim().isEmpty()) return false;
        if(SecretStore.looksLikeCredential(key) || SecretStore.looksLikeCredential(value) || looksSecret(key) || looksSecret(value)) return false;
        String cat=safe(category,"general");
        String k=safe(key,"memory-"+System.currentTimeMillis());
        String expected=bounded(value.trim(),100000);
        try{
            SQLiteDatabase db=getWritableDatabase();
            upsertMemory(db,cat,k,expected,clamp(importance,1,100),safe(source,"conversation"));
            String actual=recallMemoryInternal(db,cat,k);
            boolean ok=expected.equals(actual);
            appendLedger(db,ok?"memory-write-verified":"memory-write-failed",
                    ok?"Persistent memory write verified":"Persistent memory readback mismatch",
                    cat+"/"+k+" source="+safe(source,"conversation"),"");
            return ok;
        }catch(Throwable ignored){ return false; }
    }

    synchronized String recallMemory(String category,String key) {
        if(category==null || key==null) return "";
        try{return recallMemoryInternal(getReadableDatabase(),safe(category,"general"),safe(key,""));}
        catch(Throwable ignored){return "";}
    }

    private String recallMemoryInternal(SQLiteDatabase db,String category,String key){
        Cursor c=db.query("memories",new String[]{"value"},"category=? AND memory_key=?",new String[]{category,key},null,null,"ts DESC","1");
        try{return c.moveToFirst()?PrivateStore.decrypt(c.getString(0)):"";}finally{c.close();}
    }

    synchronized void ledger(String kind, String summary, String detail, String transactionId) {
        appendLedger(getWritableDatabase(), safe(kind, "event"), bounded(safe(summary, "Lumi event"), 1000), bounded(safe(detail, ""), 20000), bounded(safe(transactionId, ""), 200));
    }

    synchronized String contextPacket(String query, int maxChars) {
        int cap = clamp(maxChars, 1000, 16000);
        StringBuilder out = new StringBuilder();
        out.append("Persistent Lumi Memory Vault context:\n");
        ArrayList<String> terms = queryTerms(query);
        SQLiteDatabase db = getReadableDatabase();

        // Values are encrypted at rest, so relevance filtering happens after decryption in-process.
        Cursor m = db.query("memories", new String[]{"category","memory_key","value","importance"}, null,
                null, null, null, "importance DESC, ts DESC", "80");
        ArrayList<String> fallback = new ArrayList<>();
        try {
            while (m.moveToNext()) {
                String category=m.getString(0), key=m.getString(1), value=SecretStore.redact(PrivateStore.decrypt(m.getString(2)));
                if(value.isEmpty()) continue;
                String hay=(category+" "+key+" "+value).toLowerCase(Locale.US);
                boolean relevant=terms.isEmpty();
                for(String term:terms) if(hay.contains(term.toLowerCase(Locale.US))){ relevant=true; break; }
                String line="- ["+category+"] "+key+": "+value+"\n";
                if(relevant && out.length()<cap) appendBounded(out,line,cap);
                else if(fallback.size()<10) fallback.add(line);
            }
        } finally { m.close(); }
        if(out.length()<120 && !fallback.isEmpty()) for(String line:fallback) if(out.length()<cap) appendBounded(out,line,cap);

        String scopeSel = "scope='general'";
        Cursor e = db.query("events", new String[]{"role","content"}, scopeSel, null, null, null, "ts DESC", "24");
        ArrayList<String> recent = new ArrayList<>();
        try { while(e.moveToNext()) { String text=SecretStore.redact(PrivateStore.decrypt(e.getString(1))); if(!text.isEmpty())recent.add(e.getString(0)+": "+text); } } finally { e.close(); }
        if (!recent.isEmpty() && out.length()<cap) {
            appendBounded(out, "Recent cross-session continuity:\n", cap);
            for (int i=recent.size()-1;i>=0 && out.length()<cap;i--) appendBounded(out, recent.get(i)+"\n", cap);
        }
        return bounded(out.toString(), cap);
    }


    synchronized void purgePrivateModeData(){
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try{
            db.delete("events","scope=?",new String[]{"private"});
            db.delete("memories","lower(category)=? OR lower(memory_key) LIKE ?",new String[]{"private","private%"});
            setMeta(db,"private_mode_purged_at",String.valueOf(System.currentTimeMillis()));
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    /**
     * Create a consistent SQLite snapshot without decrypting/re-serializing vault rows.
     * Sensitive content remains in the exact per-field AES-GCM ciphertext already stored on disk.
     */
    synchronized JSONObject checkpointCiphertextSnapshot(File destination) throws Exception {
        if (destination == null) throw new IllegalArgumentException("Memory Vault checkpoint destination unavailable");
        File parent = destination.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new java.io.IOException("Could not create Memory Vault checkpoint directory");
        if (destination.exists() && !destination.delete()) throw new java.io.IOException("Could not replace prior Memory Vault checkpoint file");

        SQLiteDatabase db = getWritableDatabase();
        Cursor wal = db.rawQuery("PRAGMA wal_checkpoint(FULL)", null);
        try { while (wal.moveToNext()) { /* force committed WAL content into the snapshot view */ } } finally { wal.close(); }
        db.execSQL("VACUUM INTO " + DatabaseUtils.sqlEscapeString(destination.getAbsolutePath()));
        if (!destination.isFile() || destination.length() <= 0L) throw new java.io.IOException("Memory Vault checkpoint file was not created");

        JSONObject meta = new JSONObject();
        meta.put("format", "LumiMemoryVaultCiphertextSnapshot");
        meta.put("formatVersion", 1);
        meta.put("schemaVersion", DB_VERSION);
        meta.put("bytes", destination.length());
        meta.put("events", count(db,"events"));
        meta.put("memories", count(db,"memories"));
        meta.put("ledgerEntries", count(db,"ledger"));
        return meta;
    }

    /** Restore a previously integrity-checked ciphertext-preserving SQLite snapshot. */
    synchronized void restoreCiphertextSnapshot(File source) throws Exception {
        if (source == null || !source.isFile() || source.length() <= 0L) throw new java.io.FileNotFoundException("Memory Vault checkpoint database is missing");
        File live = app.getDatabasePath(DB_NAME);
        File parent = live.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) throw new java.io.IOException("Could not create Memory Vault database directory");
        File temp = new File(parent, DB_NAME + ".restore.tmp");
        File backup = new File(parent, DB_NAME + ".restore.previous");
        deleteQuietly(temp); deleteQuietly(backup);

        close();
        copySync(source,temp);
        verifyDatabaseFile(temp);
        deleteSidecars(live);

        boolean hadLive=live.exists();
        if (hadLive && !live.renameTo(backup)) { deleteQuietly(temp); throw new java.io.IOException("Could not stage current Memory Vault for restore"); }
        if (!temp.renameTo(live)) {
            if (hadLive) backup.renameTo(live);
            throw new java.io.IOException("Could not promote recovered Memory Vault");
        }

        try {
            verifyDatabaseFile(live);
            getWritableDatabase();
            deleteQuietly(backup);
        } catch (Throwable failure) {
            close();
            deleteQuietly(live);
            if (hadLive) backup.renameTo(live);
            deleteSidecars(live);
            getWritableDatabase();
            if (failure instanceof Exception) throw (Exception) failure;
            throw new java.io.IOException("Recovered Memory Vault failed validation", failure);
        }
    }

    private static void copySync(File source, File destination) throws Exception {
        byte[] buffer=new byte[1024*1024];
        try(FileInputStream in=new FileInputStream(source); FileOutputStream out=new FileOutputStream(destination)){
            int n; while((n=in.read(buffer))>0) out.write(buffer,0,n);
            out.getFD().sync();
        }
    }

    private static void verifyDatabaseFile(File file) throws Exception {
        SQLiteDatabase verify=SQLiteDatabase.openDatabase(file.getAbsolutePath(),null,SQLiteDatabase.OPEN_READONLY);
        try {
            Cursor c=verify.rawQuery("PRAGMA integrity_check",null);
            try { if(!c.moveToFirst() || !"ok".equalsIgnoreCase(c.getString(0))) throw new SecurityException("Memory Vault SQLite integrity check failed"); }
            finally { c.close(); }
            for(String table:new String[]{"events","memories","ledger","meta"}) {
                Cursor t=verify.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",new String[]{table});
                try { if(!t.moveToFirst()) throw new SecurityException("Memory Vault checkpoint missing table "+table); } finally { t.close(); }
            }
        } finally { verify.close(); }
    }

    private static void deleteSidecars(File live) {
        deleteQuietly(new File(live.getAbsolutePath()+"-wal"));
        deleteQuietly(new File(live.getAbsolutePath()+"-shm"));
        deleteQuietly(new File(live.getAbsolutePath()+"-journal"));
    }

    private static void deleteQuietly(File file) { try { if(file!=null && file.exists()) file.delete(); } catch(Throwable ignored){} }

    synchronized JSONObject exportJson() throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "LumiMemoryVault");
        root.put("schemaVersion", DB_VERSION);
        root.put("exportedAt", System.currentTimeMillis());
        SQLiteDatabase db = getReadableDatabase();
        root.put("events", exportEvents(db));
        root.put("memories", exportMemories(db));
        root.put("ledger", exportLedger(db));
        return root;
    }


    synchronized void importJson(JSONObject root) throws Exception {
        if (root == null || !"LumiMemoryVault".equals(root.optString("format"))) throw new IllegalArgumentException("Not a Lumi Memory Vault export");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            JSONArray events = root.optJSONArray("events");
            if (events != null) for(int i=0;i<events.length();i++) {
                JSONObject x=events.getJSONObject(i); ContentValues v=new ContentValues();
                if("private".equalsIgnoreCase(x.optString("scope","general"))) continue;
                v.put("ts",x.optLong("ts",System.currentTimeMillis())); v.put("scope","general");
                v.put("role",safe(x.optString("role"),"unknown")); v.put("content",PrivateStore.encrypt(bounded(SecretStore.redact(x.optString("content")),20000))); v.put("source","portable-restore");
                db.insert("events",null,v);
            }
            JSONArray memories = root.optJSONArray("memories");
            if (memories != null) for(int i=0;i<memories.length();i++) {
                JSONObject x=memories.getJSONObject(i);
                String key=x.optString("memory_key",""); String value=x.optString("value","");
                if (!SecretStore.looksLikeCredential(key) && !SecretStore.looksLikeCredential(value) && !looksSecret(key) && !looksSecret(value)) upsertMemory(db,safe(x.optString("category"),"restored"),safe(key,"restored-"+i),bounded(value,100000),clamp(x.optInt("importance",50),1,100),"portable-restore");
            }
            JSONArray ledger = root.optJSONArray("ledger");
            if (ledger != null) for(int i=0;i<ledger.length();i++) {
                JSONObject x=ledger.getJSONObject(i); appendLedger(db,safe(x.optString("kind"),"restored"),bounded(SecretStore.redact(x.optString("summary")),1000),bounded(SecretStore.redact(x.optString("detail")),20000),bounded(x.optString("transaction_id"),200));
            }
            setMeta(db,"last_restore_at",String.valueOf(System.currentTimeMillis()));
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
        pruneEvents(db);
    }

    synchronized JSONObject stats() {
        JSONObject o = new JSONObject(); SQLiteDatabase db=getWritableDatabase();
        try {
            boolean auditReady=ensureAuditSchema(db);
            scheduleAuditMaintenance();
            JSONObject audit=auditReady?cachedAuditStatus(db):new JSONObject().put("valid",false).put("pending",true).put("error","audit schema unavailable");
            o.put("events", count(db,"events")); o.put("memories", count(db,"memories")); o.put("ledgerEntries", count(db,"ledger")); o.put("schemaVersion",DB_VERSION);
            o.put("auditChainVersion",1).put("auditChainValid",audit.optBoolean("valid",false)).put("auditChainPending",audit.optBoolean("pending",true))
                    .put("auditHeadSha256",audit.optString("headHash","")).put("auditFirstBrokenId",audit.optLong("firstBrokenId",-1L))
                    .put("auditVerifiedEntries",audit.optLong("entries",0L)).put("auditLastVerifiedAt",audit.optLong("verifiedAt",0L))
                    .put("auditVerifyMs",audit.optLong("verifyMs",-1L)).put("auditVerifyThread",audit.optString("verifyThread","pending"));
            o.put("ready",true);
        } catch(Exception e) { try{o.put("ready",false);o.put("error",e.getClass().getSimpleName());}catch(Exception ignored){} }
        return o;
    }

    synchronized JSONObject auditStatus(){
        SQLiteDatabase db=getWritableDatabase();
        try{ if(!ensureAuditSchema(db)) return new JSONObject().put("valid",false).put("pending",true).put("error","audit schema unavailable"); scheduleAuditMaintenance(); return cachedAuditStatus(db); }
        catch(Throwable t){ try{return new JSONObject().put("valid",false).put("pending",true).put("error",t.getClass().getSimpleName());}catch(Exception ignored){return new JSONObject();} }
    }

    synchronized String recentLedger(int limit) {
        StringBuilder s=new StringBuilder(); Cursor c=getReadableDatabase().query("ledger",new String[]{"ts","kind","summary","detail","transaction_id"},null,null,null,null,"ts DESC",String.valueOf(clamp(limit,1,50)));
        try { while(c.moveToNext()) { String summary=SecretStore.redact(PrivateStore.decrypt(c.getString(2)));String detail=SecretStore.redact(PrivateStore.decrypt(c.getString(3)));s.append(c.getLong(0)).append(" | ").append(c.getString(1)).append(" | ").append(summary); if(!c.getString(4).isEmpty())s.append(" | tx=").append(c.getString(4)); if(!detail.isEmpty())s.append(" | ").append(detail); s.append('\n'); } }
        finally { c.close(); }
        return s.toString();
    }


    private void importLegacyTranscript(SQLiteDatabase db, String transcript, String scope) {
        if (transcript == null || transcript.trim().isEmpty()) return;
        String[] lines=transcript.split("\\r?\\n");
        for(String line:lines){ String t=line.trim(); if(t.isEmpty())continue; String role="legacy"; String content=t; int p=t.indexOf(':'); if(p>0&&p<20){role=t.substring(0,p).trim();content=t.substring(p+1).trim();}
            ContentValues v=new ContentValues();v.put("ts",System.currentTimeMillis());v.put("scope",scope);v.put("role",role);v.put("content",PrivateStore.encrypt(bounded(SecretStore.redact(content),20000)));v.put("source","legacy-transcript");db.insert("events",null,v); }
    }

    private void upsertMemory(SQLiteDatabase db,String category,String key,String value,int importance,String source){ ContentValues v=new ContentValues();v.put("ts",System.currentTimeMillis());v.put("category",category);v.put("memory_key",key);v.put("value",PrivateStore.encrypt(value));v.put("importance",importance);v.put("source",source);db.insertWithOnConflict("memories",null,v,SQLiteDatabase.CONFLICT_REPLACE); }
    private void appendLedger(SQLiteDatabase db,String kind,String summary,String detail,String tx){
        long ts=System.currentTimeMillis();
        String k=safe(kind,"event"), s=bounded(summary==null?"":summary,1000), d=bounded(detail==null?"":detail,20000), transaction=bounded(tx==null?"":tx,200);
        boolean schemaReady=ensureAuditSchema(db);
        boolean chained=schemaReady && "1".equals(meta(db,"audit_ledger_chain_v1_complete"));
        String previous=chained?safeHash(meta(db,"audit_ledger_head_sha256")):"";
        if(chained && previous.isEmpty()) previous=lastLedgerHash(db);
        if(chained && previous.isEmpty()) previous=AUDIT_GENESIS;
        String hash=chained?ledgerHash(ts,k,s,d,transaction,previous):"";
        ContentValues row=new ContentValues();row.put("ts",ts);row.put("kind",k);row.put("summary",PrivateStore.encrypt(s));row.put("detail",PrivateStore.encrypt(d));row.put("transaction_id",transaction);
        if(chained){row.put("prev_hash",previous);row.put("record_hash",hash);row.put("chain_version",1);}
        db.insertOrThrow("ledger",null,row);
        if(chained){
            setMeta(db,"audit_ledger_chain_version","1");setMeta(db,"audit_ledger_head_sha256",hash);setMeta(db,"audit_ledger_last_append_at",String.valueOf(ts));
            setMeta(db,"audit_ledger_cached_valid","true");setMeta(db,"audit_ledger_cached_entries",String.valueOf(count(db,"ledger")));
        } else if(schemaReady) scheduleAuditMaintenance();
    }
    private JSONArray exportEvents(SQLiteDatabase db)throws Exception{JSONArray a=new JSONArray();Cursor c=db.query("events",new String[]{"ts","scope","role","content","source"},null,null,null,null,"ts ASC","12000");try{while(c.moveToNext()){a.put(new JSONObject().put("ts",c.getLong(0)).put("scope",c.getString(1)).put("role",c.getString(2)).put("content",SecretStore.redact(PrivateStore.decrypt(c.getString(3)))).put("source",c.getString(4)));}}finally{c.close();}return a;}
    private JSONArray exportMemories(SQLiteDatabase db)throws Exception{JSONArray a=new JSONArray();Cursor c=db.query("memories",new String[]{"ts","category","memory_key","value","importance","source"},null,null,null,null,"ts ASC","4000");try{while(c.moveToNext()){a.put(new JSONObject().put("ts",c.getLong(0)).put("category",c.getString(1)).put("memory_key",c.getString(2)).put("value",SecretStore.redact(PrivateStore.decrypt(c.getString(3)))).put("importance",c.getInt(4)).put("source",c.getString(5)));}}finally{c.close();}return a;}
    private JSONArray exportLedger(SQLiteDatabase db)throws Exception{ensureAuditSchema(db);scheduleAuditMaintenance();JSONArray a=new JSONArray();Cursor c=db.query("ledger",new String[]{"ts","kind","summary","detail","transaction_id","prev_hash","record_hash","chain_version"},null,null,null,null,"ts ASC","5000");try{while(c.moveToNext()){a.put(new JSONObject().put("ts",c.getLong(0)).put("kind",c.getString(1)).put("summary",SecretStore.redact(PrivateStore.decrypt(c.getString(2)))).put("detail",SecretStore.redact(PrivateStore.decrypt(c.getString(3)))).put("transaction_id",c.getString(4)).put("prev_hash",c.getString(5)).put("record_hash",c.getString(6)).put("chain_version",c.getInt(7)));}}finally{c.close();}return a;}

    // CODE468 R186 AUDIT_LEDGER_CHAIN_V1
    // Additive columns intentionally leave SQLite user_version at 1 for signed Code467 rollback compatibility.
    private static final String AUDIT_GENESIS="0000000000000000000000000000000000000000000000000000000000000000";

    private boolean ensureAuditSchema(SQLiteDatabase db){
        try{
            if(!hasColumn(db,"ledger","prev_hash")) db.execSQL("ALTER TABLE ledger ADD COLUMN prev_hash TEXT NOT NULL DEFAULT ''");
            if(!hasColumn(db,"ledger","record_hash")) db.execSQL("ALTER TABLE ledger ADD COLUMN record_hash TEXT NOT NULL DEFAULT ''");
            if(!hasColumn(db,"ledger","chain_version")) db.execSQL("ALTER TABLE ledger ADD COLUMN chain_version INTEGER NOT NULL DEFAULT 0");
            return true;
        }catch(Throwable ignored){ return false; }
    }

    // CODE496 R214 VAULT_AUDIT_LOCK_ISOLATION
    // The Code495 Black Box proved the full audit-chain verifier can take ~25-30 seconds.
    // It used to hold LumiMemoryVault.this for the entire scan, so any synchronized foreground
    // memory/ledger call could block Android's interactive lane long enough to trigger an ANR.
    // Claim/release state is still serialized, but the expensive verification runs from an
    // in-memory ciphertext snapshot with no vault monitor and no long-lived SQLite cursor.
    private volatile boolean auditMaintenanceRunning=false;
    private volatile long auditMaintenanceLastAttemptAt=0L;
    private static final long AUDIT_VERIFY_MIN_INTERVAL_MS=15L*60L*1000L;

    private void scheduleAuditMaintenance(){
        final long requestedAt=System.currentTimeMillis();
        synchronized(this){
            if(auditMaintenanceRunning)return;
            boolean complete=false; long verifiedAt=0L;
            try{
                SQLiteDatabase claimDb=getWritableDatabase();
                complete="1".equals(meta(claimDb,"audit_ledger_chain_v1_complete"));
                verifiedAt=parseLongMeta(meta(claimDb,"audit_ledger_cached_verified_at"),0L);
            }catch(Throwable ignored){}
            // A verified complete chain does not need a 25-30 second full scan on every health snapshot.
            if(complete && verifiedAt>0L && requestedAt-verifiedAt<AUDIT_VERIFY_MIN_INTERVAL_MS) return;
            if(complete && auditMaintenanceLastAttemptAt>0L
                    && requestedAt-auditMaintenanceLastAttemptAt<AUDIT_VERIFY_MIN_INTERVAL_MS) return;
            auditMaintenanceRunning=true;
            auditMaintenanceLastAttemptAt=requestedAt;
        }
        new Thread(() -> {
            long started=System.currentTimeMillis();
            String thread=Thread.currentThread().getName();
            boolean stableSnapshot=false;
            long snapshotMs=-1L;
            try{
                SQLiteDatabase db=getWritableDatabase();
                if(!ensureAuditSchema(db)) return;

                // Legacy/incomplete-chain migration remains serialized because it mutates every ledger row.
                // Normal Code495+ runtime already has a complete chain and never enters this branch.
                if(!"1".equals(meta(db,"audit_ledger_chain_v1_complete"))){
                    synchronized(LumiMemoryVault.this){
                        SQLiteDatabase migrationDb=getWritableDatabase();
                        if(!"1".equals(meta(migrationDb,"audit_ledger_chain_v1_complete"))){
                            rebuildLedgerChain(migrationDb);
                            setMeta(migrationDb,"audit_ledger_chain_v1_complete","1");
                            setMeta(migrationDb,"audit_ledger_chain_migrated_at",String.valueOf(System.currentTimeMillis()));
                        }
                    }
                }

                long snapshotStarted=System.currentTimeMillis();
                AuditLedgerSnapshot snapshot=captureAuditLedgerSnapshot(db);
                snapshotMs=Math.max(0L,System.currentTimeMillis()-snapshotStarted);

                // CPU-heavy decrypt + SHA-256 walk happens only after the SQLite cursor is closed.
                JSONObject audit=auditStatusFromSnapshot(snapshot);
                long finished=System.currentTimeMillis();

                // A concurrent append is legitimate. Never publish a stale full-scan result over a newer head.
                long liveEntries=count(db,"ledger");
                String liveHead=safeHash(meta(db,"audit_ledger_head_sha256"));
                stableSnapshot=liveEntries==snapshot.entries
                        && safeHash(snapshot.headHash).equals(liveHead)
                        && audit.optLong("entries",-1L)==snapshot.entries
                        && safeHash(audit.optString("headHash","")).equals(safeHash(snapshot.headHash));

                if(stableSnapshot){
                    synchronized(LumiMemoryVault.this){
                        SQLiteDatabase cacheDb=getWritableDatabase();
                        long currentEntries=count(cacheDb,"ledger");
                        String currentHead=safeHash(meta(cacheDb,"audit_ledger_head_sha256"));
                        if(currentEntries==snapshot.entries && currentHead.equals(safeHash(snapshot.headHash))){
                            setMeta(cacheDb,"audit_ledger_cached_valid",String.valueOf(audit.optBoolean("valid",false)));
                            setMeta(cacheDb,"audit_ledger_cached_head",audit.optString("headHash",""));
                            setMeta(cacheDb,"audit_ledger_cached_entries",String.valueOf(audit.optLong("entries",0L)));
                            setMeta(cacheDb,"audit_ledger_cached_first_broken",String.valueOf(audit.optLong("firstBrokenId",-1L)));
                            setMeta(cacheDb,"audit_ledger_cached_verified_at",String.valueOf(finished));
                            setMeta(cacheDb,"audit_ledger_cached_verify_ms",String.valueOf(Math.max(0L,finished-started)));
                            setMeta(cacheDb,"audit_ledger_cached_verify_thread",thread);
                            setMeta(cacheDb,"audit_ledger_cached_error","");
                        }else{
                            stableSnapshot=false;
                        }
                    }
                }

                DeveloperFlightRecorder.record(app,null,-1L,"AUDIT",
                        stableSnapshot?"ASYNC_CHAIN_VERIFIED":"ASYNC_CHAIN_VERIFY_STALE",
                        "valid="+audit.optBoolean("valid",false)
                                +" entries="+audit.optLong("entries",0L)
                                +" snapshotMs="+snapshotMs
                                +" verifyMs="+Math.max(0L,finished-started)
                                +" stable="+stableSnapshot
                                +" mainMonitorHeldDuringVerify=false"
                                +" thread="+thread,
                        "audit-ledger","","audit-worker",false,false,false);
            }catch(Throwable t){
                try{
                    synchronized(LumiMemoryVault.this){
                        SQLiteDatabase db=getWritableDatabase();
                        setMeta(db,"audit_ledger_cached_valid","false");
                        setMeta(db,"audit_ledger_cached_verify_thread",thread);
                        setMeta(db,"audit_ledger_cached_error",t.getClass().getSimpleName());
                    }
                }catch(Throwable ignored){}
            }finally{
                synchronized(LumiMemoryVault.this){auditMaintenanceRunning=false;}
            }
        },"LumiAuditVerify").start();
    }

    private JSONObject cachedAuditStatus(SQLiteDatabase db)throws Exception{
        JSONObject o=new JSONObject();
        boolean complete="1".equals(meta(db,"audit_ledger_chain_v1_complete"));
        String verified=meta(db,"audit_ledger_cached_verified_at");
        o.put("valid",complete && "true".equals(meta(db,"audit_ledger_cached_valid")));
        o.put("pending",!complete || verified.isEmpty() || auditMaintenanceRunning);
        o.put("headHash",safeHash(meta(db,"audit_ledger_cached_head")).isEmpty()?safeHash(meta(db,"audit_ledger_head_sha256")):safeHash(meta(db,"audit_ledger_cached_head")));
        o.put("entries",parseLongMeta(meta(db,"audit_ledger_cached_entries"),0L));
        o.put("firstBrokenId",parseLongMeta(meta(db,"audit_ledger_cached_first_broken"),-1L));
        o.put("verifiedAt",parseLongMeta(verified,0L));
        o.put("verifyMs",parseLongMeta(meta(db,"audit_ledger_cached_verify_ms"),-1L));
        o.put("verifyThread",meta(db,"audit_ledger_cached_verify_thread"));
        String error=meta(db,"audit_ledger_cached_error"); if(!error.isEmpty())o.put("error",error);
        return o;
    }
    private long parseLongMeta(String s,long fallback){try{return Long.parseLong(s==null?"":s);}catch(Throwable ignored){return fallback;}}

    private boolean hasColumn(SQLiteDatabase db,String table,String column){
        Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null);
        try{while(c.moveToNext())if(column.equals(c.getString(c.getColumnIndexOrThrow("name"))))return true;return false;}finally{c.close();}
    }

    private void rebuildLedgerChain(SQLiteDatabase db){
        Cursor c=db.query("ledger",new String[]{"id","ts","kind","summary","detail","transaction_id"},null,null,null,null,"id ASC");
        String previous=AUDIT_GENESIS, head=AUDIT_GENESIS;
        try{
            while(c.moveToNext()){
                long id=c.getLong(0), ts=c.getLong(1); String kind=c.getString(2);
                String summary=PrivateStore.decrypt(c.getString(3)), detail=PrivateStore.decrypt(c.getString(4)), tx=c.getString(5);
                String hash=ledgerHash(ts,kind,summary,detail,tx,previous);
                ContentValues row=new ContentValues();row.put("prev_hash",previous);row.put("record_hash",hash);row.put("chain_version",1);
                db.update("ledger",row,"id=?",new String[]{String.valueOf(id)}); previous=hash; head=hash;
            }
        }finally{c.close();}
        setMeta(db,"audit_ledger_chain_version","1");setMeta(db,"audit_ledger_head_sha256",head);
    }

    private String lastLedgerHash(SQLiteDatabase db){
        Cursor c=db.query("ledger",new String[]{"record_hash"},null,null,null,null,"id DESC","1");
        try{return c.moveToFirst()?safeHash(c.getString(0)):"";}finally{c.close();}
    }

    private static final class AuditLedgerRow {
        final long id,ts; final String kind,summaryCipher,detailCipher,tx,prevHash,recordHash; final int chainVersion;
        AuditLedgerRow(long id,long ts,String kind,String summaryCipher,String detailCipher,String tx,
                       String prevHash,String recordHash,int chainVersion){
            this.id=id;this.ts=ts;this.kind=kind;this.summaryCipher=summaryCipher;this.detailCipher=detailCipher;
            this.tx=tx;this.prevHash=prevHash;this.recordHash=recordHash;this.chainVersion=chainVersion;
        }
    }
    private static final class AuditLedgerSnapshot {
        final ArrayList<AuditLedgerRow> rows; final long entries; final String headHash;
        AuditLedgerSnapshot(ArrayList<AuditLedgerRow> rows,long entries,String headHash){
            this.rows=rows;this.entries=entries;this.headHash=headHash;
        }
    }

    private AuditLedgerSnapshot captureAuditLedgerSnapshot(SQLiteDatabase db){
        ArrayList<AuditLedgerRow> rows=new ArrayList<>();
        Cursor c=db.query("ledger",new String[]{"id","ts","kind","summary","detail","transaction_id","prev_hash","record_hash","chain_version"},null,null,null,null,"id ASC");
        String head=AUDIT_GENESIS;
        try{
            while(c.moveToNext()){
                String storedHash=c.getString(7);
                rows.add(new AuditLedgerRow(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getString(4),
                        c.getString(5),c.getString(6),storedHash,c.getInt(8)));
                head=storedHash==null?"":storedHash;
            }
        }finally{c.close();}
        return new AuditLedgerSnapshot(rows,rows.size(),head);
    }

    private JSONObject auditStatusFromSnapshot(AuditLedgerSnapshot snapshot) throws Exception {
        JSONObject o=new JSONObject();
        String previous=AUDIT_GENESIS, head=AUDIT_GENESIS;
        long count=0L, firstBroken=-1L; boolean valid=true;
        for(AuditLedgerRow row:snapshot.rows){
            String summary=PrivateStore.decrypt(row.summaryCipher);
            String detail=PrivateStore.decrypt(row.detailCipher);
            String expected=ledgerHash(row.ts,row.kind,summary,detail,row.tx,previous);
            if(row.chainVersion!=1 || !previous.equals(row.prevHash) || !expected.equals(row.recordHash)){
                valid=false;if(firstBroken<0L)firstBroken=row.id;
            }
            previous=row.recordHash==null?"":row.recordHash;
            head=previous;count++;
        }
        o.put("valid",valid).put("chainVersion",1).put("entries",count).put("headHash",head).put("firstBrokenId",firstBroken);
        return o;
    }

    private JSONObject auditStatusInternal(SQLiteDatabase db) throws Exception {
        // Compatibility entry point for explicit diagnostics. The live DB cursor is released before
        // decrypt/hash work, so callers cannot pin the database through a multi-second chain walk.
        return auditStatusFromSnapshot(captureAuditLedgerSnapshot(db));
    }

    private String ledgerHash(long ts,String kind,String summary,String detail,String tx,String previous){
        try{MessageDigest md=MessageDigest.getInstance("SHA-256");String canonical=ts+"|"+field(kind)+"|"+field(summary)+"|"+field(detail)+"|"+field(tx)+"|"+field(previous);byte[] hash=md.digest(canonical.getBytes(StandardCharsets.UTF_8));StringBuilder out=new StringBuilder(64);for(byte b:hash)out.append(String.format(Locale.US,"%02x",b&0xff));return out.toString();}
        catch(Exception e){throw new IllegalStateException("Audit ledger SHA-256 unavailable",e);}
    }
    private String field(String s){String x=s==null?"":s;return x.length()+":"+x;}
    private String safeHash(String s){return s!=null&&s.matches("[0-9a-f]{64}")?s:"";}

    private long count(SQLiteDatabase db,String table){ Cursor c=db.rawQuery("SELECT COUNT(*) FROM "+table,null);try{return c.moveToFirst()?c.getLong(0):0;}finally{c.close();} }
    private String meta(SQLiteDatabase db,String key){ Cursor c=db.query("meta",new String[]{"meta_value"},"meta_key=?",new String[]{key},null,null,null,"1");try{return c.moveToFirst()?c.getString(0):"";}finally{c.close();} }
    private void setMeta(SQLiteDatabase db,String key,String value){ ContentValues v=new ContentValues();v.put("meta_key",key);v.put("meta_value",value);db.insertWithOnConflict("meta",null,v,SQLiteDatabase.CONFLICT_REPLACE); }
    private void pruneEvents(SQLiteDatabase db){ db.execSQL("DELETE FROM events WHERE id NOT IN (SELECT id FROM events ORDER BY ts DESC LIMIT 12000)"); }
    private String readAsset(String name)throws Exception{ try(InputStream in=app.getAssets().open(name);BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){StringBuilder s=new StringBuilder();String line;while((line=r.readLine())!=null){s.append(line).append('\n');}return s.toString();} }
    private static ArrayList<String> queryTerms(String q){ Set<String> set=new LinkedHashSet<>();if(q!=null)for(String w:q.toLowerCase(Locale.US).replaceAll("[^a-z0-9_ -]"," ").split("\\s+")){if(w.length()>=4&&!STOP.contains(w))set.add(w);}return new ArrayList<>(set); }
    private static final Set<String> STOP=new java.util.HashSet<>(java.util.Arrays.asList("this","that","with","from","have","what","when","where","which","your","about","could","would","there","they","them","then","than","into","just","like","want","need","lumi","remember"));
    private static boolean looksSecret(String s){ if(s==null)return false;String l=s.toLowerCase(Locale.US);return l.contains("api_key")||l.contains("bearer ")||l.contains("github_pat_")||l.contains("password=")||l.contains("private key-----"); }
    private static String redactSecrets(String s){ return SecretStore.redact(s); }
    private static String safe(String s,String fallback){return s==null||s.trim().isEmpty()?fallback:s.trim();}
    private static int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
    private static String bounded(String s,int max){if(s==null)return "";return s.length()<=max?s:s.substring(0,max);}
    private static void appendBounded(StringBuilder out,String s,int max){if(out.length()>=max)return;int room=max-out.length();out.append(s.length()<=room?s:s.substring(0,room));}
}
