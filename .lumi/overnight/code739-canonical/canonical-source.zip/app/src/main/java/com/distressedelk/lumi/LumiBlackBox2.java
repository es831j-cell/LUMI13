package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;

/** Code661 Black Box 2: compact current-release causal truth with explicit Core and voice evidence. */
final class LumiBlackBox2 {
    private static final int MAX_TEXT_CHARS=110000;
    private LumiBlackBox2(){}

    static byte[] bytes(Context c,SharedPreferences p){return report(c,p).getBytes(StandardCharsets.UTF_8);}

    static String report(Context c,SharedPreferences p){
        if(c==null||p==null)return "LUMI BLACK BOX 2\nUnavailable.";
        LumiRelease1Gatekeeper.initialize(c,p);
        p.edit().putBoolean("lumi1_blackbox2_active",true).putLong("lumi1_blackbox2_last_at",System.currentTimeMillis()).apply();
        StringBuilder b=new StringBuilder(28000);
        b.append("LUMI BLACK BOX 2 • CURRENT RELEASE EVIDENCE ONLY\n");
        b.append("Generated: ").append(System.currentTimeMillis()).append("\n");
        b.append("Installed: ").append(versionName(c)).append(" (code ").append(versionCode(c)).append(")\n");
        b.append("Purpose: explain what happened, what failed, and whether Lumi 1.0 gates are actually proven.\n\n");

        b.append(LumiRelease1Gatekeeper.report(c,p)).append("\n\n");
        b.append("CURRENT CORE PRODUCT-TURN AUTHORITY\n").append(LumiCoreAuthority.summary(p)).append('\n');
        b.append("candidateRoute=").append(p.getString("lumi_core_last_candidate_route","none"))
                .append(" finalCommitted=").append(p.getBoolean("lumi_core_final_reply_committed",false))
                .append(" finalAuthority=").append(p.getString("product_turn_final_authority","none")).append('\n');
        b.append("capabilityState=").append(p.getString("lumi_core_capability_state","UNKNOWN"))
                .append(" executor=").append(p.getString("lumi_core_capability_executor","none"))
                .append(" detail=").append(clip(p.getString("lumi_core_capability_detail",""),500)).append("\n\n");

        b.append("LUMI CORE AUTHORITY CONVERGENCE • CODE709\n");
        b.append("mode=").append(p.getString("lumi_core_authority_mode","UNSET"))
                .append(" fullRuntime=").append(p.getBoolean("lumi_core_full_runtime_authority",false)).append('\n');
        b.append("chain=").append(p.getString("lumi_core_authority_chain","UNSET")).append('\n');
        b.append("activeDelegate=").append(p.getString("lumi_core_active_delegate","none"))
                .append(" role=").append(p.getString("lumi_core_active_delegate_role","none")).append('\n');
        b.append("owners conversation=").append(p.getString("lumi_owner_conversation","UNSET"))
                .append(" reasoning=").append(p.getString("lumi_owner_reasoning","UNSET"))
                .append(" memory=").append(p.getString("lumi_owner_memory","UNSET"))
                .append(" actions=").append(p.getString("lumi_owner_actions","UNSET"))
                .append(" health=").append(p.getString("lumi_owner_health","UNSET"))
                .append(" maintenance=").append(p.getString("lumi_owner_maintenance","UNSET"))
                .append(" updates=").append(p.getString("lumi_owner_updates","UNSET")).append('\n');
        b.append("securityBoundary=").append(p.getString("lumi_core_security_boundary","UNSET")).append('\n');
        b.append("authorityRule=Owner grants Lumi Core runtime authority once; routers/providers/search/local executors/maintenance are delegates. Android permission, biometric, signing, and installer boundaries remain mandatory.\n\n");

        b.append("PROVIDER VAULT RECOVERY\n");
        b.append("recoveredAt=").append(p.getLong("code707_provider_recovery_at",0L))
                .append(" keyCount=").append(p.getInt("code707_provider_key_count",0))
                .append(" present=").append(p.getString("code707_provider_key_summary","none")).append('\n');
        b.append("configuredFreeProviders=").append(CloudBrainRouter.configuredProviderNames(p)).append('\n');
        b.append("providerHealth=").append(CloudBrainRouter.healthSummary(p)).append("\n");
        b.append("credentialRule=presence only; raw provider keys are never exported to Black Box.\n\n");

        b.append("EXTERNAL PROVIDER DELEGATION\n");
        b.append("provider=").append(p.getString("fallback_last_provider","none"))
                .append(" model=").append(p.getString("fallback_last_model","none"))
                .append(" role=").append(p.getString("fallback_last_role","none"))
                .append(" adviceAt=").append(p.getLong("fallback_last_advice_at",0L)).append('\n');
        b.append("providerRule=External/cloud providers may advise Lumi Core but may not impersonate Lumi, decide capability, claim action execution, or own final user-facing truth.\n\n");

        b.append("CURRENT CAUSAL TRUTH\n").append(LumiCausalJournal.currentTruthSummary(c,p)).append("\n\n");
        b.append("RUNTIME SELF\n").append(LumiRuntimeSelfModel.snapshot(c,p)).append("\n\n");
        b.append("DURABLE CONVERSATION MEMORY\n").append(LumiConversationMemory.status(c,p)).append("\n")
                .append(LumiConversationMemory.recentReport(c,8)).append("\n\n");

        b.append("CURRENT VOICE / CONVERSATION SIGNALS\n");
        b.append("recognizerPhase=").append(p.getString("code611_recognizer_phase",p.getString("recognizer_phase","UNKNOWN"))).append('\n');
        b.append("conversationState=").append(p.getString("conversation_runtime_state","UNKNOWN")).append('\n');
        b.append("lastManualRescueAt=").append(p.getLong("lumi1_manual_rescue_last_at",0L)).append(" reason=").append(p.getString("lumi1_manual_rescue_reason","none")).append('\n');
        b.append("bargeInCount=").append(p.getInt("spoken_barge_in_count",0)).append(" activeTtsStops=").append(p.getInt("spoken_barge_in_tts_stop_count",0)).append('\n');
        b.append("ownerAccepted=").append(p.getInt("owner_accepted",0)).append(" activeSpeakerBound=").append(!p.getString("active_voice_speaker_id","").isEmpty()).append('\n');
        b.append("audioGateCategory=").append(p.getString("audio_gate_last_category","none"))
                .append(" pcmBytes=").append(p.getInt("audio_gate_last_pcm_bytes",-1))
                .append(" nearField=").append(p.getBoolean("audio_gate_last_near_field",false)).append('\n');
        b.append("commDeviceRequested=").append(p.getBoolean("code661_comm_device_requested",false))
                .append(" verified=").append(p.getBoolean("code661_comm_device_verified",false))
                .append(" target=").append(p.getString("code661_comm_device_target","none"))
                .append(" type=").append(p.getInt("code661_comm_device_target_type",-1)).append('\n');
        b.append("ttsWatchdogRecoveries=").append(p.getInt("tts_watchdog_recoveries",0)).append(" recognizerCircuitBreaks=").append(p.getInt("recognizer_restart_circuit_breaks",0)).append('\n');
        b.append("readyButDeaf=").append(p.getInt("ready_but_deaf_confirmed",0)).append(" stateDivergence=").append(p.getInt("conversation_state_divergence",0))
                .append(" legacySignalContradictions=").append(p.getInt("legacy_runtime_signal_contradiction",0)).append('\n');
        b.append("lastResponseLatencyMs=").append(p.getLong("last_response_latency_ms",-1L)).append("\n\n");

        b.append("CURRENT VOICE QUALITY EVIDENCE\n");
        b.append("profile=").append(p.getString("lumi_voice_profile","unknown"))
                .append(" authority=").append(p.getString("lumi_voice_authority","unknown"))
                .append(" engineVoice=").append(p.getString("lumi_voice_profile_engine_voice","unknown")).append('\n');
        b.append("pitch=").append(p.getFloat("lumi_voice_profile_pitch",-1f))
                .append(" rate=").append(p.getFloat("lumi_voice_profile_rate",-1f))
                .append(" pitchApplied=").append(p.getBoolean("lumi_voice_profile_pitch_applied",false))
                .append(" rateApplied=").append(p.getBoolean("lumi_voice_profile_rate_applied",false))
                .append(" runtimeApplied=").append(p.getBoolean("lumi_voice_profile_runtime_verified",false)).append('\n');
        b.append("profileAppliedVersion=").append(p.getInt("lumi_voice_profile_applied_version",-1))
                .append(" applyCount=").append(p.getInt("lumi_voice_profile_apply_count",0))
                .append(" appliedAt=").append(p.getLong("lumi_voice_profile_applied_at",0L)).append('\n');
        b.append("code738 requestedVoice=").append(p.getString("tts_requested_voice_r448","unknown"))
                .append(" actualVoice=").append(p.getString("tts_actual_voice_r448","unknown"))
                .append(" fallbackReason=").append(p.getString("tts_fallback_reason_r448","none"))
                .append(" fallbackCount=").append(p.getInt("tts_voice_fallback_count_r448",0))
                .append(" lastErrorCode=").append(p.getInt("tts_last_error_code_r448",0)).append('\n');
        b.append("code738 synthesisStarted=").append(p.getBoolean("tts_synthesis_started_r448",false))
                .append(" synthesisSuccess=").append(p.getBoolean("tts_last_synthesis_success_r448",false))
                .append(" outputRoute=").append(p.getString("tts_output_route_r448","unknown")).append('\n');
        b.append("code739 cueSuppressionActive=").append(p.getBoolean("stt_cue_suppression_active_r449",false))
                .append(" count=").append(p.getInt("stt_cue_suppression_count_r449",0))
                .append(" streams=").append(p.getString("stt_cue_suppression_streams_r449","UNSET"))
                .append(" status=").append(p.getString("stt_cue_suppression_last_status_r449","UNTESTED"))
                .append(" reason=").append(p.getString("stt_cue_suppression_last_reason_r449","none"))
                .append(" musicUntouched=true").append('\n');
        b.append("naturalnessPhoneVerified=").append(p.getBoolean("lumi_voice_naturalness_phone_verified",false)).append('\n');
        b.append("voiceQualityRule=TTS success or profile application is runtime evidence only; naturalness requires installed-phone listening verification.\n\n");

        b.append("VISUAL WORKSPACE R425\n");
        b.append("mode=").append(p.getString("visual_workspace_mode","legacy"))
                .append(" ownerGrant=").append(p.getBoolean("visual_workspace_owner_grant",false))
                .append(" rebuildNeeded=").append(p.getBoolean("visual_workspace_rebuild_needed",false))
                .append(" inflight=").append(p.getBoolean("visual_workspace_rebuild_inflight",false))
                .append(" attempts=").append(p.getInt("visual_workspace_rebuild_attempts",0))
                .append(" state=").append(p.getString("visual_workspace_rebuild_state","unknown"))
                .append(" lastSource=").append(p.getString("visual_workspace_last_source","none"))
                .append(" legacySurfaceMounted=").append(p.getBoolean("visual_legacy_surface_mounted",false)).append('\n');
        b.append("schema=").append(clip(p.getString("visual_workspace_schema_json","none"),2200)).append("\n\n");

        b.append("LUMI VISUAL FINALIZATION • CODE736\n");
        b.append("visualGate=").append(p.getString("visual_gate_r446","UNTESTED"))
                .append(" framebuffer=").append(p.getString("visual_gate_r445","UNTESTED"))
                .append(" shader=").append(p.getString("pyramid_shader_program_state","UNTESTED"))
                .append(" palettePass=").append(p.getBoolean("visual_state_palette_pass_r446",false))
                .append(" selfCheck=").append(p.getString("visual_self_check_status","NOT_RUN")).append('\n');
        b.append("state=").append(p.getString("pyramid_visual_state","UNSET"))
                .append(" target=").append(p.getString("pyramid_visual_state_target","UNSET"))
                .append(" rendered=").append(p.getString("pyramid_visual_state_rendered","UNSET"))
                .append(" transitionProgress=").append(p.getFloat("pyramid_visual_transition_progress",-1f)).append('\n');
        b.append("targetRGB=").append(p.getFloat("pyramid_visual_target_r",-1f)).append(',')
                .append(p.getFloat("pyramid_visual_target_g",-1f)).append(',')
                .append(p.getFloat("pyramid_visual_target_b",-1f))
                .append(" renderedRGB=").append(p.getFloat("pyramid_visual_rendered_r",-1f)).append(',')
                .append(p.getFloat("pyramid_visual_rendered_g",-1f)).append(',')
                .append(p.getFloat("pyramid_visual_rendered_b",-1f)).append('\n');
        b.append("paletteContract=").append(p.getString("visual_state_color_contract",p.getString("visual_palette_contract","UNSET")))
                .append(" transitionMs=6000")
                .append(" legacyR424=").append(p.getString("visual_gate_r424","HISTORICAL")).append(" (historical only)\n\n");

        b.append("LUMI AVATAR SCENE FOUNDATION • CODE711\n");
        b.append("sceneAuthority=").append(p.getString("renderer_visual_authority","UNSET"))
                .append(" scene=").append(p.getString("visual_scene_id","UNSET"))
                .append(" model=").append(p.getString("visual_active_model","UNSET")).append('\n');
        b.append("sceneClass=").append(p.getString("visual_scene_mounted_class","UNSET"))
                .append(" modelClass=").append(p.getString("visual_model_mounted_class","UNSET")).append('\n');
        b.append("palette=").append(p.getString("visual_palette_contract","UNSET"))
                .append(" legacyRedBlocked=").append(p.getBoolean("visual_legacy_red_contract_blocked",false))
                .append(" autotune=").append(p.getBoolean("renderer_autotune_enabled",false))
                .append(" state=").append(p.getString("renderer_autotune_state","UNSET")).append('\n');
        b.append("runtime=").append(clip(p.getString("visual_scene_runtime_snapshot","none"),900)).append("\n\n");

        b.append("LUMI 1.0 EXPERIENCE HARDENING • CODE710\n");
        b.append("voicePolicy=").append(p.getString("code710_voice_policy","UNSET"))
                .append(" selected=").append(p.getString("lumi_voice_profile_engine_voice","unknown"))
                .append(" pitch=").append(p.getFloat("lumi_voice_profile_pitch",-1f))
                .append(" rate=").append(p.getFloat("lumi_voice_profile_rate",-1f)).append('\n');
        b.append("visualStyle=").append(p.getString("code710_visual_style","UNSET"))
                .append(" triangles=").append(p.getInt("code710_visual_triangle_count",0)).append('\n');
        b.append("bargeOnsetYields=").append(p.getInt("code710_barge_onset_yield_count",0))
                .append(" speakerLocalHits=").append(p.getInt("code710_speaker_identity_local_hits",0))
                .append(" directDiagnostics=").append(p.getInt("code710_direct_diagnostics_count",0)).append("\n\n");

        b.append("LUMI 1.0 RC HARDENING • CODE708\n");
        b.append("localDateHits=").append(p.getInt("code708_local_date_hits",0))
                .append(" lastAt=").append(p.getLong("code708_local_date_last_at",0L)).append('\n');
        b.append("bargeAcousticYields=").append(p.getInt("code708_barge_acoustic_yield_count",0))
                .append(" echoOverrides=").append(p.getInt("code708_barge_echo_override_after_strong_acoustic",0))
                .append(" lastRmsDelta=").append(p.getFloat("code708_barge_last_rms_delta",0f)).append('\n');
        b.append("staleUpdateCacheRejects=").append(p.getInt("code708_stale_update_cache_reject_count",0)).append("\n\n");

        b.append("R447 TRUTH CONVERGENCE\n");
        b.append("dependencyTopology=").append(p.getString("lumi_dependency_graph_state","UNKNOWN"))
                .append(" findings=").append(p.getInt("lumi_dependency_graph_issue_count",-1))
                .append(" runtimeCoverage=").append(p.getInt("lumi_dependency_runtime_proven",0)).append('/').append(p.getInt("lumi_dependency_runtime_total",12))
                .append(" coverageState=").append(p.getString("lumi_dependency_runtime_coverage_state","UNTESTED")).append('\n');
        b.append("sourceCorrections activeDefects=").append(LumiSourceCorrectionRegistry.activeDefectCount(p))
                .append(" pendingAcceptance=").append(LumiSourceCorrectionRegistry.pendingAcceptanceCount(p))
                .append(" totalOpen=").append(LumiSourceCorrectionRegistry.openCount(p)).append('\n');
        b.append("providerAggregate=").append(providerAggregate(p)).append(" • optional adapters may be degraded without making Lumi Core unavailable\n\n");

        b.append("CURRENT UPDATE / REMOTE ANALYSIS STATE\n");
        b.append("publicUpdateState=").append(p.getString("github_update_check_state","NOT_CHECKED"))
                .append(" channel=").append(p.getString("github_update_channel_branch","public-main"))
                .append(" published=").append(p.getLong("github_update_available_version",-1L))
                .append(" installed=").append(versionCode(c)).append('\n');
        b.append("publicUpdateError=").append(clip(p.getString("github_update_check_error","none"),800)).append('\n');
        b.append("updateStage=").append(p.getString("update_tx_last_stage",p.getString("update_bridge_stage","UNKNOWN"))).append('\n');
        b.append("lastCompletedUpdateResult=").append(clip(p.getString("update_bridge_last_completed_result","none"),800)).append(" (historical transaction; current truth is installed/published above)\n");
        b.append("developerBridgeConfigured=").append(TrustedBuildRelayClient.developerChannelConfigured(p))
                .append(" developerBridgeError=").append(clip(p.getString("remote_maintenance_last_error","none"),800)).append('\n');
        b.append("localBlackBoxPreparedAt=").append(p.getLong("black_box_prepared_at",0L))
                .append(" stableAt=").append(p.getLong("remote_black_box_stable_at",0L)).append(" path=.lumi/blackbox/current.txt\n");
        b.append("remoteBlackBoxUploadCount=").append(p.getInt("remote_black_box_upload_count",0))
                .append(" remoteWriteFailures=").append(p.getInt("remote_black_box_stable_write_failures",0)).append('\n');
        b.append("updateScheduler periodicAt=").append(p.getLong("code706_update_periodic_scheduled_at",0L))
                .append(" oneShotAt=").append(p.getLong("code706_update_oneshot_scheduled_at",0L))
                .append(" reason=").append(p.getString("code706_update_oneshot_reason","none"))
                .append(" jobStart=").append(p.getLong("code706_update_job_started_at",0L))
                .append(" jobFinish=").append(p.getLong("code706_update_job_finished_at",0L))
                .append(" jobState=").append(p.getString("code706_update_job_state","none"))
                .append(" target=").append(p.getLong("code706_update_job_target",-1L)).append('\n');
        boolean enrolled=p.getBoolean("admin_enrollment_complete",false);
        b.append("ownerContinuity=").append(enrolled?"PERSISTED_ADMIN_CONTINUITY_READY":"FRESH_INSTALL_REENROLLMENT_REQUIRED")
                .append(" biometricSession=").append(p.getString("code401_startup_identity_state","UNKNOWN"))
                .append(" rootSessionActive=").append(IdentityHierarchy.adminSessionActive(p)).append("\n\n");

        b.append("RECENT CORRELATED CAUSAL EVENTS\n").append(LumiCausalJournal.recentTraceReport(c,p,80)).append("\n\n");
        b.append("END BLACK BOX 2\n");
        String out=b.toString();
        return out.length()>MAX_TEXT_CHARS?out.substring(0,MAX_TEXT_CHARS)+"\n[TRUNCATED AT BLACK BOX 2 SAFETY BOUND]\n":out;
    }

    private static int versionCode(Context c){try{android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0);long v=android.os.Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode;return (int)Math.min(Integer.MAX_VALUE,v);}catch(Throwable t){return -1;}}
    private static String versionName(Context c){try{String n=c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionName;return n==null?"unknown":n;}catch(Throwable t){return "unknown";}}
    private static String clip(String s,int n){if(s==null)return "";s=s.replace('\n',' ').replace('\r',' ').trim();return s.length()>n?s.substring(0,n):s;}
    private static String providerAggregate(SharedPreferences p){if(p==null)return "UNKNOWN";String[] ids={"openrouter","groq","gemini","cloudflare"};int ready=0,configured=0;for(String id:ids){String st=p.getString("fallback_"+id+"_health","");boolean saved=!SecretStore.get(p,id+"_api_key").trim().isEmpty();if(saved)configured++;if("ready".equals(st))ready++;}return ready>0?"READY_WITH_"+ready+"_HEALTHY_PROVIDER"+(configured>ready?"_OPTIONAL_DEGRADATION":""):configured>0?"DEGRADED_NO_HEALTHY_PROVIDER":"LOCAL_ONLY_NO_CLOUD_PROVIDER";}

}
