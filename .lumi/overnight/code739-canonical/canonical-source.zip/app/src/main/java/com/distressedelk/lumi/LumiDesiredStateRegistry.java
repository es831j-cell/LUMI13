package com.distressedelk.lumi;
import android.content.SharedPreferences;import org.json.*;
final class LumiDesiredStateRegistry{
 private static final String KEY="lumi_desired_state_registry_v2"; private LumiDesiredStateRegistry(){}
 static void ensure(SharedPreferences p){if(p==null)return;try{JSONArray a=new JSONArray();
  add(a,"SELF","installed Lumi can derive purpose, current condition, gaps, blockers and next action from current evidence","fresh Core evaluation tied to installed build");
  add(a,"DEPENDENCIES","every governed path has purpose, owner, trigger, dependencies, destination and verification","graph has zero duplicate ids, unknown dependencies/destinations, orphans, dead ends or unbounded cycles");
  add(a,"UI","all visible controls are readable, tappable, unclipped, non-overlapping and proportionate","fresh rendered measurements before and after any Core-authorized adjustment");
  add(a,"VOICE","owner speech reaches recognition and conversation state correctly","fresh microphone, recognizer and conversation evidence");
  add(a,"AUDIO","input/output focus and route support the intended conversation state","fresh audio route/focus observations");
  add(a,"VISUAL","stable visible layered inverted-pyramid with idle/listening forest green, thinking crimson, speaking violet, and smooth six-second transitions","fresh installed-runtime framebuffer gate plus state-palette evidence");
  add(a,"UPDATE","requested update reaches installer, installs, restarts and proves new runtime","transaction, package identity, installed-version and restart evidence");
  add(a,"IDENTITY","owner/admin state is explicit and uncertain speakers never inherit owner authority","session and speaker evidence");
  add(a,"PROVIDERS","providers remain delegates and unavailable providers cannot falsify Lumi state","router evidence plus Core-owned final decision");
  add(a,"MEMORY","memory reads/writes preserve provenance and do not override current runtime truth","memory evidence and current-build precedence");
  add(a,"MAINTENANCE","maintenance actions produce before/after evidence and bounded outcomes","transaction receipt and verification evidence");
  add(a,"SOURCE_CORRECTION","runtime-unrepairable gaps remain open engineering requirements until installed acceptance passes","persistent issue lifecycle OPEN->FIXED_IN_SOURCE->INSTALLED->CLOSED_VERIFIED");
  add(a,"SECURITY","owner authority, privacy, signing and recovery controls remain intact","current security and package-signing evidence");
  add(a,"TRUTH","only Lumi Core grants final capability state; no evidence is UNKNOWN","Core state references current evidence and dependencies");
  p.edit().putString(KEY,a.toString()).putInt("lumi_desired_state_domain_count",a.length()).putLong("lumi_desired_state_at",System.currentTimeMillis()).apply();
 }catch(Throwable ignored){}}
 private static void add(JSONArray a,String id,String target,String verify)throws Exception{JSONObject o=new JSONObject();o.put("id",id);o.put("target",target);o.put("verification",verify);a.put(o);}
 static String targetFor(SharedPreferences p,String id){ensure(p);try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(id!=null&&id.equalsIgnoreCase(o.optString("id")))return o.optString("target","");}}catch(Throwable ignored){}return "";}
 static String verificationFor(SharedPreferences p,String id){ensure(p);try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(id!=null&&id.equalsIgnoreCase(o.optString("id")))return o.optString("verification","");}}catch(Throwable ignored){}return "";}
 static String summary(SharedPreferences p){ensure(p);try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));StringBuilder b=new StringBuilder("I have ").append(a.length()).append(" authoritative desired-state domains: ");for(int i=0;i<a.length();i++){if(i>0)b.append(", ");b.append(a.getJSONObject(i).optString("id"));}return b.append(". Final state belongs to Lumi Core; no evidence is UNKNOWN.").toString();}catch(Throwable t){return "My desired-state registry is unavailable, therefore UNKNOWN.";}}
}
