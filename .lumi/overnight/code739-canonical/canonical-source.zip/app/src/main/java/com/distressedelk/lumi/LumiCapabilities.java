package com.distressedelk.lumi;

/** Stable capability identifiers. Core and subsystems communicate by capability, not implementation class. */
final class LumiCapabilities {
    static final String SPEECH_FAST = "speech.fast";
    static final String SPEECH_PRECISION = "speech.precision";
    static final String BRAIN_FAST = "brain.fast";
    static final String BRAIN_SEARCH_WEB = "brain.search.web";
    static final String BRAIN_SEARCH_AI = "brain.search.ai";
    static final String BRAIN_DEEP = "brain.deep";
    static final String VOICE_BASIC = "voice.basic";
    static final String VOICE_AURORA = "voice.aurora";
    static final String CONVERSATION = "conversation.core";
    static final String VISUAL_STATE = "visual.state";
    static final String MODULE_MANAGEMENT = "modules.manage";
    static final String EVENT_BUS = "events.core";
    static final String DIAGNOSTICS = "diagnostics.core";
    static final String RECOVERY = "recovery.core";
    private LumiCapabilities() {}
}
