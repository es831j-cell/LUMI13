package com.distressedelk.lumi;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import java.io.File;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

/** Manual-only Patch Bay surface. Core/major updates never appear here. */
public final class PatchBayActivity extends Activity {
    private LinearLayout list;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setTitle("Lumi Patch Bay");
        render();
    }

    private TextView text(String value,int sp,boolean bold){
        TextView v=new TextView(this); v.setText(value); v.setTextSize(sp); v.setPadding(24,16,24,16);
        if(bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;
    }

    private void render(){
        ScrollView scroll=new ScrollView(this);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(18,18,18,32);
        scroll.addView(list); setContentView(scroll);
        list.addView(text("Lumi Patch Bay",24,true));
        list.addView(text("Core and major updates are required and use Lumi's normal trusted update path. Optional and experimental packages can sit here inert until you explicitly select one.",16,false));
        Button refresh=new Button(this); refresh.setText("Refresh optional packages"); refresh.setOnClickListener(v->refreshCatalog()); list.addView(refresh);
        try {
            JSONArray items=LumiPatchBay.list(this);
            if(items.length()==0){ list.addView(text("No optional or experimental patches are staged.",16,false)); return; }
            for(int i=0;i<items.length();i++) addPatch(items.getJSONObject(i));
        } catch(Throwable t){ list.addView(text("Patch Bay read error: "+t.getClass().getSimpleName(),14,false)); }
    }

    private void addPatch(JSONObject m){
        final String id=m.optString("patchId","unknown");
        String title=m.optString("displayName",id);
        String cls=m.optString("classification","UNKNOWN");
        String state=m.optString("state","UNKNOWN");
        list.addView(text(title,19,true));
        list.addView(text(cls+"  •  "+state,14,false));
        if(m.has("riskClassification")) list.addView(text("Risk: "+m.optString("riskClassification"),13,false));
        if(m.has("targetLumiVersion")) list.addView(text("Target: "+m.optString("targetLumiVersion"),13,false));

        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button select=new Button(this); select.setText("Select for install");
        select.setEnabled("WAITING_FOR_USER".equals(state) || "VALIDATED".equals(state));
        select.setOnClickListener(v->{
            try { JSONObject r=LumiPatchBay.authorize(this,id); if(r.optBoolean("ok",false)) installAuthorized(id); else { toast(r.optString("code")); render(); } }
            catch(Throwable t){ toast("Authorization failed: "+t.getClass().getSimpleName()); }
        });
        buttons.addView(select);
        Button revoke=new Button(this); revoke.setText("Revoke");
        revoke.setEnabled("AUTHORIZED".equals(state));
        revoke.setOnClickListener(v->{
            try { JSONObject r=LumiPatchBay.revoke(this,id); toast(r.optString("code")); render(); }
            catch(Throwable t){ toast("Revoke failed"); }
        });
        buttons.addView(revoke);
        Button delete=new Button(this); delete.setText("Delete");
        delete.setOnClickListener(v->{
            try { JSONObject r=LumiPatchBay.delete(this,id); toast(r.optString("code")); render(); }
            catch(Throwable t){ toast("Delete failed"); }
        });
        buttons.addView(delete); list.addView(buttons);
    }

    private void refreshCatalog(){
        toast("Checking optional package catalog…");
        new Thread(()->{
            try{
                SharedPreferences p=getSharedPreferences("lumi",MODE_PRIVATE);
                int n=OptionalPackageCatalog.refreshAndStage(this,p);
                runOnUiThread(()->{ toast(n==0?"Optional package catalog is current.":("Staged "+n+" optional package"+(n==1?"":"s")+".")); render(); });
            }catch(Throwable t){ runOnUiThread(()->toast("Catalog refresh failed: "+String.valueOf(t.getMessage()))); }
        },"LumiOptionalCatalog").start();
    }

    private void installAuthorized(String id){
        toast("Verifying and installing selected package…");
        new Thread(()->{
            try{
                SharedPreferences p=getSharedPreferences("lumi",MODE_PRIVATE);
                File pkg=LumiPatchBay.beginAuthorizedInstall(this,id);
                LumiUpdateManager.Result r=LumiUpdateManager.applyTrustedPackageBlocking(this,p,pkg,null);
                if(r.coreInstallReady || !"content".equalsIgnoreCase(r.type)) throw new SecurityException("Optional lane refused non-content result");
                LumiPatchBay.finishAuthorizedInstall(this,id,true,"SIGNED_CONTENT_ACTIVE");
                UpdateBridgeTelemetry.mark(this,p,"OPTIONAL_PACKAGE_ACTIVE","patchId="+id+" updateId="+r.updateId);
                runOnUiThread(()->{toast("Optional package active."); render();});
            }catch(Throwable t){
                try{LumiPatchBay.finishAuthorizedInstall(this,id,false,String.valueOf(t.getMessage()));}catch(Throwable ignored){}
                runOnUiThread(()->{toast("Optional install failed: "+String.valueOf(t.getMessage())); render();});
            }
        },"LumiOptionalInstall").start();
    }

    private void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
}
