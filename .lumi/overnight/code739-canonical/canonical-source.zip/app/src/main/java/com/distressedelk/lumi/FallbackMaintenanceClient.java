package com.distressedelk.lumi;

import android.app.Activity;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Code344 OpenAI-compatible maintenance reasoning fallback.
 *
 * This client does not grant authority. It can only request LumiMaintenanceTools, whose local
 * authorization/Android installer gates remain authoritative. Provider failover is allowed until a
 * mutating maintenance tool executes. After a mutation, the transaction stays pinned to the
 * provider that initiated it so a network retry cannot duplicate a write.
 */
final class FallbackMaintenanceClient {
    private static final int ROUND_LIMIT=10;
    interface Callback { void onSuccess(String reply,String provider,String model); void onFailure(String error); }
    private FallbackMaintenanceClient() {}

    static void request(Activity activity, SharedPreferences prefs, String instructions, String presence,
                        String recentTranscript, String userText, Callback callback){
        new Thread(() -> {
            List<CloudBrainRouter.Provider> providers=CloudBrainRouter.providers(prefs);
            if(providers.isEmpty()){ callback.onFailure("No free fallback provider is configured for maintenance reasoning."); return; }
            StringBuilder failures=new StringBuilder();
            long now=System.currentTimeMillis();
            boolean selfRepairRequest=isSelfRepairMutationRequired(userText,instructions);
            boolean anyProviderReady=false;
            long earliestCooldownUntil=Long.MAX_VALUE;
            String earliestCooldownProvider="";
            for(CloudBrainRouter.Provider candidate:providers){
                long cu=prefs.getLong("fallback_"+candidate.id+"_cooldown_until",0L);
                if(cu<=now) anyProviderReady=true;
                else if(cu<earliestCooldownUntil){ earliestCooldownUntil=cu; earliestCooldownProvider=candidate.id; }
            }
            long lastForcedProbe=prefs.getLong("maintenance_reasoning_forced_cooldown_probe_at",0L);
            boolean allowForcedProbe=selfRepairRequest && !anyProviderReady && now-lastForcedProbe>=120000L;
            for(CloudBrainRouter.Provider provider:providers){
                long cooldownUntil=prefs.getLong("fallback_"+provider.id+"_cooldown_until",0L);
                if(cooldownUntil>now){
                    boolean forced=allowForcedProbe && provider.id.equals(earliestCooldownProvider);
                    if(!forced){
                        if(failures.length()>0)failures.append(" | ");
                        failures.append(provider.id).append(": cooling down");
                        continue;
                    }
                    prefs.edit().putLong("maintenance_reasoning_forced_cooldown_probe_at",now)
                            .putString("maintenance_reasoning_forced_cooldown_probe_provider",provider.id)
                            .putLong("maintenance_reasoning_forced_cooldown_probe_original_until",cooldownUntil).apply();
                    allowForcedProbe=false;
                }
                boolean mutationExecuted=false;
                try{
                    JSONArray messages=baseMessages(instructions,presence,recentTranscript,userText);
                    JSONArray tools=chatToolDefinitions();
                    for(int round=0; round<ROUND_LIMIT; round++){
                        JSONObject response=post(provider,messages,tools);
                        JSONObject message=firstMessage(response);
                        JSONArray calls=message.optJSONArray("tool_calls");
                        if(calls==null || calls.length()==0){
                            String text=contentText(message);
                            boolean selfRepairMutationRequired=isSelfRepairMutationRequired(userText,instructions);
                            if(selfRepairMutationRequired && !mutationExecuted){
                                // Code604: a self-repair worker may not terminate as prose before attempting a
                                // bounded mutating tool. Feed the provider its own text as context and force the
                                // next reasoning round to either inspect further or call apply_core_source_patch.
                                JSONObject assistantText=new JSONObject().put("role","assistant")
                                        .put("content",text.isEmpty()?"No tool call was produced.":text);
                                messages.put(assistantText);
                                messages.put(new JSONObject().put("role","system").put("content",
                                        "SELF_REPAIR_MUTATION_REQUIRED: This turn is not complete. You have not attempted a mutating maintenance tool. " +
                                        "Continue using the available tools. For a core self-repair, inspect canonical source as needed, then call apply_core_source_patch with the exact bound request_id/requested_change. " +
                                        "Do not return a final prose answer before a mutation attempt. If a concrete source blocker exists, gather exact tool evidence for it; otherwise mutate."));
                                prefs.edit().putInt("maintenance_reasoning_forced_mutation_rounds",
                                                prefs.getInt("maintenance_reasoning_forced_mutation_rounds",0)+1)
                                        .putString("maintenance_reasoning_last_enforcement","SELF_REPAIR_MUTATION_REQUIRED")
                                        .putLong("maintenance_reasoning_last_enforcement_at",System.currentTimeMillis()).apply();
                                continue;
                            }
                            if(text.isEmpty()) text="I completed the maintenance reasoning turn, but the provider returned no readable final text.";
                            prefs.edit().putString("maintenance_reasoning_provider",provider.id)
                                    .putString("maintenance_reasoning_model",provider.model)
                                    .putLong("maintenance_reasoning_success_at",System.currentTimeMillis())
                                    .remove("fallback_"+provider.id+"_cooldown_until").apply();
                            String code730ProviderTrace=LumiEvidenceLedger.beginTrace(prefs,"PROVIDERS");LumiEvidenceLedger.appendTrace(prefs,"PROVIDERS","DELEGATE_RESULT","delegateSucceeded","true","FallbackMaintenanceClient",code730ProviderTrace); callback.onSuccess(text,provider.id,provider.model);
                            return;
                        }

                        JSONObject assistant=new JSONObject().put("role","assistant");
                        Object c=message.opt("content");
                        assistant.put("content",c==null?JSONObject.NULL:c);
                        assistant.put("tool_calls",calls);
                        messages.put(assistant);

                        for(int i=0;i<calls.length();i++){
                            JSONObject call=calls.optJSONObject(i); if(call==null)continue;
                            String callId=call.optString("id","call-"+round+"-"+i);
                            JSONObject fn=call.optJSONObject("function");
                            String name=fn==null?"":fn.optString("name","");
                            String rawArgs=fn==null?"{}":fn.optString("arguments","{}");
                            JSONObject args; try{args=new JSONObject(rawArgs);}catch(Throwable ignored){args=new JSONObject();}
                            if(!readOnly(name)) mutationExecuted=true;
                            if(activity instanceof MainActivity){
                                ((MainActivity)activity).flightRecord("MAINTENANCE_TOOL","FALLBACK_MODEL_TOOL_CALL",
                                        "provider="+provider.id+" round="+round+" name="+name+" callId="+callId+" args="+rawArgs);
                            }
                            String result=LumiMaintenanceTools.execute(activity,prefs,name,args,userText);
                            messages.put(new JSONObject().put("role","tool").put("tool_call_id",callId).put("content",result));
                        }
                    }
                    if(isSelfRepairMutationRequired(userText,instructions) && !mutationExecuted)
                        throw new IllegalStateException("SELF_REPAIR_MUTATION_NOT_ATTEMPTED after "+ROUND_LIMIT+" enforced rounds");
                    throw new IllegalStateException("maintenance tool loop exceeded "+ROUND_LIMIT+" rounds");
                }catch(Throwable t){
                    String safe=safe(t);
                    if(failures.length()>0)failures.append(" | ");
                    failures.append(provider.id).append(": ").append(safe);
                    long cooldownMs=failureCooldownMs(t);
                    if(selfRepairRequest && softTransientProviderFailure(t)) cooldownMs=Math.min(cooldownMs,120000L);
                    prefs.edit().putString("maintenance_reasoning_last_error",safe)
                            .putString("maintenance_reasoning_failed_provider",provider.id)
                            .putLong("maintenance_reasoning_failure_at",System.currentTimeMillis())
                            .putLong("fallback_"+provider.id+"_cooldown_until",System.currentTimeMillis()+cooldownMs).apply();
                    // A write may already have been accepted by Lumi. Never replay the same owner
                    // instruction through a second model after that point.
                    if(mutationExecuted){
                        callback.onFailure("Provider "+provider.id+" failed after the maintenance transaction began: "+safe+". I kept the existing transaction and did not replay it through another provider.");
                        return;
                    }
                }
            }
            String freeFailure=failures.length()==0?"Every configured free maintenance provider failed.":failures.toString();
            callback.onFailure(freeFailure);
        },"LumiFallbackMaintenance").start();
    }

    private static void tryOpenAiMaintenanceFallback(Activity activity,SharedPreferences prefs,String instructions,String presence,
                                                      String recentTranscript,String userText,String freeFailure,Callback callback){
        String key=SecretStore.get(prefs,"openai_api_key").trim();
        if(key.isEmpty()){
            callback.onFailure(freeFailure+" | openai: no API key configured");
            return;
        }
        if(!prefs.getBoolean("openai_maintenance_fallback_enabled",true)){
            callback.onFailure(freeFailure+" | openai: maintenance fallback disabled");
            return;
        }
        long now=System.currentTimeMillis();
        long cooldown=prefs.getLong("openai_maintenance_cooldown_until",0L);
        if(cooldown>now){
            callback.onFailure(freeFailure+" | openai: cooling down");
            return;
        }
        long day=now/(24L*60L*60L*1000L);
        long savedDay=prefs.getLong("openai_maintenance_day",-1L);
        int count=savedDay==day?prefs.getInt("openai_maintenance_calls_today",0):0;
        int cap=Math.max(1,Math.min(100,prefs.getInt("openai_maintenance_daily_cap",20)));
        if(count>=cap){
            callback.onFailure(freeFailure+" | openai: daily maintenance cap reached ("+cap+")");
            return;
        }
        long last=prefs.getLong("openai_maintenance_last_attempt_at",0L);
        if(last>0L && now-last<60000L){
            callback.onFailure(freeFailure+" | openai: bounded retry interval active");
            return;
        }
        String model=prefs.getString("openai_model","gpt-5.6-luna").trim();
        if(model.isEmpty()) model="gpt-5.6-luna";
        prefs.edit().putLong("openai_maintenance_day",day)
                .putInt("openai_maintenance_calls_today",count+1)
                .putLong("openai_maintenance_last_attempt_at",now)
                .putString("maintenance_reasoning_provider","openai")
                .putString("maintenance_reasoning_model",model).apply();
        final String chosenModel=model;
        OpenAIReasoningClient.request(activity,prefs,key,chosenModel,instructions,presence,recentTranscript,userText,"",
                new OpenAIReasoningClient.Callback(){
                    @Override public void onSuccess(String reply,String responseId){
                        prefs.edit().putString("maintenance_reasoning_provider","openai")
                                .putString("maintenance_reasoning_model",chosenModel)
                                .putLong("maintenance_reasoning_success_at",System.currentTimeMillis())
                                .putBoolean("maintenance_openai_last_success",true)
                                .putLong("maintenance_openai_last_success_at",System.currentTimeMillis())
                                .remove("openai_maintenance_cooldown_until").apply();
                        callback.onSuccess(reply,"openai",chosenModel);
                    }
                    @Override public void onFailure(String error){
                        prefs.edit().putBoolean("maintenance_openai_last_success",false)
                                .putString("maintenance_reasoning_last_error",error==null?"OpenAI failed":error)
                                .putLong("maintenance_reasoning_failure_at",System.currentTimeMillis())
                                .putLong("openai_maintenance_cooldown_until",System.currentTimeMillis()+120000L).apply();
                        callback.onFailure(freeFailure+" | openai: "+(error==null?"failed":error));
                    }
                });
    }

    private static JSONArray baseMessages(String instructions,String presence,String recentTranscript,String userText) throws Exception{
        JSONArray messages=new JSONArray();
        String system=(instructions==null?"":instructions.trim())+"\n"+(presence==null?"":presence.trim());
        if(system.length()>8500)system=system.substring(0,8500);
        messages.put(new JSONObject().put("role","system").put("content",system));
        String recent=recentTranscript==null?"":recentTranscript.trim();
        if(recent.length()>5000)recent=recent.substring(recent.length()-5000);
        if(!recent.isEmpty())messages.put(new JSONObject().put("role","system").put("content","Recent active-session transcript:\n"+recent));
        messages.put(new JSONObject().put("role","user").put("content",userText==null?"":userText));
        return messages;
    }

    private static JSONArray chatToolDefinitions() throws Exception{
        JSONArray responses=LumiMaintenanceTools.definitions();
        JSONArray out=new JSONArray();
        for(int i=0;i<responses.length();i++){
            JSONObject d=responses.optJSONObject(i); if(d==null)continue;
            JSONObject fn=new JSONObject().put("name",d.optString("name",""))
                    .put("description",d.optString("description",""))
                    .put("parameters",d.optJSONObject("parameters") == null ? new JSONObject().put("type","object") : d.optJSONObject("parameters"));
            out.put(new JSONObject().put("type","function").put("function",fn));
        }
        return out;
    }

    private static JSONObject post(CloudBrainRouter.Provider provider,JSONArray messages,JSONArray tools)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(provider.endpoint).openConnection();
        try{
            c.setRequestMethod("POST"); c.setConnectTimeout(9000); c.setReadTimeout(40000); c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json");
            c.setRequestProperty("Authorization","Bearer "+provider.key);
            c.setRequestProperty("User-Agent","Lumi/4.0 FallbackMaintenance/1");
            if("openrouter".equals(provider.id)) c.setRequestProperty("X-Title","Lumi");
            JSONObject body=new JSONObject().put("model",provider.model).put("messages",messages)
                    .put("tools",tools).put("tool_choice","auto").put("stream",false)
                    .put("temperature",0.15).put("max_tokens",1500);
            try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            int code=c.getResponseCode(); InputStream is=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
            String raw=readAll(is);
            if(code<200||code>=300)throw new ProviderException(code,friendly(raw));
            return new JSONObject(raw);
        }finally{c.disconnect();}
    }

    private static JSONObject firstMessage(JSONObject root)throws Exception{
        JSONArray choices=root.optJSONArray("choices");
        if(choices==null||choices.length()==0)throw new IllegalStateException("provider returned no choices");
        JSONObject choice=choices.optJSONObject(0); JSONObject message=choice==null?null:choice.optJSONObject("message");
        if(message==null)throw new IllegalStateException("provider returned no assistant message");
        return message;
    }

    private static String contentText(JSONObject message){
        Object c=message.opt("content");
        if(c instanceof String)return ((String)c).trim();
        if(c instanceof JSONArray){
            StringBuilder b=new StringBuilder(); JSONArray a=(JSONArray)c;
            for(int i=0;i<a.length();i++){
                JSONObject part=a.optJSONObject(i); if(part==null)continue;
                String t=part.optString("text",part.optString("content",""));
                if(!t.isEmpty()){if(b.length()>0)b.append('\n');b.append(t);}
            }
            return b.toString().trim();
        }
        return "";
    }

    private static boolean isSelfRepairMutationRequired(String userText,String instructions){
        String u=userText==null?"":userText;
        String i=instructions==null?"":instructions;
        return u.startsWith("Execute already-approved Lumi self-repair work order ")
                || i.contains("bounded self-repair worker")
                || i.contains("Request id=selfrepair-");
    }

    private static boolean readOnly(String name){
        return "get_lumi_status".equals(name) || "check_maintenance_bridge".equals(name)
                || "read_lumi_diagnostics".equals(name) || "get_live_diagnostic_snapshot".equals(name) || "read_maintenance_history".equals(name)
                || "search_canonical_source".equals(name) || "read_canonical_source_file".equals(name)
                || "get_trusted_build_status".equals(name) || "get_pending_bridge_update_status".equals(name);
    }

    private static String readAll(InputStream is)throws Exception{
        if(is==null)return ""; StringBuilder b=new StringBuilder();
        try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null){b.append(line);if(b.length()>24000)break;}}
        return b.toString();
    }

    private static String friendly(String raw){
        if(raw==null||raw.trim().isEmpty())return "no error body";
        try{JSONObject j=new JSONObject(raw);Object e=j.opt("error");if(e instanceof JSONObject){String m=((JSONObject)e).optString("message","");if(!m.isEmpty())return bound(m);}if(e instanceof String)return bound((String)e);String m=j.optString("message","");if(!m.isEmpty())return bound(m);}catch(Throwable ignored){}
        return bound(raw.replace('\n',' ').replace('\r',' '));
    }

    private static boolean softTransientProviderFailure(Throwable t){
        if(t instanceof ProviderException){
            int c=((ProviderException)t).code;
            return c==408 || c==409 || c==425 || c==429 || c>=500;
        }
        String m=t==null?"":String.valueOf(t.getMessage()).toLowerCase();
        return m.contains("timeout") || m.contains("timed out") || m.contains("temporar") || m.contains("unavailable");
    }

    private static long failureCooldownMs(Throwable t){
        if(t instanceof ProviderException){
            int c=((ProviderException)t).code;
            if(c==401 || c==403)return 60L*60L*1000L;
            if(c==429)return 10L*60L*1000L;
            if(c>=500)return 90L*1000L;
        }
        String m=t==null?"":String.valueOf(t.getMessage()).toLowerCase();
        if(m.contains("timeout") || m.contains("timed out"))return 90L*1000L;
        return 45L*1000L;
    }

    private static String safe(Throwable t){
        String m=t==null?"unknown error":String.valueOf(t.getMessage());
        if(t instanceof ProviderException)m="HTTP "+((ProviderException)t).code+": "+m;
        return bound(m.replaceAll("(?i)Bearer\\s+[A-Za-z0-9._~+\\-/=]+","Bearer [redacted]"));
    }
    private static String bound(String s){String v=s==null?"":s.trim();return v.length()>360?v.substring(0,360):v;}
    private static final class ProviderException extends Exception{final int code;ProviderException(int c,String m){super(m);code=c;}}
}
