package com.distressedelk.lumi;

import android.app.*;
import android.content.*;
import android.os.*;

/** Code449: persistent owner-authorized background continuity and remote-maintenance host. */
public class LumiCoreService extends Service {
    static final String CHANNEL="lumi_core_silent_v4";
    private static final long WATCHDOG_MS=20000L;
    private Handler continuityHandler;
    private Runnable continuityWatchdog;
    private PowerManager.WakeLock continuityWakeLock;

    @Override public void onCreate(){
        super.onCreate();
        android.content.SharedPreferences p=getSharedPreferences("lumi",MODE_PRIVATE);
        RuntimePolicy.applyStartupPolicy(this,p);
        LumiCoreAuthority.applyOwnerGrantedRuntimeAuthority(p);
        p.edit()
                .putString("lumi_command_authority","LUMI_CORE")
                .putString("lumi_command_authority_service","LumiCoreService")
                .putString("lumi_owner_conversation","LUMI_CORE")
                .putString("lumi_owner_reasoning","LUMI_CORE")
                .putString("lumi_owner_health","LUMI_CORE")
                .putString("lumi_owner_maintenance","LUMI_CORE")
                .putString("lumi_owner_black_box","LUMI_CORE")
                .putBoolean("code622_core_authority_active",true)
                .putBoolean("code622_boot_black_box_pending",true)
                .putLong("code622_core_authority_at",System.currentTimeMillis()).apply();
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL,"Lumi continuity",NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Keeps Lumi available for conversation and owner-authorized remote maintenance.");
            ch.setSound(null,null); ch.enableVibration(false); ch.setVibrationPattern(null);
            NotificationManager nm=getSystemService(NotificationManager.class); if(nm!=null)nm.createNotificationChannel(ch);
        }
        Intent open=new Intent(this,MainActivity.class); open.putExtra(MainActivity.EXTRA_AUTO_LISTEN,true);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setContentTitle("Lumi is available").setContentText("Background continuity • tap to talk")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(pi);
        startForeground(1401,b.build());
        acquireDeveloperContinuityWakeLock(p);
        startContinuity(p,"service-create");
        p.edit().putLong("core_last_started",System.currentTimeMillis())
                .putBoolean("code449_core_foreground_started",true)
                .putString("code449_core_foreground_type","specialUse").apply();
    }

    private void acquireDeveloperContinuityWakeLock(android.content.SharedPreferences p){
        boolean enabled=IdentityHierarchy.developerOwnerBypassEnabled(p)
                && p.getBoolean("code449_developer_background_wakelock_enabled",true);
        if(!enabled){ p.edit().putBoolean("code449_core_wakelock_held",false).apply(); return; }
        try{
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(pm!=null){
                continuityWakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Lumi:Code449RemoteContinuity");
                continuityWakeLock.setReferenceCounted(false);
                continuityWakeLock.acquire();
            }
            p.edit().putBoolean("code449_core_wakelock_held",continuityWakeLock!=null && continuityWakeLock.isHeld())
                    .putLong("code449_core_wakelock_acquired_at",System.currentTimeMillis()).apply();
        }catch(Throwable t){
            p.edit().putBoolean("code449_core_wakelock_held",false)
                    .putString("code449_core_wakelock_error",t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage())).apply();
        }
    }

    private void startContinuity(android.content.SharedPreferences p,String reason){
        LiveMaintenanceSidecar.start(this);
        RemoteDeveloperMaintenance.ensureAlive(this,reason);
        if(continuityHandler==null)continuityHandler=new Handler(Looper.getMainLooper());
        if(continuityWatchdog==null){
            continuityWatchdog=new Runnable(){
                @Override public void run(){
                    try{
                        android.content.SharedPreferences prefs=getSharedPreferences("lumi",MODE_PRIVATE);
                        long now=System.currentTimeMillis();
                        long lastPoll=prefs.getLong("remote_maintenance_last_poll_at",0L);
                        boolean stale=lastPoll<=0L || now-lastPoll>45000L;
                        prefs.edit().putLong("code449_core_watchdog_at",now)
                                .putInt("code449_core_watchdog_count",prefs.getInt("code449_core_watchdog_count",0)+1)
                                .putBoolean("code449_core_watchdog_poll_stale",stale)
                                .putLong("code449_core_watchdog_poll_age_ms",lastPoll<=0L?-1L:Math.max(0L,now-lastPoll))
                                .putBoolean("code449_core_wakelock_held",continuityWakeLock!=null && continuityWakeLock.isHeld()).apply();
                        RemoteDeveloperMaintenance.ensureAlive(LumiCoreService.this,stale?"service-watchdog-stale":"service-watchdog");
                    }catch(Throwable t){
                        try{getSharedPreferences("lumi",MODE_PRIVATE).edit().putString("code449_core_watchdog_error",t.getClass().getSimpleName()+": "+String.valueOf(t.getMessage())).apply();}catch(Throwable ignored){}
                    }finally{
                        if(continuityHandler!=null)continuityHandler.postDelayed(this,WATCHDOG_MS);
                    }
                }
            };
            continuityHandler.postDelayed(continuityWatchdog,WATCHDOG_MS);
        }
        p.edit().putString("code449_continuity_last_reason",reason==null?"":reason)
                .putLong("code449_continuity_last_start_at",System.currentTimeMillis()).apply();
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        android.content.SharedPreferences p=getSharedPreferences("lumi",MODE_PRIVATE);
        startContinuity(p,"service-start-command");
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent){
        android.content.SharedPreferences p=getSharedPreferences("lumi",MODE_PRIVATE);
        p.edit().putLong("code449_core_task_removed_at",System.currentTimeMillis()).apply();
        RemoteDeveloperMaintenance.ensureAlive(this,"task-removed");
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy(){
        try{if(continuityHandler!=null && continuityWatchdog!=null)continuityHandler.removeCallbacks(continuityWatchdog);}catch(Throwable ignored){}
        try{if(continuityWakeLock!=null && continuityWakeLock.isHeld())continuityWakeLock.release();}catch(Throwable ignored){}
        try{getSharedPreferences("lumi",MODE_PRIVATE).edit().putBoolean("code449_core_foreground_started",false)
                .putBoolean("code449_core_wakelock_held",false).putLong("code449_core_destroyed_at",System.currentTimeMillis()).apply();}catch(Throwable ignored){}
        LiveMaintenanceSidecar.stop();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent){return null;}
}
