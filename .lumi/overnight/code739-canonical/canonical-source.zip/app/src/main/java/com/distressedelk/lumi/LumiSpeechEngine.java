package com.distressedelk.lumi;

/**
 * Code466 audit boundary for speech ownership.
 * Phase 1 deliberately observes the Core2 runtime without changing recognizer algorithms.
 * The next migration can move recognizer callbacks behind this boundary without UI/MainActivity
 * becoming a competing state authority.
 */
final class LumiSpeechEngine {
    static final String MARKER = "CORE2_SPEECH_ENGINE_BOUNDARY";

    static final class Snapshot {
        final long sequence;
        final LumiRuntimeController.State runtimeState;
        final String reason;
        Snapshot(long sequence, LumiRuntimeController.State runtimeState, String reason){
            this.sequence=sequence;
            this.runtimeState=runtimeState;
            this.reason=reason==null?"":reason;
        }
        String compact(){ return "seq="+sequence+" runtime="+runtimeState+" reason="+reason; }
    }

    private long sequence=0L;
    private Snapshot latest=new Snapshot(0L, LumiRuntimeController.State.IDLE, "init");

    synchronized Snapshot observe(LumiRuntimeController.Snapshot runtime, String reason){
        LumiRuntimeController.State state=runtime==null?LumiRuntimeController.State.IDLE:runtime.authoritative;
        latest=new Snapshot(++sequence,state,reason);
        return latest;
    }

    synchronized Snapshot latest(){ return latest; }
}
