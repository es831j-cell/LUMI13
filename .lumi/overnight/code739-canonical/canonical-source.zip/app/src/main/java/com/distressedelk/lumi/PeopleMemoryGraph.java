package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Code433 deterministic relationship + contact-fact memory graph. Explicit statements only. */
final class PeopleMemoryGraph {
    private PeopleMemoryGraph(){}
    private static final String REL="wife|husband|spouse|son|daughter|child|mother|mom|father|dad|parent|brother|sister|sibling|grandmother|grandma|grandfather|grandpa|grandson|granddaughter";
    private static final Pattern MY_REL=Pattern.compile("(?i)^\\s*my\\s+("+REL+")(?:'s\\s+name)?\\s+is\\s+([A-Za-z][A-Za-z .'-]{0,49})\\s*[.!]?\\s*$");
    private static final Pattern REL_NAME=Pattern.compile("(?i)^\\s*(?:my\\s+)?("+REL+")'s\\s+name\\s+is\\s+([A-Za-z][A-Za-z .'-]{0,49})\\s*[.!]?\\s*$");
    private static final Pattern NAME_REL=Pattern.compile("(?i)^\\s*([A-Za-z][A-Za-z .'-]{0,49}?)\\s+is\\s+my\\s+("+REL+")\\s*[.!]?\\s*$");
    private static final Pattern HAVE_REL_NAMED=Pattern.compile("(?i)^\\s*(?:i have|we have)\\s+(?:a|an|one)?\\s*("+REL+")\\s+named\\s+([A-Za-z][A-Za-z .'-]{0,49})\\s*[.!]?\\s*$");
    private static final Pattern REL_IS_NAMED=Pattern.compile("(?i)^\\s*my\\s+("+REL+")\\s+is\\s+named\\s+([A-Za-z][A-Za-z .'-]{0,49})\\s*[.!]?\\s*$");
    private static final Pattern CHANGE_REL=Pattern.compile("(?i)^\\s*(?:change|set|update|correct)\\s+(?:my\\s+)?("+REL+")'s\\s+name\\s+(?:to|as)\\s+([A-Za-z][A-Za-z .'-]{0,49})\\s*[.!]?\\s*$");
    private static final Pattern REL_QUERY=Pattern.compile("(?i)^\\s*(?:what(?:'s| is)|who is)\\s+(?:my\\s+)?("+REL+")(?:'s\\s+name)?\\s*[?]?\\s*$");
    private static final Pattern PREF=Pattern.compile("(?i)^\\s*([A-Za-z][A-Za-z'-]{1,40})\\s+(likes|loves|enjoys|prefers)\\s+(.{2,160}?)(?:[.!]|$)");
    private static final Pattern NAMED_FACT=Pattern.compile("(?i)^\\s*([A-Za-z][A-Za-z .'-]{0,49}?)'s\\s+([A-Za-z][A-Za-z0-9 ' -]{1,59}?)\\s+is\\s+(.{1,180}?)\\s*[.!]?\\s*$");
    private static final Pattern REL_FACT=Pattern.compile("(?i)^\\s*my\\s+("+REL+")'s\\s+([A-Za-z][A-Za-z0-9 ' -]{1,59}?)\\s+is\\s+(.{1,180}?)\\s*[.!]?\\s*$");
    private static final Pattern PRONOUN_FACT=Pattern.compile("(?i)^\\s*(?:her|his|their)\\s+([A-Za-z][A-Za-z0-9 ' -]{1,59}?)\\s+is\\s+(.{1,180}?)\\s*[.!]?\\s*$");
    private static final Pattern OWNER_FACT=Pattern.compile("(?i)^\\s*my\\s+([A-Za-z][A-Za-z0-9 ' -]{1,59}?)\\s+is\\s+(.{1,180}?)\\s*[.!]?\\s*$");
    private static final Pattern NAMED_FACT_QUERY=Pattern.compile("(?i)^\\s*(?:what(?:'s| is)|do you know)\\s+([A-Za-z][A-Za-z .'-]{0,49}?)'s\\s+([A-Za-z][A-Za-z0-9 ' -]{1,59}?)\\s*[?]?\\s*$");
    private static final Pattern REL_FACT_QUERY=Pattern.compile("(?i)^\\s*(?:what(?:'s| is)|do you know)\\s+my\\s+("+REL+")'s\\s+([A-Za-z][A-Za-z0-9 ' -]{1,59}?)\\s*[?]?\\s*$");
    private static final Pattern PRONOUN_FACT_QUERY=Pattern.compile("(?i)^\\s*(?:what(?:'s| is)|do you know)\\s+(?:her|his|their)\\s+([A-Za-z][A-Za-z0-9 ' -]{1,59}?)\\s*[?]?\\s*$");

    static void observe(Context c,SharedPreferences prefs,String raw){
        if(c==null||prefs==null||raw==null||raw.trim().isEmpty()||raw.trim().endsWith("?"))return;
        String t=raw.trim();
        try{
            Matcher m=REL_NAME.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2))){relationship(c,prefs,m.group(2).trim(),m.group(1));return;}
            m=MY_REL.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2))){relationship(c,prefs,m.group(2).trim(),m.group(1));return;}
            m=NAME_REL.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(1))){relationship(c,prefs,m.group(1).trim(),m.group(2));return;}
            m=HAVE_REL_NAMED.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2))){relationship(c,prefs,m.group(2).trim(),m.group(1));return;}
            m=REL_IS_NAMED.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2))){relationship(c,prefs,m.group(2).trim(),m.group(1));return;}
            m=PREF.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(1)))saveFact(c,prefs,IdentityHierarchy.findContactIdByName(prefs,m.group(1).trim()),m.group(1).trim(),"preference",m.group(3).trim(),"explicit-conversation:"+m.group(2).toLowerCase(Locale.US),false);
        }catch(Throwable ignored){}
    }

    static String tryHandleLocal(Context c,SharedPreferences prefs,String raw){
        if(c==null||prefs==null||raw==null)return null;String t=raw.trim();if(t.isEmpty())return null;
        try{
            // Code626: Lumi Core owns personal identity/relationship answers. Providers are data delegates only.
            String coreQ=t.toLowerCase(Locale.US).replaceAll("[?!.,]+$","").trim();
            if(coreQ.equals("who else do you know")||coreQ.equals("who do you know")){
                String summary=IdentityHierarchy.privacySafeContactSummary(prefs);
                if(summary==null||summary.trim().isEmpty())return "I don't have any confirmed people saved yet.";
                StringBuilder names=new StringBuilder();
                for(String line:summary.split("\\n")){
                    String x=line==null?"":line.trim();
                    if(!x.startsWith("- "))continue;
                    String body=x.substring(2);
                    int cut=body.indexOf(" • state=");if(cut>=0)body=body.substring(0,cut);
                    if(names.length()>0)names.append("; ");names.append(body.replace(" • relationship="," is my "));
                }
                if(names.length()==0)return "I have a local people graph, but no confirmed names are available to speak yet.";
                prefs.edit().putString("lumi_core_last_subject","people-graph").putString("lumi_core_last_answer_basis","authoritative-local-people-graph").apply();
                return "I know "+names.toString()+". That's from my confirmed local people graph.";
            }
            if(coreQ.equals("how do you know")){
                String subject=prefs.getString("lumi_core_last_subject","");
                String last=prefs.getString("last_lumi_reply","");
                if("owner-identity".equals(subject)||(last!=null&&last.toLowerCase(Locale.US).contains("eric"))){
                    prefs.edit().putString("lumi_core_last_answer_basis","authoritative-local-identity").apply();
                    return "I know because Eric is stored in my local identity graph as my Primary Administrator with ROOT_ADMIN authority.";
                }
            }
            Matcher m=CHANGE_REL.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2)))return setRelationshipLocal(c,prefs,m.group(2).trim(),m.group(1),true);
            m=REL_NAME.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2)))return setRelationshipLocal(c,prefs,m.group(2).trim(),m.group(1),true);
            m=MY_REL.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2)))return setRelationshipLocal(c,prefs,m.group(2).trim(),m.group(1),true);
            m=NAME_REL.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(1)))return setRelationshipLocal(c,prefs,m.group(1).trim(),m.group(2),true);
            m=HAVE_REL_NAMED.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2)))return setRelationshipLocal(c,prefs,m.group(2).trim(),m.group(1),true);
            m=REL_IS_NAMED.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(2)))return setRelationshipLocal(c,prefs,m.group(2).trim(),m.group(1),true);
            m=REL_QUERY.matcher(t);if(m.matches()){String rawRel=m.group(1),rel=normalize(rawRel),name=IdentityHierarchy.relationshipContactName(prefs,rel);if(name.isEmpty())return "I don't have a confirmed "+rawRel.toLowerCase(Locale.US)+" name saved yet.";rememberPerson(prefs,name);return "Your "+rawRel.toLowerCase(Locale.US)+"'s name is "+name+".";}

            m=REL_FACT.matcher(t);if(m.matches()){String id=IdentityHierarchy.findContactIdByRelationship(prefs,normalize(m.group(1)));String name=IdentityHierarchy.contactName(prefs,id);return saveFact(c,prefs,id,name,m.group(2),m.group(3),"explicit-owner-relationship-fact",true);}
            m=NAMED_FACT.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(1))&&validTopic(m.group(2))){String name=m.group(1).trim();return saveFact(c,prefs,IdentityHierarchy.findContactIdByName(prefs,name),name,m.group(2),m.group(3),"explicit-owner-named-fact",true);}
            m=PRONOUN_FACT.matcher(t);if(m.matches()&&validTopic(m.group(1))){String name=prefs.getString("identity_last_fact_person","");return saveFact(c,prefs,IdentityHierarchy.findContactIdByName(prefs,name),name,m.group(1),m.group(2),"explicit-owner-pronoun-fact",true);}
            m=OWNER_FACT.matcher(t);if(m.matches()&&validOwnerTopic(m.group(1))){String name=IdentityHierarchy.contactName(prefs,IdentityHierarchy.PRIMARY_CONTACT_ID);return saveFact(c,prefs,IdentityHierarchy.PRIMARY_CONTACT_ID,name,m.group(1),m.group(2),"explicit-owner-self-fact",true);}

            m=REL_FACT_QUERY.matcher(t);if(m.matches()){String id=IdentityHierarchy.findContactIdByRelationship(prefs,normalize(m.group(1)));return answerFact(prefs,id,IdentityHierarchy.contactName(prefs,id),m.group(2));}
            m=NAMED_FACT_QUERY.matcher(t);if(m.matches()&&isLikelyPersonName(m.group(1))){String name=m.group(1).trim();return answerFact(prefs,IdentityHierarchy.findContactIdByName(prefs,name),name,m.group(2));}
            m=PRONOUN_FACT_QUERY.matcher(t);if(m.matches()){String name=prefs.getString("identity_last_fact_person","");return answerFact(prefs,IdentityHierarchy.findContactIdByName(prefs,name),name,m.group(1));}
        }catch(Throwable ignored){}
        return null;
    }

    static void migrateCode406OwnerConfirmedSpouse(Context c,SharedPreferences prefs){
        if(c==null||prefs==null||prefs.getBoolean("code406_spouse_repair_migrated",false))return;
        String id=IdentityHierarchy.setExclusiveRelationshipContact(prefs,"spouse","Janet","owner-confirmed-code406-repair");
        if(!id.isEmpty()){LumiMemoryVault v=LumiMemoryVault.get(c);String owner=ownerName(prefs);v.rememberVerified("relationship",IdentityHierarchy.PRIMARY_CONTACT_ID+"->"+id,owner+" -> spouse -> Janet",99,"owner-confirmed-code406-repair");v.rememberVerified("relationship",id+"->"+IdentityHierarchy.PRIMARY_CONTACT_ID,"Janet -> spouse -> "+owner,99,"owner-confirmed-code406-repair");record(c,prefs,"CODE406_SPOUSE_REPAIRED","contact="+id+" name=Janet relationship=spouse confidence=owner-confirmed");}
        prefs.edit().putBoolean("code406_spouse_repair_migrated",true).putString("code406_owner_spouse_name","Janet").apply();
    }

    private static String setRelationshipLocal(Context c,SharedPreferences prefs,String name,String rawRel,boolean reply){
        String rel=normalize(rawRel);record(c,prefs,"FACT_DETECTED","type=relationship name="+name+" relationship="+rel);String id;
        if("spouse".equals(rel))id=IdentityHierarchy.setExclusiveRelationshipContact(prefs,rel,name,"explicit-owner-local");else id=IdentityHierarchy.ensureRelationshipContact(prefs,name,rel,"explicit-owner-local");
        if(id.isEmpty()){record(c,prefs,"CONTACT_WRITE_FAILED","type=relationship name="+name+" relationship="+rel);return "I couldn't save that relationship locally.";}
        record(c,prefs,"CONTACT_WRITE_VERIFIED","contact="+id+" name="+name+" relationship="+rel);LumiMemoryVault v=LumiMemoryVault.get(c);String owner=ownerName(prefs);
        boolean a=v.rememberVerified("relationship",IdentityHierarchy.PRIMARY_CONTACT_ID+"->"+id,owner+" -> "+rel+" -> "+name,99,"explicit-owner-local");String inv=inverse(rel);boolean b=inv.isEmpty()||v.rememberVerified("relationship",id+"->"+IdentityHierarchy.PRIMARY_CONTACT_ID,name+" -> "+inv+" -> "+owner,99,"explicit-owner-local");
        record(c,prefs,a&&b?"VAULT_WRITE_VERIFIED":"VAULT_WRITE_FAILED","contact="+id+" relationship="+rel);rememberPerson(prefs,name);
        prefs.edit().putInt("people_graph_relationship_count",prefs.getInt("people_graph_relationship_count",0)+1).putLong("people_graph_last_relationship_at",System.currentTimeMillis()).apply();
        return "Got it. Your "+rawRel.toLowerCase(Locale.US)+"'s name is "+name+".";
    }

    private static String saveFact(Context c,SharedPreferences prefs,String id,String name,String topic,String rawValue,String source,boolean reply){
        String value=cleanValue(rawValue), key=IdentityHierarchy.normalizeContactFactTopic(topic);if(id==null||id.isEmpty()||name==null||name.trim().isEmpty())return reply?"I heard the fact, but I don't have a confirmed contact card for that person yet.":null;if(!validTopic(topic)||value.isEmpty())return null;
        record(c,prefs,"FACT_DETECTED","person="+name+" topic="+key+" value="+value);record(c,prefs,"FACT_CLASSIFIED","destination=contact-card+memory-vault contact="+id+" topic="+key);record(c,prefs,"CONTACT_WRITE_BEGIN","contact="+id+" topic="+key);
        boolean card=IdentityHierarchy.upsertContactFact(prefs,id,topic,value,source);String cardRead=IdentityHierarchy.contactFact(prefs,id,key);record(c,prefs,card&&value.equals(cardRead)?"CONTACT_WRITE_VERIFIED":"CONTACT_WRITE_FAILED","contact="+id+" topic="+key+" readback="+cardRead);
        String memKey=id+":fact:"+key;record(c,prefs,"VAULT_WRITE_BEGIN","key="+memKey);boolean vault=LumiMemoryVault.get(c).rememberVerified("entity_fact",memKey,name+" | "+key+" = "+value,97,source);String vaultRead=LumiMemoryVault.get(c).recallMemory("entity_fact",memKey);record(c,prefs,vault?"VAULT_WRITE_VERIFIED":"VAULT_WRITE_FAILED","key="+memKey+" readback="+vaultRead);
        boolean ok=card&&vault&&value.equals(IdentityHierarchy.contactFact(prefs,id,key))&&!vaultRead.isEmpty();record(c,prefs,ok?"READBACK_VERIFIED":"READBACK_FAILED","contact="+id+" topic="+key+" contact="+card+" vault="+vault);
        if(ok){prefs.edit().putInt("people_graph_fact_count",prefs.getInt("people_graph_fact_count",0)+1).putLong("people_graph_last_fact_at",System.currentTimeMillis()).apply();rememberPerson(prefs,name);}
        if(!reply)return null;if(!ok)return "I heard that, but the persistent-memory readback did not verify, so I did not pretend it was saved.";return "Got it. "+name+"'s "+topic.trim()+" is "+value+".";
    }

    private static String answerFact(SharedPreferences prefs,String id,String name,String topic){
        if(id==null||id.isEmpty()||name==null||name.trim().isEmpty())return "I don't have a confirmed contact card for that person yet.";String value=IdentityHierarchy.contactFact(prefs,id,topic);rememberPerson(prefs,name);if(value.isEmpty())return "I don't have a confirmed "+topic.trim()+" saved for "+name+" yet.";return name+"'s "+topic.trim()+" is "+value+".";
    }

    private static boolean validOwnerTopic(String t){String k=IdentityHierarchy.normalizeContactFactTopic(t);return k.startsWith("favorite-")||k.equals("birthday")||k.equals("anniversary")||k.equals("preference")||k.equals("favorite");}
    private static boolean validTopic(String t){String k=IdentityHierarchy.normalizeContactFactTopic(t);return !k.isEmpty()&&!k.equals("name")&&!k.equals("relationship")&&!k.equals("contact-card")&&k.length()<=64;}
    private static String cleanValue(String v){String x=v==null?"":v.trim();x=x.replaceAll("[.!]+$","").trim();return x.length()>180?x.substring(0,180):x;}
    private static void rememberPerson(SharedPreferences p,String name){if(p!=null&&name!=null&&!name.trim().isEmpty())p.edit().putString("identity_last_fact_person",name.trim()).putLong("identity_last_fact_at",System.currentTimeMillis()).apply();}
    private static boolean isLikelyPersonName(String raw){String n=raw==null?"":raw.trim();if(n.length()<1||n.length()>50||!n.matches("(?i)[a-z][a-z .'-]{0,49}"))return false;String l=n.toLowerCase(Locale.US).replaceAll("\\s+"," ");String[] bad={"what","who","where","when","why","how","okay","now","name","my","your","is my","tell me","do you"};for(String b:bad)if(l.equals(b)||l.startsWith(b+" "))return false;return true;}
    private static void relationship(Context c,SharedPreferences prefs,String name,String rawRel){setRelationshipLocal(c,prefs,name,rawRel,false);}
    private static void record(Context c,SharedPreferences p,String action,String detail){DeveloperFlightRecorder.record(c,p,0L,"MEMORY",action,detail,"memory-graph","rules","persistent-memory",false,false,false);}
    static String summary(SharedPreferences prefs){return "relationshipsObserved="+prefs.getInt("people_graph_relationship_count",0)+" • entityFactsObserved="+prefs.getInt("people_graph_fact_count",0);}
    private static String ownerName(SharedPreferences p){return p.getString("owner_call_name",p.getString("owner_name","Owner"));}
    private static String normalize(String x){String r=x==null?"":x.toLowerCase(Locale.US).trim();if(r.equals("wife")||r.equals("husband")||r.equals("spouse"))return "spouse";if(r.equals("son")||r.equals("daughter")||r.equals("child"))return "child";if(r.equals("mother")||r.equals("mom")||r.equals("father")||r.equals("dad")||r.equals("parent"))return "parent";if(r.equals("brother")||r.equals("sister")||r.equals("sibling"))return "sibling";if(r.startsWith("grandmother")||r.equals("grandma")||r.startsWith("grandfather")||r.equals("grandpa"))return "grandparent";if(r.equals("grandson")||r.equals("granddaughter"))return "grandchild";return r;}
    private static String inverse(String r){if(r.equals("spouse")||r.equals("sibling"))return r;if(r.equals("child"))return "parent";if(r.equals("parent"))return "child";if(r.equals("grandparent"))return "grandchild";if(r.equals("grandchild"))return "grandparent";return "";}
}
