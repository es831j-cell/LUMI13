package com.distressedelk.lumi;

/**
 * External/cloud models are advisers to Lumi Core, never Lumi's identity or final response authority.
 * Provider output is deliberately wrapped as advisory material so it cannot become a spoken reply
 * until Lumi Core explicitly unwraps and commits it.
 */
final class LumiProviderAdviserContract {
    static final String ROLE="ADVISER";
    static final String ENVELOPE_PREFIX="[[LUMI_ADVICE_V1]]";
    private LumiProviderAdviserContract(){}

    static String instructionsForAdvice(String upstream){
        String format=formatHint(upstream);
        return "You are an external advisory reasoning engine assisting Lumi Core. "
                +"You are not Lumi and must not speak as Lumi. Return source material for Lumi Core, not a final user-facing response. "
                +"Do not claim you performed, started, changed, sent, installed, published, saved, created, or completed any action. "
                +"Do not decide whether Lumi can perform an action. Return concise factual guidance, reasoning, options, or evidence that Lumi Core can evaluate. "
                +"Do not address the owner directly and do not use role labels such as User:, Assistant:, or Lumi:. "
                +"If the request asks for an action, explain useful method/options and any requirements, but do not promise execution. "
                +"If information is uncertain, say what is uncertain. "
                +format;
    }

    static String instructionsForResearchAdvice(String upstream){
        return instructionsForAdvice(upstream)
                +" For research synthesis, compare the supplied evidence, distinguish agreement from disagreement, and return advisory findings for Lumi Core. Do not invent consensus.";
    }

    static String normalizeAdvice(String raw){
        String s=raw==null?"":raw.trim();
        if(s.regionMatches(true,0,"ADVISORY NOTES:",0,"ADVISORY NOTES:".length()))s=s.substring("ADVISORY NOTES:".length()).trim();
        if(s.regionMatches(true,0,"ADVICE:",0,"ADVICE:".length()))s=s.substring("ADVICE:".length()).trim();
        s=s.replaceFirst("(?i)^(assistant|lumi|answer|response)\\s*:\\s*","").trim();
        if(s.startsWith(ENVELOPE_PREFIX))return s;
        return ENVELOPE_PREFIX+s;
    }

    static boolean isAdviceEnvelope(String raw){
        return raw!=null && raw.trim().startsWith(ENVELOPE_PREFIX);
    }

    static String adviceBody(String raw){
        String s=raw==null?"":raw.trim();
        if(s.startsWith(ENVELOPE_PREFIX))s=s.substring(ENVELOPE_PREFIX.length()).trim();
        return s;
    }

    /**
     * Synchronous Core rendering boundary. The cloud supplied advisory material; Lumi Core decides
     * how that material appears in the final turn. Draft/creative requests preserve the requested
     * artifact body. Ordinary factual/advisory turns are framed as Lumi's evaluated finding.
     */
    static String renderForLumiCore(String rawAdvice,String userRequest){
        String body=adviceBody(rawAdvice);
        if(body.isEmpty())return body;
        String q=userRequest==null?"":userRequest.toLowerCase(java.util.Locale.US);
        boolean artifact=q.contains("write ")||q.contains("draft ")||q.contains("rewrite ")||q.contains("email")
                ||q.contains("message")||q.contains("caption")||q.contains("post ")||q.contains("letter")
                ||q.contains("script")||q.contains("poem")||q.contains("story");
        if(artifact)return body;
        boolean listLike=body.startsWith("-")||body.startsWith("•")||body.matches("(?s)^\\d+[.)].*");
        return listLike?"Here’s what I found:\n"+body:"Based on what I found: "+body;
    }

    private static String formatHint(String upstream){
        String s=upstream==null?"":upstream.toLowerCase(java.util.Locale.US);
        if(s.contains("concise")||s.contains("brief"))return "Keep the advisory material concise.";
        if(s.contains("requested length")||s.contains("requested format"))return "Respect obvious length or format constraints from the request when they do not conflict with this adviser role.";
        return "Keep the advisory material focused enough for Lumi Core to evaluate directly.";
    }
}
