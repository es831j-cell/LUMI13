package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Code621 R339: diagnostics-to-signed-build handoff only.
 * Provider-driven autonomous source editing/build dispatch is intentionally retired for Lumi 1.0.
 * Diagnostics remain autonomous; compiled repairs flow through Black Box -> validated signed build.
 */
final class LumiMaintenanceBuildHandoff {
    private LumiMaintenanceBuildHandoff(){}

    static void enqueue(Context c, SharedPreferences p, String classification, String area, String action, long now){
        if(c==null||p==null) return;
        long candidateAt=p.getLong("maintenance_candidate_last_at",0L);
        long handled=p.getLong("maintenance_build_handoff_candidate_at",0L);
        if(candidateAt<=0L || candidateAt<=handled) return;
        String cls=classification==null?"":classification.trim();
        String ar=area==null?"":area.trim();
        String act=action==null?"":action.trim();
        String requested="classification="+cls+" area="+ar+" action="+act;
        p.edit()
                .putLong("maintenance_build_handoff_candidate_at",candidateAt)
                .putString("maintenance_build_handoff_status","MANUAL_SIGNED_BUILD_REQUIRED")
                .putString("maintenance_build_handoff_request_id","")
                .putString("maintenance_build_handoff_requested_change",requested)
                .putString("maintenance_build_handoff_tools","diagnostics,black_box,validated_signed_build")
                .putString("maintenance_build_handoff_error","")
                .putLong("maintenance_build_handoff_at",now)
                .putBoolean("maintenance_executor_escalation_pending",false)
                .apply();
    }

    static void reconcile(Context c, SharedPreferences p, long now){
        if(c==null||p==null) return;
        String s=p.getString("maintenance_build_handoff_status","NOT_REQUESTED");
        if("WORK_ORDER_READY".equals(s)||"SOURCE_PATCH_REQUIRED_RETRY".equals(s)||"RUNNER_ERROR".equals(s)||
                "RUNNER_DISPATCHED".equals(s)||"WAITING_FOR_ACTIVITY".equals(s)||"WAITING_FOR_TRANSACTION".equals(s)||
                "TRANSACTION_BIND_FAILED".equals(s)||"SELF_REPAIR_BLOCKED".equals(s)){
            p.edit().putString("maintenance_build_handoff_status","MANUAL_SIGNED_BUILD_REQUIRED")
                    .putString("maintenance_build_handoff_request_id","")
                    .putString("maintenance_build_handoff_error","autonomous provider repair retired in Code621; use Black Box validated signed-build lane")
                    .putLong("maintenance_build_handoff_at",now)
                    .putInt("maintenance_work_order_runner_retry_count",0)
                    .putLong("maintenance_work_order_runner_at",0L)
                    .apply();
        }
    }
}
