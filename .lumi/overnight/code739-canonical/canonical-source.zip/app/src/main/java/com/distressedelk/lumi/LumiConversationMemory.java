package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Code660 durable, local conversation memory used by Lumi Core before any provider. */
final class LumiConversationMemory {
    private static final String DIR="lumi-memory";
    private static final String FILE="conversation-v1.jsonl";
    private static final long PROCESS_STARTED_AT=System.currentTimeMillis();
    private static final long RETAIN_MS=14L*24L*60L*60L*1000L;
    private static final long MAX_BYTES=1024L*1024L;
    private static final int MAX_RECORDS=400;
    private static boolean initialized=false;

    private LumiConversationMemory(){}

    static synchronized void initialize(Context c,SharedPreferences p){
        if(c==null||p==null||initialized)return;
        File f=file(c);
        boolean prior=f.exists()&&f.length()>0L&&f.lastModified()<PROCESS_STARTED_AT;
        p.edit().putBoolean("lumi1_memory_store_present",f.exists()&&f.length()>0L)
                .putBoolean("lumi1_memory_reload_proof",prior||p.getBoolean("lumi1_memory_reload_proof",false))
                .putLong("lumi1_memory_initialized_at",System.currentTimeMillis()).apply();
        initialized=true;
        compactIfNeeded(c,p);
    }

    static synchronized void recordUser(Context c,SharedPreferences p,long turnId,String text,String source){
        append(c,p,turnId,"user",text,source);
    }

    static synchronized void recordLumi(Context c,SharedPreferences p,long turnId,String text,String source){
        append(c,p,turnId,"lumi",text,source);
        if(turnId>0L)p.edit().putInt("lumi1_memory_completed_turns",p.getInt("lumi1_memory_completed_turns",0)+1).apply();
    }

    static synchronized String tryAnswer(Context c,SharedPreferences p,String raw){
        if(c==null||p==null||raw==null)return null;
        initialize(c,p);
        String q=norm(raw);
        boolean recent=q.contains("what were we talking about")||q.contains("what were we just talking about")
                ||q.contains("what did we talk about")||q.contains("do you remember our conversation")
                ||q.contains("do you remember what we talked about")||q.contains("remember our conversation");
        boolean lastUser=q.contains("what did i just say")||q.contains("what was the last thing i said");
        boolean lastLumi=q.contains("what did you just say")||q.contains("what was the last thing you said");
        if(!recent&&!lastUser&&!lastLumi)return null;
        List<JSONObject> xs=recent(12,c);
        if(xs.isEmpty())return "I don't have a durable conversation record to recall yet.";
        String answer;
        if(lastUser){
            String x=lastRole(xs,"user");
            answer=x.isEmpty()?"I don't have a recent user turn stored yet.":"The last thing I have you saying is: “"+clip(x,420)+"”";
        }else if(lastLumi){
            String x=lastRole(xs,"lumi");
            answer=x.isEmpty()?"I don't have a recent Lumi reply stored yet.":"The last reply I have from me is: “"+clip(x,420)+"”";
        }else{
            ArrayList<String> pairs=new ArrayList<String>();
            for(JSONObject j:xs){
                String role=j.optString("role","");
                String text=j.optString("text","");
                if(text.isEmpty())continue;
                pairs.add(("user".equals(role)?"You: ":"Me: ")+clip(text,220));
            }
            int from=Math.max(0,pairs.size()-6);
            StringBuilder b=new StringBuilder("Yes. My durable local conversation memory has the recent thread: ");
            for(int i=from;i<pairs.size();i++){if(i>from)b.append(" | ");b.append(pairs.get(i));}
            answer=b.toString();
        }
        p.edit().putInt("lumi1_memory_recall_success",p.getInt("lumi1_memory_recall_success",0)+1)
                .putLong("lumi1_memory_recall_last_at",System.currentTimeMillis()).apply();
        boolean provenance=true,currentBuild=false;long newestAt=-1L;int newestBuild=0;for(JSONObject j:xs){boolean valid="LumiConversationMemory1".equals(j.optString("schema"))&&j.optLong("at",0L)>0L&&j.optLong("turn",0L)>0L&&!j.optString("role","").isEmpty()&&!j.optString("source","").isEmpty()&&j.optInt("build",0)>0;if(!valid)provenance=false;if(j.optLong("at",0L)>=newestAt){newestAt=j.optLong("at",0L);newestBuild=j.optInt("build",0);}}currentBuild=newestBuild==735;
        String code730MemoryTrace=LumiEvidenceLedger.activeTrace(p,"MEMORY");LumiEvidenceLedger.appendTrace(p,"MEMORY","ACCEPTANCE","recallVerified","true","LumiConversationMemory",code730MemoryTrace);LumiEvidenceLedger.appendTrace(p,"MEMORY","ACCEPTANCE","provenanceVerified",String.valueOf(provenance),"LumiConversationMemory",code730MemoryTrace);LumiEvidenceLedger.appendTrace(p,"MEMORY","ACCEPTANCE","currentBuildPrecedence",String.valueOf(currentBuild),"LumiConversationMemory",code730MemoryTrace);if(provenance&&currentBuild)LumiEvidenceLedger.endTrace(p,"MEMORY",code730MemoryTrace);
        return answer;
    }

    static synchronized String status(Context c,SharedPreferences p){
        if(c==null||p==null)return "unavailable";
        initialize(c,p);
        File f=file(c);
        return "present="+(f.exists()&&f.length()>0L)
                +" bytes="+(f.exists()?f.length():0L)
                +" records="+p.getInt("lumi1_memory_record_count",0)
                +" completedTurns="+p.getInt("lumi1_memory_completed_turns",0)
                +" reloadProof="+p.getBoolean("lumi1_memory_reload_proof",false)
                +" recallProof="+p.getInt("lumi1_memory_recall_success",0);
    }

    static synchronized String recentReport(Context c,int max){
        List<JSONObject> xs=recent(Math.max(2,Math.min(20,max)),c);
        StringBuilder b=new StringBuilder();
        for(JSONObject j:xs){
            if(b.length()>0)b.append('\n');
            b.append(j.optLong("at",0L)).append(" ").append(j.optString("role","?"))
                    .append(" turn=").append(j.optLong("turn",0L)).append(" • ").append(clip(j.optString("text",""),300));
        }
        return b.length()==0?"No durable conversation records yet.":b.toString();
    }

    private static void append(Context c,SharedPreferences p,long turnId,String role,String text,String source){
        if(c==null||p==null||text==null||text.trim().isEmpty()||turnId<=0L)return;
        initialize(c,p);
        try{
            File d=dir(c);if(!d.exists())d.mkdirs();
            JSONObject j=new JSONObject().put("schema","LumiConversationMemory1").put("at",System.currentTimeMillis())
                    .put("processStartedAt",PROCESS_STARTED_AT).put("build",735).put("turn",turnId).put("role",role)
                    .put("source",clip(source,60)).put("text",clip(text,2000));
            try(FileWriter w=new FileWriter(file(c),true)){w.write(j.toString());w.write("\n");}
            p.edit().putBoolean("lumi1_memory_store_present",true)
                    .putInt("lumi1_memory_record_count",p.getInt("lumi1_memory_record_count",0)+1)
                    .putLong("lumi1_memory_last_write_at",System.currentTimeMillis()).apply();
            String code730MemoryTrace=LumiEvidenceLedger.beginTrace(p,"MEMORY");LumiEvidenceLedger.appendTrace(p,"MEMORY","ACCEPTANCE","writeVerified","true","LumiConversationMemory",code730MemoryTrace);
            compactIfNeeded(c,p);
        }catch(Throwable t){p.edit().putInt("lumi1_memory_write_failures",p.getInt("lumi1_memory_write_failures",0)+1).apply();}
    }

    private static List<JSONObject> recent(int max,Context c){
        ArrayDeque<JSONObject> q=new ArrayDeque<JSONObject>();
        File f=file(c);if(!f.exists())return new ArrayList<JSONObject>();
        long cutoff=System.currentTimeMillis()-RETAIN_MS;
        try(BufferedReader br=new BufferedReader(new FileReader(f))){
            String line;while((line=br.readLine())!=null){
                try{JSONObject j=new JSONObject(line);if(j.optLong("at",0L)<cutoff)continue;q.addLast(j);while(q.size()>max)q.removeFirst();}catch(Throwable ignored){}
            }
        }catch(Throwable ignored){}
        return new ArrayList<JSONObject>(q);
    }

    private static String lastRole(List<JSONObject> xs,String role){
        for(int i=xs.size()-1;i>=0;i--){JSONObject j=xs.get(i);if(role.equals(j.optString("role","")))return j.optString("text","");}
        return "";
    }

    private static void compactIfNeeded(Context c,SharedPreferences p){
        File f=file(c);if(!f.exists()||f.length()<=MAX_BYTES)return;
        List<JSONObject> xs=recent(MAX_RECORDS,c);
        File tmp=new File(dir(c),FILE+".tmp");
        try(FileWriter w=new FileWriter(tmp,false)){
            for(JSONObject j:xs){w.write(j.toString());w.write("\n");}
        }catch(Throwable t){return;}
        if(f.delete()&&tmp.renameTo(f))p.edit().putInt("lumi1_memory_compactions",p.getInt("lumi1_memory_compactions",0)+1).apply();
    }

    private static File dir(Context c){return new File(c.getFilesDir(),DIR);}
    private static File file(Context c){return new File(dir(c),FILE);}
    private static String norm(String s){return s.toLowerCase(Locale.US).replace('’','\'').replaceAll("\\s+"," ").trim();}
    private static String clip(String s,int max){if(s==null)return "";s=s.replace('\n',' ').replace('\r',' ').trim();return s.length()>max?s.substring(0,max):s;}
}
