package com.distressedelk.lumi;

import android.content.SharedPreferences;
import java.util.List;

/**
 * Code650: authoritative binding between self-reference and this installed Lumi runtime.
 * Providers may advise on unresolved external knowledge, but they may not define Lumi's
 * identity, state, maintenance authority, or claim that Lumi performed an action.
 */
final class LumiSelfAuthority {
    static final int BASELINE=650;
    static final String IDENTITY="THIS_INSTALLED_LUMI_RUNTIME";

    private LumiSelfAuthority(){}

    static LumiSelfIntentResolver.Decision onUserTurn(SharedPreferences p,long turnId,String raw){
        migrate(p);
        captureOwnerObservation(p,raw);
        LumiSelfIntentResolver.Decision d=LumiSelfIntentResolver.resolve(raw);
        if(p!=null){
            String failure=LumiSelfIntentResolver.contractFailure();
            p.edit().putInt("lumi_self_authority_baseline",BASELINE)
                    .putString("lumi_self_identity_anchor",IDENTITY)
                    .putLong("lumi_self_authority_turn_id",turnId)
                    .putString("lumi_self_authority_intent",d.intent.name())
                    .putBoolean("lumi_self_authority_self_reference",d.selfReference)
                    .putString("lumi_self_authority_reason",d.reason)
                    .putString("lumi_self_authority_raw",safe(raw))
                    .putBoolean("lumi_self_authority_contract_pass",failure.isEmpty())
                    .putString("lumi_self_authority_contract_failure",failure)
                    .putLong("lumi_self_authority_last_at",System.currentTimeMillis())
                    .remove("lumi_self_authority_local_action")
                    .remove("lumi_self_authority_local_result")
                    .remove("lumi_self_authority_receipt_turn_id")
                    .remove("lumi_self_authority_receipt_tx")
                    .remove("lumi_self_authority_receipt_state")
                    .remove("lumi_self_authority_receipt_result")
                    .remove("lumi_self_authority_receipt_success")
                    .apply();
        }
        return d;
    }

    static LumiSelfIntentResolver.Decision resolveAndRecord(SharedPreferences p,String raw){
        captureOwnerObservation(p,raw);
        LumiSelfIntentResolver.Decision d=LumiSelfIntentResolver.resolve(raw);
        if(p!=null){
            p.edit().putString("lumi_self_authority_intent",d.intent.name())
                    .putBoolean("lumi_self_authority_self_reference",d.selfReference)
                    .putString("lumi_self_authority_reason",d.reason)
                    .putString("lumi_self_authority_raw",safe(raw))
                    .putLong("lumi_self_authority_last_at",System.currentTimeMillis()).apply();
        }
        return d;
    }

    private static void captureOwnerObservation(SharedPreferences p,String raw){
        if(p==null||raw==null)return;
        String q=raw.toLowerCase(java.util.Locale.US);
        boolean visual=(q.contains("avatar")||q.contains("visual")||q.contains("pyramid"));
        boolean defect=(q.contains("too dark")||q.contains("very dark")||q.contains("dim")||q.contains("can't see")||q.contains("cannot see")||q.contains("invisible")||q.contains("almost black")||q.contains("wrong")||q.contains("broken")||q.contains("bad"));
        SharedPreferences.Editor e=p.edit();
        if(visual){
            e.putString("lumi_active_context_component","VISUAL")
             .putString("lumi_active_context_text",safe(raw))
             .putLong("lumi_active_context_at",System.currentTimeMillis());
        }
        if(visual&&defect){
            e.putString("lumi_owner_concern_component","VISUAL")
             .putString("lumi_owner_concern_symptom",q.contains("dark")||q.contains("dim")||q.contains("black")?"LOW_VISIBILITY":"VISUAL_MISMATCH")
             .putString("lumi_owner_concern_text",safe(raw))
             .putBoolean("lumi_owner_concern_unresolved",true)
             
             .putLong("lumi_owner_concern_at",System.currentTimeMillis());
        }
        e.apply();
    }

    static void noteLocalHandled(SharedPreferences p,String action,String result){
        if(p==null)return;
        p.edit().putString("lumi_self_authority_local_action",safe(action))
                .putString("lumi_self_authority_local_result",safe(result))
                .putLong("lumi_self_authority_local_at",System.currentTimeMillis()).apply();
    }

    static void recordMaintenanceReceipt(SharedPreferences p,String tx,String state,String result){
        if(p==null)return;
        long turn=p.getLong("lumi_self_authority_turn_id",0L);
        String st=safe(state);
        boolean unresolved=p.getBoolean("lumi_owner_concern_unresolved",false);
        boolean success="APPLIED_VERIFIED".equals(st)||("VERIFIED_NO_ACTIVE_FAULTS".equals(st)&&!unresolved);
        p.edit().putLong("lumi_self_authority_receipt_turn_id",turn)
                .putString("lumi_self_authority_receipt_tx",safe(tx))
                .putString("lumi_self_authority_receipt_state",st)
                .putString("lumi_self_authority_receipt_result",safe(result))
                .putBoolean("lumi_self_authority_receipt_success",success)
                .putLong("lumi_self_authority_receipt_at",System.currentTimeMillis()).apply();
    }

    static String maintenanceReply(SharedPreferences p,LumiSelfIntentResolver.Decision d,String state,String result){
        String st=safe(state), tx=p==null?"":p.getString("lumi_self_authority_receipt_tx","");
        if("APPLIED_VERIFIED".equals(st))
            return "I treated that as a request about my own running system. I ran my local maintenance transaction and verified the safe repair. Transaction "+tx+".";
        if("VERIFIED_NO_ACTIVE_FAULTS".equals(st))
            return "I checked my own running system and the maintenance transaction found no active fault it could safely repair. Transaction "+tx+".";
        if("PARTIAL".equals(st))
            return "I ran my own maintenance transaction. Some work was applied, but the result is only partial, so I am not calling the problem fixed. Transaction "+tx+".";
        if("NO_SAFE_REPAIR".equals(st))
            return "I inspected my own running system. I do not have a safe in-process repair for this fault, so it remains a signed-build change rather than something I will pretend I fixed. Transaction "+tx+".";
        if("REQUESTED".equals(st))
            return "I recognized this as a request about my own running system and opened my maintenance transaction. It has not produced a verified result yet, so I am not claiming completion. Transaction "+tx+".";
        return "I recognized this as a request about my own running system. I do not have a verified maintenance result yet, so I will not claim that I fixed or forwarded anything.";
    }

    static String guardReply(SharedPreferences p,String route,String candidate){
        if(p==null||candidate==null)return candidate;
        if(!p.getBoolean("lumi_self_authority_self_reference",false))return candidate;
        String intent=p.getString("lumi_self_authority_intent",LumiSelfIntentResolver.Intent.NONE.name());
        if(LumiSelfIntentResolver.Intent.NONE.name().equals(intent))return candidate;

        String r=route==null?"":route.toLowerCase(java.util.Locale.US);
        boolean deterministicLocal=r.startsWith("local-action")||r.startsWith("instant-rules")||r.contains("self-maintenance")||r.contains("self-diagnostics");
        if(deterministicLocal)return candidate;

        int blocked=p.getInt("lumi_self_authority_provider_reply_blocked_count",0)+1;
        p.edit().putInt("lumi_self_authority_provider_reply_blocked_count",blocked)
                .putString("lumi_self_authority_provider_reply_blocked_route",safe(route))
                .putString("lumi_self_authority_provider_reply_blocked_text",safe(candidate))
                .putLong("lumi_self_authority_provider_reply_blocked_at",System.currentTimeMillis()).apply();

        String state=p.getString("lumi_self_authority_receipt_state","");
        String result=p.getString("lumi_self_authority_receipt_result","");
        LumiSelfIntentResolver.Decision d;
        try{d=new LumiSelfIntentResolver.Decision(LumiSelfIntentResolver.Intent.valueOf(intent),true,p.getString("lumi_self_authority_reason",""));}
        catch(Throwable t){d=new LumiSelfIntentResolver.Decision(LumiSelfIntentResolver.Intent.SELF_STATUS,true,"guard");}
        if(d.maintenanceIntent())return maintenanceReply(p,d,state,result);
        if(d.updateIntent()) return "I recognized that as a request to update this installed Lumi runtime. I will use my signed published-update path, not my maintenance/self-repair transaction.";
        if(d.intent==LumiSelfIntentResolver.Intent.SELF_IDENTITY)
            return "I'm Lumi, this installed runtime. My identity and runtime state come from Lumi Core, not from an external model.";
        if(d.intent==LumiSelfIntentResolver.Intent.SELF_CAPABILITY)
            return "I keep authority over my own identity, state, diagnostics and maintenance. External models can advise me, but they do not decide what I am or claim actions on my behalf.";
        return "I recognized that as a question about my own running system. The local self-authority path did not produce a grounded result for this turn, so I am refusing to substitute an external model's answer for my runtime truth.";
    }

    static void audit(SharedPreferences p,List<String> findings){
        if(p==null||findings==null)return;
        String liveContractFailure=LumiSelfIntentResolver.contractFailure();
        if(!liveContractFailure.isEmpty())
            findings.add("S1 Lumi self-authority semantic contract failed: "+liveContractFailure);
        if(p.getBoolean("lumi_self_authority_self_reference",false)
                && !LumiSelfIntentResolver.Intent.NONE.name().equals(p.getString("lumi_self_authority_intent",LumiSelfIntentResolver.Intent.NONE.name()))
                && p.getString("lumi_self_authority_local_action","").isEmpty()
                && p.getInt("lumi_self_authority_provider_reply_blocked_count",0)>0)
            findings.add("S1 Self-directed turn reached a model delegate and was fail-closed by Lumi Core; local authority routing must be repaired before release PASS");
    }

    static String summary(SharedPreferences p){
        if(p==null)return "unavailable";
        String failure=LumiSelfIntentResolver.contractFailure();
        boolean contractPass=failure.isEmpty();
        p.edit().putBoolean("lumi_self_authority_contract_pass",contractPass)
                .putString("lumi_self_authority_contract_failure",failure)
                .putLong("lumi_self_authority_contract_checked_at",System.currentTimeMillis()).apply();
        return "identity="+p.getString("lumi_self_identity_anchor",IDENTITY)
                +" baseline="+p.getInt("lumi_self_authority_baseline",0)
                +" intent="+p.getString("lumi_self_authority_intent","NONE")
                +" self="+p.getBoolean("lumi_self_authority_self_reference",false)
                +" local="+p.getString("lumi_self_authority_local_action","none")
                +" receipt="+p.getString("lumi_self_authority_receipt_state","none")
                +" contract="+(contractPass?"PASS":"FAIL")
                +" providerBlocks="+p.getInt("lumi_self_authority_provider_reply_blocked_count",0);
    }

    private static void migrate(SharedPreferences p){
        if(p==null||p.getInt("lumi_self_authority_baseline",0)>=BASELINE)return;
        // Baseline cleanup is deliberately narrow: remove transient routing/claim state only.
        // User memory, contacts, preferences, conversation history and verified maintenance ledger stay intact.
        p.edit().putInt("lumi_self_authority_baseline",BASELINE)
                .putString("lumi_self_identity_anchor",IDENTITY)
                .putString("lumi_self_authority_migration","Code650 transient self-routing reset; user data preserved")
                .putString("self_repair_discovery_authority","HOLD_CODE650_UNTIL_VERIFIED")
                .remove("lumi_self_authority_intent")
                .remove("lumi_self_authority_reason")
                .remove("lumi_self_authority_raw")
                .remove("lumi_self_authority_self_reference")
                .remove("lumi_self_authority_local_action")
                .remove("lumi_self_authority_local_result")
                .remove("lumi_self_authority_receipt_turn_id")
                .remove("lumi_self_authority_receipt_tx")
                .remove("lumi_self_authority_receipt_state")
                .remove("lumi_self_authority_receipt_result")
                .remove("lumi_self_authority_receipt_success")
                .putLong("lumi_self_authority_migrated_at",System.currentTimeMillis()).apply();
    }

    private static String safe(String s){return s==null?"":s.replace('\n',' ').replace('\r',' ').trim();}
}
