package com.distressedelk.lumi;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.List;

final class FullRemediationAcceptance {
    private static final int REQUIRED_CLEAN_REPLIES=30;
    private static final long REQUIRED_ENDURANCE_MS=10L*60L*1000L;
    private static final long REQUIRED_RESOURCE_ENDURANCE_MS=30L*60L*1000L;
    private FullRemediationAcceptance(){}

    static void initialize(SharedPreferences p,long version){
        if(p==null || p.getLong("full_remediation_acceptance_version",-1L)==version) return;
        long now=System.currentTimeMillis();
        p.edit().putLong("full_remediation_acceptance_version",version)
                .putLong("full_remediation_acceptance_started_at",now)
                .putInt("full_remediation_base_tts_success",p.getInt("tts_reply_successes",0))
                .putInt("full_remediation_base_tts_fault",p.getInt("tts_watchdog_recoveries",0))
                .putInt("full_remediation_base_circuit_break",p.getInt("recognizer_restart_circuit_breaks",0))
                .putInt("full_remediation_base_state_divergence",p.getInt("conversation_state_divergence",0))
                .putInt("full_remediation_base_ready_deaf",p.getInt("ready_but_deaf_confirmed",0))
                .putInt("full_remediation_base_runtime_stall",p.getInt("runtime_stall_recoveries",0))
                .putInt("full_remediation_base_barge_in",p.getInt("spoken_barge_in_count",0))
                .putInt("full_remediation_base_barge_tts_stop",p.getInt("spoken_barge_in_tts_stop_count",0))
                .putInt("full_remediation_base_owner_accept",p.getInt("owner_accepted",0))
                .putInt("full_remediation_base_maintenance_local",p.getInt("maintenance_intent_local_routes",0))
                .putInt("full_remediation_base_ai_preempt",p.getInt("code409_ai_preemptions",0))
                .putInt("full_remediation_base_authoritative_memory",p.getInt("code410_authoritative_memory_answers",0))
                .putBoolean("full_remediation_acceptance_complete",false).apply();
    }

    static String report(Context c,SharedPreferences p){
        if(p==null)return "Full remediation acceptance unavailable.";
        if(p.getLong("full_remediation_acceptance_version",-1L)>=660L) return LumiRelease1Gatekeeper.report(c,p);
        long started=p.getLong("full_remediation_acceptance_started_at",0L);
        long elapsed=started<=0L?0L:Math.max(0L,System.currentTimeMillis()-started);
        int replies=delta(p,"tts_reply_successes","full_remediation_base_tts_success");
        int ttsFaults=delta(p,"tts_watchdog_recoveries","full_remediation_base_tts_fault");
        int circuit=delta(p,"recognizer_restart_circuit_breaks","full_remediation_base_circuit_break");
        int divergence=delta(p,"conversation_state_divergence","full_remediation_base_state_divergence");
        int readyDeaf=delta(p,"ready_but_deaf_confirmed","full_remediation_base_ready_deaf");
        int runtimeStall=delta(p,"runtime_stall_recoveries","full_remediation_base_runtime_stall");
        int barge=delta(p,"spoken_barge_in_count","full_remediation_base_barge_in");
        int bargeTtsStop=delta(p,"spoken_barge_in_tts_stop_count","full_remediation_base_barge_tts_stop");
        int owner=delta(p,"owner_accepted","full_remediation_base_owner_accept");
        int maintenance=delta(p,"maintenance_intent_local_routes","full_remediation_base_maintenance_local");
        int aiPreempt=delta(p,"code409_ai_preemptions","full_remediation_base_ai_preempt");
        int groundedMemory=delta(p,"code410_authoritative_memory_answers","full_remediation_base_authoritative_memory");
        boolean freshFastInference=LocalBrain.lastNormalInferenceAt()>=started;
        int lowMemory=lowMemorySince(c,started);
        boolean bridge=p.getBoolean("direct_maintenance_host_ready",false);
        boolean endurance=elapsed>=REQUIRED_ENDURANCE_MS;
        boolean resourceEndurance=elapsed>=REQUIRED_RESOURCE_ENDURANCE_MS;
        boolean speechExercised=replies>0;
        boolean behavioral=endurance && resourceEndurance && replies>=REQUIRED_CLEAN_REPLIES && ttsFaults==0 && circuit==0
                && divergence==0 && readyDeaf==0 && runtimeStall==0 && lowMemory==0
                && barge>=3 && bargeTtsStop>=3 && owner>0 && maintenance>0 && aiPreempt>0 && groundedMemory>0 && freshFastInference && bridge && latencyWithinTarget(p);
        boolean relay=false,preflight=p.getBoolean("build_relay_last_preflight_ok",false);
        try{relay=TrustedBuildRelayClient.status(p).optBoolean("configured",false);}catch(Throwable ignored){}
        long code=p.getLong("full_remediation_acceptance_version",-1L);
        boolean relayProof=p.getLong("trusted_core_build_target_version",-1L)==code
                && "GUARDIAN_CERTIFIED".equals(p.getString("trusted_core_build_stage",""))
                && "CERTIFIED".equals(p.getString("update_tx_last_stage",""));
        String nativeUpdateResult=p.getString("update_bridge_last_completed_result","");
        boolean nativeUpdateProof=p.getLong("update_bridge_last_completed_target",-1L)==code
                && nativeUpdateResult.contains("installed="+code)
                && nativeUpdateResult.contains("validation=PASS")
                && nativeUpdateResult.contains("canonical=true");
        boolean proof=code<383L || relayProof || nativeUpdateProof;
        boolean keyboardProof=code<421L || (p.getLong("keyboard_zero_tap_proof_version",-1L)>=421L && p.getInt("keyboard_zero_tap_character_count",0)>0);
        boolean complete=behavioral&&relay&&preflight&&proof;
        if(complete){
            p.edit().putBoolean("full_remediation_acceptance_complete",true)
                    .putLong("full_remediation_acceptance_completed_at",System.currentTimeMillis()).apply();
            if(code>=480L && p.getLong("code407_known_good_version",-1L)!=code)
                DeviceHealthEngine.notePostInstallValidation(c,p,code,true,"frozen Lumi 1.0 acceptance PASS");
        }
        StringBuilder s=new StringBuilder();
        s.append("Code").append(code>0?code:"current").append(" Conversation Endurance acceptance: ").append(complete?"PASS":"PENDING").append('\n');
        s.append(endurance?"PASS":"PENDING").append(" • continuous acceptance age target >=10min, observed=").append(elapsed/1000L).append("s\n");
        s.append(replies>=REQUIRED_CLEAN_REPLIES?"PASS":"PENDING").append(" • clean spoken replies ").append(replies).append('/').append(REQUIRED_CLEAN_REPLIES).append("\n");
        s.append(!speechExercised?"UNTESTED":(ttsFaults==0?"PASS":"FAIL")).append(" • new TTS watchdog recoveries=").append(ttsFaults).append("\n");
        s.append(!speechExercised?"UNTESTED":(circuit==0?"PASS":"FAIL")).append(" • recognizer recovery-circuit breaks=").append(circuit).append("\n");
        s.append(!speechExercised?"UNTESTED":(divergence==0?"PASS":"FAIL")).append(" • authoritative-state divergences=").append(divergence).append("\n");
        s.append(!speechExercised?"UNTESTED":(readyDeaf==0?"PASS":"FAIL")).append(" • READY-but-deaf incidents=").append(readyDeaf).append("\n");
        s.append(!speechExercised?"UNTESTED":(runtimeStall==0?"PASS":"FAIL")).append(" • interactive request stall recoveries=").append(runtimeStall).append("\n");
        s.append(barge>0?"PASS":"PENDING").append(" • spoken barge-in proof=").append(barge).append("\n");
        s.append(barge==0?"UNTESTED":(bargeTtsStop>0?"PASS":"FAIL")).append(" • causal active-TTS interruption proof=").append(bargeTtsStop)
                .append(" • lifetime=").append(p.getInt("spoken_barge_in_tts_stop_count",0)).append("\n");
        s.append(owner>0?"PASS":"PENDING").append(" • owner voice accepts=").append(owner).append("\n");
        s.append(maintenance>0?"PASS":"PENDING").append(" • explicit maintenance proof=").append(maintenance).append("\n");        s.append(keyboardProof?"PASS":"PENDING").append(" • zero-tap keyboard character delivery proof=").append(p.getInt("keyboard_zero_tap_character_count",0)).append(" • proofVersion=").append(p.getLong("keyboard_zero_tap_proof_version",-1L)).append("\n");

        s.append(aiPreempt>0?"PASS":"PENDING").append(" • interactive AI preemption proof=").append(aiPreempt).append("\n");
        s.append(groundedMemory>0?"PASS":"PENDING").append(" • authoritative local memory proof=").append(groundedMemory).append("\n");
        s.append(freshFastInference?"PASS":"PENDING").append(" • fresh Fast Brain normal inference after this boot\n");
        s.append(bridge?"PASS":"FAIL").append(" • Local maintenance host ready=").append(bridge).append("\n");
        s.append(!resourceEndurance?"UNTESTED":(lowMemory==0?"PASS":"FAIL")).append(" • LOW_MEMORY exits=").append(lowMemory).append(" • 30minEndurance=").append(resourceEndurance).append("\n");
        long observedLatency=p.getLong("last_response_latency_ms",-1L);
        if(replies<=0){
            s.append("PENDING • AI latency <=5200ms not yet measured by a completed spoken reply in this release • historical=").append(observedLatency).append("ms\n");
        }else{
            s.append(latencyWithinTarget(p)?"PASS":"FAIL").append(" • last AI latency <=5200ms observed=").append(observedLatency).append("ms\n");
        }
        s.append(relay?"PASS":"EXTERNAL CONFIG REQUIRED").append(" • trusted relay configured=").append(relay).append("\n");
        s.append(preflight?"PASS":"PENDING").append(" • relay preflight=").append(preflight).append("\n");
        s.append(proof?"PASS":"PENDING").append(" • trusted self-update proof for Code").append(code);
        s.append("\n\n").append(Lumi1Verification.report(c,p));
        return s.toString();
    }

    private static boolean latencyWithinTarget(SharedPreferences p){long x=p==null?-1L:p.getLong("last_response_latency_ms",-1L);return x>=0L&&x<=5200L;}
    private static int delta(SharedPreferences p,String key,String base){return Math.max(0,p.getInt(key,0)-p.getInt(base,0));}
    private static int lowMemorySince(Context c,long since){
        if(c==null||since<=0L||Build.VERSION.SDK_INT<30)return 0;
        try{ActivityManager am=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);List<ApplicationExitInfo> xs=am==null?null:am.getHistoricalProcessExitReasons(c.getPackageName(),0,20);int n=0;if(xs!=null)for(ApplicationExitInfo x:xs)if(x.getTimestamp()>=since&&x.getReason()==ApplicationExitInfo.REASON_LOW_MEMORY)n++;return n;}catch(Throwable ignored){return 0;}
    }
}
