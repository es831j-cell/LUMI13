package com.distressedelk.lumi;

import org.json.JSONObject;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Small in-process Core event bus. Subsystems observe stable events instead of reaching into
 * one another's private implementation. Listener failure is isolated and never aborts the publisher.
 */
final class LumiEventBus {
    interface Listener { void onEvent(Event event); }

    static final class Event {
        final long timestamp;
        final String type;
        final String source;
        final JSONObject payload;
        Event(String type, String source, JSONObject payload) {
            this.timestamp = System.currentTimeMillis();
            this.type = safe(type);
            this.source = safe(source);
            this.payload = payload == null ? new JSONObject() : payload;
        }
    }

    private static final ConcurrentHashMap<String, CopyOnWriteArrayList<Listener>> LISTENERS = new ConcurrentHashMap<>();
    private LumiEventBus() {}

    static void subscribe(String type, Listener listener) {
        if (listener == null) return;
        String key = safe(type);
        LISTENERS.computeIfAbsent(key, k -> new CopyOnWriteArrayList<>()).addIfAbsent(listener);
    }

    static void unsubscribe(String type, Listener listener) {
        CopyOnWriteArrayList<Listener> list = LISTENERS.get(safe(type));
        if (list != null) list.remove(listener);
    }

    static void publish(String type, String source, JSONObject payload) {
        Event e = new Event(type, source, payload);
        dispatch(e.type, e);
        if (!"*".equals(e.type)) dispatch("*", e);
    }

    private static void dispatch(String type, Event event) {
        CopyOnWriteArrayList<Listener> list = LISTENERS.get(type);
        if (list == null) return;
        for (Listener listener : list) {
            try { listener.onEvent(event); } catch (Throwable ignored) { /* subsystem isolation boundary */ }
        }
    }

    private static String safe(String value) {
        String v = value == null ? "" : value.trim();
        return v.length() <= 96 ? v : v.substring(0, 96);
    }
}
