package com.distressedelk.lumi;

import android.content.SharedPreferences;
import android.speech.tts.TextToSpeech;

/** Code444 R161: Lumi's default Aurora voice profile with runtime proof. */
final class AuroraVoiceProfile {
    static final String NAME="Aurora";
    private static final float PITCH=1.02f;
    private static final float RATE=0.96f;
    private AuroraVoiceProfile(){}

    private static boolean unavailable(android.speech.tts.Voice v,SharedPreferences prefs){
        if(v==null || v.getName()==null || v.getLocale()==null || v.isNetworkConnectionRequired()) return true;
        try{
            String quarantined=prefs==null?"":prefs.getString("tts_voice_quarantine_name_r448","");
            long until=prefs==null?0L:prefs.getLong("tts_voice_quarantine_until_r448",0L);
            if(v.getName().equals(quarantined) && System.currentTimeMillis()<until) return true;
            java.util.Set<String> features=v.getFeatures();
            if(features!=null) for(String feature:features){
                String f=feature==null?"":feature.toLowerCase(java.util.Locale.US).replace("_","").replace("-","").replace(" ","");
                if(f.contains("notinstalled") || f.contains("missingdata")) return true;
            }
        }catch(Throwable ignored){}
        return false;
    }

    static void apply(TextToSpeech tts, SharedPreferences prefs, String text){
        if(tts==null)return;
        if(prefs!=null && SafeCoreProfile.active(prefs) && !SafeCoreProfile.enabled(prefs,SafeCoreProfile.VOICE_AURORA)){
            try{tts.setPitch(1.0f);}catch(Throwable ignored){}
            try{tts.setSpeechRate(1.0f);}catch(Throwable ignored){}
            prefs.edit().putString("lumi_voice_profile","none").putBoolean("lumi_voice_profile_runtime_verified",false).apply();
            return;
        }
        float userPitch=prefs==null?1.0f:prefs.getFloat("voice_pitch_multiplier",1.0f);
        float userRate=prefs==null?1.0f:prefs.getFloat("voice_rate_multiplier",1.0f);
        float effectivePitch=Math.max(.72f,Math.min(1.30f,PITCH*userPitch));
        float effectiveRate=Math.max(.70f,Math.min(1.35f,RATE*userRate));
        boolean voiceOk=false,pitchOk=false,rateOk=false;
        String engineVoice="unknown";
        try{
            java.util.Set<android.speech.tts.Voice> voices=tts.getVoices();
            String requested=prefs==null?"":prefs.getString("voice_name_override","").trim();
            String selected=prefs==null?"":prefs.getString("natural_voice_selected","").trim();
            android.speech.tts.Voice chosen=null;
            if(voices!=null){
                if(!requested.isEmpty()) for(android.speech.tts.Voice candidate:voices){
                    if(candidate!=null && requested.equals(candidate.getName()) && (!candidate.isNetworkConnectionRequired() || (prefs!=null && prefs.getBoolean("allow_network_tts_override",false))) && (candidate.isNetworkConnectionRequired() || !unavailable(candidate,prefs))){ chosen=candidate; break; }
                }
                if(chosen==null && !selected.isEmpty()) for(android.speech.tts.Voice candidate:voices){
                    if(candidate!=null && selected.equals(candidate.getName()) && !candidate.isNetworkConnectionRequired() && !unavailable(candidate,prefs)){ chosen=candidate; break; }
                }
                if(chosen==null){
                    java.util.ArrayList<android.speech.tts.Voice> local=new java.util.ArrayList<>();
                    for(android.speech.tts.Voice candidate:voices){
                        if(candidate==null || candidate.isNetworkConnectionRequired() || candidate.getLocale()==null || candidate.getName()==null || unavailable(candidate,prefs)) continue;
                        if(!"en".equalsIgnoreCase(candidate.getLocale().getLanguage())) continue;
                        local.add(candidate);
                    }
                    java.util.Collections.sort(local,(a,b)->String.valueOf(a.getName()).compareToIgnoreCase(String.valueOf(b.getName())));
                    if(!local.isEmpty()) chosen=local.get(0);
                }
            }
            if(chosen!=null){
                voiceOk=tts.setVoice(chosen)==TextToSpeech.SUCCESS;
                engineVoice=chosen.getName()==null?"unknown":chosen.getName();
                if(prefs!=null) prefs.edit().putString("natural_voice_selected",engineVoice).putString("tts_requested_voice_r448",engineVoice).apply();
            }else if(tts.getVoice()!=null){
                engineVoice=String.valueOf(tts.getVoice().getName());
                voiceOk=true;
            }
        }catch(Throwable ignored){}
        try{pitchOk=tts.setPitch(effectivePitch)==TextToSpeech.SUCCESS;}catch(Throwable ignored){}
        try{rateOk=tts.setSpeechRate(effectiveRate)==TextToSpeech.SUCCESS;}catch(Throwable ignored){}
        try{if(tts.getVoice()!=null && tts.getVoice().getName()!=null) engineVoice=tts.getVoice().getName();}catch(Throwable ignored){}
        if(prefs!=null){
            int count=prefs.getInt("lumi_voice_profile_apply_count",0)+1;
            prefs.edit()
                    .putString("lumi_voice_profile",NAME)
                    .putString("lumi_voice_authority","AURORA_NATURAL_LOCAL_QUALITY_R420")
                    .putString("lumi_voice_profile_age_band","30s")
                    .putString("lumi_voice_profile_character","warm intelligent quietly-confident grounded")
                    .putFloat("lumi_voice_profile_pitch",effectivePitch)
                    .putFloat("lumi_voice_profile_rate",effectiveRate)
                    .putString("lumi_voice_profile_engine_voice",engineVoice)
                    .putString("code710_voice_policy","LOCAL_QUALITY_FIRST_NEUTRAL_PROSODY")
                    .putBoolean("lumi_voice_profile_pitch_applied",pitchOk)
                    .putBoolean("lumi_voice_profile_rate_applied",rateOk)
                    .putBoolean("lumi_voice_profile_distinct_voice",voiceOk)
                    .putBoolean("lumi_voice_profile_runtime_verified",pitchOk&&rateOk&&voiceOk)
                    .putInt("lumi_voice_profile_applied_version",710)
                    .putInt("lumi_voice_profile_apply_count",count)
                    .putLong("lumi_voice_profile_applied_at",System.currentTimeMillis())
                    .apply();
        }
    }
}
