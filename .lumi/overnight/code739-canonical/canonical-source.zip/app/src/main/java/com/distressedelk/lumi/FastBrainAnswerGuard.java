package com.distressedelk.lumi;

import java.util.Locale;

/**
 * Code497 R215: Android-free answer guard shared by Core arithmetic routing and the Fast Brain
 * semantic output firewall. Keeping these tiny predicates pure lets CI reproduce the exact
 * installed-phone regression without loading an Android runtime or a language model.
 */
final class FastBrainAnswerGuard {
    private FastBrainAnswerGuard(){}

    static boolean isArithmeticRequest(String normalizedUserText,String normalizedExpression){
        String s=normalizedUserText==null?"":normalizedUserText.trim().toLowerCase(Locale.US);
        String e=normalizedExpression==null?"":normalizedExpression.trim();
        if(e.isEmpty() || !e.matches("[0-9.+\\-*/()\\s]+") || !e.matches(".*\\d.*")) return false;
        return s.startsWith("calculate") || s.startsWith("compute") || s.startsWith("what is")
                || s.startsWith("what's") || s.startsWith("what ")
                || s.matches("[0-9 .+\\-*/()x×÷%]+");
    }

    static boolean looksLikePromptEcho(String userText,String reply){
        String u=normalize(userText);
        String r=normalize(reply);
        if(u.isEmpty() || r.isEmpty()) return false;
        if(u.equals(r)) return true;
        String stripped=u.replaceFirst("^(?:what is|whats|what|calculate|compute|tell me|answer)\\s+","").trim();
        return !stripped.equals(u) && stripped.equals(r);
    }

    static String boundedConversationPrompt(String transcript,String currentUserText){
        String current=currentUserText==null?"":currentUserText.trim();
        String history=transcript==null?"":transcript.replace('\r','\n').trim();
        StringBuilder out=new StringBuilder();
        String[] lines=history.split("\n");
        int start=Math.max(0,lines.length-6);
        for(int i=start;i<lines.length;i++){
            String line=lines[i]==null?"":lines[i].trim();
            if(line.isEmpty()) continue;
            if(line.regionMatches(true,0,"You:",0,4)){
                String text=line.substring(4).trim();
                if(!text.equalsIgnoreCase(current)) out.append("USER: ").append(text).append('\n');
            }else if(line.regionMatches(true,0,"Lumi:",0,5)){
                out.append("LUMI: ").append(line.substring(5).trim()).append('\n');
            }
        }
        if(out.length()>260) out.delete(0,out.length()-260);
        out.append("USER_NOW: ").append(current).append("\nLUMI:");
        return out.toString();
    }

    private static String normalize(String raw){
        if(raw==null) return "";
        return raw.toLowerCase(Locale.US)
                .replace("'","")
                .replaceAll("[^a-z0-9+\\-*/x×÷. ]"," ")
                .replaceAll("\\s+"," ").trim();
    }
}
