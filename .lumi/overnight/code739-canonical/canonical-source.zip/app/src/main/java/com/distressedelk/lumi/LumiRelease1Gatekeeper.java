package com.distressedelk.lumi;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.List;

/** Frozen installed-phone acceptance gates for Lumi 1.0. Code661 makes the test explicit. */
final class LumiRelease1Gatekeeper {
    private static final int REQUIRED_REPLIES=30;
    private static final int REQUIRED_BARGE_INS=3;
    private static final long CONVERSATION_MS=10L*60L*1000L;
    private static final long ENDURANCE_MS=30L*60L*1000L;
    private LumiRelease1Gatekeeper(){}

    static synchronized void initialize(Context c,SharedPreferences p){
        if(c==null||p==null)return;
        int code=versionCode(c);
        if(p.getInt("lumi1_gate_version",-1)==code)return;
        p.edit().putInt("lumi1_gate_version",code)
                .putBoolean("lumi1_acceptance_armed",false)
                .remove("lumi1_acceptance_armed_at")
                .remove("lumi1_gate_started_at")
                .remove("lumi1_conversation_epoch_at")
                .putInt("lumi1_manual_rescue_count",0)
                .putBoolean("lumi1_release_pass",false)
                .remove("lumi1_release_pass_at").apply();
        LumiConversationMemory.initialize(c,p);
    }

    static synchronized String armAcceptance(Context c,SharedPreferences p,String reason){
        if(c==null||p==null)return "Lumi 1.0 acceptance unavailable.";
        initialize(c,p);
        long now=System.currentTimeMillis();
        snapshotBaselines(p,now,true);
        p.edit().putBoolean("lumi1_acceptance_armed",true)
                .putLong("lumi1_acceptance_armed_at",now)
                .putString("lumi1_acceptance_arm_reason",reason==null?"explicit-owner-request":reason)
                .putBoolean("lumi1_release_pass",false).remove("lumi1_release_pass_at").apply();
        return "Lumi 1.0 acceptance test armed. The 30-reply conversation window and 30-minute endurance window start now.";
    }

    static synchronized void noteManualRescue(Context c,SharedPreferences p,String reason){
        if(c==null||p==null)return;
        initialize(c,p);
        if(!p.getBoolean("lumi1_acceptance_armed",false))return;
        long now=System.currentTimeMillis();
        // Frozen rule: manual Listen invalidates only the G1 unassisted conversation window.
        p.edit().putLong("lumi1_conversation_epoch_at",now)
                .putInt("lumi1_base_tts_success",p.getInt("tts_reply_successes",0))
                .putInt("lumi1_base_tts_fault",p.getInt("tts_watchdog_recoveries",0))
                .putInt("lumi1_base_circuit",p.getInt("recognizer_restart_circuit_breaks",0))
                .putInt("lumi1_base_divergence",p.getInt("conversation_state_divergence",0))
                .putInt("lumi1_base_ready_deaf",p.getInt("ready_but_deaf_confirmed",0))
                .putInt("lumi1_base_stall",p.getInt("runtime_stall_recoveries",0))
                .putInt("lumi1_manual_rescue_count",p.getInt("lumi1_manual_rescue_count",0)+1)
                .putLong("lumi1_manual_rescue_last_at",now)
                .putString("lumi1_manual_rescue_reason",reason==null?"manual-rescue":reason)
                .putBoolean("lumi1_release_pass",false).apply();
    }

    static synchronized String report(Context c,SharedPreferences p){
        if(c==null||p==null)return "Lumi 1.0 gatekeeper unavailable.";
        initialize(c,p);
        if(!p.getBoolean("lumi1_acceptance_armed",false)){
            return "LUMI 1.0 FROZEN ACCEPTANCE • Code"+versionCode(c)+" • NOT ARMED\n"
                    +"PENDING • G1 NATURAL CONVERSATION • explicit owner test start required\n"
                    +"PENDING • G2 DURABLE CONVERSATION MEMORY • "+LumiConversationMemory.status(c,p)+"\n"
                    +"PENDING • G3 SPEAKER/OWNER CONTINUITY • acceptance not armed\n"
                    +"PENDING • G4 HANDS-FREE BARGE-IN • acceptance not armed\n"
                    +"PENDING • G5 REAL PHONE FUNCTION • acceptance not armed\n"
                    +"PENDING • G6 RESOURCE ENDURANCE • acceptance not armed\n"
                    +"PENDING • G7 BLACK BOX 2 / INTENT EVIDENCE • acceptance not armed\n"
                    +"RULE • Say 'start Lumi 1.0 acceptance test' to arm the frozen installed-phone test. Build, publish and install never make Lumi 1.0 PASS.";
        }

        long now=System.currentTimeMillis();
        long started=p.getLong("lumi1_gate_started_at",now),convStarted=p.getLong("lumi1_conversation_epoch_at",now);
        long releaseAge=Math.max(0L,now-started),convAge=Math.max(0L,now-convStarted);
        int replies=delta(p,"tts_reply_successes","lumi1_base_tts_success"),ttsFaults=delta(p,"tts_watchdog_recoveries","lumi1_base_tts_fault");
        int circuit=delta(p,"recognizer_restart_circuit_breaks","lumi1_base_circuit"),divergence=delta(p,"conversation_state_divergence","lumi1_base_divergence");
        int readyDeaf=delta(p,"ready_but_deaf_confirmed","lumi1_base_ready_deaf"),stalls=delta(p,"runtime_stall_recoveries","lumi1_base_stall");
        int barge=delta(p,"spoken_barge_in_count","lumi1_base_barge"),bargeStops=delta(p,"spoken_barge_in_tts_stop_count","lumi1_base_barge_stop");
        int owner=delta(p,"owner_accepted","lumi1_base_owner"),localActions=delta(p,"core_local_action_count","lumi1_base_local_actions");
        int uploads=delta(p,"remote_black_box_upload_count","lumi1_base_blackbox_upload");
        boolean g1=convAge>=CONVERSATION_MS&&replies>=REQUIRED_REPLIES&&ttsFaults==0&&circuit==0&&divergence==0&&readyDeaf==0&&stalls==0;
        boolean g2=p.getBoolean("lumi1_memory_store_present",false)&&p.getBoolean("lumi1_memory_reload_proof",false)&&p.getInt("lumi1_memory_recall_success",0)>0;
        boolean g3=owner>0&&!p.getString("active_voice_speaker_id","").trim().isEmpty();
        boolean g4=barge>=REQUIRED_BARGE_INS&&bargeStops>=REQUIRED_BARGE_INS;
        boolean g5=localActions>0;
        int lowMemory=lowMemorySince(c,started);boolean g6=releaseAge>=ENDURANCE_MS&&lowMemory==0;
        boolean stable=p.getInt("remote_black_box_stable_version",-1)==versionCode(c)&&p.getLong("remote_black_box_stable_at",0L)>=started&&uploads>0;
        boolean g7=stable&&p.getBoolean("lumi1_blackbox2_active",false);
        boolean pass=g1&&g2&&g3&&g4&&g5&&g6&&g7;
        p.edit().putBoolean("lumi1_release_pass",pass).putLong(pass?"lumi1_release_pass_at":"lumi1_release_last_checked_at",now).apply();
        StringBuilder b=new StringBuilder();b.append("LUMI 1.0 FROZEN ACCEPTANCE • Code").append(versionCode(c)).append(" • ").append(pass?"PASS":"NOT YET PASS").append('\n');
        b.append(g1?"PASS":"PENDING").append(" • G1 NATURAL CONVERSATION • unassistedReplies=").append(replies).append('/').append(REQUIRED_REPLIES).append(" ageSec=").append(convAge/1000L).append(" faults=").append(ttsFaults+circuit+divergence+readyDeaf+stalls).append(" manualRescues=").append(p.getInt("lumi1_manual_rescue_count",0)).append('\n');
        b.append(g2?"PASS":"PENDING").append(" • G2 DURABLE CONVERSATION MEMORY • ").append(LumiConversationMemory.status(c,p)).append('\n');
        b.append(g3?"PASS":"PENDING").append(" • G3 SPEAKER/OWNER CONTINUITY • ownerAcceptDelta=").append(owner).append(" speakerBound=").append(!p.getString("active_voice_speaker_id","").isEmpty()).append('\n');
        b.append(g4?"PASS":"PENDING").append(" • G4 HANDS-FREE BARGE-IN • accepted=").append(barge).append('/').append(REQUIRED_BARGE_INS).append(" ttsStops=").append(bargeStops).append('/').append(REQUIRED_BARGE_INS).append('\n');
        b.append(g5?"PASS":"PENDING").append(" • G5 REAL PHONE FUNCTION • localActionDelta=").append(localActions).append(" last=").append(p.getString("core_local_action_last","none")).append('\n');
        b.append(g6?"PASS":"PENDING").append(" • G6 RESOURCE ENDURANCE • ageMin=").append(releaseAge/60000L).append("/30 lowMemoryExits=").append(lowMemory).append('\n');
        b.append(g7?"PASS":"PENDING").append(" • G7 BLACK BOX 2 / INTENT EVIDENCE • autoUploads=").append(uploads).append(" stableCurrent=").append(stable).append(" executiveSummary=REMOVED_BY_CONTRACT").append('\n');
        b.append("RULE • Build, publish and install success are deployment evidence only. They never make Lumi 1.0 PASS.");return b.toString();
    }

    private static void snapshotBaselines(SharedPreferences p,long now,boolean full){
        SharedPreferences.Editor e=p.edit().putLong("lumi1_conversation_epoch_at",now)
                .putInt("lumi1_base_tts_success",p.getInt("tts_reply_successes",0))
                .putInt("lumi1_base_tts_fault",p.getInt("tts_watchdog_recoveries",0))
                .putInt("lumi1_base_circuit",p.getInt("recognizer_restart_circuit_breaks",0))
                .putInt("lumi1_base_divergence",p.getInt("conversation_state_divergence",0))
                .putInt("lumi1_base_ready_deaf",p.getInt("ready_but_deaf_confirmed",0))
                .putInt("lumi1_base_stall",p.getInt("runtime_stall_recoveries",0));
        if(full)e.putLong("lumi1_gate_started_at",now)
                .putInt("lumi1_base_barge",p.getInt("spoken_barge_in_count",0))
                .putInt("lumi1_base_barge_stop",p.getInt("spoken_barge_in_tts_stop_count",0))
                .putInt("lumi1_base_owner",p.getInt("owner_accepted",0))
                .putInt("lumi1_base_local_actions",p.getInt("core_local_action_count",0))
                .putInt("lumi1_base_blackbox_upload",p.getInt("remote_black_box_upload_count",0))
                .putInt("lumi1_manual_rescue_count",0);
        e.apply();
    }

    private static int delta(SharedPreferences p,String key,String base){return Math.max(0,p.getInt(key,0)-p.getInt(base,0));}
    private static int versionCode(Context c){try{android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0);long v=Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode;return (int)Math.min(Integer.MAX_VALUE,v);}catch(Throwable t){return -1;}}
    private static int lowMemorySince(Context c,long since){if(c==null||since<=0L||Build.VERSION.SDK_INT<30)return 0;try{ActivityManager am=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);List<ApplicationExitInfo> xs=am==null?null:am.getHistoricalProcessExitReasons(c.getPackageName(),0,30);int n=0;if(xs!=null)for(ApplicationExitInfo x:xs)if(x.getTimestamp()>=since&&x.getReason()==ApplicationExitInfo.REASON_LOW_MEMORY)n++;return n;}catch(Throwable ignored){return 0;}}
}
