package com.distressedelk.lumi;
import android.content.ComponentName;
import android.service.voice.VoiceInteractionService;
import java.util.Collections;
import java.util.Set;
public final class LumiVoiceInteractionService extends VoiceInteractionService {
  @Override public void onReady(){
    super.onReady();
    boolean active=VoiceInteractionService.isActiveService(this,new ComponentName(this,LumiVoiceInteractionService.class));
    getSharedPreferences("lumi_runtime",MODE_PRIVATE).edit().putBoolean("android_assistant_service_ready",true).putBoolean("android_assistant_is_active",active).putLong("android_assistant_checked_at",System.currentTimeMillis()).apply();
  }
  @Override public Set<String> onGetSupportedVoiceActions(Set<String> voiceActions){ return Collections.emptySet(); }
}
