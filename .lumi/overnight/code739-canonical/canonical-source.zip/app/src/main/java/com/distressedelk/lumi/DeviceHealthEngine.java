package com.distressedelk.lumi;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.biometrics.BiometricManager;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.SystemClock;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Code407 device awareness + Health Engine v1. No background sensor/GPS polling. */
final class DeviceHealthEngine {
    private static final long MIN_UPDATE_FREE=700L*1024L*1024L;
    private DeviceHealthEngine(){}

    static final class Snapshot {
        long at,version,free,heapUsed,heapMax,availMem,uptime;
        int battery=-1,thermal=-1,strong=-999,weak=-999,rotation=-1;
        float batteryC=Float.NaN;
        boolean charging,internet,wifi,cellular,unmetered,interactive,idle,btSupported,btEnabled,locEnabled,fine,coarse,accel,rotationSensor,installReady,face,fingerprint;
        String thermalClass="unknown",orientation="unknown",audio="system default",permissions="",versionName="";
    }
    static final class Readiness {
        final boolean safe; final String reason; final Snapshot snapshot;
        Readiness(boolean s,String r,Snapshot x){safe=s;reason=r;snapshot=x;}
    }

    static void onStartup(Context c,SharedPreferences p){
        if(c==null||p==null)return;
        long now=System.currentTimeMillis(),prior=p.getLong("code407_last_process_start_at",0L);
        int burst=prior>0&&now-prior<90000L?p.getInt("code407_restart_burst",0)+1:1;
        Snapshot s=capture(c,p,false);
        String old=p.getString("code407_permission_fingerprint","");
        SharedPreferences.Editor e=p.edit().putLong("code407_last_process_start_at",now).putInt("code407_restart_burst",burst)
                .putString("code407_startup_snapshot",compact(s)).putLong("code407_startup_snapshot_at",now)
                .putString("code407_permission_fingerprint",s.permissions).putBoolean("code407_restart_loop_warning",burst>=3);
        boolean permissionChanged=!old.isEmpty()&&!old.equals(s.permissions);
        if(permissionChanged){
            e.putString("code407_permission_drift_from",old)
                    .putString("code407_permission_drift_to",s.permissions)
                    .putLong("code407_permission_drift_at",now);
        }else{
            // Code513: drift is a current-start observation, not a sticky lifetime fault.
            e.remove("code407_permission_drift_from")
                    .remove("code407_permission_drift_to")
                    .remove("code407_permission_drift_at");
        }
        e.apply();
        record(c,p,"STARTUP_SNAPSHOT",compact(s));
        if(permissionChanged)record(c,p,"PERMISSION_DRIFT",old+" -> "+s.permissions);
        if(burst>=3)record(c,p,"RESTART_LOOP_WARNING","startsWithin90s="+burst);
        AutonomousMaintenanceJobService.scheduleNext(c,p,"startup");
    }

    static Snapshot capture(Context c,SharedPreferences p,boolean sampleOrientation){
        Snapshot s=new Snapshot(); s.at=System.currentTimeMillis(); s.uptime=SystemClock.elapsedRealtime();
        try{PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0);s.version=Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode;s.versionName=pi.versionName==null?"":pi.versionName;}catch(Throwable ignored){}
        try{Intent b=c.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(b!=null){int l=b.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),sc=b.getIntExtra(BatteryManager.EXTRA_SCALE,-1);if(l>=0&&sc>0)s.battery=Math.round(l*100f/sc);int st=b.getIntExtra(BatteryManager.EXTRA_STATUS,-1);s.charging=st==BatteryManager.BATTERY_STATUS_CHARGING||st==BatteryManager.BATTERY_STATUS_FULL;int t=b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,Integer.MIN_VALUE);if(t!=Integer.MIN_VALUE)s.batteryC=t/10f;}}catch(Throwable ignored){}
        try{PowerManager pm=(PowerManager)c.getSystemService(Context.POWER_SERVICE);if(pm!=null){s.interactive=pm.isInteractive();s.idle=pm.isDeviceIdleMode();if(Build.VERSION.SDK_INT>=29)s.thermal=pm.getCurrentThermalStatus();}}catch(Throwable ignored){}
        s.thermalClass=thermalClass(s.thermal,s.batteryC);
        try{ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);if(cm!=null){NetworkCapabilities n=cm.getNetworkCapabilities(cm.getActiveNetwork());if(n!=null){s.internet=n.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)&&n.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);s.wifi=n.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);s.cellular=n.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR);}s.unmetered=!cm.isActiveNetworkMetered();}}catch(Throwable ignored){}
        try{s.free=new StatFs(c.getFilesDir().getAbsolutePath()).getAvailableBytes();}catch(Throwable ignored){}
        try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();s.btSupported=a!=null;if(a!=null&&(Build.VERSION.SDK_INT<31||granted(c,Manifest.permission.BLUETOOTH_CONNECT)))s.btEnabled=a.isEnabled();}catch(Throwable ignored){}
        s.fine=granted(c,Manifest.permission.ACCESS_FINE_LOCATION);s.coarse=granted(c,Manifest.permission.ACCESS_COARSE_LOCATION);
        try{LocationManager lm=(LocationManager)c.getSystemService(Context.LOCATION_SERVICE);if(lm!=null)s.locEnabled=Build.VERSION.SDK_INT>=28?lm.isLocationEnabled():lm.isProviderEnabled(LocationManager.GPS_PROVIDER)||lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);}catch(Throwable ignored){}
        try{Configuration q=c.getResources().getConfiguration();s.orientation=q.orientation==Configuration.ORIENTATION_PORTRAIT?"portrait":q.orientation==Configuration.ORIENTATION_LANDSCAPE?"landscape":"undefined";android.view.WindowManager w=(android.view.WindowManager)c.getSystemService(Context.WINDOW_SERVICE);if(w!=null)s.rotation=w.getDefaultDisplay().getRotation();}catch(Throwable ignored){}
        try{SensorManager sm=(SensorManager)c.getSystemService(Context.SENSOR_SERVICE);if(sm!=null){s.accel=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)!=null;s.rotationSensor=sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)!=null;}}catch(Throwable ignored){}
        try{AudioManager am=(AudioManager)c.getSystemService(Context.AUDIO_SERVICE);if(am!=null)s.audio=audioRoute(am);}catch(Throwable ignored){}
        try{Runtime r=Runtime.getRuntime();s.heapUsed=r.totalMemory()-r.freeMemory();s.heapMax=r.maxMemory();ActivityManager am=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);if(am!=null){ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);s.availMem=mi.availMem;}}catch(Throwable ignored){}
        s.installReady=Build.VERSION.SDK_INT<26||c.getPackageManager().canRequestPackageInstalls();
        try{PackageManager pm=c.getPackageManager();s.face=Build.VERSION.SDK_INT>=29&&pm.hasSystemFeature(PackageManager.FEATURE_FACE);s.fingerprint=pm.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);if(Build.VERSION.SDK_INT>=29){BiometricManager bm=c.getSystemService(BiometricManager.class);if(bm!=null){if(Build.VERSION.SDK_INT>=30){s.strong=bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG);s.weak=bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);}else{s.strong=s.weak=bm.canAuthenticate();}}}}catch(Throwable ignored){}
        s.permissions=permissionFingerprint(c);
        if(sampleOrientation&&s.accel)s.orientation+=" / "+samplePhysicalOrientation(c);
        if(p!=null)p.edit().putString("code407_last_snapshot",compact(s)).putLong("code407_last_snapshot_at",s.at).apply();
        return s;
    }

    static Readiness assessUpdateReadiness(Context c,SharedPreferences p,boolean overnight){
        Snapshot s=capture(c,p,false);ArrayList<String> r=new ArrayList<>();
        if(overnight&&!s.charging)r.add("not charging");
        if(s.battery>=0&&s.battery<(s.charging?15:35))r.add("battery "+s.battery+"%");
        if("hot".equals(s.thermalClass)||"critical".equals(s.thermalClass))r.add("thermal state "+s.thermalClass);
        if(s.free>=0&&s.free<MIN_UPDATE_FREE)r.add("low storage");
        if(!s.internet)r.add("internet not validated");
        if(overnight&&!s.unmetered)r.add("network is metered");
        if(overnight&&!p.getBoolean("code407_chain_followup_pending",false)&&!s.idle)r.add("device is not idle");
        if(!s.installReady)r.add("install-source permission not ready");
        String reason=r.isEmpty()?"all maintenance gates passed":String.join(", ",r);boolean safe=r.isEmpty();
        p.edit().putBoolean("code407_update_readiness_safe",safe).putString("code407_update_readiness_reason",reason).putLong("code407_update_readiness_at",System.currentTimeMillis()).apply();
        record(c,p,safe?"UPDATE_READINESS_SAFE":"UPDATE_READINESS_BLOCKED",reason);return new Readiness(safe,reason,s);
    }

    static CoreLocalActions.Result tryHandle(Context c,SharedPreferences p,String raw){
        if(c==null||p==null||raw==null)return CoreLocalActions.Result.no();String s=raw.toLowerCase(Locale.US).replace('’','\'').replaceAll("\\s+"," ").trim();
        boolean code710DiagnosticWord=s.contains("diagnostic");
        boolean code710DiagnosticAction=s.startsWith("run ") || s.startsWith("execute ") || s.startsWith("perform ") || s.startsWith("start ") || s.startsWith("check ")
                || s.contains(" run ") || s.contains(" execute ") || s.contains(" perform ") || s.contains(" start ") || s.contains(" check ");
        boolean code710ExplicitDiagnostics=(code710DiagnosticWord && (code710DiagnosticAction || s.contains("self")))
                || s.contains("diagnose yourself") || s.contains("check yourself");
        if(code710ExplicitDiagnostics){
            String reply=LumiCoreSelfStateEngine.evaluate(c,p,"explicit-diagnostics-query");
            p.edit().putInt("code710_direct_diagnostics_count",p.getInt("code710_direct_diagnostics_count",0)+1)
                    .putLong("code710_direct_diagnostics_last_at",System.currentTimeMillis())
                    .putString("code710_direct_diagnostics_last_command",raw).apply();
            LumiSelfAuthority.noteLocalHandled(p,"self-diagnostics",reply);
            return CoreLocalActions.Result.yes("self-diagnostics",reply,"Code710 deterministic local diagnostics; provider bypassed");
        }
        LumiSelfIntentResolver.Decision selfDecision=LumiSelfAuthority.resolveAndRecord(p,raw);
        String code723GovernanceAnswer=LumiSelfGovernance.tryAnswer(c,p,raw);
        if(code723GovernanceAnswer!=null){
            LumiSelfAuthority.noteLocalHandled(p,"self-governance",code723GovernanceAnswer);
            return CoreLocalActions.Result.yes("self-governance",code723GovernanceAnswer,"Code723 Core-owned self-governance truth");
        }
        String code651SelfAnswer=LumiRuntimeSelfModel.answer(c,p,raw);
        if(code651SelfAnswer!=null){
            LumiSelfAuthority.noteLocalHandled(p,"runtime-self-model",code651SelfAnswer);
            return CoreLocalActions.Result.yes("runtime-self-model",code651SelfAnswer,"current-release causal self truth");
        }
        String code660MemoryAnswer=LumiConversationMemory.tryAnswer(c,p,raw);
        if(code660MemoryAnswer!=null){
            LumiSelfAuthority.noteLocalHandled(p,"conversation-memory",code660MemoryAnswer);
            LumiConversationMemory.recordLumi(c,p,p.getLong("product_turn_active_id",0L),code660MemoryAnswer,"local-conversation-memory");
            return CoreLocalActions.Result.yes("conversation-memory",code660MemoryAnswer,"durable local conversation memory");
        }
        if(selfDecision.localAuthorityIntent()){
            if(selfDecision.intent==LumiSelfIntentResolver.Intent.SELF_IDENTITY){
                Snapshot snap=capture(c,p,false);
                String reply="I'm Lumi, this installed runtime. I'm running "+snap.versionName+" (code "+snap.version+"). My identity and self-state are owned by Lumi Core, not by an external model.";
                LumiSelfAuthority.noteLocalHandled(p,"self-identity",reply);
                return CoreLocalActions.Result.yes("self-identity",reply,"self-authority local identity");
            }
            if(selfDecision.intent==LumiSelfIntentResolver.Intent.SELF_CAPABILITY){
                String reply="I can inspect my own runtime, run bounded local maintenance, and use my trusted signed-build/update path when a core source change is required. External models may advise me, but they are not my maintenance authority.";
                LumiSelfAuthority.noteLocalHandled(p,"self-capability",reply);
                return CoreLocalActions.Result.yes("self-capability",reply,"self-authority local capability truth");
            }
            if(selfDecision.intent==LumiSelfIntentResolver.Intent.SELF_VISUAL_COMPARE){
                String reply=visualSelfComparison(c,p);
                LumiSelfAuthority.noteLocalHandled(p,"self-visual-compare",reply);
                return CoreLocalActions.Result.yes("self-visual-compare",reply,"Code721 structured self visual comparison");
            }
            if(selfDecision.updateIntent()){
                p.edit().putString("self_update_route_authority","PUBLISHED_UPDATE_MANAGER")
                        .putLong("self_update_route_authority_at",System.currentTimeMillis()).apply();
                return CoreLocalActions.Result.no();
            }
            if(selfDecision.intent==LumiSelfIntentResolver.Intent.SELF_DIAGNOSE || selfDecision.intent==LumiSelfIntentResolver.Intent.SELF_STATUS){
                String reply=LumiCoreSelfStateEngine.evaluate(c,p,"explicit-diagnostics-query");
                LumiSelfAuthority.noteLocalHandled(p,"self-diagnostics",reply);
                return CoreLocalActions.Result.yes("self-diagnostics",reply,"self-authority local runtime diagnosis");
            }
            if(selfDecision.maintenanceIntent()){
                String result=RemoteDeveloperMaintenance.requestExplicitMaintenance(c,p,raw);
                String tx=p.getString("maintenance_explicit_tx_id","");
                String state=p.getString("maintenance_explicit_tx_state","REQUESTED");
                LumiSelfAuthority.recordMaintenanceReceipt(p,tx,state,result);
                String reply=LumiSelfAuthority.maintenanceReply(p,selfDecision,state,result);
                LumiSelfAuthority.noteLocalHandled(p,"self-maintenance",reply);
                return CoreLocalActions.Result.yes("self-maintenance",reply,"intent="+selfDecision.intent.name()+" tx="+tx+" state="+state);
            }
        }
        // Code433: social check-ins belong to conversation, not diagnostics. Health is explicit only.
        if(s.equals("health status")||s.equals("system health")||s.equals("lumi health")||s.equals("lumi health status")||s.equals("how is your system health")){String core=LumiCoreSelfStateEngine.evaluate(c,p,"device-health-query");Snapshot d=capture(c,p,false);return CoreLocalActions.Result.yes("device-health",core+" Battery "+pct(d.battery)+", temperature "+d.thermalClass+", network "+(d.internet?"online":"not validated")+", "+humanBytes(d.free)+" storage free.",compact(d));}
        if(s.contains("what's wrong with you")||s.contains("whats wrong with you")||s.contains("run diagnostics")||s.contains("self diagnostic"))return CoreLocalActions.Result.yes("diagnostics",LumiCoreSelfStateEngine.evaluate(c,p,"explicit-diagnostics-query"),diagnosticText(c,p,false));
        if(s.contains("phone temp")||s.contains("phone temperature")||s.contains("device temp")||s.equals("temperature")){Snapshot d=capture(c,p,false);return CoreLocalActions.Result.yes("thermal-status","Thermal state is "+d.thermalClass+(Float.isNaN(d.batteryC)?".":String.format(Locale.US," at %.1f°C.",d.batteryC)),compact(d));}
        if(s.equals("battery")||s.equals("battery status")||s.equals("battery level")||s.equals("battery percentage")||s.contains("how much battery")||s.equals("charging status")||s.equals("am i charging")||s.equals("is my phone charging")){Snapshot d=capture(c,p,false);return CoreLocalActions.Result.yes("battery-status","Battery "+pct(d.battery)+(d.charging?", charging.":", not charging.")+" Temperature is "+d.thermalClass+".",compact(d));}
        if(s.contains("orientation")||s.contains("face up")||s.contains("face down")||s.contains("phone position")){Snapshot d=capture(c,p,true);return CoreLocalActions.Result.yes("orientation","Phone orientation is "+d.orientation+".",compact(d));}
        if((s.contains("gps")||s.contains("location"))&&(s.contains("status")||s.contains("enabled")||s.contains("permission"))){Snapshot d=capture(c,p,false);return CoreLocalActions.Result.yes("location-status","Location services are "+(d.locEnabled?"on":"off")+" and Lumi has "+(d.fine?"precise":d.coarse?"approximate":"no")+" location permission. GPS is not polled in the background.",compact(d));}
        if(s.equals("where am i")||s.contains("gps coordinates")||s.contains("my coordinates"))return CoreLocalActions.Result.yes("location-on-demand",lastKnownLocation(c),"last-known only");
        if(s.contains("biometric")||s.contains("fingerprint")||s.contains("face recognition")||s.contains("face unlock")){Snapshot d=capture(c,p,false);return CoreLocalActions.Result.yes("biometric-status",biometricReply(d),compact(d));}
        if(s.contains("audio route")||s.contains("where are you speaking")){Snapshot d=capture(c,p,false);return CoreLocalActions.Result.yes("audio-route","My current audio output route is "+d.audio+".",compact(d));}
        if(s.contains("network status")||s.contains("wifi status")||s.contains("internet status")){Snapshot d=capture(c,p,false);return CoreLocalActions.Result.yes("network-status",d.internet?"Internet is validated over "+(d.wifi?"Wi-Fi":d.cellular?"cellular":"the active network")+".":"Android has not validated internet access.",compact(d));}
        if(s.contains("storage")&&(s.contains("free")||s.contains("status"))){Snapshot d=capture(c,p,false);return CoreLocalActions.Result.yes("storage-status","I have "+humanBytes(d.free)+" of app-storage space free.",compact(d));}
        if(s.contains("update readiness")||s.contains("safe to update")||s.contains("ready to update")){Readiness r=assessUpdateReadiness(c,p,false);return CoreLocalActions.Result.yes("update-readiness",r.safe?"Yes. Conditions are safe for an update.":"Not yet. "+r.reason+".",r.reason);}
        if(s.contains("enable overnight update")||s.contains("allow overnight update")||s.contains("turn on overnight update")){p.edit().putBoolean("code407_overnight_updates_enabled",true).putLong("code407_overnight_permission_at",System.currentTimeMillis()).apply();AutonomousMaintenanceJobService.scheduleNext(c,p,"owner-enabled");return CoreLocalActions.Result.yes("overnight-enable","Overnight updates are enabled. I'll proceed only when the safety gates pass.","enabled");}
        if(s.contains("disable overnight update")||s.contains("turn off overnight update")||s.contains("stop overnight update")){p.edit().putBoolean("code407_overnight_updates_enabled",false).apply();AutonomousMaintenanceJobService.cancel(c);return CoreLocalActions.Result.yes("overnight-disable","Overnight updates are disabled.","disabled");}
        if(s.contains("overnight update status")||s.contains("maintenance status"))return CoreLocalActions.Result.yes("maintenance-status",p.getString("code407_last_maintenance_result","No overnight maintenance has run yet."),"stage="+p.getString("code407_maintenance_stage","IDLE"));
        if((s.contains("export")||s.contains("create"))&&(s.contains("diagnostic snapshot")||s.contains("diagnostics snapshot")))return CoreLocalActions.Result.yes("diagnostic-export",exportSnapshot(c,p),"diagnostic-export");
        if(s.contains("repair speech")||s.contains("fix speech recognizer"))return safeRepair(c,"speech_rebuild");
        if(s.contains("repair update bridge")||s.contains("fix update bridge"))return safeRepair(c,"bridge_reinitialize");
        if(s.contains("recover fast brain")||s.contains("repair fast brain"))return safeRepair(c,"fast_brain_recover");
        return CoreLocalActions.Result.no();
    }

    static void appendCoreHealthIssues(Context c,SharedPreferences p,ArrayList<String> issues,Bundle out){
        Snapshot s=capture(c,p,false);if("hot".equals(s.thermalClass)||"critical".equals(s.thermalClass))issues.add("device thermal state is "+s.thermalClass);if(s.free>=0&&s.free<300L*1024L*1024L)issues.add("device storage is critically low");if(p.getBoolean("code407_restart_loop_warning",false))issues.add("recent Lumi restart burst suggests a restart loop");out.putString("device_thermal",s.thermalClass);out.putInt("device_battery_pct",s.battery);out.putLong("device_free_bytes",s.free);out.putString("device_audio_route",s.audio);out.putString("device_permissions",s.permissions);out.putBoolean("device_location_enabled",s.locEnabled);out.putBoolean("device_bluetooth_enabled",s.btEnabled);if(p.contains("code407_permission_drift_at"))out.putString("permission_drift",p.getString("code407_permission_drift_from","")+" -> "+p.getString("code407_permission_drift_to",""));
    }
    static void notePostInstallPending(Context c,SharedPreferences p,long v){p.edit().putString("code407_build_validation_state","PENDING_VALIDATION").putLong("code407_pending_validation_version",v).apply();record(c,p,"BUILD_PENDING_VALIDATION","version="+v);}
    static void noteBootstrapInstallObserved(Context c,SharedPreferences p,long v){
        p.edit().putString("code407_build_validation_state","BOOTSTRAP_PENDING_VALIDATION")
                .putLong("code407_pending_validation_version",v)
                .putLong("code705_bootstrap_install_observed_at",System.currentTimeMillis()).apply();
        record(c,p,"BUILD_BOOTSTRAP_PENDING_VALIDATION","version="+v+" package replaced without active Lumi update transaction");
    }
    static void notePostInstallValidation(Context c,SharedPreferences p,long v,boolean pass,String detail){
        boolean acceptance=p.getBoolean("full_remediation_acceptance_complete",false) && p.getLong("full_remediation_acceptance_version",-1L)==v;
        boolean knownGood=pass && (v<480L || acceptance);
        String state=!pass?"VALIDATION_FAILED":(knownGood?"KNOWN_GOOD":"TRIAL_PENDING_ACCEPTANCE");
        SharedPreferences.Editor e=p.edit().putString("code407_build_validation_state",state).putLong("code407_last_validation_version",v).putString("code407_last_validation_detail",detail);
        if(knownGood)e.putLong("code407_known_good_version",v);
        e.apply();
        record(c,p,!pass?"BUILD_VALIDATION_FAILED":(knownGood?"BUILD_PROMOTED_KNOWN_GOOD":"BUILD_TRIAL_PENDING_ACCEPTANCE"),"version="+v+" "+detail);
    }

    private static String visualSelfComparison(Context c,SharedPreferences p){
        long at=p.getLong("visual_self_check_at",0L);if(at<=0L){String request=LumiVisualSelfCheck.request(c,p);return "I do not have a fresh visual observation yet. I scheduled one: "+request+". Final visual state remains UNKNOWN until Lumi Core evaluates the capture.";}String core=LumiCoreSelfStateEngine.evaluate(c,p,"visual-owner-query");return core+" Raw visual evidence: mismatch="+p.getFloat("visual_self_check_mismatch_pct",-1f)+"%, luminance="+p.getFloat("visual_self_check_actual_luma",-1f)+"/"+p.getFloat("visual_self_check_reference_luma",-1f)+", scope="+p.getString("visual_self_check_scope","none")+".";
    }

    private static String deepDiagnostic(Context c,SharedPreferences p){        Bundle h=BootstrapHealth.healthBundle(c,p);
        ArrayList<String> raw=h.getStringArrayList("issues");
        ArrayList<String> active=new ArrayList<>(),pending=new ArrayList<>();
        if(raw!=null)for(String issue:raw){
            if(issue==null||issue.trim().isEmpty())continue;
            if(issue.startsWith("Fast Brain has not completed a fresh normal inference after this core boot")
                    || issue.contains("Full Remediation behavioral acceptance is still pending")) pending.add(issue);
            else active.add(issue);
        }
        String visualStatus=p.getString("visual_self_check_status","NOT_RUN");
        float visualLuma=p.getFloat("visual_self_check_actual_luma",-1f), visualRef=p.getFloat("visual_self_check_reference_luma",-1f);
        boolean visualFault=false||false||"FAIL".equals(p.getString("visual_gate_r424",""))||visualLuma<=0f;
        if(visualFault) active.add("visual self-check="+visualStatus+" luma="+visualLuma+"/"+visualRef+" gate="+p.getString("visual_gate_r424","UNKNOWN"));
        long driftAt=p.getLong("code407_permission_drift_at",0L),bootAt=p.getLong("code407_last_process_start_at",0L);
        if(driftAt>0L && driftAt>=bootAt){
            String from=p.getString("code407_permission_drift_from","");
            String to=p.getString("code407_permission_drift_to","");
            active.add("permission changed this startup: "+from+" -> "+to);
        }
        if(active.isEmpty()&&pending.isEmpty())return "Diagnostics are clean. Core systems are operational.";
        StringBuilder b=new StringBuilder();
        if(!active.isEmpty()){
            b.append("I found ").append(active.size()).append(active.size()==1?" active issue: ":" active issues: ");
            for(int i=0;i<Math.min(3,active.size());i++){if(i>0)b.append("; ");b.append(active.get(i));}
        }
        if(!pending.isEmpty()){
            if(b.length()>0)b.append(". ");
            b.append("Verification pending: ");
            for(int i=0;i<Math.min(3,pending.size());i++){if(i>0)b.append("; ");b.append(pending.get(i));}
        }
        return b.append('.').toString();}
    private static CoreLocalActions.Result safeRepair(Context c,String action){SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);Bundle r=LumiCoreSelfStateEngine.executeRepair(c,p,action,"owner repair request");boolean ok=r.getBoolean("ok",false);return CoreLocalActions.Result.yes("safe-repair",ok?"Core-authorized repair dispatched: "+action.replace('_',' ')+".":"I couldn't authorize that repair: "+r.getString("state",r.getString("error","unknown")),"action="+action);}
    private static String exportSnapshot(Context c,SharedPreferences p){try{File d=new File(c.getCacheDir(),"diagnostics_exports");if(!d.exists()&&!d.mkdirs())throw new Exception("folder");File f=new File(d,"Lumi-Diagnostic-Snapshot-"+new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.US).format(new Date())+".txt");try(FileOutputStream o=new FileOutputStream(f)){o.write(diagnosticText(c,p,false).getBytes(StandardCharsets.UTF_8));}if(c instanceof Activity){android.net.Uri u=FileProvider.getUriForFile(c,c.getPackageName()+".fileprovider",f);Intent i=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_STREAM,u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);((Activity)c).startActivity(Intent.createChooser(i,"Export Lumi diagnostic snapshot"));return "Diagnostic snapshot is ready to export.";}return "Diagnostic snapshot created.";}catch(Throwable t){return "I couldn't create the diagnostic snapshot: "+t.getClass().getSimpleName()+".";}}
    private static String diagnosticText(Context c,SharedPreferences p,boolean loc){Snapshot s=capture(c,p,true);Bundle h=BootstrapHealth.healthBundle(c,p);return "LUMI CODE407 DIAGNOSTIC SNAPSHOT\nCaptured: "+new Date()+"\nLumi: code "+s.version+" • "+s.versionName+"\nCore health: "+h.getString("summary","unavailable")+"\nDevice: "+compact(s)+"\nPermissions: "+s.permissions+"\nBiometrics: "+biometricReply(s)+"\nRestart burst: "+p.getInt("code407_restart_burst",0)+" warning="+p.getBoolean("code407_restart_loop_warning",false)+"\nBuild validation: "+p.getString("code407_build_validation_state","unknown")+" knownGood="+p.getLong("code407_known_good_version",-1L)+"\nOvernight: enabled="+p.getBoolean("code407_overnight_updates_enabled",false)+" last="+p.getString("code407_last_maintenance_result","none")+(loc?"\nLocation: "+lastKnownLocation(c):"")+"\n";}

    private static String lastKnownLocation(Context c){if(!granted(c,Manifest.permission.ACCESS_FINE_LOCATION)&&!granted(c,Manifest.permission.ACCESS_COARSE_LOCATION))return "Location permission is not granted.";try{LocationManager lm=(LocationManager)c.getSystemService(Context.LOCATION_SERVICE);if(lm==null)return "Location service is unavailable.";Location best=null;for(String n:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER,LocationManager.PASSIVE_PROVIDER})try{Location x=lm.getLastKnownLocation(n);if(x!=null&&(best==null||x.getTime()>best.getTime()))best=x;}catch(Throwable ignored){}if(best==null)return "I don't have a recent local location fix. I won't keep GPS running in the background.";return String.format(Locale.US,"Last known coordinates are %.5f, %.5f, accuracy about %.0f meters.",best.getLatitude(),best.getLongitude(),best.hasAccuracy()?best.getAccuracy():-1f);}catch(Throwable t){return "Location lookup failed.";}}
    private static String biometricReply(Snapshot s){String strong=bio(s.strong),weak=bio(s.weak);String hint=s.face&&"available".equals(weak)&&!"available".equals(strong)?" Your face biometric may be Class 2, so normal startup now allows it while sensitive admin authentication can remain strong.":s.face&&"available".equals(weak)?" Android reports a face-capable biometric path.":"";return "Biometric check: face="+s.face+", fingerprint="+s.fingerprint+", strong="+strong+", weak="+weak+"."+hint;}
    private static String bio(int v){if(v==BiometricManager.BIOMETRIC_SUCCESS)return "available";if(v==BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED)return "none enrolled";if(v==BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE)return "no hardware";if(v==BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE)return "unavailable";return v==-999?"unknown":"code "+v;}
    private static String samplePhysicalOrientation(Context c){SensorManager sm=(SensorManager)c.getSystemService(Context.SENSOR_SERVICE);if(sm==null)return "sample unavailable";Sensor a=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);if(a==null)return "sample unavailable";HandlerThread ht=new HandlerThread("LumiOrientationSample");ht.start();CountDownLatch l=new CountDownLatch(1);float[] v={Float.NaN,0,0};SensorEventListener e=new SensorEventListener(){public void onSensorChanged(SensorEvent x){if(x.values.length>=3){v[0]=x.values[0];v[1]=x.values[1];v[2]=x.values[2];l.countDown();}}public void onAccuracyChanged(Sensor x,int y){}};try{sm.registerListener(e,a,SensorManager.SENSOR_DELAY_NORMAL,new Handler(ht.getLooper()));l.await(450,TimeUnit.MILLISECONDS);}catch(Throwable ignored){}finally{sm.unregisterListener(e);ht.quitSafely();}if(Float.isNaN(v[0]))return "sample unavailable";if(v[2]>7)return "face-up";if(v[2]<-7)return "face-down";return Math.abs(v[0])>Math.abs(v[1])?"held sideways":v[1]>0?"upright":"inverted";}
    private static String audioRoute(AudioManager am){try{if(Build.VERSION.SDK_INT>=31&&am.getCommunicationDevice()!=null)return deviceLabel(am.getCommunicationDevice());for(AudioDeviceInfo d:am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)){int t=d.getType();if(t==AudioDeviceInfo.TYPE_BLUETOOTH_A2DP||t==AudioDeviceInfo.TYPE_BLUETOOTH_SCO||t==AudioDeviceInfo.TYPE_BLE_HEADSET||t==AudioDeviceInfo.TYPE_BLE_SPEAKER)return deviceLabel(d);}for(AudioDeviceInfo d:am.getDevices(AudioManager.GET_DEVICES_OUTPUTS))if(d.getType()==AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)return deviceLabel(d);}catch(Throwable ignored){}return "system default";}
    private static String deviceLabel(AudioDeviceInfo d){CharSequence n=d.getProductName();return n==null||n.toString().trim().isEmpty()?"audio device type "+d.getType():n.toString().trim();}
    private static String permissionFingerprint(Context c){return "mic="+bit(granted(c,Manifest.permission.RECORD_AUDIO))+",camera="+bit(granted(c,Manifest.permission.CAMERA))+",fineLoc="+bit(granted(c,Manifest.permission.ACCESS_FINE_LOCATION))+",coarseLoc="+bit(granted(c,Manifest.permission.ACCESS_COARSE_LOCATION))+",bt="+bit(Build.VERSION.SDK_INT<31||granted(c,Manifest.permission.BLUETOOTH_CONNECT))+",notify="+bit(Build.VERSION.SDK_INT<33||granted(c,Manifest.permission.POST_NOTIFICATIONS))+",install="+bit(Build.VERSION.SDK_INT<26||c.getPackageManager().canRequestPackageInstalls());}
    private static boolean granted(Context c,String x){return Build.VERSION.SDK_INT<23||c.checkSelfPermission(x)==PackageManager.PERMISSION_GRANTED;}
    private static String thermalClass(int st,float c){if(Build.VERSION.SDK_INT>=29&&st>=PowerManager.THERMAL_STATUS_CRITICAL)return "critical";if(Build.VERSION.SDK_INT>=29&&st>=PowerManager.THERMAL_STATUS_SEVERE)return "hot";if(Build.VERSION.SDK_INT>=29&&st>=PowerManager.THERMAL_STATUS_MODERATE)return "warm";if(!Float.isNaN(c)){if(c>=47)return "critical";if(c>=43)return "hot";if(c>=38)return "warm";return "normal";}return "unknown";}
    private static String compact(Snapshot s){return "v="+s.version+" battery="+pct(s.battery)+" charging="+s.charging+" thermal="+s.thermalClass+" internet="+s.internet+" wifi="+s.wifi+" unmetered="+s.unmetered+" free="+humanBytes(s.free)+" interactive="+s.interactive+" idle="+s.idle+" location="+s.locEnabled+" bluetooth="+s.btEnabled+" orientation="+s.orientation+" audio="+s.audio+" heap="+humanBytes(s.heapUsed)+"/"+humanBytes(s.heapMax);}
    private static void record(Context c,SharedPreferences p,String action,String detail){try{DeveloperFlightRecorder.record(c,p,-1L,"DEVICE_HEALTH",action,detail,"local-device-health","","code407",false,false,false);}catch(Throwable ignored){}}
    private static String pct(int v){return v<0?"unknown":v+"%";}private static String bit(boolean v){return v?"1":"0";}
    static String humanBytes(long b){if(b<0)return "unknown";double v=b;String[] u={"B","KB","MB","GB","TB"};int i=0;while(v>=1024&&i<u.length-1){v/=1024;i++;}return String.format(Locale.US,i<2?"%.0f %s":"%.1f %s",v,u[i]);}
}
