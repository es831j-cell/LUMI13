package com.distressedelk.lumi;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;
public final class LumiVoiceInteractionSession extends VoiceInteractionSession {
  public LumiVoiceInteractionSession(Context context){ super(context); }
  @Override public void onShow(Bundle args,int flags){
    super.onShow(args,flags);
    Intent i=new Intent(getContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("lumi_system_assistant_invocation",true);
    getContext().startActivity(i); hide();
  }
}
