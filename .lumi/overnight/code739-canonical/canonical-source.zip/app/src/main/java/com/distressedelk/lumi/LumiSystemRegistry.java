package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.speech.SpeechRecognizer;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Locale;

/**
 * Authoritative inventory of Lumi Core and independently serviceable subsystems.
 * This is intentionally separate from RuntimeModuleRegistry: Core is inventoried here but can never
 * be installed through the optional Patch Bay lane.
 */
final class LumiSystemRegistry {
    static final int SCHEMA_VERSION=2;
    static final String REGISTRY_RELATIVE="lumi_system/system-registry.json";
    private LumiSystemRegistry(){}

    static JSONObject reconcile(Context context,SharedPreferences prefs){
        try{
            BrainProviderPolicy.ensureDefaults(prefs);
            JSONArray systems=new JSONArray();
            android.content.pm.PackageInfo coreInfo=context.getPackageManager().getPackageInfo(context.getPackageName(),0);
            String coreVersion=coreInfo.versionName==null?"unknown":coreInfo.versionName;
            String coreCode=String.valueOf(android.os.Build.VERSION.SDK_INT>=28?coreInfo.getLongVersionCode():coreInfo.versionCode);
            boolean localSpeech=false;
            if(Build.VERSION.SDK_INT>=31){
                try{localSpeech=SpeechRecognizer.isOnDeviceRecognitionAvailable(context);}catch(Throwable ignored){}
            }
            boolean fastBrainQuarantined=prefs!=null && prefs.getLong("fast_brain_quarantine_until",0L)>System.currentTimeMillis();

            systems.put(system("lumi.core","Lumi Core","CORE",coreVersion,"OBSERVED_AVAILABLE",
                    caps(LumiCapabilities.MODULE_MANAGEMENT,LumiCapabilities.EVENT_BUS,LumiCapabilities.RECOVERY),
                    "embedded-core","mandatory","",coreVersion,"","Identity, orchestration, security and recovery boundary."));
            systems.put(system("speech.fast","Fast Speech","CORE",coreVersion,localSpeech?"OBSERVED_AVAILABLE":"OBSERVED_LIMITED",
                    caps(LumiCapabilities.SPEECH_FAST),localSpeech?"android-on-device":"android-speech-bridge",
                    "mandatory","system recognizer",coreVersion,"",
                    localSpeech?"On-device Android recognizer is available.":"Core speech route is present; a Lumi-bundled independent speech model is not yet installed."));
            systems.put(system("brain.fast","Fast Brain","CORE",coreVersion,fastBrainQuarantined?"QUARANTINED":"OBSERVED_AVAILABLE",
                    caps(LumiCapabilities.BRAIN_FAST),"isolated-fast-brain-service","mandatory","brain.search/cloud fallback",coreVersion,"",
                    "Fast Brain is a Core capability and cannot be removed through Patch Bay."));
            systems.put(system("voice.basic","Basic Voice","CORE",coreVersion,"OBSERVED_AVAILABLE",caps(LumiCapabilities.VOICE_BASIC),
                    "android-tts","mandatory","text display",coreVersion,"","Basic speech output remains available without optional voice packs."));
            systems.put(system("conversation.core","Conversation Core","CORE",coreVersion,"OBSERVED_AVAILABLE",caps(LumiCapabilities.CONVERSATION),
                    "conversation-state-machine","mandatory","typed interaction",coreVersion,"","Conversation ownership and state stay in Core."));
            systems.put(system("capability.router","Capability Router","CORE",coreVersion,"OBSERVED_AVAILABLE",caps(LumiCapabilities.BRAIN_FAST,LumiCapabilities.BRAIN_SEARCH_WEB),
                    "reasoning-router","mandatory","fast brain",coreVersion,"","Routes by capability rather than subsystem internals."));
            systems.put(system("event.bus","Core Event Bus","CORE",coreVersion,"OBSERVED_AVAILABLE",caps(LumiCapabilities.EVENT_BUS),
                    "in-process-isolated","mandatory","none",coreVersion,"","Subsystem listener failure cannot abort the publisher."));
            systems.put(system("module.manager","Module Manager","CORE",coreVersion,"OBSERVED_AVAILABLE",caps(LumiCapabilities.MODULE_MANAGEMENT),
                    "runtime-registry-v2","mandatory","core-only safe mode",coreVersion,"","Tracks module compatibility, health, candidate and last-known-good metadata."));
            systems.put(system("security.permissions","Security & Permissions","CORE",coreVersion,"OBSERVED_AVAILABLE",new JSONArray(),
                    "identity-permission-boundary","mandatory","deny-by-default",coreVersion,"","Core-owned trust boundary."));
            systems.put(system("identity.core","Identity Hooks","CORE",coreVersion,"OBSERVED_AVAILABLE",new JSONArray(),
                    "identity-hierarchy","mandatory","unauthenticated session",coreVersion,"","Identity authority remains Core-owned."));
            systems.put(system("recovery.core","Recovery / Safe Mode","CORE",coreVersion,"OBSERVED_AVAILABLE",caps(LumiCapabilities.RECOVERY),
                    "guardian-update-recovery-hooks","mandatory","last-known-good",coreVersion,"","Core recovery survives optional subsystem failure."));
            systems.put(system("diagnostics.core","Core Diagnostics","CORE",coreVersion,"OBSERVED_AVAILABLE",caps(LumiCapabilities.DIAGNOSTICS),
                    "black-box-flight-recorder","mandatory","minimal health report",coreVersion,"","Black Box includes this registry snapshot."));

            String visualImpl=prefs==null?"approved-pyramid":prefs.getString("visual_core_renderer","approved-pyramid");
            boolean safeVisual=SafeCoreProfile.enabled(prefs,SafeCoreProfile.VISUALS);
            boolean safeSearch=SafeCoreProfile.enabled(prefs,SafeCoreProfile.BRAIN_SEARCH);
            boolean safeAurora=SafeCoreProfile.enabled(prefs,SafeCoreProfile.VOICE_AURORA);
            boolean safeAdvancedDiag=SafeCoreProfile.enabled(prefs,SafeCoreProfile.DIAGNOSTICS_ADVANCED);
            systems.put(system("visuals.default","Visuals","STANDARD",coreVersion,safeVisual?"OBSERVED_AVAILABLE":"DISABLED",caps(LumiCapabilities.VISUAL_STATE),
                    visualImpl,"owner-approval","core status indicator",coreVersion,"","Provider-plumbed standard subsystem; extraction/update lane remains independent of Core contract."));
            systems.put(system("brain.search","Brain Search Intelligence","STANDARD",coreVersion,safeSearch?"OBSERVED_AVAILABLE":"DISABLED",caps(LumiCapabilities.BRAIN_SEARCH_WEB,LumiCapabilities.BRAIN_SEARCH_AI),
                    "web-research+default-search-ai:"+BrainProviderPolicy.defaultSearchAi(prefs),"owner-approval","Fast Brain offline answer",coreVersion,"",
                    "Online search results and configurable default Search AI live under Brain & Intelligence."));
            systems.put(system("voice.aurora","Aurora Voice","STANDARD",coreVersion,
                    !safeAurora?"DISABLED":(prefs!=null&&!"none".equalsIgnoreCase(prefs.getString("lumi_voice_profile","none"))?"OBSERVED_AVAILABLE":"OBSERVED_LIMITED"),
                    caps(LumiCapabilities.VOICE_AURORA),"voice-profile-provider","owner-approval","Basic Voice",coreVersion,"","Higher-quality voice can evolve independently."));
            systems.put(system("speech.precision","Precision Speech","OPTIONAL","not-installed","DISABLED",caps(LumiCapabilities.SPEECH_PRECISION),
                    "module-slot","owner-approval","Fast Speech","","","Reserved for larger independently updateable speech models."));
            systems.put(system("brain.deep","Deep Brain","OPTIONAL","not-installed","DISABLED",caps(LumiCapabilities.BRAIN_DEEP),
                    "module-slot","owner-approval","Fast Brain","","","Deep reasoning models remain optional."));
            systems.put(system("diagnostics.advanced","Advanced Diagnostics","STANDARD",coreVersion,safeAdvancedDiag?"OBSERVED_AVAILABLE":"DISABLED",caps(LumiCapabilities.DIAGNOSTICS),
                    "diagnostic-provider","owner-approval","Core Diagnostics",coreVersion,"","Advanced analysis may evolve without changing the diagnostic heartbeat."));

            JSONObject runtime=RuntimeModuleRegistry.current(context);
            JSONArray modules=runtime.optJSONArray("modules");
            if(modules!=null){
                for(int i=0;i<modules.length();i++){
                    JSONObject m=modules.optJSONObject(i); if(m==null)continue;
                    File f=new File(m.optString("path",""));
                    String h=f.isFile()?"OBSERVED_AVAILABLE":"OBSERVED_MISSING";
                    String tier=m.optString("tier",m.optBoolean("required",true)?"STANDARD":"OPTIONAL").toUpperCase(Locale.US);
                    if(!"STANDARD".equals(tier)&&!"OPTIONAL".equals(tier)&&!"EXPERIMENTAL".equals(tier))tier="OPTIONAL";
                    JSONObject rec=system(m.optString("id","runtime."+i),m.optString("id","Runtime module"),tier,
                            m.optString("version","unknown"),h,m.optJSONArray("capabilities") == null ? new JSONArray() : m.optJSONArray("capabilities"),
                            "runtime:"+m.optString("kind","unknown"),"owner-approval","module-specific fallback",
                            m.optString("lastKnownGoodVersion",m.optString("version","")),m.optString("candidateVersion",""),
                            "Installed runtime module. rollbackAvailable="+RuntimeModuleRegistry.rollbackAvailable(context,m.optString("id","")));
                    rec.put("activatedByUpdateId",m.optString("activatedByUpdateId",""));
                    systems.put(rec);
                }
            }

            int coreProblems=0, degraded=0;
            for(int i=0;i<systems.length();i++){
                JSONObject s=systems.getJSONObject(i); String h=s.optString("health","");
                if("OBSERVED_LIMITED".equals(h))degraded++;
                if("CORE".equals(s.optString("tier")) && ("OBSERVED_MISSING".equals(h)||"QUARANTINED".equals(h)))coreProblems++;
            }
            String overall=coreProblems>0?"OBSERVED_ATTENTION":degraded>0?"OBSERVED_WATCH":"OBSERVED_AVAILABLE";
            JSONObject root=new JSONObject();
            root.put("schemaVersion",SCHEMA_VERSION).put("coreVersionCode",Integer.parseInt(coreCode)).put("coreVersionName",coreVersion)
                    .put("generatedAt",System.currentTimeMillis()).put("authority","EVIDENCE_ONLY").put("overallHealth",overall)
                    .put("safeCoreMode",SafeCoreProfile.active(prefs)).put("safeCoreSummary",SafeCoreProfile.summary(prefs))
                    .put("defaultSearchAi",BrainProviderPolicy.defaultSearchAi(prefs)).put("systems",systems);
            persist(context,root);
            if(prefs!=null)prefs.edit().putInt("system_registry_schema",SCHEMA_VERSION).putInt("system_registry_count",systems.length())
                    .putString("system_registry_health",overall).putString("system_registry_core_version",coreVersion)
                    .putLong("system_registry_snapshot_at",System.currentTimeMillis()).apply();
            LumiEventBus.publish("SYSTEM_REGISTRY_READY","lumi.core",new JSONObject().put("authority","EVIDENCE_ONLY").put("localObservation",overall).put("count",systems.length())); LumiEvidenceLedger.append(prefs,"SELF","RAW_SYSTEM_INVENTORY","localObservation",overall+" count="+systems.length(),"LumiSystemRegistry");
            return root;
        }catch(Throwable t){
            try{
                JSONObject fail=new JSONObject().put("schemaVersion",SCHEMA_VERSION).put("overallHealth","OBSERVED_ATTENTION")
                        .put("error",String.valueOf(t.getMessage())).put("systems",new JSONArray());
                if(prefs!=null)prefs.edit().putString("system_registry_health","OBSERVED_ATTENTION").putString("system_registry_error",String.valueOf(t.getMessage())).apply();
                return fail;
            }catch(Throwable ignored){return new JSONObject();}
        }
    }

    static JSONObject current(Context context){
        try{
            File f=new File(context.getFilesDir(),REGISTRY_RELATIVE);
            if(!f.isFile())return new JSONObject().put("schemaVersion",SCHEMA_VERSION).put("systems",new JSONArray());
            return new JSONObject(new String(Files.readAllBytes(f.toPath()),StandardCharsets.UTF_8));
        }catch(Throwable t){try{return new JSONObject().put("error",String.valueOf(t.getMessage())).put("systems",new JSONArray());}catch(Throwable ignored){return new JSONObject();}}
    }

    static String healthSummary(Context context){
        try{
            JSONObject r=current(context); JSONArray a=r.optJSONArray("systems");
            android.content.pm.PackageInfo info=context.getPackageManager().getPackageInfo(context.getPackageName(),0);
            int installedCode=android.os.Build.VERSION.SDK_INT>=28?(int)info.getLongVersionCode():info.versionCode;
            return r.optString("overallHealth",r.has("error")?"OBSERVED_ATTENTION":"UNKNOWN")+" • systems="+(a==null?0:a.length())+" • Core="+r.optInt("coreVersionCode",installedCode);
        }catch(Throwable t){return "ATTENTION • registry unreadable";}
    }

    static String compactSummary(Context context){
        try{
            JSONObject r=current(context); JSONArray a=r.optJSONArray("systems");
            if(a==null||a.length()==0)return "System inventory: unavailable\n";
            StringBuilder b=new StringBuilder("System inventory:\n");
            for(int i=0;i<a.length();i++){
                JSONObject s=a.getJSONObject(i);
                b.append("  ").append(s.optString("id","unknown")).append(" • ").append(s.optString("tier","?"))
                        .append(" • ").append(s.optString("version","?")).append(" • ").append(s.optString("health","?")).append("\n");
            }
            return b.toString();
        }catch(Throwable t){return "System inventory: unreadable\n";}
    }

    private static JSONObject system(String id,String name,String tier,String version,String health,JSONArray capabilities,
                                     String implementation,String updatePolicy,String fallback,String lastKnownGood,String candidate,String notes)throws Exception{
        String verification=("OPTIONAL".equals(tier) && (version==null || version.isEmpty() || "not-installed".equals(version)))
                ?"NOT_SELECTED":"READY_FOR_VERIFICATION";
        return new JSONObject().put("id",id).put("name",name).put("tier",tier).put("version",version).put("health",health)
                .put("verification",verification).put("verificationVersion",476).put("lastVerifiedAt",0L).put("evidenceId","")
                .put("capabilities",capabilities==null?new JSONArray():capabilities).put("implementation",implementation)
                .put("updatePolicy",updatePolicy).put("fallback",fallback).put("lastKnownGoodVersion",lastKnownGood)
                .put("candidateVersion",candidate).put("notes",notes);
    }
    private static JSONArray caps(String... values){JSONArray a=new JSONArray();if(values!=null)for(String v:values)a.put(v);return a;}
    private static void persist(Context context,JSONObject root)throws Exception{
        File target=new File(context.getFilesDir(),REGISTRY_RELATIVE);File parent=target.getParentFile();
        if(parent!=null&&!parent.exists()&&!parent.mkdirs())throw new java.io.IOException("Could not create system registry directory");
        File tmp=new File(parent,target.getName()+".tmp");Files.write(tmp.toPath(),root.toString(2).getBytes(StandardCharsets.UTF_8));
        if(target.exists()&&!target.delete())throw new java.io.IOException("Could not rotate system registry");
        if(!tmp.renameTo(target))throw new java.io.IOException("Could not publish system registry");
    }
}
