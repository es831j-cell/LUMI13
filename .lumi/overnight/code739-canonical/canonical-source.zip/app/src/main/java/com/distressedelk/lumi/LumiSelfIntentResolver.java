package com.distressedelk.lumi;

import java.util.Locale;

/**
 * Code650: pure, provider-independent self-reference and intent resolver.
 * This class deliberately has no Android or provider dependency so its semantic
 * contract can be compiled and executed in the factory before the APK build.
 */
final class LumiSelfIntentResolver {
    enum Intent { NONE, SELF_IDENTITY, SELF_CAPABILITY, SELF_STATUS, SELF_VISUAL_COMPARE, SELF_DIAGNOSE, SELF_REPAIR, SELF_UPDATE }

    static final class Decision {
        final Intent intent;
        final boolean selfReference;
        final String reason;
        Decision(Intent intent, boolean selfReference, String reason){
            this.intent=intent==null?Intent.NONE:intent;
            this.selfReference=selfReference;
            this.reason=reason==null?"":reason;
        }
        boolean maintenanceIntent(){ return intent==Intent.SELF_REPAIR; }
        boolean updateIntent(){ return intent==Intent.SELF_UPDATE; }
        boolean actionIntent(){ return maintenanceIntent() || updateIntent(); }
        boolean localAuthorityIntent(){ return intent!=Intent.NONE; }
        @Override public String toString(){ return intent.name()+" self="+selfReference+" reason="+reason; }
    }

    private LumiSelfIntentResolver(){}

    static Decision resolve(String raw){
        String s=norm(raw);
        if(s.isEmpty()) return new Decision(Intent.NONE,false,"empty");

        boolean reflexive=word(s,"yourself") || s.contains("your own ");
        boolean identityForm=s.matches("^(who are you|what are you|are you lumi|tell me about yourself|describe yourself|do you know who you are|who do you think you are)( .*)?$")
                || s.contains("who you are");
        boolean capabilityForm=s.matches("^(what can you do|what are your capabilities|what capabilities do you have|what can lumi do)( .*)?$")
                || s.contains("your capabilities") || s.contains("your capability");
        boolean statusForm=s.matches("^(what version are you|what is your version|what's your version|whats your version|show your state|what is your state|what's your state|whats your state)( .*)?$");
        boolean yourDomain=s.matches(".*\\byour\\s+(own\\s+)?(app|application|code|source|system|runtime|software|brain|memory|voice|speech|listening|conversation|visual|visuals|avatar|update|maintenance|diagnostic|diagnostics|health|behavior|behaviour|problem|issue|fault|error|state|version)\\b.*");
        boolean youFault=word(s,"you") && any(s,"working","wrong","broken","problem","issue","fault","error","stuck","failing","failed","responding","listening","speaking");
        boolean namedSelf=any(s,"fix lumi","repair lumi","update lumi","upgrade lumi","lumi app","lumi code","lumi system","lumi runtime","lumi's code","lumi's system","lumi's runtime","wrong with lumi","problem with lumi");
        boolean explicitSelfDiagnostics=s.contains("self diagnostic") || s.contains("self diagnostics") || s.contains("diagnose yourself") || s.contains("check yourself");
        boolean visualShorthand=s.matches("^(visual|visuals|avatar|your avatar|my avatar|pyramid)( .*)?$");
        boolean visualCompare=(any(s,"compare","comparison","match","difference","different") && any(s,"visual","visuals","avatar","pyramid")) || visualShorthand;
        boolean bareDiagnose=s.matches("^(what's wrong|whats wrong|what is wrong)$");
        boolean genericDiagnostics=s.matches("^(find (any )?(issues|problems|faults|errors)|check (for )?(any )?(issues|problems|faults|errors)|any (issues|problems|faults|errors)|diagnose|diagnostics|system check)$");
        boolean self=reflexive || identityForm || capabilityForm || statusForm || yourDomain || youFault || namedSelf || explicitSelfDiagnostics || visualShorthand || bareDiagnose || genericDiagnostics;
        if(!self) return new Decision(Intent.NONE,false,"no-self-subject");

        boolean updateAction=s.matches(".*\\b(update|upgrade)\\s+(yourself|your\\s+own\\s+(app|application|code|source|system|runtime|software)|your\\s+(app|application|code|source|system|runtime|software)|lumi)\\b.*")
                || any(s,"build your update","build lumi update","publish your update","publish lumi update","install your update","install lumi update");
        if(updateAction) return new Decision(Intent.SELF_UPDATE,true,"self-update-action");
        if(visualCompare) return new Decision(Intent.SELF_VISUAL_COMPARE,true,"self-visual-compare");

        // Action verbs are intentionally bounded. In particular, "correct" must be a
        // standalone verb so diagnostic phrases such as "working correctly" do not
        // become SELF_REPAIR merely because they contain the substring "correct".
        boolean repair=any(s,"fix","repair","improve","optimize","optimise","recover","heal","self repair","self-repair")
                || word(s,"correct")
                || (s.contains("do something") && any(s,"problem","issue","wrong","fault"))
                || (s.contains("take care of") && any(s,"problem","issue","fault"));
        if(repair) return new Decision(Intent.SELF_REPAIR,true,"self-repair-action");

        boolean diagnose=bareDiagnose || genericDiagnostics || any(s,"what's wrong","whats wrong","what is wrong","why aren't","why arent","why are you not","not working","working correctly","broken","problem","issue","fault","error","diagnose","diagnostic","check your system","check your own system","check yourself","check your health","system health");
        if(diagnose) return new Decision(Intent.SELF_DIAGNOSE,true,"self-diagnostic-question");

        if(identityForm) return new Decision(Intent.SELF_IDENTITY,true,"self-identity-question");
        if(capabilityForm) return new Decision(Intent.SELF_CAPABILITY,true,"self-capability-question");
        return new Decision(Intent.SELF_STATUS,true,"self-status-reference");
    }

    static boolean isExternalizedMaintenanceClaim(String raw){
        String s=norm(raw);
        return s.contains("maintenance team") || s.contains("maintenance department")
                || s.contains("lumi's maintenance system") || s.contains("lumi maintenance system")
                || (any(s,"forward the issue","report the issue","send the issue","escalate the issue") && any(s,"maintenance","team","system","department"));
    }

    static boolean isFirstPersonActionClaim(String raw){
        String s=norm(raw);
        boolean first=word(s,"i") || s.contains("i'll ") || s.contains("i will ") || s.contains("i've ") || s.contains("i have ") || s.contains("i'm ") || s.contains("im ");
        if(!first) return false;
        return any(s," fix"," fixed"," repair"," repaired"," update"," updated"," change"," changed"," install"," installed"," publish"," published"," apply"," applied"," send"," sent"," forward"," forwarded"," report"," reported"," submit"," submitted"," save"," saved"," create"," created"," complete"," completed"," finish"," finished"," restart"," restarted"," configure"," configured"," set "," delete"," deleted");
    }

    static boolean isSuccessClaim(String raw){
        String s=norm(raw);
        return any(s,"i fixed","i've fixed","i have fixed","i repaired","i've repaired","i updated","i've updated","i changed","i've changed","i installed","i've installed","i published","i've published","i applied","i've applied","i sent","i've sent","i forwarded","i've forwarded","i reported","i've reported","i submitted","i've submitted","i saved","i've saved","i created","i've created","i completed","i've completed","i finished","i've finished","it's done","its done");
    }

    static String contractFailure(){
        Object[][] positives=new Object[][]{
                {Intent.SELF_REPAIR,"Can you fix yourself?"},
                {Intent.SELF_REPAIR,"Fix whatever is wrong with you."},
                {Intent.SELF_REPAIR,"Can you repair your own code?"},
                {Intent.SELF_REPAIR,"Do something about your problem."},
                {Intent.SELF_REPAIR,"Can you improve yourself?"},
                {Intent.SELF_REPAIR,"Repair your system."},
                {Intent.SELF_DIAGNOSE,"What's wrong with you?"},
                {Intent.SELF_DIAGNOSE,"Why aren't you working correctly?"},
                {Intent.SELF_DIAGNOSE,"Are you broken?"},
                {Intent.SELF_DIAGNOSE,"Check your own system."},
                {Intent.SELF_DIAGNOSE,"Why is your update broken?"},
                {Intent.SELF_UPDATE,"Update yourself."},
                {Intent.SELF_UPDATE,"Can you update your own code?"},
                {Intent.SELF_UPDATE,"Build your update."},
                {Intent.SELF_IDENTITY,"Who are you?"},
                {Intent.SELF_IDENTITY,"Tell me about yourself."},
                {Intent.SELF_CAPABILITY,"What can you do?"},
                {Intent.SELF_CAPABILITY,"What are your capabilities?"},
                {Intent.SELF_STATUS,"What version are you?"},
                {Intent.SELF_VISUAL_COMPARE,"Compare with your avatar"},
                {Intent.SELF_VISUAL_COMPARE,"visuals?"},
                {Intent.SELF_DIAGNOSE,"what's wrong"},
                {Intent.SELF_DIAGNOSE,"find any issues"}
        };
        for(Object[] x:positives){
            Intent want=(Intent)x[0]; String q=(String)x[1]; Intent got=resolve(q).intent;
            if(got!=want) return "intent mismatch: "+q+" expected="+want+" got="+got;
        }
        String[] negatives={
                "Can you fix my truck?",
                "Lumi, can you fix my truck?",
                "Why is my phone slow?",
                "Can you help me update Windows?",
                "Tell me about maintenance teams.",
                "How are you?"
        };
        for(String q:negatives){
            Intent got=resolve(q).intent;
            if(got!=Intent.NONE) return "false self intent: "+q+" got="+got;
        }
        String fabricated="Sure thing, I'll forward the issue to Lumi's maintenance system right now.";
        if(!isExternalizedMaintenanceClaim(fabricated)) return "externalized-maintenance claim not detected";
        if(!isFirstPersonActionClaim(fabricated)) return "first-person action claim not detected";
        if(!isSuccessClaim("I've fixed the issue.")) return "success claim not detected";
        Decision update=resolve("Update yourself.");
        if(!update.updateIntent() || update.maintenanceIntent()) return "self-update incorrectly classified as maintenance";
        if(isFirstPersonActionClaim("I think the recognizer is the likely cause.")) return "analysis sentence misclassified as action claim";
        return "";
    }

    static boolean contractSelfTest(){ return contractFailure().isEmpty(); }

    private static String norm(String raw){
        if(raw==null) return "";
        String s=raw.toLowerCase(Locale.US).replace('’','\'').replace('–','-').replace('—','-');
        s=s.replaceAll("[^a-z0-9' -]+"," ").replace('-',' ').replaceAll("\\s+"," ").trim();
        return s;
    }
    private static boolean word(String s,String w){ return (" "+s+" ").contains(" "+w+" "); }
    private static boolean any(String s,String... needles){ for(String n:needles) if(s.contains(n)) return true; return false; }
}
