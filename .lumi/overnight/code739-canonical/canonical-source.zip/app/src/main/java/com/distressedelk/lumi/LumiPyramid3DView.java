package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.SystemClock;
import android.view.View;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.Locale;

/** Code711 R421 pyramid model for the Lumi avatar scene.
 * Preserves the layered inverted-pyramid identity while replacing the low-poly demo look with
 * a 2050-triangle micro-faceted shell, graphite ribs and an explicit state-color contract.
 * Idle/listening stay forest green, thinking is crimson, speaking is violet; six-second transitions remain.
 */
public final class LumiPyramid3DView extends GLSurfaceView {
    /* Code620 frozen Code400/R117 DEFAULT calibration markers retained for contract audit.
       Runtime uses LumiRendererControl values, whose defaults are exactly these values.
       Matrix.perspectiveM(projection,0,38f,aspect,.1f,40f);
       Matrix.setLookAtM(view,0,0f,1.55f,7.65f,0f,-.12f,0f,0f,1f,0f);
       final float[][] mainBase={
       {-1.28f,.50f, 1.28f}
       final float[] mainTip={0f,-1.20f,0f};
       float[][] upperOuter={{-1.30f,.59f,1.30f}
       float[][] topBase={{-.49f,.82f,.49f}
       float[] topTip={0f,1.59f,0f};
       Matrix.scaleM(model,0,.54f,.54f,.54f);
       Matrix.rotateM(model,0,xDeg,1f,0f,0f)
       Matrix.rotateM(model,0,yDeg,0f,1f,0f)
    */

    public enum VisualState { IDLE, PAUSED, READY, LISTENING, THINKING, SPEAKING }
    static final long COLOR_TRANSITION_MS = 6000L;
    static final int CODE710_FACET_SUBDIV = 5;

    private final PyramidRenderer renderer;
    private final SharedPreferences telemetryPrefs;
    private volatile boolean frameDriverRunning;
    private volatile boolean surfacePaused;
    private long frameDriverTicks;
    private long lastDriverTickMs;
    private long frameDriverRecoveries;
    private String lastDriverEvent="init";

    private final Runnable animationWatchdog=new Runnable(){
        @Override public void run(){
            if(!isAttachedToWindow()) return;
            boolean visible=getVisibility()==View.VISIBLE && getWindowVisibility()==View.VISIBLE;
            if(visible && !surfacePaused){
                long now=SystemClock.elapsedRealtime();
                long age=lastDriverTickMs==0?Long.MAX_VALUE:now-lastDriverTickMs;
                if(!frameDriverRunning || age>750L){ frameDriverRecoveries++; startFrameDriver("watchdog"); }
                else if(renderer.frameAgeMs()>750L){ lastDriverEvent="watchdog-render-nudge"; requestRender(); }
            }
            postDelayed(this,500L);
        }
    };

    private final Runnable frameDriver=new Runnable(){
        @Override public void run(){
            if(!frameDriverRunning || !isAttachedToWindow() || getVisibility()!=View.VISIBLE) return;
            frameDriverTicks++; lastDriverTickMs=SystemClock.elapsedRealtime(); requestRender();
            VisualState st=renderer.state;
            long delay=(st==VisualState.IDLE || st==VisualState.READY || st==VisualState.PAUSED)?33L:16L;
            postDelayed(this,delay);
        }
    };

    public LumiPyramid3DView(Context context){
        super(context);
        telemetryPrefs=context.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        setEGLContextClientVersion(2);
        setPreserveEGLContextOnPause(false);
        renderer=new PyramidRenderer(context.getApplicationContext());
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        setFocusable(false); setClickable(false);
        markMount("constructed","view created");
    }

    private void markMount(String state,String detail){
        try{
            telemetryPrefs.edit()
                    .putString("pyramid_mount_state",state)
                    .putString("pyramid_mount_detail",detail==null?"":detail)
                    .putLong("pyramid_mount_event_at",System.currentTimeMillis())
                    .putBoolean("pyramid_mount_attached",isAttachedToWindow())
                    .putBoolean("pyramid_mount_visible",getVisibility()==View.VISIBLE && getWindowVisibility()==View.VISIBLE)
                    .apply();
        }catch(Throwable ignored){}
    }

    @Override protected void onAttachedToWindow(){ super.onAttachedToWindow(); surfacePaused=false; markMount("attached","home visual attached to window"); removeCallbacks(animationWatchdog); post(animationWatchdog); startFrameDriver("attached"); }
    @Override protected void onDetachedFromWindow(){ markMount("detached","visual removed from current screen"); removeCallbacks(animationWatchdog); stopFrameDriver("detached"); super.onDetachedFromWindow(); }
    @Override protected void onVisibilityChanged(View changedView,int visibility){ super.onVisibilityChanged(changedView,visibility); if(changedView==this){ markMount(visibility==View.VISIBLE?"visible":"hidden","view visibility="+visibility); if(visibility==View.VISIBLE && isAttachedToWindow() && !surfacePaused) startFrameDriver("view-visible"); else if(visibility!=View.VISIBLE) stopFrameDriver("view-hidden"); } }
    @Override protected void onWindowVisibilityChanged(int visibility){ super.onWindowVisibilityChanged(visibility); markMount(visibility==View.VISIBLE?"window-visible":"window-hidden","window visibility="+visibility); if(visibility==View.VISIBLE && isAttachedToWindow() && !surfacePaused) startFrameDriver("window-visible"); else if(visibility!=View.VISIBLE) stopFrameDriver("window-hidden"); }
    @Override public void onWindowFocusChanged(boolean focus){ super.onWindowFocusChanged(focus); if(focus && isAttachedToWindow() && getVisibility()==View.VISIBLE && !surfacePaused) startFrameDriver("window-focus"); }
    public void onHostForeground(){
        surfacePaused=false; markMount("resumed","host foreground; approved renderer active");
        if(isAttachedToWindow() && getVisibility()==View.VISIBLE && getWindowVisibility()==View.VISIBLE){ startFrameDriver("host-foreground"); requestRender(); }
    }
    public void onHostBackground(){ surfacePaused=true; markMount("paused","host background; approved renderer stopped"); stopFrameDriver("host-background"); }
    @Override public void onResume(){ super.onResume(); onHostForeground(); }
    @Override public void onPause(){ onHostBackground(); super.onPause(); }

    private void startFrameDriver(String reason){ boolean was=frameDriverRunning; frameDriverRunning=true; lastDriverEvent=reason; markMount("running","frameDriver="+reason); removeCallbacks(frameDriver); post(frameDriver); if(!was) requestRender(); }
    private void stopFrameDriver(String reason){ frameDriverRunning=false; lastDriverEvent=reason; markMount("stopped","frameDriver="+reason); removeCallbacks(frameDriver); }
    public void forceMaintenanceRecovery(){ surfacePaused=false; markMount("recovered","forced visual recovery"); startFrameDriver("maintenance-repair"); requestRender(); }

    public void setVisualState(VisualState next){
        final VisualState state=next==null?VisualState.IDLE:next;
        queueEvent(()->renderer.setState(state));
        if(isAttachedToWindow() && getVisibility()==View.VISIBLE && getWindowVisibility()==View.VISIBLE && !surfacePaused) startFrameDriver("visual-state-"+state.name().toLowerCase(Locale.US));
    }

    public String diagnosticSnapshot(){
        long now=SystemClock.elapsedRealtime(); long age=lastDriverTickMs==0?-1:Math.max(0,now-lastDriverTickMs);
        return "renderer=pyramid-model-r421 • scene=avatar-scene-r421 • driver="+(frameDriverRunning?"RUNNING":"STOPPED")
                +" • driverTicks="+frameDriverTicks+" • driverAgeMs="+age+" • recoveries="+frameDriverRecoveries
                +" • lastDriverEvent="+lastDriverEvent+" • surfacePaused="+surfacePaused+" • frames="+renderer.frameCount
                +" • fps="+String.format(Locale.US,"%.1f",renderer.fps)+" • targetFps="+((renderer.state==VisualState.IDLE||renderer.state==VisualState.READY||renderer.state==VisualState.PAUSED)?30:60)+" • frameAgeMs="+renderer.frameAgeMs()
                +" • state="+renderer.state+" • transitionMs="+COLOR_TRANSITION_MS+" • wireframe="+renderer.wireframe+" • framing=lower-center-clear-controls-scale60-y0.00 • horizontalYawDegPerSec=2.2 • triangles=2050 • contract=state-color-final-r446";
    }

    private static final class PyramidRenderer implements GLSurfaceView.Renderer {
        private static final int FPV=9;
        private final android.content.SharedPreferences prefs;
        private final float[] projection=new float[16],view=new float[16],model=new float[16],mv=new float[16],mvp=new float[16],normalMatrix=new float[16];
        private FloatBuffer vertices; private ShortBuffer indices; private int indexCount; private int program;
        private long startNanos; private volatile VisualState state=VisualState.IDLE;
        private final float[] fromColor={.060f,.260f,.130f}; private final float[] toColor={.060f,.260f,.130f}; private final float[] renderedColor={.060f,.260f,.130f};
        private long transitionStartMs=0L;
        private long lastColorEvidenceMs=0L;
        private volatile long frameCount,lastFrameElapsedMs; private volatile float fps; private long fpsWindowStartMs,fpsWindowFrames; private volatile boolean wireframe; private long profileRevision=-1L; private int surfaceW=1,surfaceH=1;

        PyramidRenderer(Context context){ LumiRendererControl.applyCode711AvatarSceneBaseline(context); prefs=context.getSharedPreferences("lumi",Context.MODE_PRIVATE); }
        private float tune(String n,float d){ return LumiRendererControl.value(prefs,n,d); }
        long frameAgeMs(){ long last=lastFrameElapsedMs; return last==0?-1:Math.max(0,SystemClock.elapsedRealtime()-last); }

        void setState(VisualState next){
            long now=SystemClock.elapsedRealtime(); updateColor(now);
            System.arraycopy(renderedColor,0,fromColor,0,3);
            float[] target=colorFor(next); System.arraycopy(target,0,toColor,0,3);
            transitionStartMs=now; state=next;
            prefs.edit().putString("pyramid_visual_state_target",next.name())
                    .putFloat("pyramid_visual_target_r",target[0]).putFloat("pyramid_visual_target_g",target[1]).putFloat("pyramid_visual_target_b",target[2])
                    .putLong("pyramid_visual_state_transition_started_at",System.currentTimeMillis())
                    .putString("visual_state_color_contract","R446_IDLE_FOREST_LISTEN_FOREST_THINK_CRIMSON_SPEAK_VIOLET").apply();
        }

        private float[] colorFor(VisualState s){
            if(s==VisualState.LISTENING) return new float[]{tune("listenR",.030f),tune("listenG",.330f),tune("listenB",.095f)}; // deep forest green
            if(s==VisualState.THINKING) return new float[]{tune("thinkR",.620f),tune("thinkG",.035f),tune("thinkB",.080f)}; // crimson
            if(s==VisualState.SPEAKING) return new float[]{tune("speakR",.360f),tune("speakG",.070f),tune("speakB",.620f)}; // violet
            return new float[]{tune("idleR",.050f),tune("idleG",.250f),tune("idleB",.105f)}; // forest idle
        }

        private void updateColor(long now){
            float p=transitionStartMs<=0?1f:Math.max(0f,Math.min(1f,(now-transitionStartMs)/(float)COLOR_TRANSITION_MS));
            float e=p*p*(3f-2f*p);
            for(int i=0;i<3;i++) renderedColor[i]=fromColor[i]+(toColor[i]-fromColor[i])*e;
        }

        @Override public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl,javax.microedition.khronos.egl.EGLConfig cfg){
            GLES20.glClearColor(.002f,.010f,.006f,1f); GLES20.glEnable(GLES20.GL_DEPTH_TEST); GLES20.glDisable(GLES20.GL_CULL_FACE);
            GLES20.glEnable(GLES20.GL_BLEND); GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA);
            buildMesh(); program=buildProgram(VS,FS); prefs.edit().putBoolean("pyramid_shader_program_ok",program!=0).putString("pyramid_shader_program_state",program!=0?"PASS_R445":"FAIL_R445").putLong("pyramid_shader_program_at",System.currentTimeMillis()).apply(); startNanos=System.nanoTime(); fpsWindowStartMs=SystemClock.elapsedRealtime(); transitionStartMs=fpsWindowStartMs;
        }
        @Override public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl,int w,int h){
            surfaceW=Math.max(1,w); surfaceH=Math.max(1,h); GLES20.glViewport(0,0,w,h); applyCameraProfile();
            prefs.edit().putInt("pyramid_surface_width",w).putInt("pyramid_surface_height",h)
                    .putLong("pyramid_surface_changed_at",System.currentTimeMillis()).apply();
        }
        private void applyCameraProfile(){ float aspect=surfaceH==0?1f:(float)surfaceW/surfaceH; Matrix.perspectiveM(projection,0,tune("fov",38f),aspect,.1f,40f); Matrix.setLookAtM(view,0,tune("eyeX",0f),tune("eyeY",1.55f),tune("eyeZ",7.65f),tune("targetX",0f),tune("targetY",-.12f),tune("targetZ",0f),0f,1f,0f); }
        @Override public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl){
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT); if(program==0)return;
            float t=(System.nanoTime()-startNanos)/1_000_000_000f; long now=SystemClock.elapsedRealtime(); updateColor(now);
            if(now-lastColorEvidenceMs>=750L){
                lastColorEvidenceMs=now;
                float progress=transitionStartMs<=0?1f:Math.max(0f,Math.min(1f,(now-transitionStartMs)/(float)COLOR_TRANSITION_MS));
                prefs.edit().putString("pyramid_visual_state_rendered",state.name())
                        .putFloat("pyramid_visual_rendered_r",renderedColor[0]).putFloat("pyramid_visual_rendered_g",renderedColor[1]).putFloat("pyramid_visual_rendered_b",renderedColor[2])
                        .putFloat("pyramid_visual_transition_progress",progress).putLong("pyramid_visual_color_evidence_at",System.currentTimeMillis()).apply();
            }
            frameCount++; fpsWindowFrames++; lastFrameElapsedMs=now; if(now-fpsWindowStartMs>=1000L){ fps=fpsWindowFrames*1000f/Math.max(1L,now-fpsWindowStartMs); fpsWindowFrames=0; fpsWindowStartMs=now; prefs.edit().putFloat("pyramid_last_fps",fps).putLong("pyramid_frame_count",frameCount).putLong("pyramid_last_frame_wall_at",System.currentTimeMillis()).apply(); }
            wireframe=prefs.getBoolean("pyramid_wireframe_mode",false);
            long rev=prefs.getLong(LumiRendererControl.REV,0L); if(rev!=profileRevision){ profileRevision=rev; buildMesh(); applyCameraProfile(); }

            boolean idle=(state==VisualState.IDLE || state==VisualState.READY || state==VisualState.PAUSED);
            boolean calibrationPose=prefs.getBoolean("visual_self_check_calibration_pose",false);
            float xDeg=calibrationPose?tune("tiltBase",-8f):(idle?(tune("tiltBase",-8f)+tune("idleTiltAmp",2.5f)*(float)Math.sin(t*.14f)):(tune("tiltBase",-8f)+.5f+tune("activeTiltAmp",1.5f)*(float)Math.sin(t*.20f)));
            // Code623: deterministic front view during measurement; normal owner-approved idle yaw remains 1.6 deg/s.
            float yDeg=calibrationPose?0f:(-18.0f+((t*tune("yawSpeed",2.2f))%360.0f));
            // Shape stays rigid. State animation lives in light/color, not geometry inflation.
            float requestedBrightness=idle?tune("brightnessIdle",.78f):(state==VisualState.THINKING?tune("brightnessThink",1.14f):(state==VisualState.SPEAKING?tune("brightnessSpeak",1.10f):tune("brightnessListen",1.02f)));
            // Code719: visibility floor. Owner-visible geometry may be muted, never effectively black.
            float brightness=Math.max(idle?1.28f:1.18f,requestedBrightness);

            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,tune("translateX",0f),tune("translateY",0f),tune("translateZ",0f));
            // Code400: keep the requested 60% display scale but lower the avatar into the clear
            // center band beneath the command buttons. Geometry itself is also more compact.
            Matrix.scaleM(model,0,tune("scaleX",.54f),tune("scaleY",.54f),tune("scaleZ",.54f));
            Matrix.rotateM(model,0,xDeg,1f,0f,0f); Matrix.rotateM(model,0,yDeg,0f,1f,0f); // horizontal Y rotation; intentionally no Z-axis spin
            Matrix.multiplyMM(mv,0,view,0,model,0); Matrix.multiplyMM(mvp,0,projection,0,mv,0); System.arraycopy(model,0,normalMatrix,0,16);

            GLES20.glUseProgram(program);
            int ap=GLES20.glGetAttribLocation(program,"aPosition"), an=GLES20.glGetAttribLocation(program,"aNormal"), au=GLES20.glGetAttribLocation(program,"aU"), av=GLES20.glGetAttribLocation(program,"aV"), al=GLES20.glGetAttribLocation(program,"aLayer");
            vertices.position(0); GLES20.glVertexAttribPointer(ap,3,GLES20.GL_FLOAT,false,FPV*4,vertices); GLES20.glEnableVertexAttribArray(ap);
            vertices.position(3); GLES20.glVertexAttribPointer(an,3,GLES20.GL_FLOAT,false,FPV*4,vertices); GLES20.glEnableVertexAttribArray(an);
            vertices.position(6); GLES20.glVertexAttribPointer(au,1,GLES20.GL_FLOAT,false,FPV*4,vertices); GLES20.glEnableVertexAttribArray(au);
            vertices.position(7); GLES20.glVertexAttribPointer(av,1,GLES20.GL_FLOAT,false,FPV*4,vertices); GLES20.glEnableVertexAttribArray(av);
            vertices.position(8); GLES20.glVertexAttribPointer(al,1,GLES20.GL_FLOAT,false,FPV*4,vertices); GLES20.glEnableVertexAttribArray(al);
            GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"uMvp"),1,false,mvp,0); GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"uModel"),1,false,model,0); GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"uNormalMatrix"),1,false,normalMatrix,0);
            GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uTime"),t); GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uBrightness"),brightness); GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uWireframe"),wireframe?1f:0f); GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uGlow"),tune("glowStrength",1f)); GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uRimStrength"),tune("rimStrength",1f)); GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uMetalLevel"),tune("metalLevel",1f)); GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uGlassAlpha"),tune("glassAlpha",.82f));
            GLES20.glUniform3f(GLES20.glGetUniformLocation(program,"uStateColor"),renderedColor[0],renderedColor[1],renderedColor[2]);
            indices.position(0); GLES20.glDrawElements(GLES20.GL_TRIANGLES,indexCount,GLES20.GL_UNSIGNED_SHORT,indices);
            GLES20.glDisableVertexAttribArray(ap); GLES20.glDisableVertexAttribArray(an); GLES20.glDisableVertexAttribArray(au); GLES20.glDisableVertexAttribArray(av); GLES20.glDisableVertexAttribArray(al);
        }

        private void buildMesh(){
            // Code400 owner-approved geometry baseline, derived from the embedded approved
            // reference asset. The lower core is broader/shorter, the crown pedestal is thin,
            // and the upright top pyramid is smaller and more luminous than the lower core.
            final float[][] mainBase={
                    {-tune("lowerHalf",1.28f),tune("lowerShoulderY",.50f), tune("lowerHalf",1.28f)}, {tune("lowerHalf",1.28f),tune("lowerShoulderY",.50f), tune("lowerHalf",1.28f)},
                    { tune("lowerHalf",1.28f),tune("lowerShoulderY",.50f),-tune("lowerHalf",1.28f)}, {-tune("lowerHalf",1.28f),tune("lowerShoulderY",.50f),-tune("lowerHalf",1.28f)}
            };
            final float[] mainTip={0f,tune("lowerTipY",-1.20f),0f};
            final int triCount=82*CODE710_FACET_SUBDIV*CODE710_FACET_SUBDIV;
            float[] data=new float[triCount*3*FPV]; short[] ix=new short[triCount*3]; int[] c={0,0,0};

            // Large inverted lower pyramid with a wide shoulder and contained luminous face.
            for(int f=0;f<4;f++){
                float[] a=mainBase[f], b=mainBase[(f+1)%4];
                float[] pa=blend(a,b,mainTip,.735f,.075f,.190f);
                float[] pb=blend(a,b,mainTip,.075f,.735f,.190f);
                float[] pt=blend(a,b,mainTip,.105f,.105f,.790f);
                emitTri(data,ix,c,pa,pb,pt,1f);
                emitQuad(data,ix,c,a,b,pb,pa,0f);
                emitQuad(data,ix,c,a,pa,pt,mainTip,0f);
                emitQuad(data,ix,c,pb,b,mainTip,pt,0f);
            }

            // Thin polished shoulder/pedestal. The approved reference has separation here, but
            // not the heavy stack of slabs that appeared in Code399.
            float uoh=tune("upperOuterHalf",1.30f),uoy=tune("upperOuterY",.59f); float[][] upperOuter={{-uoh,uoy,uoh},{uoh,uoy,uoh},{uoh,uoy,-uoh},{-uoh,uoy,-uoh}};
            float iuh=tune("innerUpperHalf",.66f),iuy=tune("innerUpperY",.71f); float[][] innerUpper={{-iuh,iuy,iuh},{iuh,iuy,iuh},{iuh,iuy,-iuh},{-iuh,iuy,-iuh}};
            float ilh=tune("innerLowerHalf",.59f),ily=tune("innerLowerY",.62f); float[][] innerLower={{-ilh,ily,ilh},{ilh,ily,ilh},{ilh,ily,-ilh},{-ilh,ily,-ilh}};
            for(int i=0;i<4;i++){
                int n=(i+1)%4;
                emitQuad(data,ix,c,mainBase[i],mainBase[n],upperOuter[n],upperOuter[i],2f);
                emitQuad(data,ix,c,upperOuter[i],upperOuter[n],innerUpper[n],innerUpper[i],2f);
                emitQuad(data,ix,c,innerUpper[i],innerUpper[n],innerLower[n],innerLower[i],2f);
            }
            emitTri(data,ix,c,innerLower[0],innerLower[1],innerLower[2],3f);
            emitTri(data,ix,c,innerLower[0],innerLower[2],innerLower[3],3f);

            // Compact upright top pyramid from the approved reference.
            float tbh=tune("topBaseHalf",.49f),tby=tune("topBaseY",.82f); float[][] topBase={{-tbh,tby,tbh},{tbh,tby,tbh},{tbh,tby,-tbh},{-tbh,tby,-tbh}};
            float[] topTip={0f,tune("topTipY",1.59f),0f};
            for(int f=0;f<4;f++){
                float[] a=topBase[f], b=topBase[(f+1)%4];
                float[] pa=blend(a,b,topTip,.71f,.08f,.21f);
                float[] pb=blend(a,b,topTip,.08f,.71f,.21f);
                float[] pt=blend(a,b,topTip,.095f,.095f,.81f);
                emitTri(data,ix,c,pa,pb,pt,4f);
                emitQuad(data,ix,c,a,b,pb,pa,0f);
                emitQuad(data,ix,c,a,pa,pt,topTip,0f);
                emitQuad(data,ix,c,pb,b,topTip,pt,0f);
            }

            if(c[1]!=triCount*3) throw new IllegalStateException("R420 faceted pyramid triangle contract mismatch: "+(c[1]/3));
            vertices=ByteBuffer.allocateDirect(data.length*4).order(ByteOrder.nativeOrder()).asFloatBuffer(); vertices.put(data).position(0);
            indices=ByteBuffer.allocateDirect(ix.length*2).order(ByteOrder.nativeOrder()).asShortBuffer(); indices.put(ix).position(0); indexCount=ix.length;
            prefs.edit().putInt("code710_visual_triangle_count",c[1]/3)
                    .putString("code710_visual_style","MUTED_FOREST_GLASS_FACETED")
                    .putLong("code710_visual_mesh_built_at",System.currentTimeMillis()).apply();
        }
        private static float[] blend(float[] a,float[] b,float[] t,float wa,float wb,float wt){
            return new float[]{a[0]*wa+b[0]*wb+t[0]*wt,a[1]*wa+b[1]*wb+t[1]*wt,a[2]*wa+b[2]*wb+t[2]*wt};
        }
        private static void emitQuad(float[] data,short[] ix,int[] c,float[] a,float[] b,float[] d,float[] e,float layer){
            emitTri(data,ix,c,a,b,d,layer); emitTri(data,ix,c,a,d,e,layer);
        }
        private static void emitTri(float[] data,short[] ix,int[] c,float[] a,float[] b,float[] d,float layer){
            final int n=CODE710_FACET_SUBDIV;
            for(int i=0;i<n;i++){
                for(int j=0;j<n-i;j++){
                    float u0=i/(float)n, v0=j/(float)n;
                    float u1=(i+1)/(float)n, v1=(j+1)/(float)n;
                    float[] p00=baryPoint(a,b,d,u0,v0);
                    float[] p10=baryPoint(a,b,d,u1,v0);
                    float[] p01=baryPoint(a,b,d,u0,v1);
                    emitRawTri(data,ix,c,p00,p10,p01,layer);
                    if(j<n-i-1){
                        float[] p11=baryPoint(a,b,d,u1,v1);
                        emitRawTri(data,ix,c,p10,p11,p01,layer);
                    }
                }
            }
        }
        private static float[] baryPoint(float[] a,float[] b,float[] d,float u,float v){
            float w=1f-u-v;
            return new float[]{a[0]*w+b[0]*u+d[0]*v,a[1]*w+b[1]*u+d[1]*v,a[2]*w+b[2]*u+d[2]*v};
        }
        private static void emitRawTri(float[] data,short[] ix,int[] c,float[] a,float[] b,float[] d,float layer){
            float[] n=normal(a,b,d); float[][] pts={a,b,d}; float[][] uv={{0f,0f},{1f,0f},{0f,1f}};
            for(int j=0;j<3;j++){
                float[] q=pts[j]; data[c[0]++]=q[0];data[c[0]++]=q[1];data[c[0]++]=q[2];
                data[c[0]++]=n[0];data[c[0]++]=n[1];data[c[0]++]=n[2];
                data[c[0]++]=uv[j][0];data[c[0]++]=uv[j][1];data[c[0]++]=layer; ix[c[1]++]=(short)c[2]++;
            }
        }
        private static float[] normal(float[] a,float[] b,float[] c){ float ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2], vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2]; float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx; float d=(float)Math.sqrt(nx*nx+ny*ny+nz*nz); if(d<1e-6f)d=1f; return new float[]{nx/d,ny/d,nz/d}; }
        private static int buildProgram(String vs,String fs){ int v=compile(GLES20.GL_VERTEX_SHADER,vs),f=compile(GLES20.GL_FRAGMENT_SHADER,fs); if(v==0||f==0)return 0; int p=GLES20.glCreateProgram(); GLES20.glAttachShader(p,v);GLES20.glAttachShader(p,f);GLES20.glLinkProgram(p);int[]ok=new int[1];GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);if(ok[0]==0){GLES20.glDeleteProgram(p);p=0;}GLES20.glDeleteShader(v);GLES20.glDeleteShader(f);return p; }
        private static int compile(int type,String src){ int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);int[]ok=new int[1];GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0){GLES20.glDeleteShader(s);return 0;}return s; }

        private static final String VS=
                "uniform mat4 uMvp; uniform mat4 uModel; uniform mat4 uNormalMatrix; uniform float uTime;"
              + "attribute vec3 aPosition; attribute vec3 aNormal; attribute float aU; attribute float aV; attribute float aLayer;"
              + "varying vec3 vNormal; varying vec3 vWorld; varying float vU; varying float vV; varying float vLayer; varying float vPulse;"
              + "void main(){ vec3 pos=aPosition; vec4 world=uModel*vec4(pos,1.0); vWorld=world.xyz; vNormal=normalize((uNormalMatrix*vec4(aNormal,0.0)).xyz); vU=aU;vV=aV;vLayer=aLayer;vPulse=.5+.5*sin(uTime*1.1+aLayer);gl_Position=uMvp*vec4(pos,1.0);}";
        private static final String FS=
                "precision mediump float; uniform vec3 uStateColor; uniform float uBrightness; uniform float uWireframe; uniform float uTime; uniform float uGlow; uniform float uRimStrength; uniform float uMetalLevel; uniform float uGlassAlpha;"
              + "varying vec3 vNormal; varying vec3 vWorld; varying float vU; varying float vV; varying float vLayer; varying float vPulse;"
              + "void main(){ vec3 n=normalize(vNormal);vec3 light=normalize(vec3(-.34,.72,.61));float nd=abs(dot(n,light));float diff=.28+.72*nd;vec3 viewDir=normalize(vec3(0.0,.54,8.9)-vWorld);float rim=pow(1.0-abs(dot(n,viewDir)),2.15);"
              + "float w=max(0.0,1.0-vU-vV);float edgeDist=min(vU,min(vV,w));float edge=1.0-smoothstep(.016,.070,edgeDist);float bary=clamp(vU*vV*w*27.0,0.0,1.0);float centerGlow=pow(bary,.62);"
              + "float sideGlass=step(.5,vLayer)*(1.0-step(1.5,vLayer));float topGlass=step(2.5,vLayer)*(1.0-step(3.5,vLayer));float core=step(3.5,vLayer);float glass=max(sideGlass,max(topGlass,core));"
              + "float cloud=.50+.50*sin(vU*5.1+sin(vV*3.7+uTime*.18)*1.25+uTime*.12);float cloud2=.50+.50*sin(vV*4.3+sin(vU*3.2-uTime*.14)*1.10-uTime*.09);"
              + "float energy=pow(clamp(cloud*cloud2,0.0,1.0),2.0)*glass*(.22+.09*sin(uTime*.55));"
              + "vec3 metalLo=vec3(.012,.030,.020);vec3 metalHi=vec3(.165,.285,.205);vec3 metalColor=mix(metalLo,metalHi,clamp((.14+.52*diff)*uMetalLevel,0.0,1.0));metalColor+=vec3(.035,.075,.050)*rim*uRimStrength;"
              + "vec3 glassColor=mix(vec3(.008,.035,.020),uStateColor,.52+.22*diff);vec3 color=mix(metalColor,glassColor,glass);"
              + "float vein=.5+.5*sin((vWorld.y*7.0-vWorld.x*3.2)+uTime*.34+vLayer*1.7);vein=pow(vein,5.0)*glass;"
              + "color+=uStateColor*glass*centerGlow*(.20+.18*core)*uGlow;color+=uStateColor*edge*(.08+.36*glass)*uGlow;color+=uStateColor*rim*(.05+.31*glass)*uRimStrength;color+=uStateColor*energy*.72*uGlow;color+=uStateColor*vein*.30*uGlow;color+=uStateColor*core*(.12+.06*sin(uTime*.72))*uGlow;"
              + "float shimmer=.985+.015*sin(uTime*.31+vU*7.0+vV*4.0);color*=uBrightness*shimmer;"
              + "float alpha=mix(.995,uGlassAlpha,glass);alpha=max(alpha,core*.93);alpha=mix(alpha,.035+edge*.94,uWireframe);gl_FragColor=vec4(color,clamp(alpha,0.0,1.0));}";
    }
}
