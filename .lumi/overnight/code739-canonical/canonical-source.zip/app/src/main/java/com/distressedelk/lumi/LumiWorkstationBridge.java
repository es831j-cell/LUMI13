package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * Code651 workstation bridge. No network listener is opened.
 * A physically/ADB-authorized workstation reads the app external LumiLive directory
 * and may place one command.json transaction there. Manual Black Box transfer is fallback only.
 */
final class LumiWorkstationBridge {
    static final String MODE="ADB_LOCAL_ONLY";
    private static volatile long lastPoll=0L;

    private LumiWorkstationBridge(){}

    static void mirrorAndPoll(Context c, SharedPreferences p,String eventLine){
        if(c==null||p==null)return;
        File dir=c.getExternalFilesDir("LumiLive");
        if(dir==null){p.edit().putString("workstation_bridge_state","NO_EXTERNAL_FILES_DIR").apply();return;}
        if(!dir.exists())dir.mkdirs();
        try(FileWriter w=new FileWriter(new File(dir,"causal-live.jsonl"),true)){w.write(eventLine);w.write("\n");}
        catch(Throwable t){p.edit().putInt("workstation_bridge_write_failures",p.getInt("workstation_bridge_write_failures",0)+1).apply();}
        writeStatus(c,p,dir);
        long now=android.os.SystemClock.elapsedRealtime();
        if(now-lastPoll<750L)return;lastPoll=now;
        pollCommand(c,p,dir);
    }

    static String status(Context c,SharedPreferences p){
        if(c==null||p==null)return "unavailable";
        File dir=c.getExternalFilesDir("LumiLive");
        return "mode="+MODE+" path="+(dir==null?"unavailable":dir.getAbsolutePath())
                +" lastCommand="+p.getString("workstation_last_command_id","none")
                +" lastResult="+p.getString("workstation_last_command_result","none")
                +" writeFailures="+p.getInt("workstation_bridge_write_failures",0);
    }

    private static void writeStatus(Context c,SharedPreferences p,File dir){
        try{
            LumiCausalJournal.ensureRelease(c,p);
            JSONObject j=new JSONObject();
            j.put("schema","LumiWorkstation651");j.put("mode",MODE);
            j.put("releaseCode",p.getInt("causal_truth_release_code",LumiCausalJournal.BASELINE));
            j.put("releaseName",p.getString("causal_truth_release_name",LumiCausalJournal.RELEASE_NAME));
            j.put("currentTruth",LumiCausalJournal.currentTruthSummary(c,p));
            j.put("selfModel",LumiRuntimeSelfModel.snapshot(c,p));
            j.put("updatedAt",System.currentTimeMillis());
            try(FileWriter w=new FileWriter(new File(dir,"status.json"),false)){w.write(j.toString(2));}
        }catch(Throwable t){p.edit().putInt("workstation_bridge_write_failures",p.getInt("workstation_bridge_write_failures",0)+1).apply();}
    }

    private static void pollCommand(Context c,SharedPreferences p,File dir){
        File cmd=new File(dir,"command.json");if(!cmd.exists()||cmd.length()<=0L)return;
        try{
            StringBuilder b=new StringBuilder();char[] buf=new char[2048];
            try(FileReader r=new FileReader(cmd)){int n;while((n=r.read(buf))>0)b.append(buf,0,n);}
            JSONObject j=new JSONObject(b.toString());
            String id=j.optString("id","").trim();String action=j.optString("action","").trim().toUpperCase(java.util.Locale.US);
            String arg=j.optString("arg","");
            if(id.isEmpty()||action.isEmpty())return;
            if(id.equals(p.getString("workstation_last_command_id","")))return;
            p.edit().putString("workstation_last_command_id",id).putString("workstation_last_command_action",action)
                    .putString("workstation_last_command_result","RUNNING").putLong("workstation_last_command_at",System.currentTimeMillis()).apply();
            String result;boolean ok=true;
            if("PING".equals(action)) result="PONG Code"+p.getInt("causal_truth_release_code",LumiCausalJournal.BASELINE);
            else if("SNAPSHOT".equals(action)) result=LumiRuntimeSelfModel.snapshot(c,p);
            else if("TRACE_SNAPSHOT".equals(action)) result=LumiCausalJournal.recentTraceReport(c,p,120);
            else if("DIAGNOSTICS".equals(action)) result=LumiBlackBox2.report(c,p);
            else if("SELF_REPAIR".equals(action)) result=RemoteDeveloperMaintenance.requestExplicitMaintenance(c,p,arg.isEmpty()?"repair yourself":arg);
            else {ok=false;result="REJECTED unsupported command "+action;}
            JSONObject out=new JSONObject();out.put("schema","LumiWorkstationCommandResult651");out.put("id",id);out.put("action",action);out.put("ok",ok);out.put("result",result);out.put("completedAt",System.currentTimeMillis());
            try(FileWriter w=new FileWriter(new File(dir,"command-result.json"),false)){w.write(out.toString(2));}
            p.edit().putString("workstation_last_command_result",ok?"SUCCESS":"REJECTED").apply();
            if(!cmd.delete())try(FileWriter w=new FileWriter(cmd,false)){w.write("");}
        }catch(Throwable t){
            p.edit().putString("workstation_last_command_result","FAILED: "+String.valueOf(t.getMessage())).apply();
        }
    }
}
