package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayDeque;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Code651 causal truth journal.
 * Current-release truth is physically separated from history. Existing Flight Recorder
 * events are mirrored as observations, while product-turn boundaries are explicit traces.
 */
final class LumiCausalJournal {
    static final int BASELINE=661;
    static final String RELEASE_NAME="5.0.1-canonical-core-rebuild-r371";
    private static final String DIR="lumi-causal";
    private static final AtomicInteger SEQ=new AtomicInteger(0);
    private static final ThreadPoolExecutor IO=new ThreadPoolExecutor(
            1,1,30L, TimeUnit.SECONDS,new ArrayBlockingQueue<Runnable>(4096),
            r->{ Thread t=new Thread(r,"LumiCausal651");t.setDaemon(true);return t; },
            new ThreadPoolExecutor.AbortPolicy());

    private LumiCausalJournal(){}

    static void ensureRelease(Context c, SharedPreferences p){
        if(c==null||p==null)return;
        int code=currentVersionCode(c);
        String name=currentVersionName(c);
        int old=p.getInt("causal_truth_release_code",0);
        if(old==code && p.getLong("causal_truth_release_epoch",0L)>0L)return;
        long now=System.currentTimeMillis();
        File dir=dir(c); if(!dir.exists())dir.mkdirs();
        if(old>0 && old!=code){
            File prior=new File(dir,"current.jsonl");
            if(prior.exists()&&prior.length()>0L){
                File hist=new File(dir,"history-code"+old+"-closed-"+now+".jsonl");
                if(!prior.renameTo(hist)){
                    p.edit().putString("causal_history_rotation","FAILED_RENAME_CODE_"+old).apply();
                }
            }
        }
        File cur=new File(dir,"current.jsonl");
        if(old!=code && cur.exists())cur.delete();
        if(old>0 && old!=code){
            String prior="release="+old+" trace="+p.getString("causal_last_trace_id","none")
                    +" terminal="+p.getString("causal_last_terminal","UNTESTED")
                    +" route="+p.getString("causal_last_route","none")
                    +" failure="+p.getString("causal_last_failure","none");
            p.edit().putString("causal_history_previous_release_summary",prior).apply();
            LumiLivingSelf.resetForRelease(p,old,code);
        }
        p.edit().putInt("causal_truth_release_code",code)
                .putLong("causal_truth_release_epoch",now)
                .putString("causal_truth_release_name",name)
                .putString("causal_truth_state","CURRENT_RELEASE_ONLY")
                .putInt("causal_open_trace_count",0)
                .putInt("causal_orphan_span_count",0)
                .putInt("causal_journal_drop_count",0)
                .remove("causal_current_trace_id")
                .remove("causal_current_turn_id")
                .remove("causal_current_input")
                .remove("causal_current_source")
                .remove("causal_current_stage")
                .remove("causal_current_started_elapsed")
                .remove("causal_last_trace_id")
                .remove("causal_last_terminal")
                .remove("causal_last_route")
                .remove("causal_last_failure")
                .remove("causal_last_duration_ms")
                .remove("causal_last_result_detail")
                .remove("causal_last_decision")
                .remove("causal_last_decision_evidence")
                .remove("causal_last_decision_component")
                .apply();
        append(c,p,event("RELEASE","RELEASE_START","release","root","START",0L,"",
                "version="+name+" code="+code,"LUMI_CORE","runtime",code,name));
    }

    static String beginTurn(Context c, SharedPreferences p,long turnId,String source,String raw){
        if(c==null||p==null)return "";
        ensureRelease(c,p);
        int code=p.getInt("causal_truth_release_code",currentVersionCode(c));
        String trace="R"+code+"-P"+android.os.Process.myPid()+"-T"+turnId+"-"+SystemClock.elapsedRealtime();
        p.edit().putString("causal_current_trace_id",trace)
                .putLong("causal_current_turn_id",turnId)
                .putString("causal_current_input",safe(raw,500))
                .putString("causal_current_source",safe(source,80))
                .putString("causal_current_stage","INPUT_ACCEPTED")
                .putLong("causal_current_started_elapsed",SystemClock.elapsedRealtime())
                .putInt("causal_open_trace_count",1)
                .apply();
        emit(c,p,event(trace,"TRACE_START","turn","root","START",turnId,"",
                "source="+safe(source,80)+" input="+safe(raw,500),"LUMI_CORE","input",code,p.getString("causal_truth_release_name",RELEASE_NAME)));
        return trace;
    }

    static String beginSpan(Context c,SharedPreferences p,long turnId,String component,String parent,String detail){
        if(c==null||p==null)return "";
        String trace=trace(c,p,turnId);
        String span=component+"-"+SEQ.incrementAndGet();
        emit(c,p,event(trace,"SPAN_START",component,span,"START",turnId,parent,detail,"LUMI_CORE","span",
                p.getInt("causal_truth_release_code",BASELINE),p.getString("causal_truth_release_name",RELEASE_NAME)));
        p.edit().putString("causal_current_stage",component+":START").apply();
        return span;
    }

    static void decision(Context c,SharedPreferences p,long turnId,String component,String span,String decision,String evidence,String alternatives){
        if(c==null||p==null)return;
        String detail="decision="+safe(decision,180)+" evidence="+safe(evidence,350)+" alternatives="+safe(alternatives,220);
        p.edit().putString("causal_last_decision",safe(decision,180))
                .putString("causal_last_decision_evidence",safe(evidence,350))
                .putString("causal_last_decision_component",safe(component,80))
                .putString("causal_current_stage",component+":DECISION").apply();
        emit(c,p,event(trace(c,p,turnId),"DECISION",component,span,"DECISION",turnId,"",detail,"LUMI_CORE","decision",
                p.getInt("causal_truth_release_code",BASELINE),p.getString("causal_truth_release_name",RELEASE_NAME)));
    }

    static void endSpan(Context c,SharedPreferences p,long turnId,String component,String span,LumiCausalContract.Terminal terminal,String detail){
        if(c==null||p==null)return;
        LumiCausalContract.Terminal t=terminal==null?LumiCausalContract.Terminal.FAILED:terminal;
        emit(c,p,event(trace(c,p,turnId),"SPAN_END",component,span,t.name(),turnId,"",detail,"LUMI_CORE","span",
                p.getInt("causal_truth_release_code",BASELINE),p.getString("causal_truth_release_name",RELEASE_NAME)));
        p.edit().putString("causal_current_stage",component+":"+t.name()).apply();
        if(t==LumiCausalContract.Terminal.FAILED||t==LumiCausalContract.Terminal.TIMEOUT)
            p.edit().putString("causal_last_failure",component+": "+safe(detail,500)).apply();
    }

    static void observeFlight(Context c,SharedPreferences p,long turn,String category,String action,String detail,String route,String model,String stage){
        if(c==null||p==null)return;
        ensureRelease(c,p);
        String trace=trace(c,p,turn);
        // Code661: provider route/model are delegation evidence, never product-turn authority.
        // The previous schema accidentally wrote route -> authority and model -> route, which made
        // Core-owned audio/runtime observations appear to be owned by Groq or another provider.
        String d="category="+safe(category,80)+" action="+safe(action,120)+" stage="+safe(stage,100)+" detail="+safe(detail,700)
                +" delegateModel="+safe(model,100);
        emit(c,p,event(trace,"OBSERVATION",safe(category,80),"obs-"+SEQ.incrementAndGet(),"OBSERVED",turn,"",d,
                "LUMI_CORE",safe(route,100),p.getInt("causal_truth_release_code",BASELINE),p.getString("causal_truth_release_name",RELEASE_NAME)));
    }

    static void finishTurn(Context c,SharedPreferences p,long turnId,String terminal,String route,String why){
        if(c==null||p==null)return;
        LumiCausalContract.Terminal t=LumiCausalContract.terminal(terminal);
        String tr=trace(c,p,turnId);
        long started=p.getLong("causal_current_started_elapsed",0L);
        long elapsed=started<=0L?-1L:Math.max(0L,SystemClock.elapsedRealtime()-started);
        String detail="route="+safe(route,120)+" why="+safe(why,600)+" elapsedMs="+elapsed;
        emit(c,p,event(tr,"TRACE_END","turn","root",t.name(),turnId,"",detail,"LUMI_CORE",safe(route,100),
                p.getInt("causal_truth_release_code",BASELINE),p.getString("causal_truth_release_name",RELEASE_NAME)));
        SharedPreferences.Editor e=p.edit().putString("causal_last_trace_id",tr)
                .putString("causal_last_terminal",t.name())
                .putString("causal_last_route",safe(route,120))
                .putString("causal_last_result_detail",safe(why,600))
                .putLong("causal_last_duration_ms",elapsed)
                .putInt("causal_open_trace_count",0)
                .remove("causal_current_trace_id")
                .remove("causal_current_turn_id")
                .remove("causal_current_stage");
        if(t==LumiCausalContract.Terminal.FAILED||t==LumiCausalContract.Terminal.TIMEOUT)e.putString("causal_last_failure",detail);
        e.apply();
        RemoteDeveloperMaintenance.publishCompactBlackBoxAsync(c,"turn-terminal-code660");
    }

    static String currentTruthSummary(Context c,SharedPreferences p){
        if(c==null||p==null)return "unavailable";
        ensureRelease(c,p);
        int code=p.getInt("causal_truth_release_code",0);
        long epoch=p.getLong("causal_truth_release_epoch",0L);
        int drops=p.getInt("causal_journal_drop_count",0);
        int open=p.getInt("causal_open_trace_count",0);
        String integrity=drops==0?"PASS":"FAIL_DROPPED_EVENTS";
        return "release="+code+" name="+p.getString("causal_truth_release_name","")
                +" epoch="+epoch+" scope=CURRENT_RELEASE_ONLY"
                +" openTraces="+open+" orphanSpans="+p.getInt("causal_orphan_span_count",0)
                +" droppedEvents="+drops+" integrity="+integrity
                +" lastTrace="+p.getString("causal_last_trace_id","none")
                +" lastTerminal="+p.getString("causal_last_terminal","UNTESTED")
                +" lastRoute="+p.getString("causal_last_route","none")
                +" lastFailure="+p.getString("causal_last_failure","none");
    }

    static String recentTraceReport(Context c,SharedPreferences p,int maxLines){
        if(c==null||p==null)return "unavailable";
        ensureRelease(c,p);
        File f=new File(dir(c),"current.jsonl");
        if(!f.exists())return "No Code"+p.getInt("causal_truth_release_code",BASELINE)+" causal events yet.";
        ArrayDeque<String> q=new ArrayDeque<String>();
        try(BufferedReader br=new BufferedReader(new FileReader(f))){
            String line;while((line=br.readLine())!=null){q.addLast(line);while(q.size()>Math.max(10,maxLines))q.removeFirst();}
        }catch(Throwable t){return "Causal read failed: "+safe(String.valueOf(t.getMessage()),200);}
        StringBuilder b=new StringBuilder();for(String x:q)b.append(x).append('\n');return b.toString().trim();
    }

    static String liveFilePath(Context c){
        if(c==null)return "unavailable";
        File ext=c.getExternalFilesDir("LumiLive");
        if(ext==null)return "internal-only";
        return new File(ext,"causal-live.jsonl").getAbsolutePath();
    }

    private static String trace(Context c,SharedPreferences p,long turn){
        String x=p==null?"":p.getString("causal_current_trace_id","");
        if(x!=null&&!x.isEmpty())return x;
        int code=p==null?currentVersionCode(c):p.getInt("causal_truth_release_code",currentVersionCode(c));
        return "R"+code+"-SYS-"+turn+"-"+SystemClock.elapsedRealtime();
    }

    private static JSONObject event(String trace,String type,String component,String span,String state,long turn,String parent,String detail,String authority,String route,int code,String name){
        JSONObject j=new JSONObject();
        try{
            j.put("schema","LumiCausal651");j.put("releaseCode",code);j.put("releaseName",name);
            j.put("epochMs",System.currentTimeMillis());j.put("elapsedMs",SystemClock.elapsedRealtime());j.put("pid",android.os.Process.myPid());
            j.put("thread",Thread.currentThread().getName());j.put("traceId",safe(trace,180));j.put("turnId",turn);
            j.put("type",safe(type,60));j.put("component",safe(component,100));j.put("spanId",safe(span,120));j.put("parentSpanId",safe(parent,120));
            j.put("state",safe(state,60));j.put("authority",safe(authority,80));j.put("route",safe(route,100));j.put("detail",safe(detail,1000));
        }catch(Throwable ignored){}
        return j;
    }

    private static void emit(Context c,SharedPreferences p,JSONObject j){ append(c,p,j); }

    private static void append(Context c,SharedPreferences p,JSONObject j){
        try{
            IO.execute(new Runnable(){@Override public void run(){
                try{
                    File d=dir(c);if(!d.exists())d.mkdirs();
                    String line=j.toString();
                    try(FileWriter w=new FileWriter(new File(d,"current.jsonl"),true)){w.write(line);w.write("\n");}
                    LumiWorkstationBridge.mirrorAndPoll(c,p,line);
                }catch(Throwable t){p.edit().putInt("causal_journal_write_failures",p.getInt("causal_journal_write_failures",0)+1).apply();}
            }});
        }catch(Throwable t){p.edit().putInt("causal_journal_drop_count",p.getInt("causal_journal_drop_count",0)+1).apply();}
    }

    private static int currentVersionCode(Context c){
        try{
            android.content.pm.PackageInfo pi=c.getPackageManager().getPackageInfo(c.getPackageName(),0);
            long v=android.os.Build.VERSION.SDK_INT>=28?pi.getLongVersionCode():pi.versionCode;
            return (int)Math.min(Integer.MAX_VALUE,Math.max(0L,v));
        }catch(Throwable t){return BASELINE;}
    }
    private static String currentVersionName(Context c){
        try{String n=c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionName;return n==null?RELEASE_NAME:n;}
        catch(Throwable t){return RELEASE_NAME;}
    }
    private static File dir(Context c){return new File(c.getFilesDir(),DIR);}
    private static String safe(String s,int max){if(s==null)return "";s=s.replace('\n',' ').replace('\r',' ').trim();return s.length()>max?s.substring(0,max):s;}
}
