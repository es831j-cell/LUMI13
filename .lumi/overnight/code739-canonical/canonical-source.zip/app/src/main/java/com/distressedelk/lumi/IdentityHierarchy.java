package com.distressedelk.lumi;

import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Code376 identity + contact-card authority boundary.
 * Recognition is identity evidence, never administrator authorization by itself.
 * Contact #001 is the single primary administrator. Introduced people always begin with NONE permissions.
 */
final class IdentityHierarchy {
    static final long ADMIN_SESSION_MS = 10L * 60L * 1000L;
    static final String PRIMARY_CONTACT_ID = "contact-001";
    private static final String ADMIN_PHRASE = "there can be only one";
    private IdentityHierarchy(){}

    // Code441 Developer Mode: during active development, Lumi treats the active user as the
    // primary owner/admin. This bypass is intentionally local policy only; Guardian and relay
    // cryptographic authorization are not weakened. Public-release builds will default this off.
    static boolean developerOwnerBypassEnabled(SharedPreferences prefs){
        return prefs!=null && prefs.getBoolean("developer_owner_auth_bypass",false);
    }

    static boolean isAdminPhrase(String raw){
        String s=raw==null?"":raw.toLowerCase(Locale.US).replaceAll("[^a-z0-9 ]"," ").replaceAll("\\s+"," ").trim();
        return s.equals(ADMIN_PHRASE) || s.equals("lumi "+ADMIN_PHRASE);
    }

    static String redactAdminPhrase(String raw,String replacement){
        if(raw==null) return "";
        String safeReplacement=(replacement==null || replacement.trim().isEmpty())?"[administrator passphrase]":replacement;
        return raw.replaceAll("(?i)\\bthere\\s+can\\s+be\\s+only\\s+one\\b",java.util.regex.Matcher.quoteReplacement(safeReplacement));
    }

    /** Cold-start boundary. A prior app process can never leave root authority propped open. */
    static void beginUnauthenticatedSession(SharedPreferences prefs){
        if(prefs==null) return;
        if(developerOwnerBypassEnabled(prefs)){
            prefs.edit().putBoolean("developer_owner_auth_bypass",true)
                    .putLong("root_admin_session_until",Long.MAX_VALUE)
                    .putBoolean("session_identity_verified",true)
                    .putString("session_identity_verified_id",PRIMARY_CONTACT_ID)
                    .putString("session_identity_verified_name",prefs.getString("owner_call_name",prefs.getString("owner_name","Owner")))
                    .putLong("session_identity_verified_at",System.currentTimeMillis())
                    .putString("session_security_state","DEVELOPER_OWNER_BYPASS")
                    .apply();
            return;
        }
        prefs.edit()
                .putLong("root_admin_session_until",0L)
                .putBoolean("session_identity_verified",false)
                .remove("session_identity_verified_id")
                .remove("session_identity_verified_name")
                .remove("session_identity_verified_at")
                .remove("active_voice_speaker_id")
                .remove("active_voice_speaker_name")
                .putString("session_security_state","UNKNOWN_UNAUTHENTICATED")
                .apply();
    }

    static boolean openAdminSession(SharedPreferences prefs){
        if(!prefs.getBoolean("admin_enrollment_complete",false)) return false;
        long until=System.currentTimeMillis()+ADMIN_SESSION_MS;
        prefs.edit().putLong("root_admin_session_until",until)
                .putLong("root_admin_last_verified_at",System.currentTimeMillis())
                .putString("root_admin_authority","SOLE_ROOT_ADMIN")
                .putString("session_security_state","ADMIN_AUTHORIZED")
                .apply();
        return true;
    }

    static boolean strongAdminSessionActive(SharedPreferences prefs){
        if(developerOwnerBypassEnabled(prefs)) return true;
        return prefs.getBoolean("admin_enrollment_complete",false)
                && System.currentTimeMillis()<=prefs.getLong("root_admin_session_until",0L);
    }

    /** Voice is retained as evidence for speaker recognition, but never opens authority on its own. */
    static boolean voiceAdminSessionActive(SharedPreferences prefs){
        if(!prefs.getBoolean("admin_enrollment_complete",false) || !prefs.getBoolean("admin_profile_verified",false)) return false;
        if(!"probable-owner".equals(prefs.getString("speaker_last_state",""))) return false;
        if(prefs.getInt("speaker_last_confidence",0)<95 || !prefs.getBoolean("speaker_liveness_passed",false)) return false;
        long liveChecked=prefs.getLong("speaker_liveness_checked_at",0L);
        long now=System.currentTimeMillis();
        return liveChecked>0L && now-liveChecked<=2L*60L*60L*1000L;
    }

    static boolean adminSessionActive(SharedPreferences prefs){
        return strongAdminSessionActive(prefs);
    }

    static boolean ownerVoiceRecentlyVerified(SharedPreferences prefs){
        if(developerOwnerBypassEnabled(prefs)) return true;
        if(prefs==null) return false;
        if(!"OWNER_ACCEPTED".equals(prefs.getString("audio_gate_last_category",""))) return false;
        if(prefs.getInt("audio_gate_last_confidence",0)<76) return false;
        long at=prefs.getLong("audio_gate_last_owner_match_at",0L);
        return at>0L && System.currentTimeMillis()-at<=20L*60L*1000L;
    }

    static void markRecognizedSessionIdentity(SharedPreferences prefs,String id,String name,int confidence){
        if(prefs==null || id==null || id.trim().isEmpty()) return;
        prefs.edit().putBoolean("session_identity_verified",true)
                .putString("session_identity_verified_id",id)
                .putString("session_identity_verified_name",name==null?"":name)
                .putInt("session_identity_confidence",Math.max(0,Math.min(100,confidence)))
                .putLong("session_identity_verified_at",System.currentTimeMillis())
                .putString("session_security_state","RECOGNIZED_NOT_ADMIN")
                .apply();
        String code730IdentityTrace=LumiEvidenceLedger.beginTrace(prefs,"IDENTITY");LumiEvidenceLedger.appendTrace(prefs,"IDENTITY","OWNER_RECOGNITION","ownerAuthorityVerified",String.valueOf(PRIMARY_CONTACT_ID.equals(id)),"IdentityHierarchy",code730IdentityTrace);
    }

    static String primaryAdminContactId(SharedPreferences prefs){ return PRIMARY_CONTACT_ID; }

    /** Creates/repairs Contact Card #001 without granting authority to anyone else. */
    static void ensurePrimaryAdminContact(SharedPreferences prefs){
        if(prefs==null) return;
        try{
            JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));
            JSONObject primary=null;
            for(int i=0;i<a.length();i++){
                JSONObject c=a.optJSONObject(i);
                if(c!=null && PRIMARY_CONTACT_ID.equals(c.optString("id"))){ primary=c; break; }
            }
            if(primary==null){ primary=new JSONObject(); a.put(primary); }
            String name=prefs.getString("owner_call_name",prefs.getString("owner_name","Primary Administrator")).trim();
            if(name.isEmpty()) name="Primary Administrator";
            primary.put("id",PRIMARY_CONTACT_ID);
            primary.put("contactNumber",1);
            primary.put("displayName",name);
            primary.put("name",name);
            primary.put("state",prefs.getBoolean("admin_enrollment_complete",false)?"PRIMARY_ADMIN":"PRIMARY_ADMIN_PENDING_ENROLLMENT");
            primary.put("relationship","Primary Administrator");
            primary.put("permissionLevel","ROOT_ADMIN");
            primary.put("privileged",true);
            primary.put("source","owner-enrollment");
            primary.put("firstMetAt",prefs.getLong("admin_enrollment_completed_at",System.currentTimeMillis()));
            primary.put("needsPrivateReview",false);
            primary.put("voiceProfile",prefs.getBoolean("admin_voice_enrolled",false)?"OWNER_ENROLLED":"PENDING");
            primary.put("voiceConsentState","OWNER_ENROLLMENT");
            primary.put("updatedAt",System.currentTimeMillis());
            prefs.edit().putString("identity_contacts_json",a.toString()).apply();
        }catch(Exception ignored){}
    }

    static String findContactIdByName(SharedPreferences prefs,String displayName){
        String target=displayName==null?"":displayName.trim();if(target.isEmpty())return "";
        try{JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;String n=c.optString("displayName",c.optString("name",""));if(target.equalsIgnoreCase(n.trim()))return c.optString("id","");}}catch(Exception ignored){}
        return "";
    }
    static String ensureRelationshipContact(SharedPreferences prefs,String displayName,String relationship,String source){
        String id=findContactIdByName(prefs,displayName);
        if(!id.isEmpty()){
            try{JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null||!id.equals(c.optString("id")))continue;String old=c.optString("relationship","UNREVIEWED");if(old.isEmpty()||"UNREVIEWED".equals(old))c.put("relationship",relationship);c.put("lastInteractionAt",System.currentTimeMillis());c.put("updatedAt",System.currentTimeMillis());prefs.edit().putString("identity_contacts_json",a.toString()).apply();break;}}catch(Exception ignored){}
            return id;
        }
        return createIntroducedContact(prefs,displayName,relationship,source);
    }
    static String relationshipContactName(SharedPreferences prefs,String relationship){
        String rel=relationship==null?"":relationship.trim();if(rel.isEmpty())return "";
        try{JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));for(int x=0;x<a.length();x++){JSONObject c=a.optJSONObject(x);if(c==null||PRIMARY_CONTACT_ID.equals(c.optString("id")))continue;if(rel.equalsIgnoreCase(c.optString("relationship","")))return c.optString("displayName",c.optString("name",""));}}catch(Exception ignored){}
        return "";
    }
    static String findContactIdByRelationship(SharedPreferences prefs,String relationship){
        String rel=relationship==null?"":relationship.trim();if(rel.isEmpty())return "";
        try{JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));for(int x=0;x<a.length();x++){JSONObject c=a.optJSONObject(x);if(c==null||PRIMARY_CONTACT_ID.equals(c.optString("id")))continue;if(rel.equalsIgnoreCase(c.optString("relationship","")))return c.optString("id","");}}catch(Exception ignored){}
        return "";
    }

    static String normalizeContactFactTopic(String raw){
        String x=raw==null?"":raw.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+","-").replaceAll("(^-|-$)","");
        return x.length()>64?x.substring(0,64):x;
    }

    /** Code433: facts live on the contact card itself, not only in model context. */
    static boolean upsertContactFact(SharedPreferences prefs,String contactId,String topic,String value,String source){
        if(prefs==null||contactId==null||contactId.isEmpty()||value==null||value.trim().isEmpty())return false;
        String key=normalizeContactFactTopic(topic);if(key.isEmpty())return false;
        String expected=value.trim();
        try{
            JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));
            boolean found=false;
            for(int x=0;x<a.length();x++){
                JSONObject c=a.optJSONObject(x);if(c==null||!contactId.equals(c.optString("id")))continue;
                JSONObject facts=c.optJSONObject("facts");if(facts==null)facts=new JSONObject();
                JSONObject fact=new JSONObject();fact.put("value",expected);fact.put("topic",topic==null?key:topic.trim());
                fact.put("source",source==null?"conversation":source);fact.put("updatedAt",System.currentTimeMillis());
                facts.put(key,fact);c.put("facts",facts);c.put("updatedAt",System.currentTimeMillis());c.put("lastInteractionAt",System.currentTimeMillis());found=true;break;
            }
            if(!found)return false;
            if(!prefs.edit().putString("identity_contacts_json",a.toString()).commit())return false;
            return expected.equals(contactFact(prefs,contactId,key));
        }catch(Exception e){return false;}
    }

    static String contactFact(SharedPreferences prefs,String contactId,String topic){
        if(prefs==null||contactId==null||contactId.isEmpty())return "";String key=normalizeContactFactTopic(topic);if(key.isEmpty())return "";
        try{JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));for(int x=0;x<a.length();x++){JSONObject c=a.optJSONObject(x);if(c==null||!contactId.equals(c.optString("id")))continue;JSONObject facts=c.optJSONObject("facts");if(facts==null)return "";Object raw=facts.opt(key);if(raw instanceof JSONObject)return ((JSONObject)raw).optString("value","");return raw==null?"":String.valueOf(raw);}}catch(Exception ignored){}
        return "";
    }

    static String setExclusiveRelationshipContact(SharedPreferences prefs,String relationship,String displayName,String source){
        if(prefs==null)return "";String rel=relationship==null?"":relationship.trim();String name=displayName==null?"":displayName.trim();if(rel.isEmpty()||name.isEmpty())return "";
        try{
            ensurePrimaryAdminContact(prefs);
            JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));JSONArray out=new JSONArray();JSONObject chosen=null;String chosenId="";
            for(int x=0;x<a.length();x++){
                JSONObject c=a.optJSONObject(x);if(c==null)continue;
                boolean same=!PRIMARY_CONTACT_ID.equals(c.optString("id"))&&rel.equalsIgnoreCase(c.optString("relationship",""));
                if(!same){out.put(c);continue;}
                if(chosen==null){chosen=c;chosenId=c.optString("id","");c.put("displayName",name);c.put("name",name);c.put("relationship",rel);c.put("source",source==null?"owner-confirmed":source);c.put("lastInteractionAt",System.currentTimeMillis());c.put("updatedAt",System.currentTimeMillis());out.put(c);}
            }
            if(chosen==null){prefs.edit().putString("identity_contacts_json",out.toString()).apply();chosenId=createIntroducedContact(prefs,name,rel,source==null?"owner-confirmed":source);}
            else prefs.edit().putString("identity_contacts_json",out.toString()).apply();
            if(!chosenId.isEmpty()&&prefs.getBoolean("identity_private_review_pending",false))prefs.edit().putString("identity_private_review_contact_id",chosenId).putString("identity_private_review_name",name).apply();
            return chosenId;
        }catch(Exception e){return "";}
    }
    static String privacySafeContactSummary(SharedPreferences prefs){
        ensurePrimaryAdminContact(prefs);StringBuilder s=new StringBuilder();
        try{JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));s.append("contacts=").append(a.length());for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;s.append("\\n- ").append(c.optString("displayName",c.optString("name","Unknown"))).append(" • relationship=").append(c.optString("relationship","UNREVIEWED")).append(" • state=").append(c.optString("state","")).append(" • permission=").append(c.optString("permissionLevel","NONE"));}}catch(Exception e){s.append("\\nsummary unavailable");}
        return s.toString();
    }

    static String createProvisionalContact(SharedPreferences prefs,String displayName,String source){
        return createIntroducedContact(prefs,displayName,"UNREVIEWED",source);
    }

    static String createIntroducedContact(SharedPreferences prefs,String displayName,String relationship,String source){
        String name=displayName==null?"":displayName.trim();
        if(name.isEmpty()) name="New person";
        String rel=relationship==null?"":relationship.trim();
        if(rel.isEmpty()) rel="UNREVIEWED";
        try{
            ensurePrimaryAdminContact(prefs);
            JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));
            JSONObject c=new JSONObject();
            String id="contact-"+UUID.randomUUID().toString();
            c.put("id",id);
            c.put("contactNumber",nextContactNumber(a));
            c.put("displayName",name);
            c.put("name",name);
            c.put("state","INTRODUCED");
            c.put("relationship",rel);
            c.put("permissionLevel","NONE");
            c.put("privileged",false);
            c.put("source",source==null?"formal-introduction":source);
            c.put("introducedBy",PRIMARY_CONTACT_ID);
            c.put("firstMetAt",System.currentTimeMillis());
            c.put("lastInteractionAt",System.currentTimeMillis());
            c.put("needsPrivateReview",true);
            c.put("voiceProfile","NOT_ENROLLED");
            c.put("voiceConsentState","REQUIRED_FOR_PERSISTENT_PROFILE");
            a.put(c);
            prefs.edit().putString("identity_contacts_json",a.toString())
                    .putBoolean("identity_private_review_pending",true)
                    .putString("identity_private_review_contact_id",id)
                    .putString("identity_private_review_name",name)
                    .apply();
            return id;
        }catch(Exception e){ return ""; }
    }

    static void noteTransientVoiceSample(SharedPreferences prefs,String contactId,int byteCount){
        if(prefs==null || contactId==null || contactId.isEmpty()) return;
        try{
            JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));
            for(int i=0;i<a.length();i++){
                JSONObject c=a.optJSONObject(i); if(c==null || !contactId.equals(c.optString("id"))) continue;
                c.put("voiceSampleObservedAt",System.currentTimeMillis());
                c.put("voiceSampleObservedBytes",Math.max(0,byteCount));
                c.put("voiceSampleRetention","SESSION_ONLY_UNTIL_CONSENT");
                c.put("lastInteractionAt",System.currentTimeMillis());
                break;
            }
            prefs.edit().putString("identity_contacts_json",a.toString()).apply();
        }catch(Exception ignored){}
    }

    static String contactName(SharedPreferences prefs,String contactId){
        try{
            JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));
            for(int i=0;i<a.length();i++){
                JSONObject c=a.optJSONObject(i); if(c!=null && contactId.equals(c.optString("id"))) return c.optString("displayName",c.optString("name","New person"));
            }
        }catch(Exception ignored){}
        return "New person";
    }

    static JSONArray contactCardsForUi(SharedPreferences prefs){
        ensurePrimaryAdminContact(prefs);
        JSONArray out=new JSONArray();
        Set<String> names=new HashSet<>();
        try{
            JSONArray ids=new JSONArray(prefs.getString("identity_contacts_json","[]"));
            for(int i=0;i<ids.length();i++){
                JSONObject c=ids.optJSONObject(i); if(c==null) continue;
                out.put(new JSONObject(c.toString()));
                names.add(c.optString("displayName",c.optString("name","")).toLowerCase(Locale.US));
            }
            JSONArray legacy=new JSONArray(prefs.getString("people_cards_json","[]"));
            for(int i=0;i<legacy.length();i++){
                JSONObject c=legacy.optJSONObject(i); if(c==null) continue;
                String n=c.optString("name","").toLowerCase(Locale.US);
                if(!n.isEmpty() && names.contains(n)) continue;
                out.put(new JSONObject(c.toString()));
            }
        }catch(Exception ignored){}
        return out;
    }

    private static String normalizeFactText(String raw){
        return raw==null?"":raw.toLowerCase(Locale.US).replaceAll("[^a-z0-9 ]"," ").replaceAll("\\s+"," ").trim();
    }

    private static JSONObject contactByRelationship(SharedPreferences prefs,String relationship){
        String wanted=relationship==null?"":relationship.trim();
        if(wanted.isEmpty()) return null;
        try{
            JSONArray a=contactCardsForUi(prefs);
            for(int i=0;i<a.length();i++){
                JSONObject c=a.optJSONObject(i); if(c==null) continue;
                if(wanted.equalsIgnoreCase(c.optString("relationship",""))) return c;
            }
        }catch(Exception ignored){}
        return null;
    }

    private static JSONObject contactMentionedInText(SharedPreferences prefs,String normalized){
        if(normalized==null || normalized.isEmpty()) return null;
        try{
            JSONArray a=contactCardsForUi(prefs);
            for(int i=0;i<a.length();i++){
                JSONObject c=a.optJSONObject(i); if(c==null) continue;
                String name=c.optString("displayName",c.optString("name","")).trim();
                String key=normalizeFactText(name);
                if(!key.isEmpty() && (" "+normalized+" ").contains(" "+key+" ")) return c;
            }
        }catch(Exception ignored){}
        return null;
    }

    private static JSONObject rememberedPerson(SharedPreferences prefs){
        String name=prefs==null?"":prefs.getString("identity_last_fact_person","");
        if(name.isEmpty()) return null;
        return contactMentionedInText(prefs,normalizeFactText(name));
    }

    private static String contactDisplayName(JSONObject c){
        return c==null?"":c.optString("displayName",c.optString("name","")).trim();
    }

    private static void rememberFactContext(SharedPreferences prefs,String person,String topic){
        if(prefs==null) return;
        SharedPreferences.Editor e=prefs.edit().putString("identity_last_fact_topic",topic==null?"":topic)
                .putLong("identity_last_fact_at",System.currentTimeMillis());
        if(person!=null && !person.trim().isEmpty()) e.putString("identity_last_fact_person",person.trim());
        e.apply();
    }

    /** Code410: deterministic, privacy-bounded answers for facts already stored locally. */
    static String authoritativeConversationFact(SharedPreferences prefs,String raw){
        if(prefs==null) return null;
        String q=normalizeFactText(raw); if(q.isEmpty()) return null;
        boolean recognized=prefs.getBoolean("session_identity_verified",false) || strongAdminSessionActive(prefs);
        if(!recognized) return null;

        String owner=prefs.getString("session_identity_verified_name",
                prefs.getString("owner_call_name",prefs.getString("owner_name",""))).trim();
        if(owner.isEmpty()) owner=prefs.getString("owner_name","").trim();
        if(q.equals("who am i") || q.equals("who am i lumi") || q.equals("what is my name") || q.equals("whats my name") || q.equals("what s my name")){
            if(owner.isEmpty()) return null;
            rememberFactContext(prefs,owner,"owner-identity");
            return "You're "+owner+", my primary administrator.";
        }

        JSONObject spouse=contactByRelationship(prefs,"spouse");
        if(q.contains("who is my wife") || q.contains("who s my wife") || q.contains("whos my wife") || q.contains("what is my wife s name") || q.contains("whats my wife s name") || q.contains("who is my spouse") || q.contains("who s my spouse")){
            String n=contactDisplayName(spouse); if(n.isEmpty()) return null;
            rememberFactContext(prefs,n,"relationship");
            return "Your wife's name is "+n+".";
        }

        boolean contactQuestion=q.contains("contact card") || q.contains("card for") || q.contains("have a card");
        boolean whyMissing=q.contains("why don t you have") || q.contains("why dont you have") || q.contains("why do you not have");
        String lastTopic=prefs.getString("identity_last_fact_topic","");
        if(q.equals("what about me") && "contact-card".equals(lastTopic)) contactQuestion=true;
        if(contactQuestion || whyMissing){
            JSONObject target=contactMentionedInText(prefs,q);
            if(target==null && (q.contains(" her") || q.endsWith("her"))) target=rememberedPerson(prefs);
            if(target==null && (q.contains(" me") || q.endsWith("me") || q.equals("what about me"))){
                try{
                    JSONArray a=contactCardsForUi(prefs);
                    for(int i=0;i<a.length();i++){
                        JSONObject c=a.optJSONObject(i); if(c!=null && PRIMARY_CONTACT_ID.equals(c.optString("id"))){target=c;break;}
                    }
                }catch(Exception ignored){}
            }
            if(target==null && spouse!=null && (q.contains("janet") || ("relationship".equals(lastTopic) && !q.contains(" my ")))) target=spouse;
            if(target==null && q.equals("do you have a contact card")) target=rememberedPerson(prefs);
            if(target!=null){
                String n=contactDisplayName(target); if(n.isEmpty()) return null;
                rememberFactContext(prefs,n,"contact-card");
                String rel=target.optString("relationship","").trim();
                if(whyMissing) return "I do have a contact card for "+n+". It's stored locally in my people memory"+(rel.isEmpty()?"":" with the relationship "+rel)+".";
                return "Yes. I have a local contact card for "+n+(rel.isEmpty()?"":" ("+rel+")")+".";
            }
            int count=contactCardsForUi(prefs).length();
            rememberFactContext(prefs,"","contact-card");
            return "Yes. I currently have "+count+" local contact card"+(count==1?"":"s")+". Tell me whose card you mean.";
        }
        return null;
    }

    private static int nextContactNumber(JSONArray a){
        int max=1;
        for(int i=0;i<a.length();i++){
            JSONObject c=a.optJSONObject(i); if(c!=null) max=Math.max(max,c.optInt("contactNumber",0));
        }
        return max+1;
    }

    static String pendingPrivateReviewPrompt(SharedPreferences prefs){
        if(!prefs.getBoolean("identity_private_review_pending",false)) return null;
        if(!adminSessionActive(prefs)) return null;
        String n=prefs.getString("identity_private_review_name","that person");
        return "When we're alone, I still need to privately review "+n+" with you: trust level and permissions. Until then, they have no privileged access.";
    }

    static boolean updatePendingReview(SharedPreferences prefs,String relationship,String permission){
        String id=prefs.getString("identity_private_review_contact_id","");
        if(id.isEmpty() || !adminSessionActive(prefs)) return false;
        try{
            JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));
            for(int i=0;i<a.length();i++){
                JSONObject c=a.optJSONObject(i); if(c==null || !id.equals(c.optString("id"))) continue;
                if(relationship!=null && !relationship.trim().isEmpty()) c.put("relationship",relationship.trim());
                if(permission!=null && !permission.trim().isEmpty()){
                    String level=permission.trim().toUpperCase(Locale.US).replace(' ','_');
                    if(level.equals("ROOT") || level.equals("ADMIN") || level.equals("ROOT_ADMIN")) level="NONE";
                    c.put("permissionLevel",level);
                    c.put("privileged",!level.equals("NONE"));
                }
                if(!"UNREVIEWED".equals(c.optString("relationship")) && permission!=null){
                    c.put("state","CONFIRMED"); c.put("needsPrivateReview",false);
                    prefs.edit().putBoolean("identity_private_review_pending",false)
                            .remove("identity_private_review_contact_id").remove("identity_private_review_name").apply();
                }
                prefs.edit().putString("identity_contacts_json",a.toString()).apply();
                return true;
            }
        }catch(Exception ignored){}
        return false;
    }

    static String contactSummary(SharedPreferences prefs){
        ensurePrimaryAdminContact(prefs);
        try{
            JSONArray a=new JSONArray(prefs.getString("identity_contacts_json","[]"));
            int introduced=0,privileged=0;
            for(int i=0;i<a.length();i++){
                JSONObject c=a.optJSONObject(i); if(c==null)continue;
                if("INTRODUCED".equals(c.optString("state"))) introduced++;
                if(c.optBoolean("privileged",false) && !PRIMARY_CONTACT_ID.equals(c.optString("id"))) privileged++;
            }
            return "Identity hierarchy: Contact #001 is the sole root administrator; "+a.length()+" total contact card"+(a.length()==1?"":"s")+", "+introduced+" introduced awaiting review, "+privileged+" non-root privileged contacts.";
        }catch(Exception e){ return "Identity hierarchy is initialized with Contact #001 as the sole root administrator."; }
    }
}
