package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.Locale;

/** Code620 renderer actuator surface. 49 bounded live parameters, snapshot/commit/revert/publish. */
final class LumiRendererControl {
    static final String PREFIX="renderer_tune_";
    static final String REV="renderer_profile_revision";
    static final class Spec { final String n; final float d,min,max,step; Spec(String n,float d,float min,float max,float step){this.n=n;this.d=d;this.min=min;this.max=max;this.step=step;} }
    static final Spec[] SPECS=new Spec[]{
        new Spec("lowerHalf",1.28f,.45f,2.60f,.08f), new Spec("lowerShoulderY",.50f,-.30f,1.30f,.05f), new Spec("lowerTipY",-1.20f,-3.20f,-.20f,.08f),
        new Spec("upperOuterHalf",1.30f,.40f,2.60f,.08f), new Spec("upperOuterY",.59f,-.10f,1.50f,.04f),
        new Spec("innerUpperHalf",.66f,.18f,1.80f,.05f), new Spec("innerUpperY",.71f,.00f,1.80f,.04f),
        new Spec("innerLowerHalf",.59f,.15f,1.70f,.05f), new Spec("innerLowerY",.62f,-.05f,1.70f,.04f),
        new Spec("topBaseHalf",.49f,.12f,1.70f,.05f), new Spec("topBaseY",.82f,.00f,2.20f,.05f), new Spec("topTipY",1.59f,.35f,3.50f,.08f),
        new Spec("scaleX",.54f,.18f,1.60f,.03f), new Spec("scaleY",.54f,.18f,1.60f,.03f), new Spec("scaleZ",.54f,.18f,1.60f,.03f),
        new Spec("translateX",0f,-2.5f,2.5f,.04f), new Spec("translateY",0f,-2.5f,2.5f,.04f), new Spec("translateZ",0f,-2.5f,2.5f,.04f), new Spec("tiltBase",-8f,-40f,40f,1f),
        new Spec("fov",38f,18f,82f,1.5f), new Spec("eyeX",0f,-4f,4f,.10f), new Spec("eyeY",1.55f,-2f,5f,.10f), new Spec("eyeZ",7.65f,3f,16f,.18f),
        new Spec("targetX",0f,-3f,3f,.08f), new Spec("targetY",-.12f,-3f,3f,.08f), new Spec("targetZ",0f,-3f,3f,.08f),
        new Spec("yawSpeed",2.2f,0f,12f,.20f), new Spec("idleTiltAmp",2.0f,0f,18f,.50f), new Spec("activeTiltAmp",1.2f,0f,18f,.50f),
        new Spec("brightnessIdle",1.15f,.20f,2.5f,.05f), new Spec("brightnessListen",1.22f,.20f,2.5f,.05f), new Spec("brightnessThink",1.28f,.20f,2.5f,.05f), new Spec("brightnessSpeak",1.25f,.20f,2.5f,.05f),
        new Spec("glowStrength",1.05f,0f,3f,.08f), new Spec("rimStrength",1.00f,0f,3f,.08f), new Spec("metalLevel",1.15f,0f,2f,.06f), new Spec("glassAlpha",.88f,.15f,1f,.03f),
        new Spec("listenR",.030f,0f,1f,.03f),new Spec("listenG",.330f,0f,1f,.03f),new Spec("listenB",.095f,0f,1f,.03f),
        new Spec("thinkR",.620f,0f,1f,.03f),new Spec("thinkG",.035f,0f,1f,.03f),new Spec("thinkB",.080f,0f,1f,.03f),
        new Spec("speakR",.360f,0f,1f,.03f),new Spec("speakG",.070f,0f,1f,.03f),new Spec("speakB",.620f,0f,1f,.03f),
        new Spec("idleR",.050f,0f,1f,.03f),new Spec("idleG",.250f,0f,1f,.03f),new Spec("idleB",.105f,0f,1f,.03f)
    };
    private LumiRendererControl(){}
    static Spec spec(String n){ for(Spec s:SPECS)if(s.n.equals(n))return s; return null; }
    static float value(SharedPreferences p,String n,float fallback){ Spec s=spec(n); return p.getFloat(PREFIX+n,s==null?fallback:s.d); }
    static float clamp(Spec s,float v){ return Math.max(s.min,Math.min(s.max,v)); }
    static JSONObject apply(Context c,JSONObject values,String actor)throws Exception{
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE); SharedPreferences.Editor e=p.edit(); JSONObject accepted=new JSONObject();
        if(values!=null) for(Spec s:SPECS) if(values.has(s.n)){ float v=clamp(s,(float)values.optDouble(s.n,s.d)); e.putFloat(PREFIX+s.n,v); accepted.put(s.n,v); }
        long rev=p.getLong(REV,0L)+1L; e.putLong(REV,rev).putLong("renderer_profile_last_apply_at",System.currentTimeMillis()).putString("renderer_profile_last_actor",actor==null?"unknown":actor).putString("renderer_profile_candidate_json",snapshotWith(p,accepted).toString()).apply();
        return new JSONObject().put("ok",true).put("revision",rev).put("accepted",accepted).put("parameterCount",SPECS.length);
    }
    static void applyCode711AvatarSceneBaseline(Context c){
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        if(p.getBoolean("renderer_code711_scene_baseline_applied",false))return;
        SharedPreferences.Editor e=p.edit();
        for(Spec sp:SPECS)e.remove(PREFIX+sp.n);
        for(String k:new String[]{"renderer_profile_candidate_json","renderer_profile_committed_json","renderer_autotune_best_json","renderer_autotune_best_score","renderer_autotune_base_value","renderer_autotune_base_score"})e.remove(k);
        long rev=p.getLong(REV,0L)+1L;
        e.putLong(REV,rev)
         .putBoolean("renderer_code711_scene_baseline_applied",true)
         .putBoolean("renderer_autotune_enabled",false)
         .putString("renderer_autotune_state","CODE711_SCENE_FOUNDATION_LOCKED")
         .putString("renderer_visual_contract","MUTED_FOREST_AVATAR_SCENE_R421")
         .putString("renderer_visual_target","code711-avatar-scene-foundation")
         .putString("renderer_visual_authority","LUMI_CORE_VISUAL_SCENE")
         .putString("visual_core_renderer","avatar-scene-r421")
         .putString("visual_active_model","pyramid-model-r421")
         .putString("visual_palette_contract","MUTED_FOREST_ONLY_R421")
         .putBoolean("visual_legacy_red_contract_blocked",true)
         .putLong("renderer_profile_last_apply_at",System.currentTimeMillis())
         .putString("renderer_profile_last_actor","code711-avatar-scene-baseline").apply();
    }

    static void applyCode735VisibilityBaseline(Context c){
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        if(p.getBoolean("renderer_code735_visibility_baseline_applied",false))return;
        SharedPreferences.Editor e=p.edit();
        e.putFloat(PREFIX+"scaleX",.68f).putFloat(PREFIX+"scaleY",.68f).putFloat(PREFIX+"scaleZ",.68f)
         .putFloat(PREFIX+"fov",34f).putFloat(PREFIX+"eyeY",1.35f).putFloat(PREFIX+"eyeZ",6.75f).putFloat(PREFIX+"targetY",0f)
         .putFloat(PREFIX+"brightnessIdle",1.15f).putFloat(PREFIX+"brightnessListen",1.22f).putFloat(PREFIX+"brightnessThink",1.28f).putFloat(PREFIX+"brightnessSpeak",1.25f)
         .putFloat(PREFIX+"glowStrength",1.05f).putFloat(PREFIX+"rimStrength",1.00f).putFloat(PREFIX+"glassAlpha",.88f)
         .putFloat(PREFIX+"idleR",.060f).putFloat(PREFIX+"idleG",.260f).putFloat(PREFIX+"idleB",.130f)
         .putFloat(PREFIX+"listenR",.055f).putFloat(PREFIX+"listenG",.330f).putFloat(PREFIX+"listenB",.145f)
         .putFloat(PREFIX+"thinkR",.085f).putFloat(PREFIX+"thinkG",.285f).putFloat(PREFIX+"thinkB",.125f)
         .putFloat(PREFIX+"speakR",.070f).putFloat(PREFIX+"speakG",.380f).putFloat(PREFIX+"speakB",.190f)
         .putBoolean("renderer_code735_visibility_baseline_applied",true).putBoolean("renderer_autotune_enabled",false)
         .putString("renderer_autotune_state","RETIRED_BROKEN_REFERENCE_TUNER_R445").putString("renderer_visual_contract","MUTED_FOREST_VISIBLE_R445")
         .putString("renderer_profile_last_actor","code735-deterministic-visibility-baseline")
         .putLong(REV,p.getLong(REV,0L)+1L).putLong("renderer_profile_last_apply_at",System.currentTimeMillis()).apply();
    }

    static void applyCode736VisualFinalBaseline(Context c){
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        if(p.getBoolean("renderer_code736_visual_final_applied",false))return;
        SharedPreferences.Editor e=p.edit();
        e.putFloat(PREFIX+"idleR",.050f).putFloat(PREFIX+"idleG",.250f).putFloat(PREFIX+"idleB",.105f)
         .putFloat(PREFIX+"listenR",.030f).putFloat(PREFIX+"listenG",.330f).putFloat(PREFIX+"listenB",.095f)
         .putFloat(PREFIX+"thinkR",.620f).putFloat(PREFIX+"thinkG",.035f).putFloat(PREFIX+"thinkB",.080f)
         .putFloat(PREFIX+"speakR",.360f).putFloat(PREFIX+"speakG",.070f).putFloat(PREFIX+"speakB",.620f)
         .putFloat(PREFIX+"brightnessIdle",1.15f).putFloat(PREFIX+"brightnessListen",1.22f).putFloat(PREFIX+"brightnessThink",1.24f).putFloat(PREFIX+"brightnessSpeak",1.24f)
         .putBoolean("renderer_code736_visual_final_applied",true)
         .putBoolean("renderer_autotune_enabled",false)
         .putBoolean("visual_legacy_red_contract_blocked",false)
         .putString("renderer_autotune_state","VISUAL_FINALIZATION_LOCKED_R446")
         .putString("renderer_visual_contract","STATE_COLOR_FINAL_R446")
         .putString("visual_palette_contract","IDLE_FOREST_LISTEN_FOREST_THINK_CRIMSON_SPEAK_VIOLET_R446")
         .putString("visual_state_color_contract","R446_IDLE_FOREST_LISTEN_FOREST_THINK_CRIMSON_SPEAK_VIOLET")
         .putString("renderer_profile_last_actor","code736-visual-finalization")
         .putLong(REV,p.getLong(REV,0L)+1L)
         .putLong("renderer_profile_last_apply_at",System.currentTimeMillis()).apply();
    }

    static void applyApprovedCode629Baseline(Context c){
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        if(p.getBoolean("renderer_code711_scene_baseline_applied",false)||p.getBoolean("renderer_code629_owner_baseline_applied",false))return;
        SharedPreferences.Editor e=p.edit();
        for(Spec s:SPECS)e.remove(PREFIX+s.n);
        long rev=p.getLong(REV,0L)+1L;
        e.putLong(REV,rev).putBoolean("renderer_code629_owner_baseline_applied",true)
         .putString("renderer_profile_last_actor","code629-owner-approved-baseline")
         .putLong("renderer_profile_last_apply_at",System.currentTimeMillis()).apply();
    }
    static void enableCode630VisualAutonomy(Context c){SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE);p.edit().putBoolean("renderer_code630_visual_autonomy_applied",true).putBoolean("renderer_autotune_enabled",false).putString("renderer_autotune_state","RETIRED_CORE_AUTHORITY_R436").putString("renderer_visual_authority","LUMI_CORE_ONLY").apply();}
    static JSONObject snapshot(SharedPreferences p)throws Exception{ JSONObject o=new JSONObject(); for(Spec s:SPECS)o.put(s.n,value(p,s.n,s.d)); return o; }
    private static JSONObject snapshotWith(SharedPreferences p,JSONObject overrides)throws Exception{ JSONObject o=snapshot(p); if(overrides!=null){java.util.Iterator<String>it=overrides.keys();while(it.hasNext()){String k=it.next();o.put(k,overrides.get(k));}} return o; }
    static JSONObject commit(Context c,String reason)throws Exception{ SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE); JSONObject o=snapshot(p); p.edit().putString("renderer_profile_committed_json",o.toString()).putLong("renderer_profile_committed_at",System.currentTimeMillis()).putString("renderer_profile_commit_reason",reason==null?"":reason).apply(); return o; }
    static JSONObject revert(Context c)throws Exception{ SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE); String raw=p.getString("renderer_profile_committed_json",""); JSONObject v=raw.isEmpty()?new JSONObject():new JSONObject(raw); if(raw.isEmpty())for(Spec s:SPECS)v.put(s.n,s.d); return apply(c,v,"rollback"); }
    static JSONArray capabilityMap()throws Exception{ JSONArray a=new JSONArray(); for(Spec s:SPECS)a.put(new JSONObject().put("name",s.n).put("default",s.d).put("min",s.min).put("max",s.max).put("step",s.step)); return a; }
    static JSONObject publish(Context c,String reason,float score)throws Exception{
        SharedPreferences p=c.getSharedPreferences("lumi",Context.MODE_PRIVATE); JSONObject profile=snapshot(p);
        JSONObject out=new JSONObject().put("format","LumiRendererProfile").put("formatVersion",1).put("rendererBaseline","code623-isolated-reference-r341").put("versionCode",623).put("profile",profile).put("score",score).put("reason",reason==null?"":reason).put("publishedAt",System.currentTimeMillis());
        if(TrustedBuildRelayClient.developerChannelConfigured(p)){
            String text=out.toString(2)+"\n";
            TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/renderer/profiles/code623-best.json",text,"Publish Lumi Code623 renderer best profile");
            TrustedBuildRelayClient.writeDeveloperFile(p,".lumi/renderer/profiles/latest.json",text,"Update Lumi renderer latest profile");
            p.edit().putBoolean("renderer_profile_publish_ok",true).putFloat("renderer_profile_published_score",score).putLong("renderer_profile_published_at",System.currentTimeMillis()).apply();
            out.put("published",true);
        }else{ p.edit().putBoolean("renderer_profile_publish_ok",false).putString("renderer_profile_publish_error","RELAY_NOT_CONFIGURED").apply(); out.put("published",false); }
        return out;
    }
}
