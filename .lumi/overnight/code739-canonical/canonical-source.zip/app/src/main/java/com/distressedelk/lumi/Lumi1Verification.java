package com.distressedelk.lumi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.speech.SpeechRecognizer;
import org.json.JSONArray;
import org.json.JSONObject;

final class Lumi1Verification {
    private Lumi1Verification(){}
    static int currentVersionCode(Context c){
        try{ return c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionCode; }
        catch(Throwable t){ return -1; }
    }
    static String report(Context c, SharedPreferences p){
        StringBuilder out=new StringBuilder("LUMI 1.0 PRE-RELEASE VERIFICATION • Code"+currentVersionCode(c)+"\n");
        try{
            JSONObject reg=LumiSystemRegistry.current(c); JSONArray systems=reg.optJSONArray("systems");
            if(systems!=null){
                for(int i=0;i<systems.length();i++){
                    JSONObject x=systems.optJSONObject(i); if(x==null)continue;
                    out.append(x.optString("id","unknown")).append(" • ").append(x.optString("verification","READY_FOR_VERIFICATION"));
                    String h=x.optString("health",""); if(!h.isEmpty())out.append(" • runtime=").append(h); out.append('\n');
                }
            }
        }catch(Throwable t){out.append("system.registry • READY_FOR_VERIFICATION • registry read pending\n");}
        boolean local=false; try{local=Build.VERSION.SDK_INT>=31&&SpeechRecognizer.isOnDeviceRecognitionAvailable(c);}catch(Throwable ignored){}
        out.append("speech.local-first • ").append(local?"READY_FOR_VERIFICATION":"BLOCKED • Android on-device recognizer unavailable").append('\n');
        out.append("speech.failover • READY_FOR_VERIFICATION • 2 local failures -> system fallback; local return only after 3 successful silent on-device shadow recognitions\n");
        out.append("speech.dual-failure • READY_FOR_VERIFICATION • quiet degraded mode / explicit retry only\n");
        out.append("conversation.endurance • READY_FOR_VERIFICATION • target=30 spoken replies / >=10min\n");
        out.append("barge-in • READY_FOR_VERIFICATION\n");
        out.append("fast-brain.quality • READY_FOR_VERIFICATION • malformed/repetitive output rejected to fallback\n");
        out.append("identity.production • READY_FOR_VERIFICATION • developer bypass default=false\n");
        out.append("memory.persistence • READY_FOR_VERIFICATION\n");
        out.append("visual.baseline • READY_FOR_VERIFICATION • reference=lumi_3d_reference_r257_approved_compression • wireframe=false • yaw=1.6deg/s\n");
        boolean localCandidate=p.getBoolean("natural_voice_local_candidate_available",false);
        boolean localTts=!p.getBoolean("natural_voice_network_required",true) && localCandidate;
        String localVoice=p.getString("natural_voice_selected","unknown");
        out.append("offline.core • ").append(local&&localTts?"READY_FOR_VERIFICATION":"BLOCKED • localSTT="+local+" localTTS="+localTts+" voice="+localVoice+" localCandidate="+localCandidate).append('\n');
        out.append("routing.search • READY_FOR_VERIFICATION\n");
        out.append("tts.aurora • READY_FOR_VERIFICATION\n");
        out.append("update.recovery • READY_FOR_VERIFICATION\n");
        out.append("resource.endurance • READY_FOR_VERIFICATION • target=30min no LOW_MEMORY exit\n");
        out.append("release.stage • READY_FOR_VERIFICATION");
        return out.toString();
    }
}
