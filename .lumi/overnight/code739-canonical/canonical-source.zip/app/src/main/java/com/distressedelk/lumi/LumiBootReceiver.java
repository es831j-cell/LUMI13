package com.distressedelk.lumi;

import android.content.*;
import android.os.Build;

/** Starts Lumi continuity after boot and finalizes native self-updates after package replacement. */
public class LumiBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        String action=intent==null?"":intent.getAction();
        boolean boot=Intent.ACTION_BOOT_COMPLETED.equals(action);
        boolean replaced=Intent.ACTION_MY_PACKAGE_REPLACED.equals(action);
        if(!boot && !replaced) return;
        android.content.SharedPreferences p=context.getSharedPreferences("lumi",Context.MODE_PRIVATE);
        RuntimePolicy.applyStartupPolicy(context,p);
        MaintenanceFoundation.initialize(context,p);
        LumiSelfUpdateEngine.initialize(context,p);
        if(replaced) {
            // Code705: capture transaction ownership before onPackageReplaced() consumes/clears state.
            boolean activeLumiUpdate=p.getLong("self_update_install_requested_target",-1L)>0L
                    || p.getLong("self_update_install_requested_at",0L)>0L
                    || p.getBoolean("trusted_core_build_active",false);
            LumiSelfUpdateEngine.onPackageReplaced(context,p);
            DeviceHealthEngine.Snapshot post=DeviceHealthEngine.capture(context,p,false);
            boolean validationPass=p.getBoolean("self_update_last_validation_pass",false);
            if(activeLumiUpdate){
                DeviceHealthEngine.notePostInstallValidation(context,p,post.version,validationPass,p.getString("self_update_last_validation_detail",validationPass?"existing post-install validation passed":"existing post-install validation did not pass"));
            }else{
                DeviceHealthEngine.noteBootstrapInstallObserved(context,p,post.version);
            }
            if(p.getBoolean("code407_overnight_updates_enabled",false) && p.getBoolean("code407_installer_overnight",false)){
                p.edit().putBoolean("code407_overnight_update_in_progress",false).putBoolean("code407_maintenance_report_pending",true)
                        .putString("code407_last_maintenance_result",validationPass?"Update installed and validated; checking for the next sequential update.":"Update installed but post-install validation needs attention.").apply();
                if(validationPass)AutonomousMaintenanceJobService.scheduleSoon(context,p,15000L,"post-install-chain");
            }
        }
        if(p.getBoolean("trusted_core_build_active",false)) TrustedBuildRelayJobService.schedule(context,3000L);
        GitHubUpdateCheckJobService.schedulePeriodic(context);
        if(replaced){
            // Package replacement must finalize the existing transaction before any new discovery.
            GitHubUpdateCheckJobService.cancelOneShot(context);
        } else {
            GitHubUpdateCheckJobService.scheduleNow(context,7000L);
        }
        if(boot || replaced){
            Intent core=new Intent(context,LumiCoreService.class);
            try{
                if(Build.VERSION.SDK_INT>=26)context.startForegroundService(core); else context.startService(core);
                p.edit().putBoolean("code449_boot_continuity_start_ok",true)
                        .putLong("code449_boot_continuity_start_at",System.currentTimeMillis()).remove("code449_boot_continuity_start_error").apply();
            }catch(Exception e){
                p.edit().putBoolean("code449_boot_continuity_start_ok",false)
                        .putString("code449_boot_continuity_start_error",e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage())).apply();
            }
        }
    }
}
