package com.distressedelk.lumi

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ResultReceiver
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Code404 main-process proxy. Native cancellation happens by terminating only :fastbrain. */
object LocalBrain {
    interface Callback{fun onReply(text:String,tokensPerSecond:Double);fun onError(message:String)}
    private const val WARM="com.distressedelk.lumi.fastbrain.WARM"
    private const val ASK="com.distressedelk.lumi.fastbrain.ASK"
    private const val PROBE="com.distressedelk.lumi.fastbrain.PROBE"
    private const val RESET="com.distressedelk.lumi.fastbrain.RESET"
    private const val CANCEL="com.distressedelk.lumi.fastbrain.CANCEL"
    private const val OK=1;private const val ERROR=2;private const val WARMED=3;private const val RESET_OK=4;private const val STAGE=5
    private const val REQUEST_TIMEOUT=9000L;private const val PROBE_TIMEOUT=10000L;private const val HARD=30000L
    private const val COLD=45000L;private const val WARM_TIMEOUT=45000L;private const val CONTROL=3000L;private const val RESET_SETTLE=1500L
    private const val IDLE_UNLOAD=2*60*1000L

    @Volatile private var ctx:Context?=null
    @Volatile private var loaded=false
    @Volatile private var busy=false
    @Volatile private var startedAt=0L
    @Volatile private var stage="idle"
    @Volatile private var stageAt=0L
    @Volatile private var completedId=-1L
    @Volatile private var completedAction=""
    @Volatile private var completedAt=0L
    @Volatile private var completedText=""
    @Volatile private var completedTps=0.0
    @Volatile private var generation=-1L
    @Volatile private var workerPid=-1
    @Volatile private var cancelReason=""
    @Volatile private var cancelAt=0L
    @Volatile private var cancels=0L
    @Volatile private var normalInferenceAt=0L
    @Volatile private var rawChars=0
    @Volatile private var sanitizedChars=0
    @Volatile private var hadThinkOpen=false
    @Volatile private var hadThinkClose=false
    @Volatile private var thinkOnly=false
    @Volatile private var cancellationSettlingUntil=0L
    private val rejected=AtomicLong(0L)
    private val main=Handler(Looper.getMainLooper())
    private val active=ConcurrentHashMap<Long,Boolean>()
    // Code716: retain request callbacks until terminal evidence so a genuine worker death
    // reports back to Lumi Core instead of silently stranding a repair transaction.
    private val callbacks=ConcurrentHashMap<Long,Callback>()
    private val stages=ConcurrentHashMap<Long,String>()
    private val actions=ConcurrentHashMap<Long,String>()
    private val serial=AtomicLong(0L)

    @JvmStatic fun initialize(context:Context){ctx=context.applicationContext}
    @JvmStatic fun isLoaded()=loaded
    @JvmStatic fun isBusy()=busy
    @JvmStatic fun activeGenerationId()=generation
    @JvmStatic fun workerPid()=workerPid
    @JvmStatic fun lastCancelReason()=cancelReason
    @JvmStatic fun lastCancelAt()=cancelAt
    @JvmStatic fun cancelCount()=cancels
    @JvmStatic fun lastNormalInferenceAt()=normalInferenceAt
    @JvmStatic fun lastRawChars()=rawChars
    @JvmStatic fun lastSanitizedChars()=sanitizedChars
    @JvmStatic fun lastHadThinkOpen()=hadThinkOpen
    @JvmStatic fun lastHadThinkClose()=hadThinkClose
    @JvmStatic fun lastThinkOnly()=thinkOnly
    @JvmStatic fun isCancellationSettling()=System.currentTimeMillis()<cancellationSettlingUntil
    @JvmStatic fun lastRequestAgeMs()=if(!busy||startedAt<=0)0L else System.currentTimeMillis()-startedAt
    @JvmStatic fun rejectedRequestCount()=rejected.get()
    @JvmStatic fun workerStage()=stage
    @JvmStatic fun workerStageAgeMs()=if(stageAt<=0)0L else System.currentTimeMillis()-stageAt
    @JvmStatic fun lastCompletedRequestId()=completedId
    @JvmStatic fun lastCompletedAction()=completedAction
    @JvmStatic fun lastCompletedAt()=completedAt
    @JvmStatic fun lastCompletedText()=completedText
    @JvmStatic fun lastCompletedTps()=completedTps
    @JvmStatic fun isResponsive()=loaded&&!busy&&!isCancellationSettling()&&(stage=="generation-complete"||stage=="late-generation-complete"||stage=="probe-complete"||stage=="late-probe-complete"||stage=="model-ready"||stage=="warm-complete")

    // CODE502 R220 FAST_BRAIN_REARM: the native worker completed successfully before the visible
    // quality gate rejected its text. Restore the completed lifecycle state after that semantic
    // rejection so the next turn can use the same loaded worker. Never mask real busy/cancel/error state.
    @JvmStatic fun rearmAfterQualityRejection():Boolean{
        if(stage!="quality-rejected" || !loaded || busy || isCancellationSettling()) return isResponsive()
        rec("generation-complete")
        return true
    }

    @JvmStatic fun warm(path:String,context:Int,threads:Int)=warm0(path,context,threads,null)
    @JvmStatic fun warmForRecovery(path:String,context:Int,threads:Int,cb:Callback)=warm0(path,context,threads,cb)
    private fun warm0(path:String,context:Int,threads:Int,cb:Callback?){
        val c=ctx;if(c==null){cb?.onError("Fast Brain worker is not initialized");return}
        if(busy){cb?.onError("Fast Brain worker already owns a generation");return}
        val id=serial.incrementAndGet();activate(id,WARM,"warm-dispatched",false);if(cb!=null)callbacks[id]=cb
        val rr=object:ResultReceiver(main){override fun onReceiveResult(code:Int,data:Bundle?){
            pid(data);if(code==STAGE){note(id,data?.getString("status")?:"worker-stage");return}
            if(active.remove(id)==null)return;callbacks.remove(id);clean(id)
            if(code==WARMED||code==OK){loaded=true;complete(id,WARM,"LOADED",0.0,"model-ready");cb?.onReply("LOADED",0.0)}
            else{loaded=false;rec("warm-error");cb?.onError(data?.getString("error")?:"Fast Brain warm failed")}
        }}
        try{start(c,WARM,id,path,context,threads,"","",0,true,rr)}catch(t:Throwable){active.remove(id);callbacks.remove(id);clean(id);loaded=false;rec("warm-start-error");cb?.onError(t.message?:t.javaClass.simpleName);return}
        main.postDelayed({if(active.remove(id)!=null){callbacks.remove(id);clean(id);loaded=false;rec("warm-timeout");cb?.onError("Fast Brain model did not finish loading")}},WARM_TIMEOUT)
    }

    @JvmStatic fun probe(path:String,context:Int,threads:Int,cb:Callback)=dispatch(PROBE,path,context,threads,"","",8,true,cb)
    @JvmStatic fun askRaw(path:String,context:Int,threads:Int,prompt:String,system:String,max:Int,cb:Callback)=dispatch(ASK,path,context,threads,prompt,system,max,false,cb)
    @JvmStatic fun ask(path:String,context:Int,threads:Int,prompt:String,system:String,max:Int,cb:Callback)=dispatch(ASK,path,context,threads,prompt,system,max,true,cb)

    @JvmStatic fun cancelActiveGeneration(reason:String){
        val c=ctx?:return
        val now=System.currentTimeMillis()
        cancelReason=reason;cancelAt=now;cancels++;cancellationSettlingUntil=now+700L
        failActiveCallbacks("Fast Brain generation cancelled: $reason")
        loaded=false;busy=false;generation=-1L;active.clear();stages.clear();actions.clear();startedAt=0L;rec("cancel-requested")
        val id=serial.incrementAndGet();val done=AtomicBoolean(false)
        val rr=object:ResultReceiver(main){override fun onReceiveResult(code:Int,data:Bundle?){
            pid(data);if(code==STAGE){rec(data?.getString("status")?:"cancel-stage");return}
            if(done.compareAndSet(false,true))rec("cancel-acknowledged")
        }}
        try{start(c,CANCEL,id,"",0,0,reason,"",0,true,rr)}catch(_:Throwable){rec("cancel-start-error")}
        main.postDelayed({
            if(done.compareAndSet(false,true))rec("cancel-settled")
            loaded=false;busy=false;generation=-1L;active.clear();stages.clear();actions.clear();startedAt=0L;cancellationSettlingUntil=0L
        },700L)
    }

    @JvmStatic fun reconcileProcessDeath(reason:String){
        failActiveCallbacks("Fast Brain worker process exited: $reason")
        loaded=false;busy=false;generation=-1L;active.clear();stages.clear();actions.clear();startedAt=0L;workerPid=-1;cancellationSettlingUntil=0L;rec("process-death-"+reason.replace(Regex("[^A-Za-z0-9_-]"),"_").take(50))
    }

    @JvmStatic fun restartWorker(cb:Callback){
        val c=ctx;if(c==null){cb.onError("Fast Brain worker is not initialized");return}
        failActiveCallbacks("Fast Brain worker restarted for recovery")
        loaded=false;busy=false;generation=-1L;active.clear();stages.clear();actions.clear();startedAt=0L;rec("reset-requested")
        val id=serial.incrementAndGet();val done=AtomicBoolean(false)
        val rr=object:ResultReceiver(main){override fun onReceiveResult(code:Int,data:Bundle?){
            pid(data);if(code==STAGE){rec(data?.getString("status")?:"reset-stage");return}
            if(code!=RESET_OK&&code!=OK){if(done.compareAndSet(false,true)){rec("reset-error");cb.onError(data?.getString("error")?:"Fast Brain reset failed")};return}
            if(!done.compareAndSet(false,true))return
            rec("reset-acknowledged");main.postDelayed({rec("reset-settled");cb.onReply("RESET_SETTLED",0.0)},RESET_SETTLE)
        }}
        try{start(c,RESET,id,"",0,0,"","",0,true,rr)}catch(t:Throwable){if(done.compareAndSet(false,true))cb.onError(t.message?:t.javaClass.simpleName);return}
        main.postDelayed({if(done.compareAndSet(false,true))cb.onError("Fast Brain reset did not acknowledge")},CONTROL)
    }

    private fun scheduleIdleUnloadTruth(at:Long){
        main.postDelayed({if(!busy && normalInferenceAt==at && System.currentTimeMillis()-at>=IDLE_UNLOAD) loaded=false},IDLE_UNLOAD)
    }

    private fun captureOutputMeta(data:Bundle?){
        rawChars=data?.getInt("rawChars",0)?:0
        sanitizedChars=data?.getInt("sanitizedChars",0)?:0
        hadThinkOpen=data?.getBoolean("hadThinkOpen",false)?:false
        hadThinkClose=data?.getBoolean("hadThinkClose",false)?:false
        thinkOnly=data?.getBoolean("thinkOnly",false)?:false
    }

    private fun dispatch(action:String,path:String,context:Int,threads:Int,prompt:String,system:String,max:Int,sanitize:Boolean,cb:Callback){
        val c=ctx;if(c==null){rejected.incrementAndGet();cb.onError("Fast Brain worker is not initialized");return}
        if(isCancellationSettling()){rejected.incrementAndGet();cb.onError("Fast Brain cancellation settling");return}
        if(generation>0||busy){rejected.incrementAndGet();cb.onError("Fast Brain generation already active id=$generation");return}
        val id=serial.incrementAndGet();activate(id,action,if(action==PROBE)"probe-dispatched" else "request-dispatched",true);callbacks[id]=cb
        val rr=object:ResultReceiver(main){override fun onReceiveResult(code:Int,data:Bundle?){
            pid(data);if(code==STAGE){note(id,data?.getString("status")?:"worker-stage");return}
            if(active.remove(id)==null){
                callbacks.remove(id)
                if(code==OK){captureOutputMeta(data);val text=data?.getString("text").orEmpty();val tps=data?.getDouble("tps",0.0)?:0.0;complete(id,action,text,tps,if(action==PROBE)"late-probe-complete" else "late-generation-complete");if(action==ASK&&text.isNotBlank())normalInferenceAt=System.currentTimeMillis()}
                return
            }
            callbacks.remove(id);clean(id)
            if(code==OK){loaded=true;captureOutputMeta(data);val text=data?.getString("text").orEmpty();val tps=data?.getDouble("tps",0.0)?:0.0;complete(id,action,text,tps,if(action==PROBE)"probe-complete" else "generation-complete");
                if(action==ASK&&!usableVisibleReply(text)){rejected.incrementAndGet();rec("quality-rejected");cb.onError("Fast Brain output failed visible quality gate")}
                else{if(action==ASK&&text.isNotBlank()){normalInferenceAt=System.currentTimeMillis();scheduleIdleUnloadTruth(normalInferenceAt)};cb.onReply(text,tps)}}
            else{loaded=false;rec("worker-error");cb.onError(data?.getString("error")?:"Fast Brain worker failed")}
        }}
        try{start(c,action,id,path,context,threads,prompt,system,max,sanitize,rr)}catch(t:Throwable){active.remove(id);callbacks.remove(id);clean(id);loaded=false;cb.onError(t.message?:t.javaClass.simpleName);return}
        val timeout=if(action==PROBE)PROBE_TIMEOUT else if(!loaded)COLD else REQUEST_TIMEOUT
        main.postDelayed({
            if(!active.containsKey(id))return@postDelayed
            val st=stages[id]?:"unknown"
            if(st.contains("generation-start")||st.contains("generation-slow")){
                note(id,"generation-slow-wait")
                main.postDelayed({if(active.remove(id)!=null){callbacks.remove(id);clean(id);loaded=false;rec("request-hard-timeout");cancelActiveGeneration("hard-timeout id=$id stage=$st");cb.onError("Fast Brain generation exceeded hard timeout; native worker cancelled")}},(HARD-timeout).coerceAtLeast(1L))
            }else if(active.remove(id)!=null){callbacks.remove(id);clean(id);loaded=false;cancelActiveGeneration("timeout id=$id stage=$st");cb.onError("Fast Brain worker timeout; native worker cancelled")}
        },timeout)
    }

    private fun failActiveCallbacks(message:String){
        val pending=callbacks.entries.toList();callbacks.clear()
        if(pending.isEmpty())return
        for(entry in pending){
            if(active.remove(entry.key)!=null){
                try{main.post{try{entry.value.onError(message)}catch(_:Throwable){}}}catch(_:Throwable){}
            }
        }
    }
    private fun activate(id:Long,a:String,s:String,gen:Boolean){active[id]=true;actions[id]=a;stages[id]=s;busy=true;if(gen)generation=id;startedAt=System.currentTimeMillis();rec(s)}
    private fun note(id:Long,s:String){if(active.containsKey(id))stages[id]=s;rec(s)}
    private fun clean(id:Long){stages.remove(id);actions.remove(id);if(generation==id)generation=-1L;busy=active.isNotEmpty();if(!busy)startedAt=0L}
    private fun complete(id:Long,a:String,text:String,tps:Double,s:String){completedId=id;completedAction=a;completedAt=System.currentTimeMillis();completedText=text;completedTps=tps;rec(s)}
    private fun rec(s:String){stage=s;stageAt=System.currentTimeMillis()}
    private fun pid(data:Bundle?){val x=data?.getInt("workerPid",-1)?:-1;if(x>0)workerPid=x}
    private fun start(c:Context,a:String,id:Long,path:String,context:Int,threads:Int,prompt:String,system:String,max:Int,sanitize:Boolean,rr:ResultReceiver){
        c.startService(Intent(c,FastBrainProcessService::class.java).setAction(a).putExtra("requestId",id).putExtra("modelPath",path)
            .putExtra("contextSize",context).putExtra("threads",threads).putExtra("prompt",prompt).putExtra("systemPrompt",system)
            .putExtra("maxTokens",max).putExtra("sanitize",sanitize).putExtra("receiver",rr))
    }

    @JvmStatic fun usableVisibleReply(raw:String?):Boolean{
        val s=sanitizeVisibleReply(raw).replace(Regex("\\s+")," ").trim()
        if(s.length<2)return false
        val low=s.lowercase()
        if(low=="ready" || low=="error" || low=="null")return false
        val words=low.split(" ").filter{it.isNotBlank()}
        if(words.size>=8 && words.toSet().size<=2)return false
        if(low.matches(Regex("(?:hey! ?good to meet you[.! ]*){2,}")))return false
        return true
    }

    @JvmStatic fun sanitizeVisibleReply(raw:String?):String{
        if(raw==null)return ""
        var out=raw.replace("\u0000","").trim()
        out=out.replace(Regex("<think\\b[^>]*>.*?</think\\s*>",setOf(RegexOption.IGNORE_CASE,RegexOption.DOT_MATCHES_ALL)),"").trim()
        val close=out.lowercase().lastIndexOf("</think>");if(close>=0)out=out.substring(close+8).trim()
        out=out.replace(Regex("<think\\b[^>]*>.*$",setOf(RegexOption.IGNORE_CASE,RegexOption.DOT_MATCHES_ALL)),"").trim()
        out=out.replace(Regex("\\s*/(?:no_?think|no_?talent|think)\\b",RegexOption.IGNORE_CASE),"").trim()
        return out
    }
}
