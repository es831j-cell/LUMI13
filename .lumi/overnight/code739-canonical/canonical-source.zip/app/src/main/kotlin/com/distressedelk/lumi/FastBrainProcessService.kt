package com.distressedelk.lumi

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Process
import android.os.ResultReceiver
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.atomic.AtomicBoolean

/** Code404: one native generation owns the isolated Fast Brain process at a time. */
class FastBrainProcessService : Service() {
    private val resetAction="com.distressedelk.lumi.fastbrain.RESET"
    private val cancelAction="com.distressedelk.lumi.fastbrain.CANCEL"
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
    private val commands=Channel<Command>(capacity=1)
    private val generationOwned=AtomicBoolean(false)
    @Volatile private var workerStarted=false
    @Volatile private var activePath:String?=null
    @Volatile private var activeRequestId=-1L
    private val idleUnloadMs=5*60*1000L

    private data class Command(val requestId:Long,val action:String,val path:String,val contextSize:Int,val threads:Int,
        val prompt:String,val system:String,val maxTokens:Int,val sanitize:Boolean,val receiver:ResultReceiver)

    override fun onLowMemory(){
        super.onLowMemory()
        if(!generationOwned.get() && activeRequestId<0L){
            workerStarted=false
            activePath=null
            stopSelf()
            Handler(Looper.getMainLooper()).postDelayed({try{Process.killProcess(Process.myPid())}catch(_:Throwable){}},120L)
        }
    }

    override fun onTrimMemory(level:Int){
        super.onTrimMemory(level)
        if(level>=android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW && !generationOwned.get() && activeRequestId<0L){
            workerStarted=false
            activePath=null
            stopSelf()
            Handler(Looper.getMainLooper()).postDelayed({try{Process.killProcess(Process.myPid())}catch(_:Throwable){}},120L)
        }
    }

    override fun onBind(intent:Intent?):IBinder?=null

    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        if(intent==null)return START_NOT_STICKY
        val rr=receiver(intent)?:return START_NOT_STICKY
        val id=intent.getLongExtra("requestId",-1L)
        if(intent.action==resetAction||intent.action==cancelAction){
            val kind=if(intent.action==cancelAction)"cancel" else "reset"
            stage(rr,id,"$kind-command-received")
            try{rr.send(4,Bundle().apply{putLong("requestId",id);putInt("workerPid",Process.myPid());putString("status","$kind-ack")})}catch(_:Throwable){}
            stopSelf(startId)
            Handler(Looper.getMainLooper()).postDelayed({try{Process.killProcess(Process.myPid())}catch(_:Throwable){}},80L)
            return START_NOT_STICKY
        }
        val c=Command(id,intent.action.orEmpty(),intent.getStringExtra("modelPath").orEmpty(),
            intent.getIntExtra("contextSize",512),intent.getIntExtra("threads",4),
            intent.getStringExtra("prompt").orEmpty(),intent.getStringExtra("systemPrompt").orEmpty(),
            intent.getIntExtra("maxTokens",32),intent.getBooleanExtra("sanitize",true),rr)
        val generation=c.action.endsWith(".ASK")||c.action.endsWith(".PROBE")
        if(generation&&!generationOwned.compareAndSet(false,true)){
            error(rr,id,"Fast Brain generation already owns native worker");return START_NOT_STICKY
        }
        activeRequestId=id
        stage(rr,id,"command-accepted")
        ensureWorker(c.path,c.contextSize,c.threads,rr,id)
        if(commands.trySend(c).isFailure){
            if(generation)generationOwned.set(false)
            error(rr,id,"Fast Brain worker queue is full")
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun receiver(i:Intent):ResultReceiver?=i.getParcelableExtra("receiver")

    @Synchronized private fun ensureWorker(path:String,contextSize:Int,threads:Int,rr:ResultReceiver,id:Long){
        if(workerStarted&&activePath==path){stage(rr,id,"model-already-active");return}
        if(workerStarted){stage(rr,id,"worker-already-started");return}
        workerStarted=true;activePath=path
        scope.launch{
            try{
                stage(rr,id,"model-load-start")
                val model=Llama.loadModel(path,LlamaConfig(contextSize=contextSize,threads=threads))
                stage(rr,id,"model-load-complete")
                while(true){
                    val c=withTimeoutOrNull(idleUnloadMs){commands.receive()}
                    if(c==null){
                        if(!generationOwned.get() && activeRequestId<0){
                            stage(rr,id,"model-idle-unload")
                            break
                        }
                        continue
                    }
                    activeRequestId=c.requestId
                    try{
                        when(c.action){
                            "com.distressedelk.lumi.fastbrain.WARM"->c.receiver.send(3,Bundle().apply{
                                putLong("requestId",c.requestId);putInt("workerPid",Process.myPid());putString("status","loaded");putString("workerStage","warm-complete")})
                            "com.distressedelk.lumi.fastbrain.ASK"->{
                                stage(c.receiver,c.requestId,"generation-start")
                                val prompt=if(c.prompt.contains("/no_think",true))c.prompt else c.prompt+"\n/no_think"
                                val sys=c.system+" Reply directly. Do not emit hidden reasoning or <think> tags."
                                val r=Llama.complete(model,prompt,sys,c.maxTokens.coerceIn(4,128))
                                val raw=r.text?.replace("\u0000","")?.trim().orEmpty()
                                val text=if(c.sanitize)LocalBrain.sanitizeVisibleReply(raw) else raw
                                val low=raw.lowercase()
                                val thinkOpen=low.contains("<think")
                                val thinkClose=low.contains("</think>")
                                c.receiver.send(1,Bundle().apply{putLong("requestId",c.requestId);putInt("workerPid",Process.myPid())
                                    putString("workerStage","generation-complete");putString("text",text);putDouble("tps",r.tokensPerSecond.toDouble())
                                    putInt("rawChars",raw.length);putInt("sanitizedChars",text.length);putBoolean("hadThinkOpen",thinkOpen);putBoolean("hadThinkClose",thinkClose);putBoolean("thinkOnly",raw.isNotEmpty()&&text.isEmpty()&&thinkOpen)})
                            }
                            "com.distressedelk.lumi.fastbrain.PROBE"->{
                                stage(c.receiver,c.requestId,"probe-generation-start")
                                val r=Llama.complete(model,"READY? /no_think","Reply with exactly READY. No reasoning. No explanation.",8)
                                c.receiver.send(1,Bundle().apply{putLong("requestId",c.requestId);putInt("workerPid",Process.myPid())
                                    putString("workerStage","probe-generation-complete");putString("text",LocalBrain.sanitizeVisibleReply(r.text));putDouble("tps",r.tokensPerSecond.toDouble())})
                            }
                            else->error(c.receiver,c.requestId,"Unknown Fast Brain action")
                        }
                    }catch(t:Throwable){error(c.receiver,c.requestId,t.message?:t.javaClass.simpleName)}
                    finally{if(c.action.endsWith(".ASK")||c.action.endsWith(".PROBE"))generationOwned.set(false);activeRequestId=-1L}
                }
                Llama.releaseModel(model)
                stopSelf()
            }catch(t:Throwable){
                stage(rr,id,"model-load-error")
                while(true){val c=commands.tryReceive().getOrNull()?:break;generationOwned.set(false);error(c.receiver,c.requestId,t.message?:t.javaClass.simpleName)}
            }finally{generationOwned.set(false);activeRequestId=-1L;workerStarted=false;activePath=null}
        }
    }
    private fun stage(rr:ResultReceiver,id:Long,s:String){try{rr.send(5,Bundle().apply{putLong("requestId",id);putInt("workerPid",Process.myPid());putLong("activeRequestId",activeRequestId);putString("status",s)})}catch(_:Throwable){}}
    private fun error(rr:ResultReceiver,id:Long,s:String){try{rr.send(2,Bundle().apply{putLong("requestId",id);putInt("workerPid",Process.myPid());putString("error",s)})}catch(_:Throwable){}}
}
