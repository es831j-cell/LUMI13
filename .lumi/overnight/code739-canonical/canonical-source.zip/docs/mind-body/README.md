# Lumi runtime architecture

Code623 retires the unused MindBodyCoordinator/TransitionPlanner architecture described by the old Code361 documentation.

Current runtime authority is the shipping path: MainActivity/LumiCoreService orchestration, LocalBrain + FastBrainProcessService for local inference, CloudBrainRouter for cloud policy/routing, WebResearchAgent for sourced web research, ConversationRuntimeState/TTS/STT for the live turn, and LumiPyramid3DView for the approved visual.

The approved visual transition remains six seconds. Code623 does not rewire the working Fast Brain/Cloud Brain stack.
