Lumi Code662 Nightly Fresh-Install Repair R372

Repairs driven by clean Code661 phone evidence:
- Fresh installs explicitly surface that secure Administrator enrollment must be completed after device-biometric recognition instead of leaving a confusing RECOGNIZED_NOT_ADMIN state with no recovery cue.
- Root authority remains closed until explicit secure enrollment. No biometric-to-root bypass is introduced.
- Lumi self-authority semantic contract truth is evaluated from the pure resolver at runtime instead of defaulting to FAIL before the first user turn.
- Existing Code661 Core authority, provider-adviser boundary, memory, audio, Bluetooth and diagnostics behavior remains intact.
