# Lumi Code661 Canonical Core Rebuild R371

## Baseline
Code661 may only be produced from the exact published Code660 package advertised by `lumi-release/.lumi/latest-update.json` when that pointer still names:

- targetVersionCode: 660
- targetVersionName: `5.0.0-lumi1-convergence-rc1-r370`
- package: `.lumi/updates/Lumi-Code660-Lumi1-Convergence-RC1-R370.zip`
- package SHA-256: `a109cf48e4da5c3f33b9d8a3df37b49f1c4250c4ee4ab8309fe37bf6fccc9515`
- Git blob SHA: `200985191c30985d357f4881be86e6fad78804bf`

Historical Code660 is never overwritten. The phone is not uninstalled as part of this build.

## One authority
The product-turn authority is Lumi Core. Providers, routers, local actions, memory, SelfAuthority, LivingSelf and the causal journal may classify, advise, execute, store or observe. They may not independently decide that a user goal is complete or author the final user-facing truth.

Authoritative flow:

`INPUT -> LUMI CORE -> INTENT/GOAL -> CAPABILITY TRUTH -> DELEGATE/EXECUTOR -> OUTCOME EVIDENCE -> LUMI CORE COMMIT -> VOICE`

Universal turn contract:

`UNDERSTAND -> CAN_I_DO_IT? -> HOW? -> EXECUTE/ASK_ADVISER -> VERIFY -> SPEAK`

External-model contract:

`LUMI CORE QUESTION -> EXTERNAL ADVISER -> [[LUMI_ADVICE_V1]] MATERIAL -> LUMI CORE RENDER/VERIFY/COMMIT -> VOICE`

The adviser envelope is internal only. It may never be spoken, stored as `last_lumi_reply`, or treated as proof that an action occurred.

## Required Code661 corrections

1. **General action understanding.** Modal/indirect commands are ACTION, including `Can you make that playlist?`, `Could you...`, `Would you...`, `I want you to...`, `I need you to...`. Contextual continuations such as `Then set it up`, `Do it`, `Proceed`, `Continue` inherit an open action goal when appropriate.
2. **No prose-only completion.** An ACTION cannot become SATISFIED from provider prose. Action completion requires executor evidence and, where required, outcome verification.
3. **Final reply authority.** Every provider/local candidate reply crosses one Core commit gate before becoming `last_lumi_reply` or being spoken.
4. **Provider adviser envelope.** Ordinary cloud replies and consensus/research results are source material for Lumi Core, never direct Lumi answers. All external-model successes are marked as adviser material; Core unwraps/renders/records the material before the common reply boundary. Consensus does not get a synthesis side door.
5. **Self intent is subordinate.** `LumiSelfIntentResolver` remains useful for self-directed requests, but ordinary external actions are not outside Core authority.
6. **Causal journal is observation only.** It records what happened but does not own decisions. Provider route/model may not be mislabeled as product-turn authority.
7. **Memory is data only.** Conversation memory may answer recall locally but does not become a second product-turn authority.
8. **Speaker continuity when PCM is unavailable.** For an already bound owner, zero raw PCM plus accepted near-field/transcript/liveness evidence is `IDENTITY_EVIDENCE_UNAVAILABLE_CONTINUITY_ALLOWED`, not an automatic speaker-handoff rejection. An unknown speaker with no PCM may not acquire/transfer identity automatically. Contradictory speaker evidence still rejects.
9. **Fault accounting separation.** Speaker/audio admission rejection is not a SpeechRecognizer engine failure and must not increment recognizer restart/circuit-break failure accounting.
10. **Single conversational state truth.** Core2/shadow state may observe and report disagreements, but may not overrule the authoritative runtime state. A valid admitted transcript must not remain RECOVERING solely because a shadow model disagrees.
11. **Acceptance arming.** Lumi 1.0 phone acceptance does not begin automatically at release initialization. It is explicitly armed for a test session. The frozen numeric gates remain unchanged.
12. **Car audio contract.** Connected communication-device selection is verified rather than assumed, and failure is explicit diagnostics rather than silent fallback.
13. **Voice quality truth.** Successful TTS is not equivalent to natural voice quality. Voice selection/profile evidence is reported separately.
14. **Diagnostics tell the same authority story as runtime.** Causal observations identify `LUMI_CORE` as authority and preserve provider/model details only as delegation evidence.

## Semantic release tests

- `Can you make that playlist?` => ACTION
- `Did you make the playlist?` after that action => ACTION status continuation
- `Then set it up` after the playlist request => ACTION continuation
- `Can you fix my truck?` => external ACTION, never SELF_REPAIR
- `Can you fix yourself?` => SELF_REPAIR under Core
- fact question => INFORMATION
- casual dialog => CONVERSATION
- inherited `You are Lumi` provider wording is not forwarded to cloud advisers
- provider output is wrapped as `[[LUMI_ADVICE_V1]]` material
- ordinary and consensus provider paths both return adviser material to Core
- no provider-produced candidate becomes final without Core commit
- ACTION cannot complete without action evidence
- only Core may commit the final reply
- only Core may mark the turn/goal satisfied

## Pre-publish validation wall

The exact reconstructed Code660 source and the canonical source extracted back out of the signed Code661 APK must both pass:

- 36 canonical-Core rebuild gates
- 28 hardening/adviser-boundary gates
- 4 causal-authority gates
- pure-Java intent/action-continuity tests
- pure-Java provider-adviser contract tests
- APK version/name and signing-certificate continuity checks

That is **68 static gates plus executable semantic tests** before publication can advance `lumi-release`.

## Frozen Lumi 1.0 installed-phone gates

1. 30 unassisted spoken replies over at least 10 minutes with zero watchdog/circuit/state-divergence/READY-deaf/stall defects; manual Listen resets the active acceptance window.
2. Durable user/Lumi turns, real post-restart reload proof, local recall proof.
3. Owner acceptance plus active speaker binding.
4. Three spoken interruptions that causally stop active TTS.
5. At least one actual Core Local Action executes.
6. At least 30 minutes without LOW_MEMORY exit.
7. Compact current-release Black Box 2, stable `.lumi/blackbox/current.txt`, automatic authenticated relay, no legacy executive-summary authority.

Build/sign/publish/install are deployment evidence only. They are never Lumi 1.0 acceptance.
